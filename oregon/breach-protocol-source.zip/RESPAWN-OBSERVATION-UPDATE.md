# Respawn, guest networking and observation update

The next-round start now clears old killcam/replay work, death presentation and observation state. It carries the authoritative round number and is sent reliably. The first spawn snapshot cannot be blocked by a previous result timeline, and older-round packets cannot restore a dead player. Host-side remote actors also receive the new round number.

## Reproduction and validation

The saved v11 implementation reproduced the bug on the original imported map: the guest remained at **round 1 / HP 0 / pending result / queued round-2 snapshot**. The candidate reaches **round 2 / HP 100 / no pending result or queued snapshot**.

A three-client test uses a 120 Hz host and 30/60 Hz guests through the local four-letter relay. Both defenders are actually killed, the result and replay complete, all players select and confirm again, and both eliminated guests respawn at 100 HP with observation off and responsive movement. This repeats through rounds 2 and 3, with deliberately stale result timing and late prior-round death snapshots. All 14 assertions pass.

Other passing suites: 6 full-map guest regression assertions, 17 observation/control/model assertions, 11 existing three-client kit/killcam/spectating assertions, 8 existing next-round assertions, and 8 full-map presentation assertions. TypeScript and production build pass. Relay CLI checks: 113 pass, including 100 ordered messages and 24 parallel rooms. Custom destruction: 7 pass.

An initial integration fixture used duplicate Vigils on the same team; the existing unique-operator rule correctly refused confirmation. The corrected fixture uses legal distinct defenders and waits for the actual authoritative spawn snapshot.

## Guest lag changes

- Replay traffic is paced to one 12 KB payload per peer per 50 ms. Control packets take priority, obsolete replay queues are discarded at a new round, and asynchronous old replay work is invalidated.
- The final elimination no longer adds a duplicate personal killcam transfer after the round has ended; the round replay supplies that presentation.
- Guests coalesce snapshot bursts before simulation. A 20-snapshot burst applies only the newest state: 1 application, 19 coalesced snapshots.
- Unchanged panel state skips repeated material/geometry work. Across 30 unchanged full-map snapshots, damage applications fall from 1,230 to 0. Destruction, repairs/reset and resynchronization keep their existing behavior.

These results demonstrate bounded bursts and less redundant work, not an FPS or latency guarantee on friends' computers. The small two-player snapshot CPU profile measured approximately 0.1 ms median / 0.2 ms p95 for both versions; no meaningful measured CPU-time speedup is claimed. Zero aiming recoil and the 240 FPS option are preserved.

## Observation

With a feed open, Q selects the previous available tool and E the next, wrapping in both directions. This works alive and dead. Normal leaning remains available outside observation. Available allied human/bot drones, static defender cameras and allied bulletproof cameras are included according to the team. Destroyed/stowed drones and destroyed/disabled cameras are skipped. The old held-Q/E drone-yaw behavior is removed. Mouse looking and driving remain. Pending feed switches survive old snapshots until their ordered command acknowledgement arrives. The feed HUD displays the configured cycling keys.

## Drone model

An original two-wheel reconnaissance model replaces the four-wheel box: cylindrical chassis, angled tread rollers, hubs/axles, camera/lens, indicator, rear stabilizer and wheel animation tied to actual travel/turning. It fits the existing gameplay clearance: approximately 0.272 x 0.141 x 0.206 m, 9 batched meshes, 1,184 triangles. No proprietary model or texture was extracted.

Visual inspiration: Ubisoft's [Tools of Attack drone concept](https://www.ubisoft.com/en-us/game/rainbow-six/siege/news-updates/1qBe9DIHhdmclzHegvNZi2/behind-the-wall-series-tools-of-attack) and [official two-wheel drone coverage](https://news.ubisoft.com/en-us/article/1bWDKjR3rOmpf736SMY400/rainbow-six-siege-wasteland-circuit-race-drones-today). The early concept is not a current production-model measurement. This is an original Siege-style interpretation, not an exact asset replica.

## Scope and artifacts

Five existing source files changed: game, session, lobby, main and drone. One new drone-model module was added. Map assets, menu/loadout choices and custom destruction rules remain unchanged. The compatibility suffix is round-v12: host and guests must refresh together.

Results: Three-Player-Respawn.json, Respawn-Cost-Checks.json, Observation-Checks.json, Kit-Network-Regression.json, Existing-Round-Network.json, Full-Map-Regression.json and Drone-Preview.png. The source ZIP includes the saved v11 baseline and reproducible round-v12 fixtures.

The home relay health endpoint responded. The localhost-origin public-relay test was rejected; the service allows the real GitHub Pages and home-service origins. No access policy was weakened.

Two clients then connected from the actual public GitHub Pages site using a four-letter lobby code. Both appeared connected, chose locations and loadouts, completed the synchronized three-second countdown and reached the same live round at 100 HP with no browser errors. This public smoke test is separate from the controlled three-client repeated-elimination test. It does not establish cross-device FPS or latency. Results are in Public-Lobby-Smoke.json and Published-Connected-Lobby.png.

Final presentation cleanup corrects the observation hint's text encoding and clears a stale Connected status after leaving a lobby. All changed source files validate as UTF-8. The core respawn/network behavior is unchanged by that cleanup.

# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

Existing TypeScript, Vite and Three.js application; native HTML controls and CSS.

## Product Purpose

Breach Protocol is a private browser tactical shooter on Oregon. Players choose an operator and legal loadout, prepare, attack or defend bomb sites, and play until a team wins three rounds.

## Operating Context

The user tests in Brave on a high-end PC with normal settings. The requested interface must also support common desktop and Chromebook screen sizes. Private multiplayer uses generated four-letter codes, visible connected-player rosters and a home-PC WebSocket room service. The browser host stays connected and remains authoritative for gameplay. GitHub Pages serves the game files and uses a separately configured secure lobby endpoint. Offline play can include bots.

## Capabilities and Constraints

Preserve operator eligibility, weapon/optic/skin customization, all match rules, controls, settings, pause, results, field guide, objectives, destruction, traversal, drones and multiplayer. Operator selection shows legal equipment, availability, time and readiness. All connected players confirming valid selections triggers preparation immediately. Performance and source limitations belong in optional diagnostics. No movement or simulation reductions to improve performance.

## Brand Commitments

Existing product name: Breach Protocol. Map: Oregon. The user requests a completely redesigned, consistent and readable interface, with Play emphasized and Host Lobby, Join Lobby, Loadout and Settings easy to find. Visual-world preferences remain optional until answered.

## Evidence on Hand

The explicit three-stage request is retained in verification/stages/new-three-stage-goal-october10/review.md. Runtime implementation and verification/stages contain actual workflows, measurements and reference screenshots. Exact Siege/Y9S4 fidelity is unverified; no marketing or compatibility claims should be invented.

## Product Principles

- Preserve functional gameplay and every visible control.
- Make selection, legal equipment and the next phase apparent.
- Keep diagnostics separate from the player's main task.
- Keep menu rendering and motion inexpensive.

The user confirmed on October 11, 2026: all-dark interface; build directly in code. This supersedes the light workspace assumption from the prior delivery.

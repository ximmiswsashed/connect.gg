from pathlib import Path
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import json,gzip,hashlib,urllib.request
w=Path('C:/Users/cruzi/Documents/Codex/2026-10-16/fi/work');out=Path('C:/Users/cruzi/Documents/Codex/2026-10-16/fi/outputs/Breach-Protocol-Loading');web=out/'website-patch/oregon';(web/'packs').mkdir(parents=True,exist_ok=True);cache=w/'original-map-packs';cache.mkdir(exist_ok=True)
original=json.loads((w/'asset-packs-current.json').read_text(encoding='utf-8'));groups=defaultdict(list)
for key,entry in original['files'].items():groups[entry['pack']].append((key,entry))
def download(name):
 p=cache/Path(name).name
 if not p.exists():
  with urllib.request.urlopen('https://ximmiswsashed.github.io/connect.gg/oregon/'+name,timeout=60) as response:data=response.read()
  p.write_bytes(data)
 return name,p.read_bytes()
with ThreadPoolExecutor(max_workers=5) as pool:buffers=dict(pool.map(download,groups))
metadata={};files={};pack_sizes={};verified=0;new_bytes=0
for name,entries in groups.items():
 raw=buffers[name];changed=any(key.endswith('.json') for key,_ in entries);parts=[];offset=0
 for key,entry in sorted(entries,key=lambda v:v[1]['offset']):
  data=raw[entry['offset']:entry['offset']+entry['length']];assert len(data)==entry['length'];verified+=1
  if key.endswith('.json'):
   text=data.decode('utf-8');json.loads(text);metadata[key]=text;continue
  if changed:
   files[key]={'pack':'pending','offset':offset,'length':len(data),'type':entry['type']};parts.append((key,data));offset+=len(data)
  else:files[key]=entry
 if changed and parts:
  packed=b''.join(data for _,data in parts);digest=hashlib.sha256(packed).hexdigest()[:12];target='packs/map-fast-'+Path(name).name.split('-')[1]+'-'+digest+'.bin';(web/target).write_bytes(packed);new_bytes+=len(packed);pack_sizes[target]=len(packed)
  for key,_ in parts:files[key]['pack']=target
 elif not changed:pack_sizes[name]=len(raw)
meta_raw=json.dumps({'version':1,'files':metadata},ensure_ascii=False,separators=(',',':')).encode();meta_gz=gzip.compress(meta_raw,compresslevel=9,mtime=0);meta_name='packs/map-metadata-'+hashlib.sha256(meta_gz).hexdigest()[:12]+'.json.gz';(web/meta_name).write_bytes(meta_gz)
for key in metadata:files[key]={'metadata':meta_name,'type':'application/json'}
manifest={'version':2,'files':files,'packSizes':pack_sizes};encoded=json.dumps(manifest,separators=(',',':')).encode();index_name='asset-packs-v2-'+hashlib.sha256(encoded).hexdigest()[:12]+'.json';(web/index_name).write_bytes(encoded)
# Prove every repacked asset is byte-identical, including metadata and the unchanged packs.
for key,new in files.items():
 old=original['files'][key];a=buffers[old['pack']][old['offset']:old['offset']+old['length']]
 if 'metadata' in new:b=metadata[key].encode('utf-8')
 else:
  p=web/new['pack'];blob=p.read_bytes() if p.exists() else buffers[new['pack']];b=blob[new['offset']:new['offset']+new['length']]
 assert a==b,key
total_before=sum(len(v) for v in buffers.values());total_after=sum(pack_sizes.values())+len(meta_gz)
report={'originalPayloadBytes':total_before,'optimizedPayloadBytes':total_after,'savedBytes':total_before-total_after,'savedPercent':(1-total_after/total_before)*100,'metadataFiles':len(metadata),'originalMetadataBytes':sum(len(v.encode('utf-8')) for v in metadata.values()),'compressedMetadataBytes':len(meta_gz),'byteIdenticalAssets':verified,'newPackBytesToPublish':new_bytes+len(meta_gz),'manifest':index_name,'metadataPack':meta_name}
(out/'Asset-Pack-Verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))

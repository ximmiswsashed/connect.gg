import {operatorFirearm} from './operator-firearms';
import {catalogFirearm} from './catalog-firearms';
import {r4cModel} from './r4c-model';
import * as THREE from 'three';import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';import {finishMaterial,paintUV} from './cosmetics';
const polymer=new THREE.MeshLambertMaterial({color:0x2f3735}),hardware=new THREE.MeshLambertMaterial({color:0x687073});polymer.userData.shared=hardware.userData.shared=true;
const sightGreen=new THREE.MeshBasicMaterial({color:0x4bdd62});sightGreen.userData.shared=true;
// Original procedural models. Profiles distinguish the AR receiver, SIG receiver, roller SMG,
// compact machine pistol, pump shotgun and USP-style slide/frame. See WEAPON_REFERENCES.md.
export function firearmModel(weapon:number,finish:unknown='Factory'){
 if(weapon>=18)return operatorFirearm(weapon,finish);if(weapon>=6)return catalogFirearm(weapon,finish);if(weapon===0)return r4cModel(finish);const root=new THREE.Group(),paint=finishMaterial(finish),parts=new Map<THREE.Material,THREE.BufferGeometry[]>(),magParts=new Map<THREE.Material,THREE.BufferGeometry[]>(),pumpParts=new Map<THREE.Material,THREE.BufferGeometry[]>();let magazinePart=false,pumpPart=false;
 const add=(g:THREE.BufferGeometry,m:THREE.Material=paint)=>{if(g.index){const indexed=g;g=g.toNonIndexed();indexed.dispose();}const target=magazinePart?magParts:pumpPart?pumpParts:parts,list=target.get(m)??[];list.push(g);target.set(m,list);};
 const box=(x:number,y:number,z:number,w:number,h:number,d:number,m:THREE.Material=paint)=>add(new THREE.BoxGeometry(w,h,d).translate(x,y,z),m);
 const tube=(x:number,y:number,z:number,r:number,length:number,m:THREE.Material=hardware)=>{const g=new THREE.CylinderGeometry(r,r,length,12);g.rotateX(Math.PI/2);g.translate(x,y,z);add(g,m);};
 const profile=(points:number[][],width:number,m:THREE.Material=paint)=>{const shape=new THREE.Shape();points.forEach(([z,y],i)=>i?shape.lineTo(z,y):shape.moveTo(z,y));shape.closePath();const bevel=[1,2,3,4,5].includes(weapon)?.001:.004;const geo=new THREE.ExtrudeGeometry(shape,{depth:width,bevelEnabled:true,bevelThickness:bevel,bevelSize:bevel,bevelSegments:1,steps:1});geo.rotateY(-Math.PI/2);geo.translate(width/2,0,0);add(geo,m);};
 if(weapon===5){
  // USP9-sized stylized profile: 194 mm long, 136 mm tall, 32 mm frame width.
  // HK USP operator's manual dimensions; the project's custom 12/60 ammo is independent.
  profile([[-.124,.010],[-.121,.029],[.061,.029],[.067,.016],[.063,-.002],[-.123,-.002]],.027);
  profile([[-.112,-.004],[.061,-.004],[.062,-.024],[.050,-.096],[.011,-.094],[-.007,-.024],[-.111,-.020]],.029,polymer);
  tube(0,.014,-.124,.006,.004);tube(0,-.011,-.115,.004,.012);
  box(0,.034,-.114,.0035,.006,.005,hardware);
  // Rear notch is open: two shoulders frame the front post at the same 37 mm sight line.
  for(const x of [-.005,.005])box(x,.0335,.046,.005,.007,.006,hardware);
  box(0,.031,.046,.013,.002,.006,hardware);
  for(const x of [-.005,.005])box(x,.035,.04915,.0015,.0015,.0003,sightGreen);
  box(0,.0362,-.11135,.0015,.0015,.0003,sightGreen);
  // Open trigger guard, not a solid slab filling the trigger space.
  for(const x of [-.010,.010]){box(x,-.028,-.046,.003,.020,.006,polymer);box(x,-.040,-.025,.003,.004,.041,polymer);}
  profile([[-.008,-.015],[-.011,-.025],[-.022,-.033],[-.021,-.037],[-.007,-.029],[-.004,-.016]],.004,hardware);
  box(.0145,.004,.020,.003,.006,.024,hardware);
  for(let i=0;i<7;i++)for(const x of [-.014,.014])box(x,.013,.018+i*.005,.0015,.017,.0015,hardware);
  magazinePart=true;box(0,-.076,.029,.022,.047,.030,hardware);box(0,-.098,.032,.032,.002,.039,polymer);magazinePart=false;
 }else if(weapon===4){
  // Siege's triangular stock corresponds to an extended PDW profile, not stockless MP5K.
  // HK 2025 brochure: extended length 600 mm. Geometry remains an original low-poly model.
  tube(0,.018,-.052,.021,.260);box(0,-.011,-.038,.036,.028,.220);
  profile([[.047,-.024],[.090,-.025],[.081,-.139],[.038,-.143],[.035,-.071]],.028,polymer);
  box(0,-.012,-.184,.043,.054,.066,polymer);tube(0,.018,-.223,.010,.034);
  profile([[-.212,-.025],[-.173,-.025],[-.177,-.130],[-.205,-.130]],.026,polymer);
  for(let i=0;i<5;i++)box(0,-.049-i*.014,-.193,.030,.003,.040,hardware);
  // Open trigger guard beside the magazine well.
  for(const x of [-.012,.012]){box(x,-.042,.012,.004,.033,.005,polymer);box(x,-.059,.031,.004,.004,.044,polymer);}
  box(0,-.039,.044,.006,.030,.005,hardware);
  box(-.025,.030,-.140,.010,.010,.035,hardware);box(.022,-.016,.033,.006,.010,.030,hardware);
  // Skeletal stock with a real opening; no filled triangle hidden beneath the outline.
  const stock=new THREE.Shape();stock.moveTo(.084,.020);stock.lineTo(.340,.020);stock.lineTo(.350,-.108);stock.lineTo(.323,-.106);stock.lineTo(.087,-.007);stock.closePath();
  const opening=new THREE.Path();opening.moveTo(.133,.005);opening.lineTo(.326,.005);opening.lineTo(.328,-.079);opening.lineTo(.135,-.004);opening.closePath();stock.holes.push(opening);
  const stockGeo=new THREE.ExtrudeGeometry(stock,{depth:.014,bevelEnabled:false});stockGeo.rotateY(-Math.PI/2);stockGeo.translate(.007,0,0);add(stockGeo,polymer);box(0,-.044,.354,.034,.130,.012,polymer);
  // Hooded front post through the open rear notch seen in the game reference.
  const hood=new THREE.TorusGeometry(.011,.002,6,16);hood.translate(0,.050,-.217);add(hood,hardware);
  box(0,.041,-.217,.003,.018,.004,hardware);
  box(0,.032,.043,.054,.008,.016,hardware);for(const x of [-.021,.021])box(x,.0485,.043,.012,.029,.016,hardware);
  for(const x of [-.018,.018])box(x,.050,.05115,.0035,.0015,.0003,sightGreen);
  box(0,.0492,-.21485,.0015,.0015,.0003,sightGreen);
  magazinePart=true;for(let i=0;i<5;i++){const y=-.047-i*.025,z=-.071-i*i*.0018;box(0,y,z,.025,.029,.045,paint);for(const x of [-.0135,.0135])box(x,y,z,.0015,.023,.030,hardware);}box(0,-.163,-.100,.031,.008,.047,polymer);magazinePart=false;
  // Picatinny adapter is physically seated on the MP5K receiver.
 box(0,.051,-.03,.032,.024,.17,hardware);
 }else if(weapon===1){
  // 18.5-inch barrel / 39.5-inch overall conventional-stock envelope (Mossberg 50774).
  profile([[-.110,.041],[.116,.041],[.145,.020],[.130,-.020],[-.108,-.020]],.044);
  // Underside loading port: side walls and end bridges leave a real central opening.
  for(const x of [-.0185,.0185])box(x,-.031,.010,.007,.022,.236);
  box(0,-.031,-.071,.030,.022,.080);box(0,-.031,.089,.030,.022,.074);
  tube(0,.025,-.345,.013,.470);tube(0,-.003,-.345,.0115,.460);
  pumpPart=true;box(0,-.020,-.275,.048,.050,.150,polymer);for(let i=0;i<9;i++)box(0,-.020,-.340+i*.016,.052,.052,.004,hardware);pumpPart=false;
  profile([[.133,.010],[.223,-.008],[.238,-.044],[.210,-.064],[.150,-.047]],.032,polymer);
  profile([[.210,-.017],[.400,-.025],[.412,-.057],[.409,-.127],[.341,-.130],[.214,-.066]],.044,polymer);box(0,-.077,.4173,.048,.130,.012,hardware);
  for(const x of [-.013,.013]){box(x,-.058,.084,.004,.032,.005,hardware);box(x,-.076,.115,.004,.004,.063,hardware);}box(0,-.052,.124,.005,.027,.006,hardware);
  box(.023,.016,.018,.002,.022,.060,hardware);
  // Siege silhouette: receiver rail, rear ghost ring and protected front post.
  box(0,.046,.092,.023,.008,.049,hardware);for(let i=0;i<5;i++)box(0,.052,.071+i*.009,.026,.003,.003,hardware);
  const ghost=new THREE.TorusGeometry(.0075,.0015,6,16);ghost.translate(0,.057,.105);add(ghost,hardware);
  for(const x of [-.0075,.0075])box(x,.057,.10665,.0015,.0015,.0003,sightGreen);
  box(0,.0562,-.55335,.0015,.0015,.0003,sightGreen);
  box(0,.049,-.556,.003,.016,.005,hardware);for(const x of [-.009,.009])box(x,.055,-.556,.003,.018,.009,hardware);
  for(const x of [-.0155,.0155])box(x,.006,-.525,.003,.057,.011,hardware);
  root.userData.loadingPort=[0,-.041,.013];
 }else if(weapon===3){
  // SIG's 2014 catalog: standard 556xi 35.8-inch extended envelope, 16-inch barrel.
  // Cross sections and low-poly details are stylized; Ubisoft silhouette informs the stock/rail.
  profile([[-.166,.043],[.107,.043],[.132,.012],[.119,-.030],[-.157,-.030]],.046);
  box(0,-.025,-.057,.040,.035,.155,polymer);
  profile([[.047,-.025],[.090,-.028],[.081,-.139],[.038,-.143],[.035,-.071]],.028,polymer);
  // Open trigger guard and separate trigger: no filled slab between magazine and grip.
  for(const x of [-.012,.012]){box(x,-.048,.007,.004,.037,.005,polymer);box(x,-.067,.027,.004,.004,.044,polymer);}
  box(0,-.047,.042,.005,.029,.005,hardware);
  // Hollow handguard sleeve with real side vent gaps, continuous top/bottom rails.
  box(0,.039,-.302,.052,.014,.242);box(0,-.028,-.302,.050,.014,.242,polymer);
  for(const x of [-.024,.024]){box(x,.006,-.302,.004,.025,.242);for(let i=0;i<7;i++)box(x,.023,-.414+i*.034,.004,.023,.012);}
  tube(0,.012,-.2968,.009,.4064);tube(0,.012,-.487,.012,.026);
  box(0,.048,-.132,.032,.008,.566,hardware);for(let i=0;i<39;i++)box(0,.055,-.411+i*.014,.036,.005,.005,hardware);
  // Swiss-style stock has an actual triangular opening.
  const stock=new THREE.Shape();stock.moveTo(.114,.016);stock.lineTo(.389,.018);stock.lineTo(.401,-.126);stock.lineTo(.375,-.131);stock.lineTo(.116,-.019);stock.closePath();
  const opening=new THREE.Path();opening.moveTo(.173,.002);opening.lineTo(.372,.003);opening.lineTo(.378,-.100);opening.lineTo(.176,-.010);opening.closePath();stock.holes.push(opening);
  const geo=new THREE.ExtrudeGeometry(stock,{depth:.026,bevelEnabled:false});geo.rotateY(-Math.PI/2);geo.translate(.013,0,0);add(geo,polymer);box(0,-.0565,.40332,.043,.151,.012,polymer);
  // Flip-up rear aperture and front post share the 70 mm central sight axis.
  box(0,.059,.091,.020,.007,.018,hardware);const rear=new THREE.TorusGeometry(.006,.0015,6,16);rear.translate(0,.070,.091);add(rear,hardware);
  box(0,.062,-.404,.003,.016,.005,hardware);for(const x of [-.008,.008])box(x,.068,-.404,.003,.018,.008,hardware);
  for(const x of [-.006,.006])box(x,.070,.09265,.0025,.0015,.0003,sightGreen);
  box(0,.0692,-.40135,.0015,.0015,.0003,sightGreen);
  box(.025,.014,.030,.004,.018,.048,hardware);box(-.027,.019,-.026,.008,.009,.022,hardware);box(.021,-.036,.071,.004,.009,.018,hardware);
  magazinePart=true;
  profile([[-.089,-.042],[-.035,-.042],[-.041,-.111],[-.068,-.161],[-.110,-.202],[-.160,-.187],[-.114,-.136],[-.091,-.100]],.026);
  for(const x of [-.0145,.0145])for(let i=0;i<3;i++)profile([[-.083-i*.012,-.060],[-.079-i*.012,-.106],[-.096-i*.012,-.147],[-.122-i*.012,-.177],[-.126-i*.012,-.175],[-.100-i*.012,-.143],[-.083-i*.012,-.103]],.0015,hardware);
  magazinePart=false;
 }else if(weapon===2){
  // Fictional SMG-12: scale estimate from an adult grip and Ubisoft's loadout silhouette.
  // 550 mm extended envelope is an artistic target, not a manufacturer measurement.
  profile([[-.116,.035],[.077,.035],[.093,.019],[.083,-.018],[-.116,-.018]],.036);
  box(0,-.017,-.027,.031,.015,.140,polymer);
  const grip=new THREE.Shape();[[.015,-.024],[.058,-.025],[.049,-.139],[.006,-.143],[.003,-.071]].forEach(([z,y],i)=>i?grip.lineTo(z,y):grip.moveTo(z,y));grip.closePath();
  // Side cheeks and fore/aft straps leave a 20 x 29 mm removable-magazine channel.
  for(const x of [-.013,.013]){const g=new THREE.ExtrudeGeometry(grip,{depth:.005,bevelEnabled:false});g.rotateY(-Math.PI/2);g.translate(x+.0025,0,0);add(g,polymer);}
  box(0,-.082,.004,.021,.119,.006,polymer);box(0,-.082,.050,.021,.112,.008,polymer);
  // The removable straight magazine runs through the hollow grip, not a rifle-style forward well.
  for(const x of [-.012,.012]){box(x,-.044,-.025,.004,.036,.005,polymer);box(x,-.063,-.006,.004,.004,.044,polymer);}
  box(0,-.042,.010,.005,.029,.005,hardware);
  // Integrated front shroud with longitudinal port gaps and exposed muzzle face.
  tube(0,.010,-.171,.012,.158);box(0,.026,-.168,.043,.011,.154);box(0,-.016,-.168,.043,.012,.154,polymer);
  for(const x of [-.020,.020]){box(x,.006,-.168,.003,.014,.154);for(let i=0;i<6;i++)box(x,.018,-.237+i*.026,.003,.016,.010,hardware);}
  tube(0,.010,-.245,.015,.010);box(0,.039,-.024,.027,.007,.196,hardware);for(let i=0;i<15;i++)box(0,.044,-.111+i*.013,.031,.004,.005,hardware);
  // Thin canted wire stock; no solid slab fills the space behind the receiver.
  for(const x of [-.011,.011]){profile([[.082,-.004],[.291,-.052],[.291,-.061],[.082,-.013]],.005,hardware);parts.get(hardware)!.at(-1)!.translate(x,0,0);}
  box(0,-.060,.295,.033,.085,.010,polymer);box(0,-.008,.092,.039,.024,.023,hardware);
  // Open rear notch and front post at the 53 mm sight line.
  for(const x of [-.0045,.0045])box(x,.049,.053,.004,.008,.006,hardware);box(0,.044,.053,.013,.003,.006,hardware);
  box(0,.046,-.112,.003,.014,.006,hardware);for(const x of [-.007,.007])box(x,.051,-.112,.0025,.016,.007,hardware);
  for(const x of [-.0045,.0045])box(x,.051,.05615,.0015,.0015,.0003,sightGreen);
  box(0,.0522,-.10885,.0015,.0015,.0003,sightGreen);
  box(.020,.018,.015,.004,.013,.037,hardware);box(-.023,.028,-.010,.010,.007,.019,hardware);
  magazinePart=true;box(0,-.116,.025,.020,.162,.029,hardware);box(0,-.200,.024,.029,.006,.036,polymer);for(let i=0;i<4;i++)for(const x of [-.0105,.0105])box(x,-.152-i*.012,.025,.001,.002,.028,paint);magazinePart=false;
 }

 const pump=new THREE.Group();for(const [m,geos] of pumpParts){const geometry=mergeGeometries(geos);if(geometry)pump.add(new THREE.Mesh(geometry,m));geos.forEach(g=>g.dispose());}if(pump.children.length){root.add(pump);root.userData.pump=pump;}
 const magazine=new THREE.Group();magazine.position.set(0,-.12,0);for(const [m,geos] of magParts){const geometry=mergeGeometries(geos);if(geometry){geometry.translate(0,.12,0);magazine.add(new THREE.Mesh(geometry,m));}geos.forEach(g=>g.dispose());}if(magazine.children.length){root.add(magazine);root.userData.magazine=magazine;}
 for(const [m,geos] of parts){const geometry=mergeGeometries(geos);if(geometry){if(m.userData.finish)paintUV(geometry);const mesh=new THREE.Mesh(geometry,m);mesh.userData.dynamic=true;root.add(mesh);}geos.forEach(g=>g.dispose());}root.userData.weapon=weapon;root.userData.finish=finish;return root;
}
export function disposeFirearm(root:THREE.Group){root.userData.disposed=true;root.traverse(o=>{if(o instanceof THREE.Mesh&&!o.userData.sharedGeometry)o.geometry.dispose();if(o instanceof THREE.Mesh||o instanceof THREE.Sprite){const material=o.material as THREE.Material;if(!material.userData.shared){if(o instanceof THREE.Sprite)(material as THREE.SpriteMaterial).map?.dispose();material.dispose();}}});}

import * as THREE from 'three';
/** Cosmetic phases share authoritative normalized action progress; no gameplay timers here. */
export function installationPose(progress:number,reinforce:boolean,hatch:boolean){
 const p=THREE.MathUtils.clamp(progress,0,1),ease=(a:number,b:number)=>THREE.MathUtils.smoothstep(p,a,b);
 const present=ease(0,.16),recover=ease(.90,1),unfold=ease(.16,.48),fasten=ease(.48,.89);
 const cycle=THREE.MathUtils.clamp((p-.48)/.41,0,.99999)*(reinforce?6:8),stroke=p>=.48&&p<.89?Math.sin((cycle%1)*Math.PI)**6:0;
 const beat=Math.floor(cycle),between=THREE.MathUtils.smoothstep(cycle%1,.68,1),next=Math.min((reinforce?6:8)-1,beat+1),travel=reinforce?THREE.MathUtils.lerp(beat,next,between)/5:THREE.MathUtils.lerp(Math.floor(beat/2),Math.floor(next/2),between)/3;
 const toolX=reinforce?.21:THREE.MathUtils.lerp(beat%2?-.20:.20,next%2?-.20:.20,between);
 return {position:new THREE.Vector3(0,-.25*(1-present)-.30*recover+(hatch?-.10:.04),-.08+.2*(1-present)+.12*recover),
 rotation:new THREE.Euler(hatch?-.65:.14,0,(1-present)*-.55+recover*.35),
 panelScale:new THREE.Vector3(1,reinforce?THREE.MathUtils.lerp(.35,3,unfold):1,1),
 left:new THREE.Vector3(-.25,.04+.03*unfold-.06*fasten,-.43),
 right:new THREE.Vector3(toolX,.14-.30*travel+stroke*.018,-.39-stroke*.07),
 stroke,unfold,fasten,recover};
}
export const installationBeats=(reinforce:boolean)=>[.08,.22,.36,...Array.from({length:reinforce?6:8},(_,i)=>.48+(i+.5)*.41/(reinforce?6:8)),.94];

export const bindingLabel=(code:string)=>({Mouse0:'Left mouse',Mouse1:'Middle mouse',Mouse2:'Right mouse',Mouse3:'Mouse back',Mouse4:'Mouse forward',Unbound:'Unbound'}[code]??code.replace('Key','').replace('Digit','').replace('Left','').replace('Control','CTRL').replace('Shift','SHIFT').replace('Alt','ALT'));
export const actionLabel=(action:string)=>action==='aim'?'Aim / ADS':action==='fire'?'Fire':action.replace(/([A-Z])/g,' $1').replace(/^./,c=>c.toUpperCase());
export function rebind(bindings:Record<string,string>,action:string,code:string){
 const previous=bindings[action],conflicts=Object.keys(bindings).filter(a=>a!==action&&bindings[a]===code);
 for(const other of conflicts)bindings[other]=previous;
 bindings[action]=code;
 return actionLabel(action)+' assigned to '+bindingLabel(code)+(conflicts.length?'; swapped with '+conflicts.map(actionLabel).join(', ')+'.':'.');
}
export function bindable(code:string){return /^Mouse[0-4]$/.test(code)||(/^(Key[A-Z]|Digit[0-9]|Numpad\w+|Arrow\w+|Shift(Left|Right)|Control(Left|Right)|Alt(Left|Right)|Space|Tab|Enter|Backspace|Delete|Insert|Home|End|Page(Up|Down)|CapsLock|Backquote|Minus|Equal|Bracket(Left|Right)|Backslash|Semicolon|Quote|Comma|Period|Slash|F([1-7]|9|10|11|12))$/.test(code));}

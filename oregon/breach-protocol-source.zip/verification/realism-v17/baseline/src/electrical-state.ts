import type {Vector3} from 'three';
export const electrifiedPositions=new WeakSet<Vector3>();

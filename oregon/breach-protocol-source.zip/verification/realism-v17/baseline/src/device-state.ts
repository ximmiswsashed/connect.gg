import type {Device} from './game';
export const ensureDeviceId=(d:Device):string=>d.mesh.userData.id??=crypto.randomUUID();
export function destroyDevice(d:Device){if(!d.mesh.visible)return false;d.mesh.visible=false;d.active=false;d.flightVelocity=undefined;d.mesh.userData.destroyed=true;return true;}
export const electronicTypes=new Set(['jammer','battery','grzmot','selma','charge','utility:camera','utility:alarm','utility:claymore','utility:nitro','utility:breach']);
export const electronicBreacher=(d:Device)=>['charge','selma','utility:breach'].includes(d.type);

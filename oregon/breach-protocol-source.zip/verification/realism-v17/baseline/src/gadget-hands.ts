import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
export const chargeGrip=(side:number)=>new THREE.Vector3(side*.18,-.045,.04);
export const chargeWrist=(side:number)=>new THREE.Vector3(side*.06,-.035,.055);
export function chargeHand(side:number,sleeve=true){
 const root=new THREE.Group(),parts:THREE.BufferGeometry[]=[];const add=(g:THREE.BufferGeometry)=>{parts.push(g.toNonIndexed());g.dispose();};
 const link=(a:number[],b:number[],r:number)=>{const from=new THREE.Vector3(...a),to=new THREE.Vector3(...b),delta=to.clone().sub(from),g=new THREE.CapsuleGeometry(r,delta.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()));g.translate(...from.add(to).multiplyScalar(.5).toArray());add(g);};
 const palm=new THREE.SphereGeometry(1,8,6);palm.scale(.011,.032,.027);add(palm);
 for(const y of [.021,.005,-.011,-.026]){link([0,y,.014],[-side*.035,y,.023],.006);link([-side*.035,y,.023],[-side*.035,y,.006],.005);}
 link([-side*.006,.027,-.008],[-side*.028,.052,.012],.008);link([-side*.028,.052,.012],[-side*.04,.049,.036],.006);
 link([side*.009,-.024,.018],chargeWrist(side).toArray(),.019);
 const geometry=mergeGeometries(parts)!;parts.forEach(g=>g.dispose());root.add(new THREE.Mesh(geometry,new THREE.MeshLambertMaterial({color:0x30392f})));
 if(sleeve){const from=chargeWrist(side),to=from.clone().add(new THREE.Vector3(side*.09,-.10,.18)),delta=to.clone().sub(from),g=new THREE.CapsuleGeometry(.03,delta.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()));g.translate(...from.add(to).multiplyScalar(.5).toArray());root.add(new THREE.Mesh(g,new THREE.MeshLambertMaterial({color:0x526048})));}
 return root;
}
export function chargeHoldPose(progress:number,stanceAmount=0){const p=THREE.MathUtils.clamp(progress,0,1),smooth=(a:number,b:number)=>THREE.MathUtils.smoothstep(p,a,b),hold=smooth(0,.12)*(1-smooth(.92,1)),lower=.25*(1-.75*THREE.MathUtils.clamp(stanceAmount-1,0,1))*(1-hold),peel=smooth(.14,.28)*(1-smooth(.34,.44)),press=smooth(.46,.54)*(1-smooth(.80,.90));return {position:new THREE.Vector3(-.14,.09-lower,-.03-.025*press),rotation:new THREE.Euler(-.25*(1-hold)+.04*press,0,.04*peel),leftOffset:new THREE.Vector3(-.06*peel,.09*peel+.015*press,-.025*press),rightOffset:new THREE.Vector3(0,.012*press,-.025*press)};}

export const chargeCarryPosition=new THREE.Vector3(.14,-.14,-.45);
export function chargeWorldPose(eye:THREE.Vector3,camera:THREE.Quaternion,progress:number,stanceAmount=0){const pose=chargeHoldPose(progress,stanceAmount);return {position:pose.position.add(chargeCarryPosition).applyQuaternion(camera).add(eye),quaternion:camera.clone().multiply(new THREE.Quaternion().setFromEuler(pose.rotation))};}
export function chargeRecoveryPose(eye:THREE.Vector3,target:THREE.Vector3,progress:number){const facing=new THREE.Object3D();facing.position.copy(target);facing.lookAt(eye);const start=eye.clone().addScaledVector(target.clone().sub(eye).normalize(),.45).add(new THREE.Vector3(0,-.2,0));return {position:start.lerp(target,THREE.MathUtils.smoothstep(progress,0,.65)),quaternion:facing.quaternion};}
export const canisterGrip=(side:number)=>new THREE.Vector3(side*.136,-.015,0);
export const canisterWrist=(side:number)=>new THREE.Vector3(side*.055,-.045,.085);
export function canisterHand(side:number,sleeve=true){
 const root=new THREE.Group();
 const shape=(open:boolean)=>{
  const parts:THREE.BufferGeometry[]=[];
  const add=(g:THREE.BufferGeometry)=>{parts.push(g.toNonIndexed());g.dispose();};
  const link=(a:THREE.Vector3,b:THREE.Vector3,r:number)=>{const delta=b.clone().sub(a),g=new THREE.CapsuleGeometry(r,delta.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()));g.translate(...a.clone().add(b).multiplyScalar(.5).toArray());add(g);};
  const palm=new THREE.SphereGeometry(1,8,6);palm.scale(.017,.037,.030);add(palm);
  for(const y of [.05,.025,0,-.027]){
   const points=open?[[.136,y,.015],[.136,y,-.035],[.136,y,-.08],[.136,y,-.125]]:[[.136,y,.015],[.113,y,-.046],[.07,y,-.10],[.018,y,-.121]];
   const v=points.map(p=>{const radial=new THREE.Vector2(p[0],p[2]).normalize().multiplyScalar(.003);return new THREE.Vector3(side*(p[0]+radial.x),p[1],p[2]+radial.y).sub(canisterGrip(side));});
   for(let i=1;i<v.length;i++)link(v[i-1],v[i],.0085);
  }
  const thumb=[new THREE.Vector3(0,.035,.014),new THREE.Vector3(-side*.021,.066,.053),new THREE.Vector3(-side*.052,.055,.088)];link(thumb[0],thumb[1],.010);link(thumb[1],thumb[2],.009);
  link(new THREE.Vector3(side*.008,-.027,.018),canisterWrist(side),.019);
  const geometry=mergeGeometries(parts)!;parts.forEach(g=>g.dispose());return geometry;
 };
 const closed=shape(false),open=shape(true);closed.morphAttributes.position=[open.attributes.position.clone()];closed.morphAttributes.normal=[open.attributes.normal.clone()];open.dispose();
 const glove=new THREE.Mesh(closed,new THREE.MeshLambertMaterial({color:0x30392f}));root.add(glove);root.userData.glove=glove;
 if(sleeve){const from=canisterWrist(side),to=from.clone().add(new THREE.Vector3(side*.09,-.10,.18)),delta=to.clone().sub(from),g=new THREE.CapsuleGeometry(.03,delta.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()));g.translate(...from.add(to).multiplyScalar(.5).toArray());root.add(new THREE.Mesh(g,new THREE.MeshLambertMaterial({color:0x526048})));}
 return root;
}
export function canisterHoldPose(progress:number,stanceAmount=0){
 const release=.32/.55,wind=THREE.MathUtils.smoothstep(progress,0,.25),throwing=THREE.MathUtils.smoothstep(progress,.25,release),follow=THREE.MathUtils.smoothstep(progress,release,1);
 return {position:new THREE.Vector3(.09*wind*(1-throwing),(.18+.025*wind)*(1-throwing),(-.15+.06*wind)*(1-throwing)-.08*follow),rotation:new THREE.Euler(-.35*wind*(1-throwing),0,.08*wind*(1-throwing)),open:follow,leftOffset:new THREE.Vector3(-.17*throwing,-.12*throwing*(1-.9*THREE.MathUtils.clamp(stanceAmount-1,0,1)),.08*throwing)};
}
export const jammerGrip=(side:number)=>new THREE.Vector3(side*.163,-.02,0);
export const jammerWrist=(side:number)=>new THREE.Vector3(side*.045,-.04,.08);
export function jammerHand(side:number,sleeve=true){
 const root=new THREE.Group(),parts:THREE.BufferGeometry[]=[];
 const add=(g:THREE.BufferGeometry)=>{parts.push(g.toNonIndexed());g.dispose();};
 const link=(from:THREE.Vector3,to:THREE.Vector3,r:number)=>{const delta=to.clone().sub(from),g=new THREE.CapsuleGeometry(r,delta.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()));g.translate(...from.clone().add(to).multiplyScalar(.5).toArray());add(g);};
 const palm=new THREE.SphereGeometry(1,8,6);palm.scale(.012,.035,.03);add(palm);
 for(const y of [.04,.018,-.005,-.029]){const v=[[.163,y,.025],[.16,y,-.045],[.154,y,-.112],[.11,y,-.123]].map(p=>new THREE.Vector3(side*p[0],p[1],p[2]).sub(jammerGrip(side)));for(let i=1;i<v.length;i++)link(v[i-1],v[i],.006);}
 link(new THREE.Vector3(0,.031,.025),new THREE.Vector3(-side*.015,.057,.083),.008);link(new THREE.Vector3(-side*.015,.057,.083),new THREE.Vector3(-side*.061,.052,.123),.007);
 link(new THREE.Vector3(side*.008,-.023,.02),jammerWrist(side),.019);
 const geometry=mergeGeometries(parts)!;parts.forEach(g=>g.dispose());root.add(new THREE.Mesh(geometry,new THREE.MeshLambertMaterial({color:0x30392f})));
 if(sleeve){const from=jammerWrist(side),to=from.clone().add(new THREE.Vector3(side*.09,-.10,.18)),delta=to.clone().sub(from),g=new THREE.CapsuleGeometry(.03,delta.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()));g.translate(...from.add(to).multiplyScalar(.5).toArray());root.add(new THREE.Mesh(g,new THREE.MeshLambertMaterial({color:0x526048})));}
 return root;
}
export function jammerHoldPosition(eye:THREE.Vector3,yaw:number,progress:number,stanceAmount=0,destination?:THREE.Vector3){
 const lower=THREE.MathUtils.smoothstep(progress,.2,.9),prone=THREE.MathUtils.clamp(stanceAmount-1,0,1);
  // Prone eyes already sit forward of the body; shorten that carry before lowering to the checked floor point.
  const carry=eye.clone().addScaledVector(new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw)),.60+.02*lower-.20*prone).add(new THREE.Vector3(0,-(.14+.07*lower)*(1-.65*prone),0));
 return destination?carry.lerp(destination,THREE.MathUtils.smoothstep(progress,.2,.95)):carry;
}

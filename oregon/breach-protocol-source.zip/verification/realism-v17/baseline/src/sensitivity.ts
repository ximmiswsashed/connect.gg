import {aimSensitivity} from './aiming-profile';
export const sensitivityOptics=[['iron','Iron sights · 1.0×'],['holo','Holographic · 1.0×'],['reddot','Red dot · 1.0×'],['reflex','Reflex · 1.0×'],['acog','ACOG · 2.5×']] as const;
export type AimSettings={aimSettingsVersion:number;horizontalSensitivity:number;verticalSensitivity:number;adsMode:string;standardADS:number;opticADS:Record<string,number>};
const finite=(value:unknown,fallback:number,min:number,max:number)=>typeof value==='number'&&Number.isFinite(value)?Math.max(min,Math.min(max,value)):fallback;
/** Preserve the old angular gain when upgrading. Sliders are game units, not a claimed Siege cm/360 conversion. */
export function migrateAimSettings(old:Partial<AimSettings>&{sensitivity?:number;adsSensitivity?:number}):AimSettings{
 const legacy=old.aimSettingsVersion!==1,base=legacy?finite(old.adsSensitivity,.55,.02,4)*50:finite(old.standardADS,50,1,200);
 return {aimSettingsVersion:1,horizontalSensitivity:legacy?finite(old.sensitivity,1,.1,10)*10:finite(old.horizontalSensitivity,10,1,100),verticalSensitivity:legacy?finite(old.sensitivity,1,.1,10)*10:finite(old.verticalSensitivity,10,1,100),adsMode:old.adsMode==='Advanced'?'Advanced':'Standard',standardADS:base,opticADS:Object.fromEntries(sensitivityOptics.map(([id])=>[id,finite(old.opticADS?.[id],base,1,200)]))};
}
export function mouseGain(settings:AimSettings,axis:'horizontal'|'vertical',fov:number,optic:string,progress:number){
 const value=settings.adsMode==='Advanced'?(settings.opticADS[optic]??settings.opticADS[optic==='rusacog'?'acog':'holo']??settings.standardADS):settings.standardADS;
 return .0017*(axis==='horizontal'?settings.horizontalSensitivity:settings.verticalSensitivity)/10*aimSensitivity(fov,optic,progress,value/50);
}
export function aimSettingsMarkup(settings:AimSettings){
 const slider=(id:string,label:string,value:number,max:number)=>`<label class="setting-row aim-slider" for="${id}"><span>${label}</span><input id="${id}" type="range" min="1" max="${max}" step=".5" value="${value}"><output for="${id}">${+value.toFixed(3)}</output></label>`;
 return `<div class="aim-controls"><h4>Mouse sensitivity</h4>${slider('horizontalSensitivity','Horizontal',settings.horizontalSensitivity,100)}${slider('verticalSensitivity','Vertical',settings.verticalSensitivity,100)}<h4>Aim down sights</h4><label class="setting-row">ADS mode<select id="adsMode"><option ${settings.adsMode==='Standard'?'selected':''}>Standard</option><option ${settings.adsMode==='Advanced'?'selected':''}>Advanced</option></select></label><div id="standard-ads" ${settings.adsMode==='Advanced'?'hidden':''}>${slider('standardADS','All optics',settings.standardADS,200)}</div><div id="advanced-ads" ${settings.adsMode!=='Advanced'?'hidden':''}>${sensitivityOptics.map(([id,label])=>slider('ads-'+id,label,settings.opticADS[id],200)).join('')}</div><p class="aim-help">50 is neutral ADS screen-motion gain. Zoom scaling still applies. Advanced stores each sight separately; changing modes keeps your values.</p><button class="secondary" id="reset-aim">RESTORE AIM DEFAULTS</button></div>`;
}

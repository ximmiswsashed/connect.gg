import {OperatorHeldView} from './operator-held-view';
import {isPumpShotgun} from './weapon-catalog';
import {rebuiltSightCenters} from './procedural-sights';
import {leanPose} from './player-motion';
import {worldADSFov,aimProfiles,blendFov} from './aiming-profile';
import {visualShotKick,presentationPriority} from './viewmodel-motion';
import {weaponCatalog,weaponModel,weaponRail} from './weapon-catalog';
import {hammerModel,hammerHand,hammerGrip,hammerPose} from './breaching-hammer';
import {launcherModel,launcherHand,launcherGrip,launcherPose} from './breaching-launcher';
import {deviceMesh,setJammerDeployment} from './devices';
import {chargeHand,chargeGrip,chargeHoldPose,chargeCarryPosition,chargeRecoveryPose,canisterHand,canisterGrip,canisterHoldPose,jammerHand,jammerGrip,jammerHoldPosition} from './gadget-hands';
import {InstallationView} from './installation-view';
import {reticleImageWidths} from './optical-reticle';
import {ViewmodelSleeves} from './viewmodel-sleeves';
import {weaponMuzzle,ironHeight,magazineReloadMotion,shotgunPumpStroke} from './weapon-geometry';
import {handModel,supportHandMorph,gripPose,inspectionPose,magazineHandPose,shotgunReloadPose,proneReloadLift} from './weapon-pose';
import {sightCenters} from './equipment';
import {attachmentSocket} from './attachment-sockets';

import {attachmentModel,disposeAttachment} from './attachments';

import {firearmModel,disposeFirearm} from './firearms';import {barricadeMaterial} from './barricades';

import * as THREE from 'three';

import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';



import type {Game} from './game';



export type Optic='iron'|'holo'|'reddot'|'reflex'|'acog'|'rusholo'|'rusdot'|'rusacog'|'mozholo'|'nomreflex';

export const opticLabel:Record<Optic,string>={iron:'Iron sights',holo:'NATO holographic · 1×',reddot:'NATO red dot · 1×',reflex:'NATO reflex · 1×',acog:'NATO ACOG · 2.5×',rusholo:'Russian holographic · 1×',rusdot:'Russian red dot · 1×',rusacog:'Russian ACOG · 2.5×',mozholo:'Mozzie holographic · 1×',nomreflex:'Nomad reflex · 1×'};

export const compatibleOptics=(weapon:number,attacker=true):Optic[]=>{if(!weaponCatalog[weapon])return ['iron'];if([2,5,12,13,15,20,25,29].includes(weapon))return ['iron'];if([16,23].includes(weapon))return ['reddot'];const magnified=weapon===11||attacker&&![1,9,14,17,19,22,28].includes(weapon);return ['iron','holo','reddot','reflex',...(magnified?['acog' as Optic]:[])];};

export const hipOffsetX=(weapon:number)=>[.20,.13,.12,.17,.13,.10][weaponModel(weapon)]??.21;
export const hipOffsetZ=(weapon:number)=>[-.40,-.43,-.34,-.45,-.36,-.36][weaponModel(weapon)];
export const hipOffsetY=(weapon:number)=>[-.18,-.12,-.08,-.14,-.09,-.08][weaponModel(weapon)]??-.24;

export function adsFov(optic:Optic,base=78){return worldADSFov(base,optic);}

// Individual receiver-space iron framing; world camera magnification remains independent.
export const ironViewmodelFov=[12,24,18,20,38,18] as const;
export function viewmodelFov(optic:Optic,progress:number,weapon=-1){return blendFov(64,aimProfiles[weapon]?.[optic]?.viewmodelFov??64,progress);}

// Receiver-relative sight line is calibrated per original gun, independent of optical FOV.

// Optical framing uses supplied geometry and recorded comparison screenshots. A narrower viewmodel FOV preserves the clear aperture; world zoom
// remains independent. All gun, hands and sight transforms stay together.
const referenceSightMode=typeof location!=='undefined'&&new URLSearchParams(location.search).get('sights')==='reference';
// Mechanical alignment must use the geometry being rendered, even before an
// optional source-asset preparation promise has completed.
export const opticCenter=(weapon:number,optic:Optic)=>{const c=!referenceSightMode?(rebuiltSightCenters as Record<string,{x?:number,y:number,z:number}>)[optic]??sightCenters[optic]:sightCenters[optic],socket=attachmentSocket(weapon,optic),base=attachmentSocket(0,optic);return {x:c?.x??0,y:(c?.y??.12)+(socket?.mountY??0)-(base?.mountY??0),z:(c?.z??-.1)+(socket?.rearZ??0)-(base?.rearZ??0)};};
export const adsAlignment=(weapon:number,optic:Optic)=>{const center=opticCenter(weapon,optic),profile=aimProfiles[weapon]?.[optic];return {x:optic==='iron'?0:-center.x,y:optic==='iron'?-ironHeight(weapon):-center.y,z:optic==='iron'?-.30:-(center.z+(profile?.eyeRelief??.27))};};

export class WeaponView{
 private sleeves=new ViewmodelSleeves();

 operatorHeld=new OperatorHeldView();heldHammer=new THREE.Group();heldHammerModel=hammerModel();heldLauncher=new THREE.Group();heldLauncherModel=launcherModel();heldJammer=new THREE.Group();heldJammerDevice=deviceMesh('jammer');heldCanister=new THREE.Group();heldCanisterDevice=deviceMesh('gas');heldCharge=new THREE.Group();heldChargeDevice=deviceMesh('charge');pumpLife=0;rig=new THREE.Group();body=new THREE.Group();sight=new THREE.Group();flash:THREE.Mesh;reticle:THREE.Mesh<THREE.BufferGeometry,THREE.ShaderMaterial>|null=null;current='';shot=-1;flashLife=0;clock=0;inspectionPosition=new THREE.Vector3();inspectionRotation=new THREE.Vector3();motion=new THREE.Vector3();sprintBlend=0;lastPose=0;stanceDip=0;leftHand=new THREE.Group();rightHand=new THREE.Group();magazine:THREE.Mesh|null=null;firearm:THREE.Group|null=null;installBoard:InstallationView;shell=new THREE.Mesh(new THREE.CylinderGeometry(.009,.009,.045,8),new THREE.MeshLambertMaterial({color:0xb9a14f}));

 constructor(camera:THREE.Camera){this.rig.add(this.operatorHeld);this.heldHammer.add(this.heldHammerModel);for(const side of [-1,1]){const h=hammerHand(side);h.position.copy(hammerGrip(side));this.heldHammer.add(h);}this.heldHammer.visible=false;this.body.add(this.heldHammer);this.heldLauncher.add(this.heldLauncherModel);for(const side of [-1,1]){const h=launcherHand(side);h.position.copy(launcherGrip(side));this.heldLauncher.add(h);}this.heldLauncher.visible=false;this.body.add(this.heldLauncher);this.heldJammer.add(this.heldJammerDevice);for(const side of [-1,1]){const hand=jammerHand(side);hand.position.copy(jammerGrip(side));this.heldJammer.add(hand);}this.heldJammer.visible=false;this.body.add(this.heldJammer);this.heldCanister.add(this.heldCanisterDevice);for(const side of [-1,1]){const hand=canisterHand(side);hand.position.copy(canisterGrip(side));this.heldCanister.add(hand);}this.heldCanister.visible=false;this.body.add(this.heldCanister);this.heldCharge.add(this.heldChargeDevice);for(const side of [-1,1]){const hand=chargeHand(side);hand.position.copy(chargeGrip(side));this.heldCharge.add(hand);}this.heldCharge.visible=false;this.body.add(this.heldCharge);this.installBoard=new InstallationView();this.installBoard.visible=false;this.rig.add(this.installBoard);camera.add(this.rig);this.body.add(this.shell);this.shell.visible=false;this.rig.add(this.body);this.body.add(this.sight,this.leftHand,this.rightHand);const geo=new THREE.ConeGeometry(.045,.15,6);geo.rotateX(Math.PI/2);this.flash=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({color:0xffe39a,transparent:true,opacity:.9,depthWrite:false}));this.rig.add(this.flash);this.flash.visible=false;}

 dispose(){this.sleeves.dispose();if(this.firearm){disposeFirearm(this.firearm);this.firearm.removeFromParent();this.firearm=null;}this.rig.traverse(o=>{if(o instanceof THREE.InstancedMesh)o.dispose();if(o instanceof THREE.Mesh){if(!o.userData.sharedGeometry)o.geometry.dispose();const mats=Array.isArray(o.material)?o.material:[o.material];for(const m of mats)if(!m.userData.shared)m.dispose();}else if(o instanceof THREE.Sprite&&!o.material.userData.shared)o.material.dispose();});this.rig.removeFromParent();}

 build(weapon:number,optic:Optic,weaponSkin:unknown='Factory',attachmentSkin:unknown='Factory'){if(this.firearm){disposeFirearm(this.firearm);this.body.remove(this.firearm);this.firearm=null;}for(const group of [this.body,this.sight]){for(const child of [...group.children]){if(child===this.sight||child===this.leftHand||child===this.rightHand||child===this.shell||child===this.heldCharge||child===this.heldCanister||child===this.heldJammer||child===this.heldLauncher||child===this.heldHammer)continue;group.remove(child);if(child instanceof THREE.Group)disposeAttachment(child);else if(child instanceof THREE.Mesh){child.geometry.dispose();const m=child.material;if(Array.isArray(m))m.forEach(x=>x.dispose());else if(!m.userData.shared)m.dispose();}}}this.reticle=null;this.magazine=null;this.pumpLife=0;for(const group of [this.leftHand,this.rightHand]){for(const child of [...group.children]){group.remove(child);child.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();(o.material as THREE.Material).dispose();}});}}

  this.firearm=firearmModel(weapon,weaponSkin);this.body.add(this.firearm);

  this.rightHand.add(handModel(1,weapon));this.leftHand.add(handModel(-1,weapon));const grip=gripPose(weapon);this.rightHand.position.fromArray(grip.right);this.leftHand.position.fromArray(grip.left);
  this.sleeves.install(this.leftHand,this.rightHand,weapon);
  const attachment=attachmentModel(optic,attachmentSkin,true,weapon);this.sight.add(attachment);this.reticle=attachment.userData.reticle??null;

  this.flash.position.fromArray(weaponMuzzle(weapon));this.current=[weapon,optic,weaponSkin,attachmentSkin].join(':');

 }

 update(game:Game,dt:number,brightness:number,effects:boolean,color?:string,opacity=1){this.clock+=dt;const weapon=game.slot===0?game.weapon:game.secondary,optic=game.optic;const weaponSkin=game.weaponSkins[weapon]??'Factory',attachmentSkin=game.attachmentSkins[weapon]??'Factory';if(this.current!==[weapon,optic,weaponSkin,attachmentSkin].join(':'))this.build(weapon,optic,weaponSkin,attachmentSkin);this.rig.visible=!game.observing&&game.hp>0;const alignment=adsAlignment(weapon,optic),aimY=alignment.y,progress=game.adsProgress;const near=game.world.trace(game.eye(),game.face(),.85,true)[0]?.distance??.85;this.sprintBlend=THREE.MathUtils.damp(this.sprintBlend,game.state==='sprint'?1:0,18,dt);const vault=game.vaultFrom?Math.sin(Math.PI*game.vaultProgress):0;const climbing=game.vaultPlan?.action==='onto';const lower=this.sprintBlend*.24+vault*((climbing?.16:.23)+Math.min(.10,Math.max(0,(game.vaultPlan?.points[1][1]??game.pos.y)-game.pos.y)*.08))+(game.gadgetTime>0?.2:Math.max(0,.65-near)*.45);this.rig.position.set(THREE.MathUtils.lerp(hipOffsetX(weapon),alignment.x,progress),THREE.MathUtils.lerp(hipOffsetY(weapon),aimY,progress)-lower*(1-progress),THREE.MathUtils.lerp(hipOffsetZ(weapon),alignment.z,progress)+Math.max(0,.65-near)*.25*(1-progress));const priority=presentationPriority(game),inspection=inspectionPose(weapon,['ads','locomotion'].includes(priority)?game.inspect:0);
 this.inspectionPosition.lerp(new THREE.Vector3(...inspection.position),1-Math.exp(-dt*28));this.inspectionRotation.lerp(new THREE.Vector3(...inspection.rotation),1-Math.exp(-dt*28));this.rig.position.add(this.inspectionPosition);this.rig.rotation.set(-this.sprintBlend*.35-vault*(climbing?.12:.20)+this.inspectionRotation.x,this.inspectionRotation.y,this.inspectionRotation.z);
 this.motion.lerp(game.actualVelocity,1-Math.exp(-dt*18));const local=this.motion.clone().applyAxisAngle(new THREE.Vector3(0,1,0),-game.yaw),moving=Math.min(1,this.motion.length()/3.4),gait=game.gaitCycle;this.stanceDip=THREE.MathUtils.damp(this.stanceDip,(game.stanceAmount-this.lastPose)*.1,18,dt);this.lastPose=game.stanceAmount;const stabilize=(1-progress)**2*(1-vault);this.rig.position.x+=(Math.sin(gait)*.008*moving-local.x*.0015)*stabilize;this.rig.position.y+=(Math.abs(Math.sin(gait))*.008*moving-this.stanceDip-game.landingBlend*.018)*stabilize;this.rig.rotation.z+=local.x*.003*stabilize-game.lean*(leanPose.bodyRoll-leanPose.cameraRoll);const kick=visualShotKick(weapon,game.shotAge,progress);if(['ads','locomotion','handling'].includes(priority)){this.rig.position.z+=kick.back*game.shakeScale;this.rig.rotation.x+=kick.pitch*game.shakeScale;this.rig.rotation.z+=kick.roll*game.shakeScale;}

 if(optic!=='iron'&&progress>0){const center=opticCenter(weapon,optic),pivot=new THREE.Vector3(center.x,center.y,center.z),turned=pivot.clone().applyEuler(this.rig.rotation);this.rig.position.addScaledVector(pivot.sub(turned),progress);}
 const installing=game.action>0&&['barricade','reinforce'].includes(game.actionKind);this.installBoard.visible=installing;if(installing){const pose=this.installBoard.update(1-game.action/game.actionTotal,game.actionKind==='reinforce',game.actionPanel?.kind==='floor');this.rig.position.copy(pose.position);this.rig.rotation.copy(pose.rotation);this.leftHand.position.copy(pose.left);this.rightHand.position.copy(pose.right);}else{const grip=gripPose(weapon);this.rightHand.position.fromArray(grip.right);this.leftHand.position.fromArray(grip.left);}

  // Cosmetic firing shake never changes the camera aim or ballistic ray.

  if(vault>0){this.rig.updateWorldMatrix(true,false);const support=new THREE.Vector3(-.23,climbing?-.08:-.13,-.48);this.rig.parent!.localToWorld(support);this.body.worldToLocal(support);const grip=new THREE.Vector3(...gripPose(weapon).left),low=grip.clone().add(new THREE.Vector3(0,-.14,0)),release=THREE.MathUtils.smoothstep(vault,0,.18),reach=THREE.MathUtils.smoothstep(vault,.18,.42),lift=THREE.MathUtils.smoothstep(vault,.42,1);this.leftHand.position.copy(grip).lerp(low,release);const lowSupport=support.clone();lowSupport.y=Math.min(low.y,support.y);this.leftHand.position.lerp(lowSupport,reach).lerp(support,lift);this.leftHand.rotation.set(-lift*.7,0,lift*.2);this.rightHand.rotation.set(-vault*.15,0,0);}else{this.leftHand.rotation.set(0,0,0);this.rightHand.rotation.set(0,0,0);if(game.stanceAmount>1&&!progress){const crawl=(game.stanceAmount-1)*Math.min(1,moving);this.leftHand.position.z+=Math.sin(gait)*.02*crawl;}}

  if(isPumpShotgun(weapon)&&game.shotSerial>this.shot&&this.shot>=0)this.pumpLife=.48;this.pumpLife=Math.max(0,this.pumpLife-dt);const pump=this.firearm?.userData.pump as THREE.Group|undefined;if(pump){const stroke=shotgunPumpStroke(this.pumpLife);pump.position.z=stroke;if(!game.reload&&!vault&&!installing)this.leftHand.position.z+=stroke;}
  supportHandMorph(this.leftHand);this.body.position.set(0,0,0);this.body.rotation.set(0,0,0);this.shell.visible=false;const mag=this.firearm?.userData.magazine as THREE.Group|undefined;if(mag){const original=mag.userData.reloadHome??=mag.position.clone();mag.position.copy(original);mag.rotation.set(0,0,0);mag.visible=true;}

  if(game.reload>0&&game.reloadTotal>0){const p=1-game.reload/game.reloadTotal;const lift=THREE.MathUtils.smoothstep(p,0,.15)*(1-THREE.MathUtils.smoothstep(p,.82,1));this.body.rotation.set(.15*lift,-.18*lift,-.48*lift);this.body.position.y=-.035*lift+proneReloadLift(p)*THREE.MathUtils.clamp(game.stanceAmount-1,0,1);

   if(weaponCatalog[weapon].reloadMode==='tube'){const pose=shotgunReloadPose(p,game.gun.mag);this.shell.visible=pose.visible;this.shell.position.copy(pose.shell);this.shell.rotation.set(Math.PI/2,0,0);this.leftHand.position.copy(pose.hand);supportHandMorph(this.leftHand,pose.gripBlend);}

   else {const motion=magazineReloadMotion(weapon,p);if(mag){mag.position.y-=motion.down;mag.position.x-=motion.left;mag.rotation.z=motion.angle;}const hand=magazineHandPose(weapon,p,game.reloadEmpty);this.leftHand.position.copy(hand.position);this.leftHand.rotation.z=hand.rotationZ;supportHandMorph(this.leftHand,hand.magazineBlend,hand.controlBlend);}

  }if(priority==='handling'){const swap=1-THREE.MathUtils.clamp(game.switchRemaining/Math.max(.001,game.switchTotal),0,1),envelope=Math.sin(swap*Math.PI);this.rig.position.y-=.12*envelope;this.rig.rotation.x-=.18*envelope;}this.sight.visible=true;if(this.reticle){this.reticle.material.uniforms.brightness.value=brightness;this.reticle.material.uniforms.opacity.value=opacity;if(color)this.reticle.material.uniforms.tint.value.set(color);const extent=(reticleImageWidths[optic]??.008)/Math.max(.04,-alignment.z-opticCenter(weapon,optic).z);this.reticle.material.uniforms.angularSize.value.set(extent,optic==='acog'?extent*2:extent);this.reticle.visible=priority!=='handling'&&game.reload<=0&&game.action<=0&&game.gadgetTime<=0&&game.adsProgress>.95&&game.state!=='sprint'&&!game.vaultFrom;}

  const chargeInstalling=game.operator===3&&game.action>0&&['charge','charge-pickup'].includes(game.actionKind);this.heldCharge.visible=chargeInstalling;this.heldChargeDevice.visible=game.actionKind!=='charge-pickup';this.leftHand.visible=this.rightHand.visible=!chargeInstalling;if(this.firearm)this.firearm.visible=!chargeInstalling;if(chargeInstalling){this.rig.position.copy(chargeCarryPosition);this.rig.rotation.set(0,0,0);const pose=chargeHoldPose(1-game.action/game.actionTotal,game.stanceAmount);this.heldCharge.position.copy(pose.position);this.heldCharge.rotation.copy(pose.rotation);for(let i=0;i<2;i++)this.heldCharge.children[i+1].position.copy(chargeGrip(i?1:-1)).add(game.actionKind==='charge'?(i?pose.rightOffset:pose.leftOffset):new THREE.Vector3());if(game.actionKind==='charge-pickup'){const recovery=chargeRecoveryPose(game.eye(),game.actionPosition,1-game.action/game.actionTotal);this.rig.position.copy(recovery.position.sub(game.camera.position).applyQuaternion(game.camera.quaternion.clone().invert()));this.rig.quaternion.copy(game.camera.quaternion.clone().invert().multiply(recovery.quaternion));this.heldCharge.position.set(0,0,0);this.heldCharge.rotation.set(0,0,0);}this.sight.visible=false;this.shell.visible=false;this.body.rotation.set(0,0,0);}
  const smokeRecovering=game.operator===1&&game.action>0&&game.actionKind==='gas-pickup',smokeThrowing=game.operator===1&&(game.smokeThrow>0||smokeRecovering);this.heldCanister.visible=smokeThrowing;this.heldCanisterDevice.visible=!smokeRecovering&&!game.smokeReleased;if(smokeThrowing){this.leftHand.visible=this.rightHand.visible=false;if(this.firearm)this.firearm.visible=false;this.sight.visible=this.shell.visible=false;this.rig.position.copy(new THREE.Vector3(0,-.22,0).applyQuaternion(game.camera.quaternion.clone().invert())).add(new THREE.Vector3(0,0,-.45));this.rig.rotation.set(0,0,0);this.body.rotation.set(0,0,0);const pose=canisterHoldPose(smokeRecovering?0:1-game.smokeThrow/.55,game.stanceAmount);if(smokeRecovering){const recovery=chargeRecoveryPose(game.eye(),game.actionPosition,1-game.action/game.actionTotal);this.rig.position.copy(recovery.position.sub(game.camera.position).applyQuaternion(game.camera.quaternion.clone().invert()));this.rig.quaternion.copy(game.camera.quaternion.clone().invert().multiply(recovery.quaternion));pose.position.set(0,0,0);pose.rotation.set(0,0,0);pose.leftOffset.set(0,0,0);pose.open=0;}this.heldCanister.position.copy(pose.position);this.heldCanister.rotation.copy(pose.rotation);for(let i=1;i<=2;i++){const h=this.heldCanister.children[i];h.position.copy(canisterGrip(i===1?-1:1));if(i===1)h.position.add(pose.leftOffset);h.userData.glove.morphTargetInfluences[0]=i===1?Math.max(pose.open,Math.min(1,pose.leftOffset.length()*4)):pose.open;}}
  const jammerInstalling=game.operator===4&&game.action>0&&['jammer','jammer-pickup'].includes(game.actionKind);this.heldJammer.visible=jammerInstalling;this.heldJammerDevice.visible=game.actionKind!=='jammer-pickup';if(jammerInstalling){setJammerDeployment(this.heldJammerDevice,THREE.MathUtils.smoothstep(1-game.action/game.actionTotal,.12,.48));this.leftHand.visible=this.rightHand.visible=false;if(this.firearm)this.firearm.visible=false;this.sight.visible=this.shell.visible=false;this.rig.position.copy(jammerHoldPosition(game.eye(),game.jammerYaw,1-game.action/game.actionTotal,game.stanceAmount,game.actionPosition).sub(game.camera.position).applyQuaternion(game.camera.quaternion.clone().invert()));this.rig.quaternion.copy(game.camera.quaternion.clone().invert().multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),game.jammerYaw)));this.body.rotation.set(0,0,0);}
  const launcherHolding=game.operator===0&&game.launcherEquipped;this.heldLauncher.visible=launcherHolding;if(launcherHolding){this.leftHand.visible=this.rightHand.visible=false;if(this.firearm)this.firearm.visible=false;this.sight.visible=this.shell.visible=false;const pose=launcherPose(game.adsProgress,game.launcherDraw,game.launcherReload,game.stanceAmount);this.rig.position.copy(pose.position);this.rig.rotation.copy(pose.rotation);this.body.rotation.set(0,0,0);this.heldLauncher.children[1].position.copy(launcherGrip(-1)).add(pose.supportOffset);}
  const hammerHolding=game.operator===2&&game.hammerSwing>0&&!!game.hammerTarget;this.heldHammer.visible=hammerHolding;if(hammerHolding){this.leftHand.visible=this.rightHand.visible=false;if(this.firearm)this.firearm.visible=false;this.sight.visible=this.shell.visible=false;const pose=hammerPose(game.eye(),game.camera.quaternion,game.hammerTarget!,game.hammerSwing,game.stanceAmount);this.rig.position.copy(pose.position.sub(game.camera.position).applyQuaternion(game.camera.quaternion.clone().invert()));this.rig.quaternion.copy(game.camera.quaternion.clone().invert().multiply(pose.quaternion));this.body.rotation.set(0,0,0);}
  this.shot=game.shotSerial;this.flashLife=game.shotSerial>0?Math.max(0,.035-game.shotAge):0;this.flash.visible=!chargeInstalling&&!smokeThrowing&&!jammerInstalling&&!launcherHolding&&!hammerHolding&&effects&&this.flashLife>0;this.flash.rotation.z=this.clock*17;
  if(this.leftHand.visible||this.rightHand.visible){this.rig.updateWorldMatrix(true,false);this.sleeves.update(this.rig.parent!);}

 const operatorHolding=game.action>0&&['battery','battery-pickup','grzmot-pickup'].includes(game.actionKind)||game.operatorThrow>0;this.operatorHeld.visible=operatorHolding;if(operatorHolding){const pickup=game.action>0&&game.actionKind.endsWith('-pickup'),kind=game.action>0&&game.actionKind.startsWith('battery')?'battery':game.action>0&&game.actionKind==='grzmot-pickup'?'grzmot':game.operatorThrowKind,progress=game.action>0?1-game.action/game.actionTotal:1-game.operatorThrow/.55;this.rig.position.set(0,0,0);this.rig.rotation.set(0,0,0);this.operatorHeld.show(kind,progress,game.stanceAmount,pickup?progress<.5:kind!=='battery'&&game.operatorThrowReleased);this.leftHand.visible=this.rightHand.visible=false;if(this.firearm)this.firearm.visible=false;this.sight.visible=this.flash.visible=this.shell.visible=false;}
 if(installing){if(this.firearm)this.firearm.visible=false;this.sight.visible=false;this.flash.visible=false;this.shell.visible=false;this.body.rotation.set(0,0,0);}
 }

}

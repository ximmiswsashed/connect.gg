export const secondaryWeapon=5;
export const operatorWeapons=[[0,6],[1,7],[8,1],[3,9],[4,1],[10,11],[18,19],[21,22],[24,9],[26,27,28]];
export const operatorSecondaries=[[13,12],[5,14],[5,16],[13,12],[5,14],[2,15],[20],[23],[25],[25,29]];
export const operatorUtilities=[['breach','claymore'],['wire','alarm','shield'],['frag','stun','emp'],['smoke','stun'],['camera','nitro'],['camera','impact'],['wire','nitro'],['wire','shield','impact'],['breach','claymore'],['smoke','claymore']];
export type Utility='breach'|'claymore'|'wire'|'alarm'|'shield'|'frag'|'stun'|'emp'|'smoke'|'camera'|'nitro'|'impact';
export const utilityLabel:Record<string,string>={breach:'Breach Charge',claymore:'Claymore',wire:'Barbed Wire',alarm:'Proximity Alarm',shield:'Deployable Shield',frag:'Frag Grenade',stun:'Stun Grenade',emp:'Impact EMP Grenade',smoke:'Smoke Grenade',camera:'Bulletproof Camera',nitro:'Nitro Cell',impact:'Impact Grenade'};
export const utilityCapacity:Record<string,number>={breach:3,claymore:2,wire:2,alarm:2,shield:1,frag:2,stun:3,emp:2,smoke:2,camera:1,nitro:1,impact:2};
export function eligible(op:number,weapon:number){return Number.isInteger(op)&&!!operatorWeapons[op]?.includes(weapon);}
export function validatedWeapon(op:number,weapon:number){return eligible(op,weapon)?weapon:operatorWeapons[op]?.[0]??0;}
export function validatedSecondary(op:number,weapon:unknown){return typeof weapon==='number'&&operatorSecondaries[op]?.includes(weapon)?weapon:operatorSecondaries[op]?.[0]??5;}
export function validatedUtility(op:number,value:unknown):Utility{return (typeof value==='string'&&operatorUtilities[op]?.includes(value)?value:operatorUtilities[op]?.[0]??'breach') as Utility;}
export function isSecondaryOnly(_op:number){return false;}

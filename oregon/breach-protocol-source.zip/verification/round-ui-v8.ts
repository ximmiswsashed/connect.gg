declare global {interface Window {NodeShooter:{onNavigate:(page:string)=>void}}}
window.NodeShooter.onNavigate('shooter');
const frame=document.querySelector<HTMLIFrameElement>('#shooter-frame')!,output=document.querySelector('#results')!;
document.querySelector('#verify')!.addEventListener('click',async()=>{const w=frame.contentWindow as any,g=w.breach?.game,doc=frame.contentDocument!;const checks:any[]=[];const check=(name:string,pass:boolean,detail?:unknown)=>{checks.push({name,pass,detail});output.textContent=JSON.stringify({checks},null,2);if(!pass)throw Error(name);};try{
 check('Match stays unpaused while settings are open',!!g&&!g.paused&&doc.querySelector('#ui')?.classList.contains('live-settings'));
 const panel=doc.querySelector('#ui')!.getBoundingClientRect();check('Settings leaves most of the game visible',panel.width<w.innerWidth*.65,{width:panel.width,viewport:w.innerWidth});
 const colour=(doc.querySelector('#reticleColor') as HTMLInputElement).value,opacity=+(doc.querySelector('#reticleOpacity') as HTMLInputElement).value;
 check('Colour and opacity input save preferences',w.breach.settings.reticleColor===colour&&w.breach.settings.reticleOpacity===opacity,{colour,opacity});
 const mat=w.breach.weaponView.reticle?.material;check('Live weapon reticle receives the chosen opacity and RGB',g.optic==='iron'?!mat:!!mat&&Math.abs(mat.uniforms.opacity.value-opacity)<.001&&'#'+mat.uniforms.tint.value.getHexString()===colour,{optic:g.optic,shaderColour:mat?.uniforms.tint.value.getHexString(),shaderOpacity:mat?.uniforms.opacity.value});
 check('Embedded fullscreen ownership is visible',!!document.fullscreenElement,{fullscreen:document.fullscreenElement?.id??null});
 const round=g.round;g.cool=5;const before=g.cool,phase=g.phase;await new Promise(r=>setTimeout(r,1200));check('Live simulation runs while settings remain open',!g.paused&&g.cool<before-.5,{before,after:g.cool,phase:g.phase,paused:g.paused});
 g.phase='action';g.end(0,'DEFUSER DISABLED');await new Promise(r=>setTimeout(r,5400));check('Next round returns to side-appropriate operator selection',g.round===round+1&&g.phase==='selection'&&!!doc.querySelector('#offline-ready'),{round:g.round,phase:g.phase,team:g.team,disabledOperators:[...doc.querySelectorAll<HTMLButtonElement>('[data-op]')].filter(b=>b.disabled).map(b=>b.dataset.op)});
 output.textContent=JSON.stringify({pass:true,checks},null,2);
 }catch(error){output.textContent=JSON.stringify({pass:false,error:String(error),checks},null,2);}});
export {};

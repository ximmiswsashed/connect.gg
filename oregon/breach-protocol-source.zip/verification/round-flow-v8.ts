import * as THREE from 'three';
import {Game} from '/src/game';import {World} from '/src/world';import {Lobby} from '/src/lobby';import {defaults} from '/src/data';import {lineupScreen,selectionBanner,homeScreen} from '/src/menu-screens';import {opticalReticle} from '/src/optical-reticle';
const output=document.querySelector('#results')!;
const delay=(ms:number)=>new Promise(r=>setTimeout(r,ms));
document.querySelector('#run')!.addEventListener('click',async()=>{
 const checks:{name:string,pass:boolean,detail?:unknown}[]=[];const check=(name:string,pass:boolean,detail?:unknown)=>{checks.push({name,pass,detail});output.textContent=JSON.stringify({checks},null,2);if(!pass)throw Error(name);};
 const lobby=new Lobby(),guest=new Lobby();let game:Game|undefined;let timer:ReturnType<typeof setInterval>|undefined;
 try{
  lobby.host('HOST',0);guest.profile.operator=4;guest.profile.weapon=4;const invite=await lobby.invite(),response=await guest.join(invite,'GUEST');await lobby.accept(response);
  const until=async(fn:()=>boolean,ms=8000)=>{const end=performance.now()+ms;while(!fn()){if(performance.now()>end)throw Error('Timed out');await delay(10);}};
  await until(()=>lobby.members.length===2&&guest.members.length===2);check('Real data channel connects both lobby members',true);
  lobby.beginSelection(0,0);await until(()=>guest.selection?.active===true);
  lobby.confirm();check('One ready player cannot start countdown',!lobby.selection?.startAt);
  const banner=selectionBanner(guest);check('Selection banner conceals opponent operator',banner.includes('Unknown operator')&&!banner.includes('HOST Â· Ash'));
  guest.confirm();await until(()=>!!lobby.selection?.startAt&&!!guest.selection?.startAt);const first=lobby.selection!.startAt!;
  check('Both peers receive a three-second countdown',Math.abs(first-Date.now()-3000)<150&&guest.selection!.startAt===first);
  let starts=0;lobby.onReady=()=>starts++;lobby.tickSelection();check('All ready does not start immediately',starts===0);
  guest.updateProfile();await until(()=>!lobby.selection?.startAt&&!guest.selection?.startAt);check('Loadout edit cancels countdown on both peers',!lobby.members[1].ready);
  guest.confirm();await until(()=>!!lobby.selection?.startAt);const second=lobby.selection!.startAt!;check('Reconfirmation gets a fresh full countdown',second>=first&&second-Date.now()>2800);
  timer=setInterval(()=>lobby.tickSelection(),10);await until(()=>starts===1,5000);check('Countdown completes once and never early',Date.now()>=second);await delay(80);check('Repeated ticks cannot start twice',starts===1);clearInterval(timer);timer=undefined;
  const lineup=lineupScreen(lobby.members,0,second);const wrapper=document.createElement('div');wrapper.innerHTML=lineup;const enemies=wrapper.querySelector('.enemy')!;check('Opponent lineup contains no portrait, operator name or asset path',!enemies.querySelector('img')&&enemies.textContent!.includes('Unknown operator')&&!enemies.innerHTML.includes('operator-icons'));
  check('Friendly lineup shows the actual operator badge',!!wrapper.querySelector('.friendly img[src="/operator-icons/0.png"]')&&wrapper.querySelector('.friendly strong')?.textContent==='ASH');
  const home=homeScreen({op:0,weapon:0,site:0,spawn:0,slot:0,optics:{},skins:{},attachmentSkins:{},lobby});check('Home has only requested launch actions and no operator/loadout section',home.includes('Host Lobby')&&home.includes('Join Lobby')&&home.includes('Match options')&&!home.includes('operator-stage')&&!home.includes('home-kit')&&!home.includes('Edit loadout'));
  const material=opticalReticle(new THREE.Texture(),'holo').material;check('Optic supports independent color and zero-to-full opacity',!!material.uniforms.tint&&material.uniforms.opacity.value===1&&material.fragmentShader.includes('*opacity')&&!material.fragmentShader.includes('image.rgb*tint'));
  game=new Game(new World(false),new THREE.PerspectiveCamera());game.rules.aiEnabled=false;game.phase='action';game.setObservation(false);game.pos.set(30,.015,30);game.yaw=0;game.authority=true;
  game.acceptRoundResult({id:'final-kill',round:game.round,winner:0,reason:'DEFENDERS ELIMINATED',score:[1,0],replayId:'clip'});const origin=game.pos.clone(),anchor=game.roundSequence.shownAt!;
  check('Final result enters aftermath with input active',game.phase==='aftermath'&&!game.paused);
  for(let i=0;i<30;i++)game.update(1/60,new Set([defaults.forward]),defaults,true,false,1/60);
  check('Survivor moves after final kill',game.pos.distanceTo(origin)>.1,{metres:game.pos.distanceTo(origin)});check('Confirmed result cannot accept further damage',!game.takeDamage(100,'enemy',1)&&game.hp===100);
  check('Result is not duplicated by another end call',(()=>{game!.end(1,'ATTACKERS ELIMINATED');return game!.score[0]===1&&game!.score[1]===0;})());
  while(performance.now()-anchor<2940){game.update(.01,new Set(),defaults,false,false);await delay(10);}
  check('Replay does not start before three seconds',game.phase==='aftermath',{elapsed:performance.now()-anchor});
  await delay(80);game.update(.01,new Set(),defaults,false,false);check('Replay starts after the full three-second grace',game.phase==='replay',{elapsed:performance.now()-anchor});
  output.textContent=JSON.stringify({pass:true,checks,scope:'Production Lobby over real WebRTC, live wall clocks, actual Game movement, menu DOM and optical shader.'},null,2);
 }catch(e){output.textContent=JSON.stringify({pass:false,error:String(e),checks},null,2);console.error(e);}
 finally{if(timer)clearInterval(timer);lobby.leave();guest.leave();game?.droneUnit.dispose();}
});

import {weaponCatalog,weaponModel,weaponRail} from './weapon-catalog';
export const referenceVersion='Siege X Y10S3.0 / Operation High Stakes';
// Published ADS classes predate Y10S3; retained as inherited rules, not newly
// frame-measured Y10S3 timings. Laser/grip bonuses are not added to the loadout.
export type WeaponClass='handgun'|'machine-pistol'|'smg'|'rifle'|'shotgun'|'slug';
const classes:WeaponClass[]=['rifle','shotgun','machine-pistol','rifle','smg','handgun','rifle','smg','rifle','shotgun','smg','slug','handgun','handgun','machine-pistol','machine-pistol','machine-pistol','shotgun','smg','shotgun','handgun','smg','shotgun','handgun','rifle','handgun','rifle','rifle','shotgun','handgun'];
const milliseconds={handgun:240,'machine-pistol':380,smg:460,rifle:520,shotgun:340,slug:520};
export const weaponClass=(weapon:number)=>classes[weapon]??'rifle';
export const isMagnifying=(optic:string)=>optic==='acog'||optic==='rusacog';
export const opticalMagnification=(optic:string)=>isMagnifying(optic)?2.5:1;
export const adsDuration=(weapon:number,optic:string)=>milliseconds[weaponClass(weapon)]/1000/(optic==='iron'?1.10:isMagnifying(optic)?1:1.05);
export function aimPrecision(weapon:number,progress:number){const p=Math.max(0,Math.min(1,progress)),fast=['handgun','shotgun'].includes(weaponClass(weapon));return fast?1-(1-p)*(1-p):p*p;}
export function worldADSFov(base:number,optic:string){const cameraADS=base*.9;return 2*Math.atan(Math.tan(cameraADS*Math.PI/360)/opticalMagnification(optic))*180/Math.PI;}
export const blendFov=(from:number,to:number,p:number)=>2*Math.atan(THREElerp(Math.tan(from*Math.PI/360),Math.tan(to*Math.PI/360),Math.max(0,Math.min(1,p))))*180/Math.PI;
const THREElerp=(a:number,b:number,p:number)=>a+(b-a)*p;
export function aimSensitivity(baseFov:number,optic:string,progress:number,preference:number){const fov=blendFov(baseFov,worldADSFov(baseFov,optic),progress),focal=Math.tan(fov*Math.PI/360)/Math.tan(baseFov*Math.PI/360);return (1-progress)+progress*preference*focal;}
// Each pair has an independent profile. Until matching, known-FOV images exist,
// inherited framing is explicit rather than fabricated screen measurements.
export const aimProfiles=weaponCatalog.map((w,id)=>Object.fromEntries(['iron','holo','reddot','reflex','acog'].map(optic=>[optic,{weapon:id,optic,rail:weaponRail(id),opticalMagnification:opticalMagnification(optic),viewmodelFov:optic==='iron'?[52,58,56,54,58,56][weaponModel(id)]:isMagnifying(optic)?34:64,eyeRelief:optic==='iron'?.30:isMagnifying(optic)?.18:.27,evidence:id===16&&optic==='holo'?'Creator-declared 85 degree / 5:4, Y10S3 preview frame 854.322s; estimated 0.08 lens-height fraction (+/-0.015), approximate manual estimate, original housing differs':'Mechanical framing derived from original lens geometry; independent matching screenshot unavailable',name:w.name}])));

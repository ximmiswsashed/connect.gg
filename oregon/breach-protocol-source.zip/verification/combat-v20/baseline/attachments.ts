import {realizeModel} from './realism-materials';
import {rebuiltSight} from './procedural-sights';
import * as THREE from 'three';
import {sourceSight,sourceIron} from './equipment';
import type {Optic} from './optics';
import {attachmentSocket} from './attachment-sockets';
import {finishMaterial,paintUV} from './cosmetics';
export function attachmentModel(optic:Optic,_skin:unknown='Factory',showReticle=false,weapon=0){const socket=attachmentSocket(weapon,optic);if(!socket||optic==='iron'&&weapon!==0)return new THREE.Group();const reference=new URLSearchParams(location.search).get('sights')==='reference',model=reference?(optic==='iron'?sourceIron():sourceSight(optic,showReticle)):rebuiltSight(optic as 'iron'|'holo'|'reddot'|'reflex'|'acog',showReticle);const base=attachmentSocket(0,optic)!;model.position.y=socket.mountY-base.mountY;model.position.z=socket.rearZ-base.rearZ;if(_skin!=='Factory')model.traverse(o=>{if(o instanceof THREE.Mesh){const mats=Array.isArray(o.material)?o.material:[o.material];if(mats.every(m=>!m.transparent&&m instanceof THREE.MeshLambertMaterial)){o.geometry=o.geometry.clone();o.userData.sharedGeometry=false;paintUV(o.geometry);o.material=finishMaterial(_skin,'attachment');}}});model.userData.socket={weapon,optic,...socket};realizeModel(model);return model;}
export function disposeAttachment(root:THREE.Group){root.userData.disposed=true;root.traverse(o=>{if(o instanceof THREE.Mesh){if(!o.userData.sharedGeometry)o.geometry.dispose();for(const m of Array.isArray(o.material)?o.material:[o.material])if(!m.userData.shared)m.dispose();}if(o instanceof THREE.Sprite){if(o.material.map&&!o.material.map.userData.shared)o.material.map.dispose();o.material.dispose();}});}

import * as THREE from 'three';
import type {Game,Bot} from './game';
import {posture,stanceValue} from './pose';
export const botPosture=(b:Bot)=>posture(b.stanceAmount??stanceValue(b.stance??'stand'));
export function turnBot(game:Game,b:Bot,delta:number){
 // Standing/crouched capsules are rotationally symmetric; only prone adds a long footprint.
 if((b.stanceAmount??0)<=1){b.mesh.rotation.y+=delta;return;}
 const from=b.mesh.rotation.y,n=Math.max(1,Math.ceil(Math.abs(delta)/.05));
 for(let i=1;i<=n;i++)if(game.postureBlocked(b.pos,b.stanceAmount??0,from+delta*i/n))return;
 b.mesh.rotation.y+=delta;
}

export function choosePosture(game:Game,b:Bot,threat:THREE.Vector3|null,dt:number){
 const data=b.mesh.userData;data.stanceHold=Math.max(0,(data.stanceHold??0)-dt);
 // During the committed hold, only animate; avoid repeated cover rays and clearance sweeps.
 if(data.stanceHold>0){b.stanceAmount=THREE.MathUtils.damp(b.stanceAmount??0,stanceValue(b.stance??'stand'),10,dt);return;}
 const travelling=b.path.length>0&&b.pos.distanceTo(b.goal)>.8;
 let next:Game['stance']='stand';
 if(threat){
  const target=threat.clone().add(new THREE.Vector3(0,1.2,0));
  const hides=(height:number)=>!game.world.sight(b.pos.clone().add(new THREE.Vector3(0,height,0)),target);
  if(hides(1.04)||b.hp<70)next='crouch';
  if(!travelling&&b.role==='anchor'&&b.pos.distanceTo(threat)>10&&hides(.43)&&!hides(1.04))next='prone';
 }
 if(!threat&&!travelling&&b.role==='anchor')next='crouch';
 if(data.stanceHold<=0&&next!==(b.stance??'stand')){
  const from=b.stanceAmount??stanceValue(b.stance??'stand'),to=stanceValue(next);
  let clear=true;for(let i=0;i<=8;i++)if(game.postureBlocked(b.pos,THREE.MathUtils.lerp(from,to,i/8),b.mesh.rotation.y)){clear=false;break;}
  if(clear){b.stance=next;data.stanceHold=3.5;data.stanceChanges=(data.stanceChanges??0)+1;}
 }
 b.stanceAmount=THREE.MathUtils.damp(b.stanceAmount??0,stanceValue(b.stance??'stand'),10,dt);
}

export function holdAngle(game:Game,b:Bot,dt:number,defer=false){
 if(b.brain?.visible||b.path.length||!['hold','guard','support'].includes(b.brain?.mode??''))return;
 const data=b.mesh.userData;data.angleHold=(data.angleHold??0)-dt;
 if(data.angleHold<=0){
  const origin=b.pos.clone().add(new THREE.Vector3(0,botPosture(b).eye));
  let yaw=b.mesh.rotation.y,best=0;
  for(let i=0;i<8;i++){const angle=i*Math.PI/4,dir=new THREE.Vector3(-Math.sin(angle),0,-Math.cos(angle));const free=game.world.trace(origin,dir,10,true)[0]?.distance??10;const score=free+(Math.abs(angle-yaw)<.4?1:0);if(score>best){best=score;data.holdYaw=angle;}}
  data.angleHold=6+Math.random()*3;
 }
 const diff=THREE.MathUtils.euclideanModulo((data.holdYaw??b.mesh.rotation.y)-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI;
 if(!defer)turnBot(game,b,THREE.MathUtils.clamp(diff,-dt*1.2,dt*1.2));
}

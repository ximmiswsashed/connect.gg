import {surfaceMaterial} from './realism-materials';
import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
const material=surfaceMaterial(new THREE.MeshLambertMaterial({vertexColors:true}),'fabric');material.userData.shared=true;
// Rigid weights retain the original articulated silhouette; one GPU skin draw replaces
// separate limb draws. Collision meshes remain attached to the same authored transforms.
export function skinRig(root:THREE.Group,groups:THREE.Group[]){
 root.updateMatrixWorld(true);const bones=groups.map(()=>new THREE.Bone()),lookup=new Map(groups.map((g,i)=>[g,i]));
 groups.forEach((g,i)=>{const parent=lookup.get(g.parent as THREE.Group);(parent===undefined?root:bones[parent]).add(bones[i]);bones[i].position.copy(g.position);bones[i].quaternion.copy(g.quaternion);bones[i].scale.copy(g.scale);});
 const geometries:THREE.BufferGeometry[]=[];let vertexOffset=0;
 groups.forEach((group,i)=>{
  const parts:{object:THREE.Mesh,attachment?:THREE.Object3D}[]=[];
  for(const child of [...group.children]){if(child instanceof THREE.Mesh&&!child.userData.hitbox)parts.push({object:child});else if(child.userData.skinAttachment){child.userData.skinRanges=[];child.traverse(object=>{if(object instanceof THREE.Mesh&&!object.userData.hitbox)parts.push({object,attachment:child});});}}
  for(const {object,attachment} of parts){const source=object.geometry,geo=(source.index?source.toNonIndexed():source.clone()).applyMatrix4(object.matrixWorld),count=geo.getAttribute('position').count,colors=geo.getAttribute('color'),mat=object.material as THREE.MeshBasicMaterial,tint=mat.color,newColors=new Float32Array(count*3),indices=new Uint16Array(count*4),weights=new Float32Array(count*4);for(let v=0;v<count;v++){const shade=mat.vertexColors&&colors?new THREE.Color(colors.getX(v),colors.getY(v),colors.getZ(v)):new THREE.Color(1,1,1);shade.multiply(tint);newColors.set([shade.r,shade.g,shade.b],v*3);indices[v*4]=i;weights[v*4]=1;}geo.setAttribute('color',new THREE.BufferAttribute(newColors,3));geo.setAttribute('skinIndex',new THREE.BufferAttribute(indices,4));geo.setAttribute('skinWeight',new THREE.BufferAttribute(weights,4));geometries.push(geo);if(attachment)attachment.userData.skinRanges.push([vertexOffset,count]);vertexOffset+=count;object.removeFromParent();source.dispose();if(object.userData.ownedSkinMaterial)mat.dispose();}
 });
 const geometry=mergeGeometries(geometries);geometries.forEach(g=>g.dispose());if(!geometry)throw Error('Unable to combine character geometry');const mesh=new THREE.SkinnedMesh(geometry,material);mesh.boundingSphere=new THREE.Sphere(new THREE.Vector3(0,.85,0),1.75);root.add(mesh);root.updateMatrixWorld(true);mesh.bind(new THREE.Skeleton(bones));
 return {mesh,sync(){groups.forEach((g,i)=>{bones[i].position.copy(g.position);bones[i].quaternion.copy(g.quaternion);bones[i].scale.copy(g.scale);if(g.matrixAutoUpdate)g.updateMatrix();bones[i].matrixAutoUpdate=false;bones[i].matrix.copy(g.matrix);});}};
}

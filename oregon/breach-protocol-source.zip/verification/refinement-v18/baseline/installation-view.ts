import {realizeModel,surfaceMaterial} from './realism-materials';
import {beveledBox} from './model-detail';
import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {installationPose} from './installation-pose';
/** Original compact installation kit. Materials/geometries allocated once per view. */
export class InstallationView extends THREE.Group{
 panel=new THREE.Group();tool=new THREE.Group();wood=new THREE.Group();metal=new THREE.Group();
 constructor(){super();this.name='installation-kit';this.add(this.panel,this.tool);this.panel.position.set(0,.08,-.45);this.panel.add(this.wood,this.metal);
 const material=(color:number)=>new THREE.MeshLambertMaterial({color});const steel=material(0x7d8a90),dark=material(0x20282c),wood=material(0xa48150),yellow=material(0xc3a64b);
 const batch=(parent:THREE.Group,mat:THREE.Material,parts:THREE.BufferGeometry[])=>{const merged=mergeGeometries(parts)!;parts.forEach(p=>p.dispose());parent.add(new THREE.Mesh(merged,mat));};
 const box=(w:number,h:number,d:number,x=0,y=0,z=0)=>beveledBox(w,h,d).translate(x,y,z);
 batch(this.wood,wood,[box(.62,.11,.028),box(.60,.10,.025,0,-.115,.012),box(.58,.10,.025,0,-.23,.025)]);
 const nails:THREE.BufferGeometry[]=[];for(const x of [-.25,.25])for(const y of [0,-.115,-.23])nails.push(new THREE.CylinderGeometry(.006,.006,.006,6).rotateX(Math.PI/2).translate(x,y,.02));batch(this.wood,steel,nails);
 const slats:THREE.BufferGeometry[]=[];for(let i=0;i<9;i++)slats.push(box(.60,.035,.014,0,(i-4)*.038,(i%2)*.006));batch(this.metal,steel,slats);
 batch(this.metal,dark,[box(.028,.36,.022,-.24),box(.028,.36,.022,.24),box(.65,.035,.038,0,.18)]);
 batch(this.metal,yellow,[box(.085,.018,.004,0,.18,.021)]);
 // Ratchet/fastener tool with a trigger guard, driver nose and battery heel.
 batch(this.tool,dark,[box(.055,.10,.06,0,-.035,.01),box(.075,.045,.10,0,-.10,.025),box(.012,.055,.045,.025,-.025,-.043),box(.012,.012,.05,.025,-.05,-.04)]);
 batch(this.tool,steel,[box(.075,.065,.10,0,.025,-.01),new THREE.CylinderGeometry(.012,.012,.07,8).rotateX(Math.PI/2).translate(0,.025,-.09)]);
 realizeModel(this);this.visible=false;
 }
 update(progress:number,reinforce:boolean,hatch:boolean){const pose=installationPose(progress,reinforce,hatch);this.visible=true;this.wood.visible=!reinforce;this.metal.visible=reinforce;this.panel.scale.copy(pose.panelScale);this.panel.rotation.y=(1-pose.unfold)*.18;this.tool.position.copy(pose.right).add(new THREE.Vector3(0,.02,-.025));this.tool.rotation.set(-pose.stroke*.12,0,0);this.tool.visible=progress>.36&&progress<.96;return pose;}
 dispose(){const materials=new Set<THREE.Material>();this.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();for(const mat of Array.isArray(o.material)?o.material:[o.material])materials.add(mat);}});materials.forEach(m=>m.dispose());this.removeFromParent();}
}

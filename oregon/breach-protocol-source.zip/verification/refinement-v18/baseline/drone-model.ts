import {realizeModel} from './realism-materials';
import {beveledBox} from './model-detail';
import * as THREE from 'three';import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
// Original low-poly mesh inspired by the standard two-wheel reconnaissance silhouette.
// No extracted Siege mesh, texture or proprietary asset is used. Dimensions retain game clearance.
export function reconnaissanceDrone(shock=false){
 const root=new THREE.Group(),wheels:THREE.Group[]=[],materials=[new THREE.MeshLambertMaterial({color:0x656e52}),new THREE.MeshLambertMaterial({color:0x242927}),new THREE.MeshLambertMaterial({color:0x89918a}),new THREE.MeshLambertMaterial({color:0x152d35}),new THREE.MeshBasicMaterial({color:0xc9ad48})];
 const parts:THREE.BufferGeometry[][]=materials.map(()=>[]),add=(mat:number,g:THREE.BufferGeometry,x:number,y:number,z:number,rx=0,ry=0,rz=0)=>{g.rotateX(rx);g.rotateY(ry);g.rotateZ(rz);g.translate(x,y,z);parts[mat].push(g);},box=(m:number,x:number,y:number,z:number,w:number,h:number,d:number)=>add(m,beveledBox(w,h,d),x,y,z);
 add(0,new THREE.CylinderGeometry(.052,.052,.17,32),0,.075,0,0,0,Math.PI/2);box(0,0,.104,-.026,.102,.035,.063);box(1,0,.045,.045,.11,.025,.075);box(2,0,.038,.083,.072,.009,.072);box(2,0,.055,.112,.065,.008,.03);
 add(1,new THREE.CylinderGeometry(.023,.023,.014,32),0,.12,-.062,Math.PI/2);add(3,new THREE.CylinderGeometry(.017,.017,.015,32),0,.12,-.071,Math.PI/2);add(4,new THREE.CylinderGeometry(.005,.005,.012,8),.035,.12,-.066,Math.PI/2);
 for(const side of [-1,1]){add(2,new THREE.CylinderGeometry(.014,.014,.05,8),side*.089,.075,0,0,0,Math.PI/2);for(const z of [-.024,.024])box(1,side*.073,.113,z,.009,.007,.008);const wheel=new THREE.Group();wheel.position.set(side*.112,.075,0);const gs:THREE.BufferGeometry[]=[];const tire=new THREE.CylinderGeometry(.062,.062,.026,32);tire.rotateZ(Math.PI/2);gs.push(tire);for(let i=0;i<12;i++){const a=i*Math.PI/6,g=new THREE.CylinderGeometry(.011,.011,.043,6);g.rotateZ(Math.PI/2);g.rotateY(side*.60);g.rotateX(a);g.translate(0,Math.cos(a)*.061,Math.sin(a)*.061);gs.push(g);}const rubber=mergeGeometries(gs)!;gs.forEach(g=>g.dispose());wheel.add(new THREE.Mesh(rubber,materials[1]));const hub=new THREE.CylinderGeometry(.029,.029,.031,24);hub.rotateZ(Math.PI/2);wheel.add(new THREE.Mesh(hub,materials[2]));wheels.push(wheel);root.add(wheel);}
 if(shock){box(1,0,.155,-.015,.09,.045,.10);add(3,new THREE.CylinderGeometry(.012,.012,.035,10),0,.155,-.08,Math.PI/2);}
 for(let i=0;i<parts.length;i++)if(parts[i].length){const geometry=mergeGeometries(parts[i])!;parts[i].forEach(g=>g.dispose());root.add(new THREE.Mesh(geometry,materials[i]));}realizeModel(root);root.name='Reconnaissance drone';return {root,wheels,materials};
}

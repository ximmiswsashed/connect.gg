import {realizeModel,surfaceMaterial} from './realism-materials';
import {beveledBox} from './model-detail';
import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import type {Panel} from './world';
export function installationPreview(panel:Panel,reinforce:boolean,materials:Record<string,THREE.Material>,actor:THREE.Vector3){
 const group=new THREE.Group(),axis=panel.gridAxis??(panel.max.x-panel.min.x<panel.max.z-panel.min.z?'x':'z'),hatch=axis==='y',v=hatch?'z':'y',u=axis==='x'?'z':'x',size=panel.max.clone().sub(panel.min),center=panel.min.clone().add(panel.max).multiplyScalar(.5),side=Math.sign(actor[axis]-center[axis])||1,count=reinforce?10:8;
 group.userData.axis=axis;group.userData.side=side;
 for(let i=0;i<count;i++){const segment=size.clone();segment[v]=Math.max(.005,size[v]/count-.008);segment[axis]=Math.max(.025,Math.min(.08,size[axis]));const board=new THREE.Mesh(beveledBox(segment.x,segment.y,segment.z),reinforce?materials.metal:materials.barricade);board.position.copy(center);board.position[v]=panel.min[v]+(i+.5)*size[v]/count;board.userData.installHome=board.position.clone();board.userData.reveal=reinforce?.16+i*.032:.16+i*.064;board.userData.duration=reinforce?.18:.13;board.userData.scaleAxis=v;group.add(board);}
 // One batch for fastener heads on the working face, plus two locking rails.
 const fasteners:THREE.BufferGeometry[]=[];for(const edge of [-1,1])for(let i=0;i<count;i++){const pos=center.clone();pos[u]+=edge*Math.max(0,size[u]/2-.08);pos[v]=panel.min[v]+(i+.5)*size[v]/count;pos[axis]+=side*(Math.max(.025,Math.min(.08,size[axis]))/2+.004);const bolt=new THREE.CylinderGeometry(reinforce?.014:.008,reinforce?.014:.008,.008,6);if(axis==='x')bolt.rotateZ(Math.PI/2);if(axis==='z')bolt.rotateX(Math.PI/2);bolt.translate(pos.x,pos.y,pos.z);fasteners.push(bolt);}
 const geo=mergeGeometries(fasteners)!;fasteners.forEach(g=>g.dispose());const bolts=new THREE.Mesh(geo,materials.metal);bolts.userData.installHome=new THREE.Vector3();bolts.userData.reveal=.85;bolts.userData.duration=.06;group.add(bolts);
 if(reinforce)for(const edge of [-1,1]){const dimensions=new THREE.Vector3(.035,.035,.035);dimensions[v]=size[v];const rail=new THREE.Mesh(beveledBox(dimensions.x,dimensions.y,dimensions.z),materials.metal);rail.position.copy(center);rail.position[u]+=edge*Math.max(0,size[u]/2-.065);rail.position[axis]+=side*.055;rail.userData.installHome=rail.position.clone();rail.userData.reveal=.65;rail.userData.duration=.18;rail.userData.scaleAxis=v;group.add(rail);}
 return group;
}
export function updateInstallationPreview(group:THREE.Group,progress:number){const axis=group.userData.axis as 'x'|'y'|'z';for(const object of group.children){const amount=THREE.MathUtils.smoothstep(progress,object.userData.reveal,object.userData.reveal+object.userData.duration);object.visible=amount>0;object.position.copy(object.userData.installHome);object.position[axis]+=(1-amount)*.18*group.userData.side;if(object.userData.scaleAxis)object.scale[object.userData.scaleAxis as 'x'|'y'|'z']=Math.max(.01,amount);}}

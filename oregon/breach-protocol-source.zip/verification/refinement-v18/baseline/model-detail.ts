import * as T from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {realizeModel,surfaceMaterial} from './realism-materials';
import {weaponRail,weaponPoint,weaponModel} from './weapon-catalog';

export function beveledBox(w:number,h:number,d:number){const g=new RoundedBoxGeometry(w,h,d,1,Math.min(.0025,w*.12,h*.12,d*.12));g.setIndex(Array.from({length:g.attributes.position.count},(_,i)=>i));return g;}
export function firearmDetail(root:T.Group,id:number){
 if(root.userData.realisticModel)return root;root.userData.realisticModel=true;const rail=weaponRail(id),muzzle=weaponPoint(id),pistol=weaponModel(id)===5,shotgun=weaponModel(id)===1,width=pistol?.018:.029,top=rail.mountY-.014;
 const steel=surfaceMaterial(new T.MeshLambertMaterial({color:0x58636b}),'metal'),black=surfaceMaterial(new T.MeshLambertMaterial({color:0x171c20}),'polymer'),parts=[[] as T.BufferGeometry[],[] as T.BufferGeometry[]];
 const add=(g:T.BufferGeometry,m=0)=>{parts[m].push(g.index?g.toNonIndexed():g);if(g.index)g.dispose();};const box=(w:number,h:number,d:number,x:number,y:number,z:number,m=0)=>add(beveledBox(w,h,d).translate(x,y,z),m);
 // Recessed ejection-port well, lip, bolt and receiver takedown pins. Keep the sight/aim axis clear.
 box(.0015,.017,pistol?.028:.068,width,.006,-.042,1);box(.002,.003,pistol?.030:.072,width+.001,.016,-.042);box(.002,.006,.016,width+.002,.005,-.023);
 for(const side of [-1,1])for(const z of pistol?[.020,-.028]:[.045,-.09]){const g=new T.CylinderGeometry(.0032,.0032,.0035,12).rotateZ(Math.PI/2).translate(side*(width+.001),-.015,z);add(g);box(.001,.001,.004,side*(width+.003),-.015,z,1);}
 if(!pistol){
  // Separate machined receiver ribs, charging latch, safety and selector detent.
  for(const side of [-1,1]){box(.0025,.006,.12,side*(width-.001),top-.009,-.012);box(.004,.012,.020,side*(width+.001),-.028,.045);for(let i=0;i<9;i++)box(.002,.009,.005,side*(width+.001),.008,-.16-i*.015,1);}
  box(.012,.011,.035,-width-.007,top-.017,.055,1);
  box(.009,Math.max(.015,rail.mountY-muzzle[1]),.009,0,(rail.mountY+muzzle[1])/2,muzzle[2]+.018,1);const ring=new T.TorusGeometry(shotgun?.0145:.0095,.0017,6,24).translate(0,muzzle[1],muzzle[2]-.001);add(ring);
  // Sling eyelets and rail retaining screws, below the optical ray.
  for(const z of [-.17,.105])add(new T.TorusGeometry(.009,.002,6,16).rotateY(Math.PI/2).translate(width+.003,-.027,z));
  for(const x of [-.012,.012])for(const z of [rail.rearZ-.025,rail.rearZ-.12])add(new T.CylinderGeometry(.0027,.0027,.0018,8).translate(x,rail.mountY-.006,z));
 }else{
  for(const side of [-1,1])for(let i=0;i<10;i++)box(.0012,.022,.0012,side*(width-.001),.012,.005+i*.003,1);
  for(const side of [-1,1])box(.0018,.045,.027,side*.017,-.075,.036,1);
 }
 for(let i=0;i<parts.length;i++){const geometry=mergeGeometries(parts[i]);parts[i].forEach(g=>g.dispose());if(geometry){const mesh=new T.Mesh(geometry,i?black:steel);mesh.name='Machined receiver details';mesh.userData.realismDetail=true;root.add(mesh);}}
 // Magazine seam, witness slots and reinforced baseplate stay with the moving magazine.
 const magazine=root.userData.magazine as T.Group|undefined;if(magazine){magazine.updateMatrixWorld(true);const b=new T.Box3().setFromObject(magazine),center=b.getCenter(new T.Vector3());magazine.worldToLocal(center);const height=b.max.y-b.min.y;const geos:T.BufferGeometry[]=[];for(const side of [-1,1])for(let i=0;i<4;i++)geos.push(beveledBox(.0015,.003,.012).translate(side*.016,center.y-height*.3+i*height*.16,center.z));const geometry=mergeGeometries(geos)!;geos.forEach(g=>g.dispose());const mesh=new T.Mesh(geometry,black);mesh.userData.realismDetail=true;magazine.add(mesh);}
 realizeModel(root);root.userData.visualVersion='realism-v17';return root;
}

export function deviceDetail(root:T.Mesh,type:string){
 if(root.userData.realisticModel)return root;root.userData.realisticModel=true;const geometry=root.geometry;if(geometry.getAttribute('position')){
  geometry.computeBoundingBox();const b=geometry.boundingBox!,w=b.max.x-b.min.x,h=b.max.y-b.min.y,d=b.max.z-b.min.z,parts:T.BufferGeometry[]=[];
  if(w>.08&&h>.05&&d<.6){for(const x of [-1,1])for(const y of [-1,1])parts.push(new T.CylinderGeometry(.0028,.0028,.002,10).rotateX(Math.PI/2).translate(x*w*.38,y*h*.36,b.max.z+.002));for(let i=0;i<4;i++)parts.push(beveledBox(w*.18,.002,.003).translate(w*.22,-h*.16+i*.009,b.max.z+.002));
   const merged=mergeGeometries(parts)!;parts.forEach(g=>g.dispose());const m=surfaceMaterial(new T.MeshLambertMaterial({color:0x6c7578}),'metal'),mesh=new T.Mesh(merged,m);mesh.name='Fasteners and housing vents';mesh.userData.realismDetail=true;root.add(mesh);
  }
 }
 realizeModel(root);root.traverse(o=>{o.userData.deviceRoot=root;});return root;
}

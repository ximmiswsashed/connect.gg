import * as T from 'three';
type Box={p:number[],n:number[],uv:number[],tile:number[],color:number[],idx:number[]};
type Patch={remove:number[],boxes:Box[]};
let request:Promise<Record<string,Patch>>|undefined;
export function mapVisualPatches(){return request??=fetch('/assets/realism-v17/map-bevels.json.gz').then(async r=>{if(!r.ok)throw Error('Visual geometry patch unavailable');const raw=await r.arrayBuffer(),b=new Uint8Array(raw);return JSON.parse(await (b[0]===31&&b[1]===139?new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('gzip'))):new Response(raw)).text());});}
export function applyMapVisualPatch(g:T.BufferGeometry,patch:Patch|undefined){
 if(!patch)return;const offset=g.getAttribute('position').count,add=patch.boxes.reduce((n,b)=>n+b.p.length/3,0),indices=g.index!,removed=new Set(patch.remove),kept:number[]=[];
 for(let i=0;i<indices.count;i+=3)if(!removed.has(i))kept.push(indices.getX(i),indices.getX(i+1),indices.getX(i+2));let base=offset;
 for(const box of patch.boxes){for(const i of box.idx)kept.push(base+i);base+=box.p.length/3;}
 for(const [attribute,key,size,Type,normalized] of [['position','p',3,Float32Array,false],['normal','n',3,Int8Array,true],['uv','uv',2,Float32Array,false],['atlasTile','tile',2,Uint8Array,false],['color','color',3,Uint8Array,true]] as const){
  const source=g.getAttribute(attribute),data=new Type((offset+add)*size);data.set(source.array);let start=offset*size;for(const box of patch.boxes){data.set(box[key],start);start+=box[key].length;}g.setAttribute(attribute,new T.BufferAttribute(data,size,normalized));
 }
 g.setIndex(new T.BufferAttribute(offset+add<=65535?new Uint16Array(kept):new Uint32Array(kept),1));g.userData.beveledProps=patch.boxes.length;
}

import * as T from 'three';
import type {World} from './world';
import type {Device} from './game';
import type {ImpactPool} from './effects';
import {buildGasCloud} from './gas-cloud';
const clocks=new WeakMap<T.Object3D,number>();
/** Cosmetic only: authoritative timers, gas damage and collision stay in the gadget simulation. */
export function updateVisualDevices(world:World,devices:Device[],effects:ImpactPool,dt:number){for(const d of devices){if(!d.mesh.visible)continue;
 if(d.type==='charge'&&d.active&&effects.enabled){const clock=(clocks.get(d.mesh)??0)-dt;if(clock<=0){const normal=new T.Vector3(0,0,1).applyQuaternion(d.mesh.quaternion);effects.burst(d.pos.clone().addScaledVector(normal,.04),normal,'metal',.6);clocks.set(d.mesh,.075);}else clocks.set(d.mesh,clock);}
 if(d.type==='utility:smoke'&&d.active){const material=d.mesh.userData.smokeMaterial as T.ShaderMaterial;material.uniforms.cloudTime.value=performance.now()/1000;const key=d.pos.toArray().join(',')+':'+world.surfaceRevision;if(d.mesh.userData.visualSmokeKey!==key){const previous=d.mesh.userData.smokeGeometry as T.BufferGeometry;const geometry=buildGasCloud(world,d.pos,d.mesh.quaternion,2.5);d.mesh.userData.smokeGeometry=geometry;d.mesh.geometry=geometry;d.mesh.userData.visualSmokeKey=key;previous.dispose();}}
 }}

import * as T from 'three';
/** Open side plates retain real vent apertures instead of painted black rectangles. */
export function ventedHandguard(w:number,h:number,d:number){
 const parts:T.BufferGeometry[]=[];
 for(const side of [-1,1]){const shape=new T.Shape();shape.moveTo(-d/2,-h/2);shape.lineTo(d/2,-h/2);shape.lineTo(d/2,h/2);shape.lineTo(-d/2,h/2);shape.closePath();const count=Math.max(2,Math.min(7,Math.floor(d/.035)));for(let i=0;i<count;i++){const z=-d*.4+(i+.5)*d*.8/count,hw=d*.27/count,hh=h*.18,hole=new T.Path();hole.moveTo(z-hw,-hh);hole.lineTo(z-hw,hh);hole.lineTo(z+hw,hh);hole.lineTo(z+hw,-hh);hole.closePath();shape.holes.push(hole);}const g=new T.ExtrudeGeometry(shape,{depth:.003,bevelEnabled:false,steps:1});g.rotateY(-Math.PI/2);g.translate(side*w/2+.0015,0,0);parts.push(g);}
 for(const y of [-1,1])parts.push(new T.BoxGeometry(w,.005,d).translate(0,y*(h/2-.0025),0));
 return parts;
}

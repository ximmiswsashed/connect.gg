import * as T from 'three';

export type SurfaceFinish='metal'|'polymer'|'fabric'|'leather'|'wood'|'plaster';
const cache=new WeakMap<T.Material,Map<string,T.MeshStandardMaterial>>(),textures=new Map<string,T.Texture>(),registered=new Set<T.Material>(),pending:Promise<unknown>[]=[];
const detailGain={value:1};
let quality='Medium';
export const realismQuality=()=>quality;
export function setRealismQuality(value:string){const changed=quality!==value;quality=value;detailGain.value=value==='Low'?0:1;for(const texture of textures.values())texture.anisotropy=value==='High'?4:2;if(changed)for(const material of registered)material.needsUpdate=true;}
export function trackRealismMaterial(material:T.Material){registered.add(material);material.addEventListener('dispose',()=>registered.delete(material));return material;}
export async function prepareRealismTextures(){for(const kind of ['fabric','leather','metal','plaster','wood'])for(const channel of kind==='wood'?['diffuse']:kind==='plaster'?['diffuse','nor_gl']:['diffuse','rough','nor_gl'])photographedTexture(kind,channel);await Promise.all(pending);}
export function photographedTexture(kind:string,channel='diffuse'){
 const key=kind+'-'+channel;let texture=textures.get(key);if(!texture){let done:()=>void=()=>{},fail:(e:unknown)=>void=()=>{};const promise=new Promise<void>((resolve,reject)=>{done=resolve;fail=reject;});promise.catch(()=>{});pending.push(promise);texture=new T.TextureLoader().load('/assets/realism-v17/'+key+'.jpg',done,undefined,fail);texture.colorSpace=channel==='diffuse'?T.SRGBColorSpace:T.NoColorSpace;texture.wrapS=texture.wrapT=T.RepeatWrapping;texture.anisotropy=2;texture.userData.shared=true;textures.set(key,texture);}return texture;
}
/** Object-space photographic microdetail avoids stretching or missing UVs on merged parts. */
export function surfaceMaterial(source:T.Material,kind:SurfaceFinish='metal'){
 if(source instanceof T.ShaderMaterial||source instanceof T.MeshBasicMaterial||source.transparent||!source.visible||source.userData.realism)return source;
 let variants=cache.get(source);if(!variants){variants=new Map();cache.set(source,variants);}const old=variants.get(kind);if(old)return old;
 const s=source as T.MeshStandardMaterial,metal=kind==='metal',cloth=kind==='fabric',leather=kind==='leather',photoKind=cloth?'fabric':leather?'leather':kind==='wood'?'wood':kind==='plaster'?'plaster':'metal';
 const material=new T.MeshStandardMaterial({name:s.name,color:s.color?.clone()??new T.Color(1,1,1),map:s.map,vertexColors:s.vertexColors,side:s.side,alphaTest:s.alphaTest,roughness:metal?.52:leather?.78:cloth?.94:.82,metalness:metal?.62:0,emissive:s.emissive?.clone()??new T.Color(0),emissiveIntensity:s.emissiveIntensity??1});
 material.userData={...s.userData,realism:kind,shared:s.userData.shared===true};
 material.onBeforeCompile=shader=>{
  if(quality==='Low')return;
  shader.uniforms.surfaceDetail={value:photographedTexture(photoKind)};shader.uniforms.surfaceRelief={value:photographedTexture(photoKind,'nor_gl')};shader.uniforms.surfaceRough={value:photographedTexture(photoKind,'rough')};shader.uniforms.detailGain=detailGain;
  shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vSurfacePoint;varying vec3 vSurfaceAxis;').replace('#include <begin_vertex>','#include <begin_vertex>\nvSurfacePoint=position;vSurfaceAxis=normal;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nuniform sampler2D surfaceDetail;uniform sampler2D surfaceRelief;uniform sampler2D surfaceRough;uniform float detailGain;varying vec3 vSurfacePoint;varying vec3 vSurfaceAxis;vec2 surfaceUV(){vec3 n=abs(vSurfaceAxis);return (n.x>n.y&&n.x>n.z?vSurfacePoint.zy:n.y>n.z?vSurfacePoint.xz:vSurfacePoint.xy)*'+(cloth?'4.0':leather?'8.0':metal?'2.5':'1.4')+';}');
  shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
   vec2 detailUV=surfaceUV();vec3 photograph=texture2D(surfaceDetail,detailUV).rgb;float luma=dot(photograph,vec3(.299,.587,.114));float grain=clamp(luma*${({fabric:6.19,leather:24.06,metal:27.72,wood:4.44,plaster:4.05} as Record<string,number>)[photoKind]},.55,1.35);diffuseColor.rgb*=mix(1.0,grain,detailGain*${cloth?'.5':leather?'.45':'.30'});`);
  if(quality==='High'){
   shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>','#include <roughnessmap_fragment>\nroughnessFactor=clamp(roughnessFactor*(.75+.45*texture2D(surfaceRough,surfaceUV()).r),.22,1.0);');
   shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>','#include <normal_fragment_maps>\nvec3 detailNormal=texture2D(surfaceRelief,surfaceUV()).xyz*2.0-1.0;normal=normalize(normal+vec3(detailNormal.xy,0.0)*detailGain*'+(cloth?'.16':'.095')+');');
  }
 };
 material.customProgramCacheKey=()=> 'photographic-surface-v18-'+kind+'-'+quality;trackRealismMaterial(material);variants.set(kind,material);return material;
}
export function realizeModel(root:T.Object3D,kind:SurfaceFinish='metal'){
 const signals=new Set<T.Material>();root.traverse(o=>{if(o.userData.signalMaterial)signals.add(o.userData.signalMaterial);});
 root.traverse(o=>{if(!(o instanceof T.Mesh)||o.userData.hitbox||o.userData.tripBeam||o.userData.reticle)return;const convert=(m:T.Material)=>{if(signals.has(m))return m;const c=(m as T.MeshBasicMaterial).color;const lum=c?(c.r+c.g+c.b)/3:.5;return surfaceMaterial(m,kind==='metal'&&lum<.035?'polymer':kind);};o.material=Array.isArray(o.material)?o.material.map(convert):convert(o.material);if(o.userData.deviceMaterial)o.userData.deviceMaterial=o.material;o.castShadow=o.receiveShadow=true;});return root;
}
/** Retains the map atlas and every sectional-destruction shader branch. Adds only shading. */
export function mapSurfaceShader(shader:{uniforms:Record<string,any>,fragmentShader:string}){
 if(quality==='Low')return;
 shader.uniforms.wallPhoto={value:photographedTexture('plaster')};shader.uniforms.woodPhoto={value:photographedTexture('wood')};shader.uniforms.wallNormal={value:photographedTexture('plaster','nor_gl')};shader.uniforms.detailGain=detailGain;
 shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nuniform sampler2D wallPhoto;uniform sampler2D woodPhoto;uniform sampler2D wallNormal;uniform float detailGain;');
 shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
 vec3 worldAxis=abs(cross(dFdx(vMapWorld),dFdy(vMapWorld)));vec2 metricUV=worldAxis.y>worldAxis.x&&worldAxis.y>worldAxis.z?vMapWorld.xz:worldAxis.x>worldAxis.z?vMapWorld.zy:vMapWorld.xy;
 vec3 base=diffuseColor.rgb;float warm=smoothstep(.02,.13,base.r-base.b)*step(base.g,base.r)*step(base.r,.68);
 vec3 scan=warm>.5?texture2D(woodPhoto,metricUV*.45).rgb:texture2D(wallPhoto,metricUV*.55).rgb;float brightness=dot(scan,vec3(.299,.587,.114));diffuseColor.rgb*=mix(1.0,clamp(brightness*mix(4.05,4.44,step(.5,warm)),.55,1.30),.65*detailGain);`);
 if(quality==='High')shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>','#include <normal_fragment_maps>\nvec3 surfaceMicro=texture2D(wallNormal,metricUV*.55).xyz*2.0-1.0;normal=normalize(normal+vec3(surfaceMicro.xy,0.0)*.14*detailGain);');
}

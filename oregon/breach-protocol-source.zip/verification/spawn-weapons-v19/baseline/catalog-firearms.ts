import {ventedHandguard} from './weapon-shell';
import {beveledBox} from './model-detail';
import * as THREE from 'three';import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';import {weaponCatalog,weaponModel,weaponRail,weaponPoint} from './weapon-catalog';import {finishMaterial,paintUV} from './cosmetics';
// Original low-poly silhouettes: shared receiver-space rail and grip coordinates.
export function catalogFirearm(id:number,skin:unknown){const root=new THREE.Group(),model=weaponModel(id),pistol=model===5,shotgun=model===1,compact=model===2,paint=finishMaterial(skin),dark=new THREE.MeshLambertMaterial({color:0x273136}),metal=new THREE.MeshLambertMaterial({color:0x6c7679}),batches=new Map<THREE.Material,THREE.BufferGeometry[]>(),magazine=new THREE.Group();
 const add=(g:THREE.BufferGeometry,m:THREE.Material)=>{const flat=g.index?g.toNonIndexed():g;if(flat!==g)g.dispose();const list=batches.get(m)??[];list.push(flat);batches.set(m,list);},box=(w:number,h:number,d:number,x:number,y:number,z:number,m=paint)=>{if(m===dark&&w>.03&&h>.04&&d>.10&&z<-.10){for(const g of ventedHandguard(w,h,d))add(g.translate(x,y,z),m);}else add(beveledBox(w,h,d).translate(x,y,z),m);},tube=(r:number,l:number,x:number,y:number,z:number,m=metal)=>{const g=new THREE.CylinderGeometry(r,r,l,10);g.rotateX(Math.PI/2);g.translate(x,y,z);add(g,m);};
 const muzzle=weaponPoint(id)[2],rail=weaponRail(id),bullpup=id===8;
 if(pistol){box(.030,.034,.19,0,.014,-.04);box(.032,.025,.18,0,-.013,-.033,dark);box(.030,.095,.042,0,-.066,.029,dark);tube(.006,.018,0,.012,muzzle+.009);for(const x of [-.014,.014])box(.003,.025,.048,x,-.034,-.025,dark);box(.030,.004,.048,0,-.047,-.025,dark);if(id===15){box(.030,.07,.035,0,-.062,-.112,dark);}for(let i=0;i<8;i++)for(const x of [-.015,.015])box(.001,.018,.002,x,.014,.006+i*.004,metal);
 }else if(id===11){box(.046,.075,.22,0,.010,-.025);tube(.014,.45,0,.018,-.305);tube(.014,.45,0,-.010,-.305);box(.045,.040,.19,0,-.025,-.24,dark);box(.036,.095,.065,0,-.055,.13,dark);box(.047,.11,.18,0,-.045,.26,dark);
 }else{box(compact?.038:.052,.075,compact?.19:.30,0,.010,compact?-.025:-.045);tube(shotgun?.012:.009,Math.abs(muzzle)-.12,0,.018,(muzzle-.12)/2);box(compact?.041:.052,.062,compact?.12:.24,0,-.002,compact?-.17:-.27,dark);if(id===6){box(.04,.018,.17,0,.092,-.045,dark);for(const x of [-.019,.019])box(.005,.05,.04,x,.06,.02,dark);}if(bullpup){box(.055,.12,.18,0,-.02,.19,dark);}else if(id===7){box(.04,.08,.095,0,-.05,.13,dark);}else{box(.025,.026,.16,0,.002,.17,metal);box(.044,.115,.030,0,-.040,.25,dark);}box(.028,.10,.040,0,-.08,.052,dark);for(const x of [-.014,.014]){box(.003,.030,.006,x,-.048,.004,dark);box(.003,.004,.05,x,-.064,.025,dark);}for(let i=0;i<6;i++)for(const x of [-.027,.027])box(.002,.018,.006,x,.004,-.18-i*.024,metal);if(shotgun){tube(.012,Math.abs(muzzle)-.12,0,-.011,(muzzle-.12)/2,dark);}
 }
 // Silhouette refinements share the existing material batches and receiver-space
 // sockets. These are economical original meshes, not scanned Siege assets.
 if(id===7){ // FMG: open carry bridge over the folding polymer receiver.
  for(const x of [-.019,.019])for(const z of [-.13,.045])box(.006,.035,.018,x,.078,z,dark);
  for(const x of [-.019,.019])box(.006,.009,.19,x,.100,-.043,dark);
 }
 if(id===10){ // K1A: two exposed stock rods and a compact butt plate.
  for(const x of [-.016,.016])tube(.0035,.17,x,.012,.184,metal);
  box(.044,.09,.010,0,-.023,.274,dark);
 }
 if(id===15){ // C75's spare-magazine foregrip, heel and slide controls.
  for(const x of [-.0155,.0155])for(let i=0;i<4;i++)box(.0015,.004,.026,x,-.045-i*.014,-.112,metal);
  box(.033,.007,.038,0,-.100,-.112,dark);box(.003,.008,.022,-.017,-.006,.020,metal);
 }
 // A physical rail supports the optic base, including short machine-pistol rails.
 const railLength=pistol?.07:compact?.15:.21;box(pistol?.022:.030,.008,railLength,0,rail.mountY-.004,rail.rearZ-railLength/2,metal);for(let i=0;i<7;i++)box(pistol?.025:.034,.003,.004,0,rail.mountY-.0015,rail.rearZ-.006-i*(railLength-.012)/6,metal);
 const ironY=rail.mountY+.016;for(const x of [-.005,.005])box(.003,.010,.005,x,ironY-.003,rail.rearZ,metal);box(.003,.017,.004,0,ironY-.004,muzzle+.018,metal);
 if(!shotgun){const z=pistol||compact?.025:bullpup?.19:-.07,g=beveledBox(.024,compact?.17:pistol?.06:.13,.038),mesh=new THREE.Mesh(g,dark);mesh.position.set(0,pistol?-.08:compact?-.12:-.10,z);magazine.add(mesh);root.add(magazine);root.userData.magazine=magazine;}
 for(const [material,geometries] of batches){const geometry=mergeGeometries(geometries)!;geometries.forEach(g=>g.dispose());if(material===paint)paintUV(geometry);root.add(new THREE.Mesh(geometry,material));}root.userData={...root.userData,weapon:id,weaponName:weaponCatalog[id].name,rail:{...rail},finish:skin};return root;}

import * as T from 'three';

export function curvedFaceCover(w:number,h:number){const p:number[]=[],uv:number[]=[],indices:number[]=[];for(let j=0;j<=4;j++)for(let i=0;i<=16;i++){const u=i/16,a=(u-.5)*1.7;p.push(Math.sin(a)*w*.665,(j/4-.5)*h,(1-Math.cos(a))*.075);uv.push(u,j/4);}for(let j=0;j<4;j++)for(let i=0;i<16;i++){const a=j*17+i;indices.push(a,a+17,a+1,a+1,a+17,a+18);}const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();return g;}

/** Tailored volume, elliptical sections and small cloth folds; the authored skeleton and hitboxes remain fixed. */
export function tailoredGeometry(w:number,h:number,d:number){
 const positions:number[]=[],uv:number[]=[],indices:number[]=[],sides=20,rings=12;
 for(let j=0;j<=rings;j++){const v=j/rings,y=(v-.5)*h,end=Math.sin(Math.PI*v),taper=.84+.16*end;
  for(let i=0;i<=sides;i++){const u=i/sides,a=u*Math.PI*2,fold=(Math.sin(a*5+v*13)+.45*Math.sin(a*9-v*19))*.008*end;positions.push(Math.cos(a)*(w*.5*taper+fold),y,Math.sin(a)*(d*.5*taper+fold*.55));uv.push(u,v);}
 }
 for(let j=0;j<rings;j++)for(let i=0;i<sides;i++){const a=j*(sides+1)+i,b=a+sides+1;indices.push(a,b,a+1,a+1,b,b+1);}
 // Caps do not create open holes at cuffs or stance transitions.
 for(const j of [0,rings])for(let i=1;i<sides-1;i++){const a=j*(sides+1);indices.push(a,a+(j?i:i+1),a+(j?i+1:i));}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();return g;
}
export function characterTailoring(parts:{body:T.Group,headGroup:T.Group,detail:T.Group,leftLeg:T.Group,rightLeg:T.Group},operator:number,cloth:T.Material,armor:T.Material,metal:T.Material,skin:T.Material,box:(parent:T.Group,x:number,y:number,z:number,w:number,h:number,d:number,m:T.Material)=>T.Mesh){
 const {detail,headGroup}=parts;
 const sphere=(parent:T.Group,x:number,y:number,z:number,rx:number,ry:number,rz:number,m:T.Material)=>{const mesh=new T.Mesh(new T.SphereGeometry(1,20,14).scale(rx,ry,rz),m);mesh.position.set(x,y,z);parent.add(mesh);return mesh;};
 // Ear protection, headband, boom microphone and curved brow. Eyewear is independent of the skull volume.
 for(const side of [-1,1]){sphere(headGroup,side*.133,.006,.004,.027,.052,.043,armor);box(headGroup,side*.148,.010,-.025,.012,.065,.045,metal);box(headGroup,side*.105,-.045,-.118,.010,.010,.045,armor);}
 sphere(headGroup,-.094,-.081,-.161,.010,.008,.023,armor);
 if([0,3,7].includes(operator)){
  sphere(headGroup,0,-.008,-.116,.015,.030,.021,skin);box(headGroup,0,-.065,-.112,.035,.004,.005,armor);
  for(const side of [-1,1]){sphere(headGroup,side*.047,.022,-.116,.035,.017,.010,armor);box(headGroup,side*.047,.021,-.126,.044,.017,.003,metal);box(headGroup,side*.055,.049,-.118,.057,.008,.010,cloth);}
 }
 // MOLLE rows, webbing bar tacks, pouch seams, zipper teeth and side-release buckles.
 for(let row=0;row<5;row++)for(let col=0;col<6;col++){const x=-.171+col*.068,y=.195-row*.065;box(detail,x,y,-.232,.055,.012,.006,cloth);for(const side of [-1,1])box(detail,x+side*.024,y,-.237,.002,.009,.002,metal);}
 for(const x of [-.15,.15]){box(detail,x,.17,-.24,.043,.034,.012,armor);box(detail,x,.17,-.248,.026,.017,.003,metal);}
 for(let i=0;i<18;i++)box(detail,.213,.20-i*.023,-.139,.004,.007,.005,metal);
 for(const x of [-.13,0,.13]){box(detail,x,-.04,-.301,.082,.007,.008,armor);box(detail,x,-.13,-.301,.082,.005,.008,cloth);for(const side of [-1,1])box(detail,x+side*.043,-.05,-.301,.003,.15,.004,cloth);}
 // Curved shoulder plates and a sleeve pocket, replacing featureless upper-arm blocks visually.
 for(const side of [-1,1]){sphere(parts.body,side*.235,.205,0,.067,.055,.11,armor);box(detail,side*.243,.115,-.065,.012,.095,.063,cloth);}
 const patch=box(detail,-.252,.135,-.076,.006,.042,.040,armor);patch.name='Sleeve identification patch';
}

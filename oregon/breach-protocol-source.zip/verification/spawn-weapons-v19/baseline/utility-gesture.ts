import type {Game} from './game';
import {useUtility} from './secondary-gadgets';
import {validatedUtility} from './loadouts';
export const utilityGestureDuration=.70,utilityReleaseAt=.36;
export function cancelUtilityGesture(g:Game){if(g.utilityThrow>0){g.utilityThrow=0;g.utilityThrowKind='';g.utilityReleased=false;g.gadgetTime=0;}}
export function beginUtilityGesture(g:Game,kind:string=g.utility){
 if(!g.authority||g.hp<=0||g.downed||g.observing||g.action>0||g.operatorThrow>0||g.utilityThrow>0||g.utilityCooldown>0||g.rappel||g.vaultFrom||!['prep','action'].includes(g.phase))return false;
 if(kind==='shock-drone'){if(g.operator!==9||g.gadgetCount<=0||g.phase!=='action')return false;}
 else{g.utility=validatedUtility(g.operator,g.utility);if(g.utilityCount<=0||g.phase==='prep'&&g.team===0)return false;kind=g.utility;}
 g.cancelReload();g.inspect=0;g.ads=false;g.utilityThrow=utilityGestureDuration;g.utilityThrowKind=kind;g.utilityReleased=false;g.gadgetTime=utilityGestureDuration;g.emitSound('gadget',g.pos,.12);return true;
}
export function updateUtilityGesture(g:Game,dt:number){if(g.utilityThrow<=0)return;
 if(g.hp<=0||g.downed||g.observing||g.reload>0||g.action>0||g.state==='sprint'||!['prep','action'].includes(g.phase)){cancelUtilityGesture(g);return;}
 const before=g.utilityThrow;g.utilityThrow=Math.max(0,g.utilityThrow-dt);const threshold=utilityGestureDuration-utilityReleaseAt;
 if(before>threshold&&g.utilityThrow<=threshold&&!g.utilityReleased){g.utilityReleased=true;if(g.authority){const count=g.utilityCount;
  if(g.utilityThrowKind==='shock-drone'){if(!g.deployShockDrone()){cancelUtilityGesture(g);return;}}
  else{if(g.utility!==g.utilityThrowKind){cancelUtilityGesture(g);return;}useUtility(g);if(g.utilityCount===count){cancelUtilityGesture(g);return;}}
  g.gadgetTime=g.utilityThrow;
 }}
 if(g.utilityThrow===0){g.utilityThrowKind='';g.utilityReleased=false;}
}

import {realismQuality,trackRealismMaterial,mapSurfaceShader} from './realism-materials';
import {sweepSphereTriangle} from './swept-sphere';
import {triangleFootprintSupport} from './triangle-footprint';
import {mapGeometry,mapCollision} from './map-variant';
import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {MeshoptDecoder} from 'meshoptimizer';
import {MeshBVH,ExtendedTriangle} from 'three-mesh-bvh';
import type {World,Panel} from './world';
import {loadMapBatches} from './map-batches';
type Collider={geometry:THREE.BufferGeometry,bvh:MeshBVH,box:THREE.Box3,owners:Uint16Array,objects:Panel[],broken:Uint8Array};
type DestructionVolume={panel:Panel,box:THREE.Box3,axis:'x'|'y'|'z'};
type Tile={page:number,x:number,y:number};
const boundsGeo=new THREE.BoxGeometry(1,1,1),boundsMat=new THREE.MeshBasicMaterial();
// Source material 534 is the lamp beam effect (15 cone meshes), not architecture.
// Baking its shader into the diffuse atlas made it opaque and physically blocking.
const sourceLightEffects=new Set(['mat_534.001']);
const floatAttribute=(a:THREE.BufferAttribute|THREE.InterleavedBufferAttribute)=>{const data=new Float32Array(a.count*a.itemSize);for(let i=0;i<a.count;i++)for(let j=0;j<a.itemSize;j++)data[i*a.itemSize+j]=a.getComponent(i,j);return new THREE.BufferAttribute(data,a.itemSize);};
export class ImportedOregon{
 private disposed=false;
 colliders:Collider[]=[];batches:THREE.Mesh[]=[];sourceObjects=new Map<string,Panel[]>();
 private colliderCells=new Map<string,Collider[]>();private groundCells=new Map<string,Collider[]>();private colliderOrder=new WeakMap<Collider,number>();
 private nearby(x:number,z:number){return this.colliderCells.get(Math.floor(x/8)+':'+Math.floor(z/8))??[];}
 private index(c:Collider){this.colliderOrder.set(c,this.colliders.length-1);for(let x=Math.floor(c.box.min.x/8);x<=Math.floor(c.box.max.x/8);x++)for(let z=Math.floor(c.box.min.z/8);z<=Math.floor(c.box.max.z/8);z++){const key=x+':'+z,list=this.colliderCells.get(key)??[];list.push(c);this.colliderCells.set(key,list);this.groundCells.delete(key);}}
 destructionVolumes:DestructionVolume[]=[];
 private cutCount={value:0};private cutMeta={value:new Float32Array(128*4)};private maskData=new Uint8Array(512*1024);private maskTexture=new THREE.DataTexture(this.maskData,512,1024,THREE.RedFormat,THREE.UnsignedByteType);private visualRevision=-1;private cutIndexData=new Uint8Array(512*512);private cutIndexTexture=new THREE.DataTexture(this.cutIndexData,512,512,THREE.RedFormat,THREE.UnsignedByteType);private cutOrigin={value:new THREE.Vector3()};private cutDimensions={value:new THREE.Vector3(1,1,1)};private cutSlots={value:1};private cutLayoutCount=-1;private cutMin={value:new Float32Array(128*3)};private cutMax={value:new Float32Array(128*3)};
 private prepareCutIndex(){
  if(this.cutLayoutCount===this.destructionVolumes.length)return;this.cutLayoutCount=this.destructionVolumes.length;
  const bounds=new THREE.Box3();for(const v of this.destructionVolumes)bounds.union(v.box);const origin=bounds.min.clone().divideScalar(2).floor().multiplyScalar(2),dim=bounds.max.clone().sub(origin).divideScalar(2).floor().addScalar(1);this.cutOrigin.value.copy(origin);this.cutDimensions.value.copy(dim);
  const counts=new Map<number,number>();for(const v of this.destructionVolumes)this.cutIndexCells(v.box,i=>counts.set(i,(counts.get(i)??0)+1));const slots=Math.max(1,...counts.values());if(slots>32||dim.x*dim.y*dim.z*slots>this.cutIndexData.length)throw Error('Destruction spatial atlas capacity exceeded');this.cutSlots.value=slots;
 }
 private cutIndexCells(box:THREE.Box3,visit:(index:number)=>void){const origin=this.cutOrigin.value,dim=this.cutDimensions.value,min=box.min.clone().sub(origin).divideScalar(2).floor(),max=box.max.clone().sub(origin).divideScalar(2).floor();for(let y=min.y;y<=max.y;y++)for(let z=min.z;z<=max.z;z++)for(let x=min.x;x<=max.x;x++)visit(x+dim.x*(z+dim.z*y));}
 syncDestruction(replay?:Map<number,Panel>){
  if(!replay&&this.visualRevision===this.world.surfaceRevision)return;this.visualRevision=replay?-1:this.world.surfaceRevision;
  const active=this.destructionVolumes.filter(v=>{const p=replay?.get(this.world.panels.indexOf(v.panel))??v.panel;return p.broken||p.grid?.removed;});
  if(active.length>128)throw Error('Destruction surface uniform capacity exceeded');
  this.prepareCutIndex();this.cutCount.value=active.length;this.maskData.fill(0);this.cutIndexData.fill(0);
  active.forEach((v,i)=>{this.cutIndexCells(v.box,cell=>{const base=cell*this.cutSlots.value;for(let j=0;j<this.cutSlots.value;j++)if(!this.cutIndexData[base+j]){this.cutIndexData[base+j]=i+1;break;}});const p=replay?.get(this.world.panels.indexOf(v.panel))??v.panel;v.box.min.toArray(this.cutMin.value,i*3);v.box.max.toArray(this.cutMax.value,i*3);
   this.cutMeta.value.set([p.broken?-1:i,p.grid?.nx??1,p.grid?.ny??1,v.axis==='x'?0:v.axis==='y'?1:2],i*4);
   if(!p.broken&&p.grid){const ox=(i%8)*64,oy=Math.floor(i/8)*64;for(let y=0;y<p.grid.ny;y++)for(let x=0;x<p.grid.nx;x++)if(p.grid.health[y*p.grid.nx+x]===0)this.maskData[(oy+y)*512+ox+x]=255;}
  });this.maskTexture.needsUpdate=true;this.cutIndexTexture.needsUpdate=true;
 }
 private volumeCells=new Map<string,DestructionVolume[]>();private activeVolumeCells=new Map<string,DestructionVolume[]>();private volumeCount=-1;private holeIndexRevision=-1;
 private nearVolumes(point:THREE.Vector3,r=0,active=false){
  if(this.volumeCount!==this.destructionVolumes.length){this.volumeCells.clear();this.volumeCount=this.destructionVolumes.length;for(const v of this.destructionVolumes)this.indexVolume(v,this.volumeCells);this.holeIndexRevision=-1;}
  if(active&&this.holeIndexRevision!==this.world.surfaceRevision){this.activeVolumeCells.clear();for(const v of this.destructionVolumes)if(v.panel.broken||v.panel.grid?.removed)this.indexVolume(v,this.activeVolumeCells);this.holeIndexRevision=this.world.surfaceRevision;}
  const map=active?this.activeVolumeCells:this.volumeCells,x0=Math.floor((point.x-r)/8),x1=Math.floor((point.x+r)/8),z0=Math.floor((point.z-r)/8),z1=Math.floor((point.z+r)/8);
  if(x0===x1&&z0===z1)return map.get(x0+':'+z0)??[];const found=new Set<DestructionVolume>();for(let x=x0;x<=x1;x++)for(let z=z0;z<=z1;z++)for(const v of map.get(x+':'+z)??[])found.add(v);return [...found];
 }
 private indexVolume(v:DestructionVolume,map:Map<string,DestructionVolume[]>){for(let x=Math.floor(v.box.min.x/8);x<=Math.floor(v.box.max.x/8);x++)for(let z=Math.floor(v.box.min.z/8);z<=Math.floor(v.box.max.z/8);z++){const key=x+':'+z,list=map.get(key)??[];list.push(v);map.set(key,list);}}
 private gridOpening(point:THREE.Vector3,r:number,height:number,x:number,y:number,z:number){
  const volumes=this.nearVolumes(point,r,true),initial=volumes.find(v=>v.panel.grid&&v.box.containsPoint(point)&&!v.panel.grid.materialAt(point[v.axis==='x'?'z':'x'],point[v.axis==='y'?'z':'y']));if(!initial)return false;
  const axis=initial.axis,u=axis==='x'?'z':'x',v=axis==='y'?'z':'y',center=u==='x'?x:z;
  const loU=center-r,hiU=center+r,loV=axis==='y'?z-r:y,hiV=axis==='y'?z+r:y+height;
  if(r===0&&height===0)return true;
  const candidates=volumes.filter(n=>n.axis===axis&&(n.panel.broken||n.panel.grid?.removed)&&point[axis]>=n.box.min[axis]&&point[axis]<=n.box.max[axis]&&n.box.max[u]>=loU&&n.box.min[u]<=hiU&&n.box.max[v]>=loV-.075&&n.box.min[v]<=hiV);
  const us=[loU,hiU],vs=[loV,hiV];for(const n of candidates){for(const b of [n.box.min[u],n.box.max[u]])if(b>loU&&b<hiU)us.push(b);for(const b of [n.box.min[v],n.box.max[v]])if(b>loV&&b<hiV)vs.push(b);}us.sort((a,b)=>a-b);vs.sort((a,b)=>a-b);
  for(let i=0;i<us.length-1;i++)for(let j=0;j<vs.length-1;j++){if(us[i+1]-us[i]<1e-7||vs[j+1]-vs[j]<1e-7)continue;const cu=(us[i]+us[i+1])/2,cv=(vs[j]+vs[j+1])/2;
   if(!candidates.some(n=>cu>=n.box.min[u]&&cu<=n.box.max[u]&&cv>=n.box.min[v]-(axis==='y'?.005:.075)&&cv<=n.box.max[v]+.005&&(n.panel.broken||n.panel.grid!.clear(Math.max(n.box.min[u],us[i]),Math.min(n.box.max[u],us[i+1]),Math.max(n.box.min[v],vs[j]),Math.min(n.box.max[v],vs[j+1])))))return false;
  }return true;
 }

 hole(point:THREE.Vector3,r=0,height=0,x=point.x,y=point.y,z=point.z){if(this.gridOpening(point,r,height,x,y,z))return true;const volumes=this.nearVolumes(point,r,true);return volumes.some(v=>{
  if(!v.panel.broken||!v.box.containsPoint(point))return false;
  const fitsY=(b:THREE.Box3,p:Panel)=>y>=b.min.y-(p.kind==='soft'?.075:.005)&&y+height<=b.max.y+.005;
  if(v.axis==='y')return x-r>=v.box.min.x-.005&&x+r<=v.box.max.x+.005&&z-r>=v.box.min.z-.005&&z+r<=v.box.max.z+.005;
  if(!fitsY(v.box,v.panel))return false;
  const lateral=v.axis==='x'?'z':'x',lo=(lateral==='x'?x:z)-r,hi=(lateral==='x'?x:z)+r;
  let min=v.box.min[lateral],max=v.box.max[lateral];if(lo>=min-.005&&hi<=max+.005)return true;
  // Adjacent destroyed panels form one opening. An intact neighbor never extends it.
  let changed=true;while(changed){changed=false;for(const n of volumes){if(!n.panel.broken||n.axis!==v.axis||!fitsY(n.box,n.panel)||point[v.axis]<n.box.min[v.axis]||point[v.axis]>n.box.max[v.axis]||n.box.min[lateral]>max+.005||n.box.max[lateral]<min-.005)continue;const a=Math.min(min,n.box.min[lateral]),b=Math.max(max,n.box.max[lateral]);if(a<min||b>max){min=a;max=b;changed=true;}}}
  return lo>=min-.005&&hi<=max+.005;
 });}

 surface(point:THREE.Vector3){return this.nearVolumes(point).find(v=>!v.panel.broken&&v.box.containsPoint(point))?.panel;}
 get shaderTextures(){return [this.maskTexture,this.cutIndexTexture];}
 dispose(){if(this.disposed)return;this.disposed=true;for(const collider of this.colliders)collider.geometry.dispose();this.maskTexture.dispose();this.cutIndexTexture.dispose();this.colliders=[];this.batches=[];this.sourceObjects.clear();this.colliderCells.clear();this.groundCells.clear();this.volumeCells.clear();this.activeVolumeCells.clear();this.destructionVolumes=[];this.groundCache.clear();this.collisionCache.clear();this.maskData=new Uint8Array();this.cutIndexData=new Uint8Array();this.maskTexture.image.data=this.maskData;this.cutIndexTexture.image.data=this.cutIndexData;this.cutMeta.value.fill(0);this.cutMin.value.fill(0);this.cutMax.value.fill(0);this.cutCount.value=0;}
 constructor(public world:World){}
 async load(progress:(text:string)=>void,includeCollision=true){
  const base='/assets/oregon/',visualBase=mapGeometry==='scratch'?base+'scratch/':mapGeometry==='reference'?base:base+'lod/',manifest=await fetch(visualBase+'manifest.json').then(r=>r.json()),atlas=await fetch(base+(mapGeometry==='scratch'?'scratch/palette.json':mapGeometry==='reference'?'source-atlas.json':(new URLSearchParams(location.search).get('textures')==='reference'?'source-atlas-fast.json':'source-atlas-simple.json'))).then(r=>r.json());
  const collisionTask=includeCollision&&(mapGeometry==='browser'||mapGeometry==='scratch')?this.loadCollision(progress):null;collisionTask?.catch(()=>{});const maps=await Promise.all(atlas.pages.map((p:string)=>new THREE.TextureLoader().loadAsync(base+p)));const materials=maps.map((map:THREE.Texture,page:number)=>{const grid=atlas.grids?.[page]??16,atlasGrid=Array.isArray(grid)?new THREE.Vector2(grid[0],grid[1]):new THREE.Vector2(grid,grid),atlasCombined=atlas.layout==='mask64-marking256-v1'?1:0;map.flipY=false;map.colorSpace=THREE.SRGBColorSpace;map.anisotropy=1;const ambient=false;const m=ambient?new THREE.MeshBasicMaterial({map,alphaTest:.35,side:THREE.DoubleSide,vertexColors:true}):new THREE.MeshPhongMaterial({map,alphaTest:.35,side:THREE.DoubleSide,vertexColors:true,shininess:8,specular:0x111314});
   m.userData.mapSurface=true;trackRealismMaterial(m);m.onBeforeCompile=shader=>{shader.uniforms.atlasGrid={value:atlasGrid};shader.uniforms.atlasCombined={value:atlasCombined};shader.uniforms.cutIndex={value:this.cutIndexTexture};shader.uniforms.cutOrigin=this.cutOrigin;shader.uniforms.cutDimensions=this.cutDimensions;shader.uniforms.cutSlots=this.cutSlots;shader.uniforms.cutMask={value:this.maskTexture};shader.uniforms.cutMeta=this.cutMeta;shader.uniforms.cutCount=this.cutCount;shader.uniforms.cutMin=this.cutMin;shader.uniforms.cutMax=this.cutMax;shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nuniform vec2 atlasGrid; uniform float atlasCombined; attribute vec2 atlasTile; varying vec2 vAtlasTile; varying vec3 vMapWorld;').replace('#include <begin_vertex>','#include <begin_vertex>\nvAtlasTile=atlasTile/atlasGrid;vec4 mapPosition=vec4(position,1.0);\n#ifdef USE_INSTANCING\nmapPosition=instanceMatrix*mapPosition;\n#endif\nvMapWorld=(modelMatrix*mapPosition).xyz;');shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nuniform vec2 atlasGrid; uniform float atlasCombined; varying vec2 vAtlasTile; varying vec3 vMapWorld; uniform int cutCount; uniform vec3 cutMin[128]; uniform vec3 cutMax[128]; uniform vec4 cutMeta[128]; uniform sampler2D cutMask; uniform sampler2D cutIndex; uniform vec3 cutOrigin; uniform vec3 cutDimensions; uniform int cutSlots;').replace('#include <map_fragment>','if(cutCount>0){vec3 spatial=floor((vMapWorld-cutOrigin)/2.0);if(all(greaterThanEqual(spatial,vec3(0.0)))&&all(lessThan(spatial,cutDimensions))){float cellId=spatial.x+cutDimensions.x*(spatial.z+cutDimensions.z*spatial.y);for(int j=0;j<32;j++){if(j>=cutSlots)break;float address=cellId*float(cutSlots)+float(j);int i=int(floor(texture2D(cutIndex,(vec2(mod(address,512.0),floor(address/512.0))+0.5)/512.0).r*255.0+0.5))-1;if(i<0)break;if(all(greaterThanEqual(vMapWorld,cutMin[i]))&&all(lessThanEqual(vMapWorld,cutMax[i]))){vec4 meta=cutMeta[i];if(meta.x<0.0)discard;vec3 rel=(vMapWorld-cutMin[i])/(cutMax[i]-cutMin[i]);vec2 local=meta.w<0.5?rel.zy:(meta.w<1.5?rel.xz:rel.xy);vec2 cell=min(floor(local*meta.yz),meta.yz-1.0);vec2 tile=vec2(mod(meta.x,8.0),floor(meta.x/8.0))*64.0;if(texture2D(cutMask,(tile+cell+0.5)/vec2(512.0,1024.0)).r>0.5)discard;}}}}vec4 sampledDiffuseColor=texture2D(map,vAtlasTile+(fract(vMapUv)*.992+.004)*(1.0+3.0*atlasCombined*step(.499,vAtlasTile.x))/atlasGrid); diffuseColor*=sampledDiffuseColor;');if(ambient)shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>','#include <color_fragment>\nvec3 mapAmbientNormal=cross(dFdx(vMapWorld),dFdy(vMapWorld));mapAmbientNormal*=inversesqrt(max(dot(mapAmbientNormal,mapAmbientNormal),1e-16));diffuseColor.rgb*=.75+.20*abs(mapAmbientNormal.y)+.05*abs(mapAmbientNormal.x);');mapSurfaceShader(shader);};m.customProgramCacheKey=()=>String(atlasCombined)+'realism-v17'+realismQuality()+(ambient?'oregon-atlas-sectional-spatial-v4-ambient':'oregon-atlas-sectional-spatial-v4');return m;});
  if(mapGeometry==='browser'||mapGeometry==='scratch'){
   this.batches=await loadMapBatches(materials,progress);for(const mesh of this.batches){this.world.scene.add(mesh);this.world.staticBatches.push(mesh);}
   if(collisionTask)await collisionTask;return;
  }
  const loader=new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);let completed=0;
  const queue=[...manifest.sectors];await Promise.all(Array.from({length:3},async()=>{while(queue.length){const sector=queue.shift();const json=await fetch(visualBase+sector.file).then(r=>r.json()),tiles=new Map<string,Tile>();for(const m of json.materials??[]){const index=m.pbrMetallicRoughness?.baseColorTexture?.index;const image=json.images?.[json.textures?.[index]?.source];tiles.set(m.name,atlas.materials?.[m.name]??atlas.tiles?.[image?.uri]??{page:0,x:0,y:0});}
    for(const m of json.materials??[]){delete m.pbrMetallicRoughness?.baseColorTexture;delete m.pbrMetallicRoughness?.metallicRoughnessTexture;delete m.normalTexture;delete m.occlusionTexture;delete m.emissiveTexture;}json.images=[];json.textures=[];json.samplers=[];
    const asset=await loader.parseAsync(JSON.stringify(json),visualBase);asset.scene.position.y=-3.6;asset.scene.updateMatrixWorld(true);const groups=new Map<number,THREE.BufferGeometry[]>();asset.scene.traverse(o=>{if(!(o instanceof THREE.Mesh))return;const original=Array.isArray(o.material)?o.material[0]:o.material,tile=tiles.get(original.name)??{page:0,x:0,y:0},geo=new THREE.BufferGeometry();if(sourceLightEffects.has(original.name)||(includeCollision&&original.name==='mat_430.001'))return;for(const key of ['position','normal','uv']){const a=o.geometry.getAttribute(key);if(a)geo.setAttribute(key,floatAttribute(a));}if(o.geometry.index)geo.setIndex(o.geometry.index.clone());if(!geo.getAttribute('uv'))geo.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(geo.getAttribute('position').count*2),2));geo.applyMatrix4(o.matrixWorld);const count=geo.getAttribute('position').count,t=new Float32Array(count*2),color=new Float32Array(count*3),normal=geo.getAttribute('normal');for(let i=0;i<count;i++){t[i*2]=tile.x*16;t[i*2+1]=tile.y*16;const ao=.82+.18*Math.max(0,normal.getY(i));color.fill(ao,i*3,i*3+3);}geo.setAttribute('atlasTile',new THREE.BufferAttribute(t,2));geo.setAttribute('color',new THREE.BufferAttribute(color,3));const list=groups.get(tile.page)??[];list.push(geo);groups.set(tile.page,list);});
    for(const [page,geos] of groups){const geometry=mergeGeometries(geos,false)!;const mesh=new THREE.Mesh(geometry,materials[page]);mesh.userData.importedSector=sector.file;this.world.scene.add(mesh);this.batches.push(mesh);this.world.staticBatches.push(mesh);for(const g of geos)g.dispose();}
    asset.scene.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();for(const m of (Array.isArray(o.material)?o.material:[o.material])){(m as THREE.MeshStandardMaterial).map?.dispose();m.dispose();}}});progress(`Preparing Oregon geometry · ${++completed}/${manifest.sectors.length}`);
   }}));
  if(!includeCollision)return;
  await this.loadCollision(progress);
 }
 async loadCollision(progress:(text:string)=>void){
  const base='/assets/oregon/',folder=mapCollision==='scratch'?'scratch/collision/':mapCollision==='reference'?'collision/':mapCollision==='browser'?'browser/collision/':'collision-fast/';let completed=0;
  const collision=await fetch(base+folder+'manifest.json').then(r=>r.json()),remaining=[...collision.sectors];completed=0;
  await Promise.all(Array.from({length:3},async()=>{while(remaining.length){const sector=remaining.shift(),[meta,response]=await Promise.all([fetch(base+folder+sector.metadata).then(r=>r.json()),fetch(base+folder+sector.file)]);const raw=await response.arrayBuffer(),magic=new Uint8Array(raw,0,2),buffer=magic[0]===31&&magic[1]===139?await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer():raw,h=new Uint32Array(buffer,0,4);if(h[1]!==h[2]*3||buffer.byteLength!==16+h[0]*12+h[1]*4+h[2]*2)throw Error('Invalid collision buffer '+sector.file);const compact=mapCollision==='scratch'&&h[0]<=65535,sourcePositions=new Float32Array(buffer,16,h[0]*3),sourceIndices=new Uint32Array(buffer,16+h[0]*12,h[1]),sourceOwners=new Uint16Array(buffer,16+h[0]*12+h[1]*4,h[2]);if(compact&&sourceIndices.some(i=>i>=h[0]))throw Error('Invalid compact collision index '+sector.file);const positions=compact?sourcePositions.slice():sourcePositions,indices=compact?new Uint16Array(sourceIndices):sourceIndices,owners=compact?sourceOwners.slice():sourceOwners,geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(positions,3));geo.setIndex(new THREE.BufferAttribute(indices,1));geo.computeBoundingBox();const objects:Panel[]=meta.objects.map((o:{name:string,min:number[],max:number[],material:string})=>{const min=new THREE.Vector3().fromArray(o.min),max=new THREE.Vector3().fromArray(o.max),mesh=new THREE.Mesh(boundsGeo,boundsMat);mesh.position.copy(min).add(max).multiplyScalar(.5);mesh.userData.importedCollider=true;mesh.userData.sourceName=o.name;mesh.userData.surfaceMaterial=o.material;mesh.userData.panelOrder=-1;const p:Panel={mesh,min,max,kind:'solid',hp:100,reinforced:false,broken:sourceLightEffects.has(o.material)||['mat_430.001','mat_284.001','mat_138.001'].includes(o.material)};mesh.userData.nonPhysicalSource=sourceLightEffects.has(o.material);mesh.userData.panel=p;const list=this.sourceObjects.get(o.name)??[];list.push(p);this.sourceObjects.set(o.name,list);this.world.indexImportedPanel(p);return p;});const bvh=new MeshBVH(geo,{indirect:true,maxLeafTris:10});const broken=Uint8Array.from(objects,p=>Number(p.broken));objects.forEach((p,index)=>p.mesh.userData.collisionState={values:broken,index});const collider={geometry:geo,bvh,box:geo.boundingBox!,owners,objects,broken};this.colliders.push(collider);this.index(collider);progress(`Preparing Oregon collision · ${++completed}/${collision.sectors.length}`);}}));
  if(mapCollision==='scratch')await this.loadLogicalSources();
 }
 private async loadLogicalSources(){
  const response=await fetch('/assets/oregon/scratch/logical-sources.json');if(!response.ok)throw Error('Logical map definitions unavailable');
  const data=await response.json() as {objects:{name:string,material:string,min:number[],max:number[],reason:string}[]};
  for(const o of data.objects){const min=new THREE.Vector3().fromArray(o.min),max=new THREE.Vector3().fromArray(o.max),mesh=new THREE.Mesh(boundsGeo,boundsMat);mesh.position.copy(min).add(max).multiplyScalar(.5);Object.assign(mesh.userData,{importedCollider:true,sourceName:o.name,surfaceMaterial:o.material,panelOrder:-1,nonPhysicalSource:true,logicalSource:true,permanent:true});const p:Panel={mesh,min,max,kind:'solid',hp:100,reinforced:false,broken:true,defaultBroken:true};mesh.userData.panel=p;const list=this.sourceObjects.get(o.name)??[];list.push(p);this.sourceObjects.set(o.name,list);this.world.indexImportedPanel(p);}
 }
 private collisionCache=new Map<string,boolean>();private collisionRevision=-1;
 collide(x:number,y:number,z:number,r:number,height:number){
  if(this.collisionRevision!==this.world.surfaceRevision){this.collisionCache.clear();this.collisionRevision=this.world.surfaceRevision;}
  const key=x+':'+y+':'+z+':'+r+':'+height,cached=this.collisionCache.get(key);
  if(cached!==undefined)return cached;
  const value=this.collideUncached(x,y,z,r,height);
  if(this.collisionCache.size>=4096)this.collisionCache.delete(this.collisionCache.keys().next().value!);
  this.collisionCache.set(key,value);return value;
 }
 collideUncached(x:number,y:number,z:number,r:number,height:number){const flat=height<2*r,segment=new THREE.Line3(new THREE.Vector3(x,y+r+.025,z),new THREE.Vector3(x,y+Math.max(r+.025,height-r),z)),box=flat?new THREE.Box3(new THREE.Vector3(x-r,y+.025,z-r),new THREE.Vector3(x+r,y+height,z+r)):new THREE.Box3().setFromPoints([segment.start,segment.end]).expandByScalar(r),point=new THREE.Vector3(),capsule=new THREE.Vector3();const candidates=new Set([...this.nearby(x-r,z-r),...this.nearby(x+r,z-r),...this.nearby(x-r,z+r),...this.nearby(x+r,z+r)]);for(const c of candidates){if(!c.box.intersectsBox(box))continue;const blocked=c.bvh.shapecast({intersectsBounds:b=>b.intersectsBox(box),intersectsTriangle:(triangle:ExtendedTriangle,index:number)=>{if(c.broken[c.owners[index]])return false;if(Math.max(triangle.a.y,triangle.b.y,triangle.c.y)<=y+.025)return false;const distance=triangle.closestPointToSegment(segment,point,capsule);if(this.hole(point,r,height,x,y,z))return false;return flat?box.intersectsTriangle(triangle):distance<r-.004;}});if(blocked)return true;}return false;}
 private rayCandidates(origin:THREE.Vector3,dir:THREE.Vector3,length:number){const found=new Set<Collider>();let x=Math.floor(origin.x/8),z=Math.floor(origin.z/8);const sx=Math.sign(dir.x),sz=Math.sign(dir.z),dx=sx?8/Math.abs(dir.x):Infinity,dz=sz?8/Math.abs(dir.z):Infinity;let tx=sx?((x+(sx>0?1:0))*8-origin.x)/dir.x:Infinity,tz=sz?((z+(sz>0?1:0))*8-origin.z)/dir.z:Infinity,t=0;const add=(a:number,b:number)=>{for(const c of this.colliderCells.get(a+':'+b)??[])found.add(c);};for(let i=0;i<512&&t<=length;i++){add(x,z);if(!Number.isFinite(Math.min(tx,tz)))break;if(Math.abs(tx-tz)<1e-9){add(x+sx,z);add(x,z+sz);t=tx;x+=sx;z+=sz;tx+=dx;tz+=dz;}else if(tx<tz){t=tx;x+=sx;tx+=dx;}else{t=tz;z+=sz;tz+=dz;}}return found;}
 trace(origin:THREE.Vector3,dir:THREE.Vector3,maxDistance:number,first=false){const ray=new THREE.Ray(origin,dir),hits:{distance:number,point:THREE.Vector3,object:THREE.Mesh,face:{normal:THREE.Vector3}}[]=[];for(const c of this.rayCandidates(origin,dir,maxDistance)){const cross=ray.intersectBox(c.box,new THREE.Vector3());if(!cross||cross.distanceTo(origin)>maxDistance&&!c.box.containsPoint(origin))continue;let found=first?[c.bvh.raycastFirst(ray,THREE.DoubleSide,0,maxDistance)].filter(Boolean):c.bvh.raycast(ray,THREE.DoubleSide,0,maxDistance);if(first&&found[0]&&(c.broken[c.owners[found[0].faceIndex!]]||this.hole(found[0].point)))found=c.bvh.raycast(ray,THREE.DoubleSide,0,maxDistance);for(const h of found.sort((a,b)=>a!.distance-b!.distance)){const p=c.objects[c.owners[h.faceIndex!]];if(c.broken[c.owners[h.faceIndex!]]||this.hole(h.point))continue;hits.push({distance:h.distance,point:h.point,object:p.mesh,face:{normal:h.face!.normal}});if(first)break;}}return hits.sort((a,b)=>a.distance-b.distance);}
 /** Boolean visibility queries stop at the first intact occluder. */
 occluded(origin:THREE.Vector3,dir:THREE.Vector3,maxDistance:number){
  const ray=new THREE.Ray(origin,dir),cross=new THREE.Vector3();
  for(const c of this.rayCandidates(origin,dir,maxDistance)){
   if(!ray.intersectBox(c.box,cross)||cross.distanceTo(origin)>maxDistance&&!c.box.containsPoint(origin))continue;
   const hit=c.bvh.raycastFirst(ray,THREE.DoubleSide,0,maxDistance);if(!hit)continue;
   if(!c.broken[c.owners[hit.faceIndex!]]&&!this.hole(hit.point))return true;
   for(const h of c.bvh.raycast(ray,THREE.DoubleSide,0,maxDistance))if(!c.broken[c.owners[h.faceIndex!]]&&!this.hole(h.point))return true;
  }return false;
 }
 sweepSphere(from:THREE.Vector3,dir:THREE.Vector3,length:number,radius:number):{distance:number,point:THREE.Vector3,object:THREE.Mesh,face:{normal:THREE.Vector3}}|null{
  const box=new THREE.Box3().setFromPoints([from,from.clone().addScaledVector(dir,length)]).expandByScalar(radius);
  let best:null|{distance:number,point:THREE.Vector3,object:THREE.Mesh,face:{normal:THREE.Vector3}}=null;
  for(const c of this.sweepCandidates(box)){if(!c.box.intersectsBox(box))continue;
   c.bvh.shapecast({intersectsBounds:b=>b.intersectsBox(box),intersectsTriangle:(triangle:ExtendedTriangle,index:number)=>{
    if(c.broken[c.owners[index]])return false;
    const hit=sweepSphereTriangle(from,dir,best?.distance??length,radius,triangle);if(!hit)return false;
    const center=from.clone().addScaledVector(dir,hit.distance);
    if(this.hole(hit.point,radius,2*radius,center.x,center.y-radius,center.z))return false;
    best={distance:hit.distance,point:hit.point,object:c.objects[c.owners[index]].mesh,face:{normal:hit.normal}};return false;
   }});
  }
  return best;
 }
 private sweepCandidates(box:THREE.Box3){const cells=(Math.floor(box.max.x/8)-Math.floor(box.min.x/8)+1)*(Math.floor(box.max.z/8)-Math.floor(box.min.z/8)+1);if(!Number.isFinite(cells)||cells>128)return this.colliders;const found=new Set<Collider>();for(let x=Math.floor(box.min.x/8);x<=Math.floor(box.max.x/8);x++)for(let z=Math.floor(box.min.z/8);z<=Math.floor(box.max.z/8);z++)for(const collider of this.colliderCells.get(x+':'+z)??[])found.add(collider);return [...found].sort((a,b)=>this.colliderOrder.get(a)!-this.colliderOrder.get(b)!);}
 /** Rare blocked-movement fallback: rays can miss small raised floor details. */
 footprintGround(x:number,z:number,current:number,radius:number,maxStep:number){
  const ceiling=current+maxStep,box=new THREE.Box3(new THREE.Vector3(x-radius,current-.36,z-radius),new THREE.Vector3(x+radius,ceiling,z+radius));let best=-25;
  for(const c of this.sweepCandidates(box)){if(!c.box.intersectsBox(box))continue;c.bvh.shapecast({intersectsBounds:b=>b.intersectsBox(box),intersectsTriangle:(triangle:ExtendedTriangle,index:number)=>{
   if(c.broken[c.owners[index]])return false;
   const low=Math.min(triangle.a.y,triangle.b.y,triangle.c.y),high=Math.max(triangle.a.y,triangle.b.y,triangle.c.y);
   // Open baseboard meshes may have vertical sides but no upward top face.
   // Only finite lips near the feet qualify; never invent a top on a tall wall.
   const lowEdge=high<=ceiling&&low<=current+.03&&high-low<=maxStep+.04;
   const support=triangleFootprintSupport(triangle,x,z,radius,ceiling,lowEdge);
   if(support&&support.y>best&&support.y>=current-.36&&!this.hole(support))best=support.y;
   return false;
  }});}return best;
 }
 private groundCache=new Map<string,number>();private groundRevision=-1;
 ground(x:number,z:number,current:number,maxStep:number){
  // Exact coordinates/elevation/step only: no grid rounding or stale destruction.
  if(this.groundRevision!==this.world.surfaceRevision){this.groundCache.clear();this.groundRevision=this.world.surfaceRevision;}
  const key=x+':'+z+':'+current+':'+maxStep,cached=this.groundCache.get(key);
  if(cached!==undefined)return cached;
  const value=this.groundUncached(x,z,current,maxStep);
  if(this.groundCache.size>=4096)this.groundCache.delete(this.groundCache.keys().next().value!);
  this.groundCache.set(key,value);return value;
 }
 groundUncached(x:number,z:number,current:number,maxStep:number){
  if(mapCollision!=='scratch'){const hits=this.trace(new THREE.Vector3(x,current+maxStep+.025,z),new THREE.Vector3(0,-1,0),50);for(const h of hits)if(h.face.normal.y>.45)return h.point.y;return -25;}
  const from=new THREE.Vector3(x,current+maxStep+.025,z),ray=new THREE.Ray(from,new THREE.Vector3(0,-1,0)),key=Math.floor(x/8)+':'+Math.floor(z/8);
  let candidates=this.groundCells.get(key);
  if(!candidates){candidates=this.nearby(x,z).slice().sort((a,b)=>b.box.max.y-a.box.max.y||this.colliderOrder.get(a)!-this.colliderOrder.get(b)!);if(candidates.length)this.groundCells.set(key,candidates);}
  let bestDistance=50,bestHeight=-25,bestOrder=Infinity;
  for(const c of candidates){
   // A sector's upper bound cannot beat a floor already found above it. The
   // small guard band retains equal-height contacts despite floating point noise.
   if(c.box.max.y+1e-8<from.y-bestDistance)break;
   if(x<c.box.min.x||x>c.box.max.x||z<c.box.min.z||z>c.box.max.z||c.box.min.y>from.y)continue;
   const order=this.colliderOrder.get(c)!;
   const far=Math.min(50,bestDistance+1e-8),nearest=c.bvh.raycastFirst(ray,THREE.DoubleSide,0,far);
   // The common case stops at the first intact walkable face. Undersides,
   // steep faces and destroyed triangles retain the full exact fallback.
   const hits=nearest&&nearest.face!.normal.y>.45&&!c.broken[c.owners[nearest.faceIndex!]]&&!this.hole(nearest.point)?[nearest]:c.bvh.raycast(ray,THREE.DoubleSide,0,far);
   for(const h of hits){
    if(h.face!.normal.y<=.45||c.broken[c.owners[h.faceIndex!]]||this.hole(h.point))continue;
    if(h.distance<bestDistance||h.distance===bestDistance&&order<bestOrder){bestDistance=h.distance;bestHeight=h.point.y;bestOrder=order;}
   }
  }return bestHeight;
 }
}

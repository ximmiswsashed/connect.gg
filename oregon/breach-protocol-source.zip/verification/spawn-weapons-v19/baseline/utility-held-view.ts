import * as T from 'three';
import {deviceMesh,disposeDevice} from './devices';
import {canisterHand} from './gadget-hands';
import {reconnaissanceDrone} from './drone-model';
export function utilityPose(kind:string,p:number){
 const thrown=['frag','stun','emp','smoke','impact','nitro'].includes(kind),wall=['breach','camera','alarm'].includes(kind),large=kind==='shield',smooth=(a:number,b:number)=>T.MathUtils.smoothstep(p,a,b),draw=smooth(0,.22),wind=smooth(.16,.40)*(1-smooth(.40,.63)),place=smooth(.28,.60),recover=smooth(.74,1),release=smooth(.45,.65);
 return {position:new T.Vector3(thrown?.13:0,-.25-(1-draw)*.22-recover*.20-(wall?0:place*.10),-.42+(thrown?wind*.13-release*.18:-place*.16)),rotation:new T.Euler(thrown?.32*wind-.34*release:wall?-.05:.4*place,thrown?-.18*wind:0,thrown?-.25*wind:0),left:new T.Vector3(large?-.23:wall?-.13:-.08,0,0),right:new T.Vector3(large?.23:wall?.13:.08,0,0),open:release,scale:large?.48:kind==='wire'?.38:1};
}
export class UtilityHeldView extends T.Group{
 model:T.Object3D|null=null;kind='';hands:T.Group[]=[];
 constructor(hands=true){super();if(hands)for(const side of [-1,1]){const hand=canisterHand(side);this.hands.push(hand);this.add(hand);}this.visible=false;}
 show(kind:string,p:number,released=false){if(this.kind!==kind){this.clearModel();this.kind=kind;this.model=kind==='shock-drone'?reconnaissanceDrone(true).root:deviceMesh('utility:'+kind);this.add(this.model);}
  const pose=utilityPose(kind,p);this.visible=true;this.position.copy(pose.position);this.rotation.copy(pose.rotation);if(this.model){this.model.visible=!released;this.model.scale.setScalar(pose.scale);}
  for(let i=0;i<this.hands.length;i++){const hand=this.hands[i];hand.position.copy(i?pose.right:pose.left);hand.rotation.set(0,0,i?-.12:.12);const glove=hand.children[0]?.userData.glove;if(glove)glove.morphTargetInfluences[0]=pose.open;}
  return pose;
 }
 private clearModel(){if(!this.model)return;if(this.model instanceof T.Mesh)disposeDevice(this.model);else{this.model.traverse(o=>{if(o instanceof T.Mesh){o.geometry.dispose();for(const m of Array.isArray(o.material)?o.material:[o.material])if(!m.userData.shared)m.dispose();}});this.model.removeFromParent();}this.model=null;}
 dispose(){this.clearModel();this.traverse(o=>{if(o instanceof T.Mesh){o.geometry.dispose();for(const m of Array.isArray(o.material)?o.material:[o.material])if(!m.userData.shared)m.dispose();}});this.removeFromParent();}
}

export type Stance='stand'|'crouch'|'prone';
export type MovementState='idle'|'stand'|'slow'|'crouch'|'prone'|'sprint'|'rappel'|'vault'|'reload'|'gadget'|'reinforce'|'plant'|'disable'|'observation';
export const movementConfig={stand:{speed:3.4,height:1.82,eye:1.68,radius:.27,noise:.045},crouch:{speed:1.85,height:1.12,eye:1.04,radius:.27,noise:.022},prone:{speed:.85,height:.6,eye:.43,radius:.23,noise:.012},slowSpeed:1.35,sprintSpeed:5.7,acceleration:60,stopping:100,adsSpeedMultiplier:.72,adsSpeed:2.34,stanceBlend:12,leanDistance:.48,leanSpeed:24,maxStep:.32,gravity:12,vaultDuration:.55,rappelSpeed:2.4};
export class MovementMachine{state:MovementState='idle';transition(next:MovementState,stance:Stance){if(next==='sprint'&&stance!=='stand')return false;this.state=next;return true;}get canShoot(){return ['idle','stand','slow','crouch','prone','rappel'].includes(this.state);}}

// Exact integration of an exponential velocity response avoids frame-rate-dependent drift.
export function integrateMovement(current:number[],desired:number[],dt:number,config=movementConfig){
 const moving=Math.hypot(...desired)>.001,reversal=current[0]*desired[0]+current[1]*desired[1]<0;
 const start=reversal?[0,0]:current,rate=moving?config.acceleration:config.stopping,e=Math.exp(-rate*dt);
 return {velocity:desired.map((v,i)=>v+(start[i]-v)*e),travel:desired.map((v,i)=>v*dt+(start[i]-v)*(1-e)/rate)};
}

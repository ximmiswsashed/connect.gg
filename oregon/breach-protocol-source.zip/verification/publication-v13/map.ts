import * as THREE from 'three';
import {nativeMap} from '/src/native-map';
import {Game} from '/src/game';
const status=document.querySelector('#status')!,output=document.querySelector('#results')!;
let game:Game;
document.querySelector('#load')!.addEventListener('click',async()=>{try{
 const world=await nativeMap(s=>status.textContent=s);game=new Game(world,new THREE.PerspectiveCamera());game.configure({...game.rules,aiEnabled:false});
 for(const p of world.panels)if(p.kind==='barricade')p.broken=true;
 world.surfaceRevision++;world.imported!.syncDestruction();
 document.querySelector<HTMLButtonElement>('#audit')!.disabled=false;document.querySelector<HTMLButtonElement>('#diagnose')!.disabled=false;status.textContent='Native map ready; exterior barricades removed for physical doorway tests';
}catch(e){status.textContent=String(e);}});
document.querySelector('#audit')!.addEventListener('click',async()=>{try{
 const report=await fetch('../stages/round-update/doorway-candidates.json').then(r=>r.json()),candidates=report.candidates;
 for(const p of game.world.panels)if(p.kind==='barricade'&&!p.mesh.userData.window&&!candidates.some((c:any)=>c.kind==='exterior-door'&&c.owners.includes(p.mesh.userData.openingId))){const axis=p.max.x-p.min.x<p.max.z-p.min.z?'x':'z',side=axis==='x'?'z':'x';candidates.push({id:'exterior-'+p.mesh.userData.openingId,kind:'exterior-door',axis,at:(p.min[axis]+p.max[axis])/2,lo:p.min[side],hi:p.max[side],floorY:p.min.y,owners:[p.mesh.userData.openingId]});}
 const w=game.world,classified:any[]=[],checks:any[]=[];
 function point(c:any,lateral:number,normal:number,r:number,h:number){const x=c.axis==='x'?c.at+normal:lateral,z=c.axis==='z'?c.at+normal:lateral,y=w.ground(x,z,c.floorY+.18,.36);return {p:new THREE.Vector3(x,y+.015,z),clear:y!==-25&&Math.abs(y-c.floorY)<.6&&!w.collide(x,y+.015,z,r,h)};}
 function chord(c:any,lateral:number,r:number,h:number){const step=Math.min(.1,r*.5);for(let n=-.65;n<=.651;n+=step)if(!point(c,lateral,n,r,h).clear)return false;return true;}
 for(let ci=0;ci<candidates.length;ci++){
  const c=candidates[ci],samples:any[]=[];for(let s=c.lo;s<=c.hi+.001;s+=.1){const raw=chord(c,s,.04,1.82),stand=raw&&chord(c,s,.27,1.82),crouch=chord(c,s,.27,1.12);samples.push({s,raw,stand,crouch,prone:chord(c,s,.27,.48)});}
  const bands:any[]=[];for(const mode of ['raw','stand','crouch','prone']){let start=-1;for(let i=0;i<=samples.length;i++){if(i<samples.length&&samples[i][mode]){if(start<0)start=i;}else if(start>=0){bands.push({mode,lo:samples[start].s,hi:samples[i-1].s,width:(i-start)*.1});start=-1;}}}
  const item={id:c.id,kind:c.kind,axis:c.axis,at:c.at,floorY:c.floorY,owners:c.owners,bands};classified.push(item);
  for(const band of bands.filter(b=>b.mode!=='raw')){
   const lateral=(band.lo+band.hi)/2,height=band.mode==='stand'?1.82:band.mode==='crouch'?1.12:.48;
   for(const sign of [-1,1])for(const tangent of [0,-.15,.15]){
    const a=point(c,lateral-tangent,-sign*.65,.27,height),b=point(c,lateral+tangent,sign*.65,.27,height);if(!a.clear||!b.clear)continue;
    const p=a.p.clone(),delta=b.p.clone().sub(a.p);for(let i=0;i<100;i++)game.move(p,delta.x/100,delta.z/100,height);
    checks.push({id:c.id,mode:band.mode,sign,tangent,start:a.p.toArray(),target:b.p.toArray(),actual:p.toArray(),pass:Math.hypot(p.x-b.p.x,p.z-b.p.z)<.045});
   }
  }
  if(ci%8===0){status.textContent=`Classifying ${ci+1}/${candidates.length}; ${checks.length} movement paths`;await new Promise(r=>setTimeout(r,0));}
 }
 const failures=checks.filter(c=>!c.pass);output.textContent=JSON.stringify({date:new Date().toISOString(),inventoryComplete:false,candidates:candidates.length,withStandingChord:classified.filter(c=>c.bands.some((b:any)=>b.mode==='stand')).length,thinOnlyCandidates:classified.filter(c=>c.bands.some((b:any)=>b.mode==='raw')&&!c.bands.some((b:any)=>b.mode==='stand')),movementChecks:checks.length,movementFailures:failures.length,failures,classified,checks,scope:'Candidate classification and real Game.move paths, stand/crouch/prone capsule, both directions, straight and diagonal. Candidate set includes false positives and broad room boundaries; no claim of exhaustive doorway coverage. Strafing has the same displacement path, but full update/input/prone-footprint/lean and window-vault checks remain required.'},null,2);status.textContent=`Survey finished: ${checks.length} movement paths, ${failures.length} failures; doorway coverage remains unverified`;
}catch(e){status.textContent=String(e);}});
addEventListener('pagehide',()=>{game?.droneUnit.dispose();game?.world.dispose();});
document.querySelector('#diagnose')!.addEventListener('click',async()=>{try{
 const input=await fetch('../stages/round-update/doorway-collision-survey.json').then(r=>r.json()),diagnostics:any[]=[];
 const contacts=(p:THREE.Vector3,r=.27,h=1.82)=>{const segment=new THREE.Line3(p.clone().add(new THREE.Vector3(0,r+.025,0)),p.clone().add(new THREE.Vector3(0,h-r,0))),box=new THREE.Box3().setFromPoints([segment.start,segment.end]).expandByScalar(r),hits:any[]=[];
  for(const c of game.world.imported!.colliders){if(!c.box.intersectsBox(box))continue;c.bvh.shapecast({intersectsBounds:b=>b.intersectsBox(box),intersectsTriangle:(t:any,index:number)=>{if(c.broken[c.owners[index]]||Math.max(t.a.y,t.b.y,t.c.y)<=p.y+.025)return false;const point=new THREE.Vector3(),capsule=new THREE.Vector3(),d=t.closestPointToSegment(segment,point,capsule);if(d<r-.004){const owner=c.objects[c.owners[index]];hits.push({owner:owner.mesh.userData.sourceName,material:owner.mesh.userData.surfaceMaterial,distance:d,point:point.toArray(),triangle:[t.a.toArray(),t.b.toArray(),t.c.toArray()]});}return false;}});}return hits;};
 for(const c of input.thinOnlyCandidates){const raw=c.bands.filter((b:any)=>b.mode==='raw').sort((a:any,b:any)=>b.width-a.width)[0],lateral=(raw.lo+raw.hi)/2,probes=[];for(let n=-.65;n<=.651;n+=.1){const x=c.axis==='x'?c.at+n:lateral,z=c.axis==='z'?c.at+n:lateral,y=game.world.ground(x,z,c.floorY+.18,.36)+.015,p=new THREE.Vector3(x,y,z);probes.push({p:p.toArray(),blocked:game.world.collide(x,y,z,.27,1.82),contacts:contacts(p)});}diagnostics.push({candidate:c,probes});}
 for(const f of input.failures){const p=new THREE.Vector3().fromArray(f.actual),offsets=[[0,0],[.3,0],[-.3,0],[0,.3],[0,-.3]],floors=offsets.map(([dx,dz])=>({dx,dz,y:game.world.ground(p.x+dx,p.z+dz,p.y)})),next=p.clone().add(new THREE.Vector3(0,0,.013)),nextFloors=offsets.map(([dx,dz])=>({dx,dz,y:game.world.ground(next.x+dx,next.z+dz,next.y)})),supported=next.clone().setY(Math.max(...nextFloors.map(f=>f.y))+.015),moved=p.clone();game.move(moved,0,.013,f.mode==='stand'?1.82:1.12);diagnostics.push({failure:f,floors,nextFloors,supported:supported.toArray(),moveZResult:moved.toArray(),contacts:contacts(p),nextContacts:contacts(next),supportedContacts:contacts(supported)});}
 output.textContent=JSON.stringify({date:new Date().toISOString(),diagnostics,scope:'Raw native BVH contacts before destruction-volume filtering; correlate each contact against World.collide before classifying it as a blocker.'},null,2);status.textContent='Blocked-candidate contacts collected';
}catch(e){status.textContent=String(e);}});

# Active request (2026-10-21)

User: replace reload/defuse/reinforce/barricade bars with a small progressively filling circle; fully killed players see their own killer replay then live spectate teammates and their placements; all six existing operators get current Siege weapon and secondary-gadget choices with functioning deployables; fix optic seating, especially SMG-12.

Project: C:/Users/cruzi/Documents/Codex/2026-10-02/files-pasted-by-the-user-build/outputs/oregon-tactical. Workspace scripts in current work/. No agents authorized. Approval never; full FS/network. Node C:/Users/cruzi/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe. Python sibling dependencies/python/python.exe.

## Implemented locally, not yet verified or published

- New weapon-catalog.ts: 18 weapons, original ids0..5 preserved (5 now P226), new ids6G36C7FMG9 8L85A2 9M1014 10K1A11BOSG12M4513FiveSeven14SMG1115C7516Reaper17ITA12S. New catalog-firearms.ts provides original procedural silhouettes, magazines, physical rails and irons for added guns. Existing six model geometry retained. Socket SMG12 railTop .046 instead of .069; optic sockets/centers shared across FP/TP/replay.
- loadouts.ts primary/secondary/utility legal choices from current Ubisoft pages. data.ts reexports catalog, Vigil default K1A. Game handles actual selected secondary and utility count. Lobby validates/syncs both, optics/skins loops extended18. Network actor snapshots carry secondary/utility/count/flash. Protocol bumped `equipment-v10`. Gameplay/replay/third-person use selected secondary rather than hardcoded5. Semi-auto trigger edge added. Pose helpers map ids to base families; needs thorough 18xoptic/animation verification.
- menu-screens.ts has primary choices plus secondary and gadget selects; main selectedSecondary/selectedUtility passed through menus/profile/offline deployment. Cosmetics extend all weapons. New action-progress.ts generates 30px SVG ring, horizontal HUD progress tags replaced. CSS ring and spectator statuses added. Page-change scroll resets.
- utility-models.ts, secondary-gadgets.ts: all12 gadget kinds (breach,claymore,wire,alarm,shield,frag,stun,emp,smoke,camera,nitro,impact), host-only validated placement/throws/counts, blast/destruction, enemy claymore trigger, sound alarms, smoke LOS, wire slowing (humans/bots), EMP disabling jammer/charges/traps/cameras, bulletproof camera observation/EMP, remote detonations5, pickup F and melee damage. Bind World utilityPanels+utilitySight callbacks to root Game; dynamic shield panels participate spatial/ray/collision without altering authoritative static panel ids. Existing device loop skips utility types. Guest snapshot disabledTime and smoke cloud replicated. Need tests; grenades currently reuse sticky throwable solver, should refine bounce for frag/stun/smoke while leaving nitro sticky/impact on-hit.
- Personal killcams: Game.recordElimination records human death clip using ReplayHistory.deathClip; separate deathReplay/At/Waiting fields reset per round. Network targeted `killcam-part` compressed chunks only to killed peer, assembler validates victim/round/epoch. Existing round replay transport untouched. main has separate death ReplayView and renderer branch, no game-phase switch; other players continue in action. spectator-state.ts selects living human/bot, proxies AI current actions for viewmodel. Camera/weapon view follow subject; subject body hidden during FP render; dedicated LIVE status shows target name, gun and actual action ring. 2 cycles teammates, V observation. Killcam can be skipped with2. Needs real runtime and network tests.
- All TypeScript currently passes after last script `implement-spectator-presentation.py`. No browser tests or build yet for this request. Do not claim complete until tested/published.

## Current official references read

https://www.ubisoft.com/en-us/game/rainbow-six/siege/game-info/operators/{ash,smoke,sledge,thermite,mute,vigil}
- Ash: R4C/G36C; 5.7USG/M45; breach/claymore.
- Smoke: M590/FMG9; P226/SMG11; wire/alarm/shield.
- Sledge: L85/M590; P226/ReaperMK2; frag/stun/impactEMP.
- Thermite:556/M1014;5.7/M45/ITA12S;smoke/stun.
- Mute:MP5K/M590;P226/SMG11;bulletproofcamera/nitro.
- Vigil:K1A/BOSG;SMG12/C75;bulletproofcamera/impact.
Ubisoft High Stakes guide confirms ReaperMK2 as sighted machine pistol added to Sledge: https://news.ubisoft.com/en-us/article/7argvNYn3AvUMW23nqkY1B/rainbow-six-siege-x-operation-high-stakes-operator-and-gadget-guide . Official Y10S3 notes confirm addition. Don't use outdated Sledge SMG11 or Vigil custom SMG12 primary.

## Next checks / known concerns

1. Correct new shotgun reload animation branch for M1014/ITA12S (currently optics/characters only special-case id1). Slug BOSG should stay pellet1 with tighter aim, not inherit pump's .039 cone. New pistol visual geometry original, not imported exact licensed assets; be honest.
2. Check session.start host optics/profile copy: makeHuman initializes selected secondary/utility then Game.start validates preserving it. Active-round onReady copies both. Ensure reload/spectator replay secondary skin paths no remaining hardcoded5.
3. Test utilities through Game commands and network, camera observation and EMP. EMP fields disabledTime sync done. Grenade bounce improvement and dead camera activation behavior outstanding. Dead utilityActivate early path currently activateUtility checks hp<=0, so dead defenders cannot fire camera EMP yet; alive works. Host .utilityCount counts only own actor. Utility placement not currently animated beyond .5s lowering; unique gadget animations already exist.
4. Killcam ReplayView must successfully render actual frames, preserve live world/destruction; possible state/order bugs need real checks. Private clip can arrive before HP snapshot; Game accepts ahead but renderer gates hp<=0. Guest deathWaitingAt set at transition. Round-ending replay retains priority. Bot spectator proxy covers actual objective/gadget states.
5. Runtime acceptance fixture(s) build meaningful18gun/optic/firing/reload, primarysecondary validation, utilities damage/collision/EMP/counts/visibility, private killcam targeting and spectator live placement, existing deployment/readiness/replay/loading regressions. Dev Vite5263 (session76382), preview5264(session33487) from prior task still running.

## Delivery base

Existing public site https://ximmiswsashed.github.io/connect.gg/ sidebar Breach. GitHub repo ximmiswsashed/connect.gg, main last merge281c0c1b898d8b3d68cdc6301548259e67f4266c (PR7, source974e64f4de0d596f289086640026eb59fd08fd75). Game entry index-Cz1myQCZ.js, shared imported-oregon-BAui9ef1.js. Previous work completed loading/location/defuser, docs outputs/Breach-Protocol-Loading/VERIFICATION.md. Keep fast menu/background full-map readiness gating, asset-loader-v2 caching/compressed metadata, all195batches481colliders41470nodes, 240FPS, existing GPU launcher, fullscreen parent integration, per-player spawns/site voting and round replay.

Public relay wss://mhm.tail8dfc7f.ts.net/breach/lobby healthy. Don't restart it via workaround; user manually starts service after previous auto-review rejection. Local dev relay usable.

Publish with GitHub connector blobs/tree/commit/branch/PR/merge; always attach PR. Inspect ALL_TOOLS names `github_create_blob`, tree,commit,branch,PR,merge. Blob inputs repository_full_name,encoding base64,content; result structuredContent.sha. Large base64 read in500000char chunks using PowerShell substring via exec_command, never print payload. tools exposed dynamically through functions.exec. Read fresh main/base tree via public GitHub API. New package helper adapt work/package-loading-deployment.py to new output and build dist-kit-killcam; DO NOT republish unchanged29MB packs. Reuse v2loader+index deployed paths unchanged; include new entry chunks/CSS/worker/gameHTML/sourcezip. Update parent root files only if needed (likelynone). Filesystem real paths absolute in final links. Publish authorized by continuing existing website update instruction.

## Browser / skill

CUA browser2IAB; must call cua.rewriteDocumentation after compaction. Existing persistent bindings from earlier task may survive: deploymentDeliverable tab22 public v7 defender selection (marked), publicHostCheck tab6 previous deliverable; olduser1/2/3 don'ttouch. Agentcreatedtesttabs13..21 mostlyclosed. Use new background tabs for this request; all browser work via CUA only. DOM evaluate read-only; actual Game mutation/testing only authored app-owned fixture scripts and click their buttons. No Playwright shell/CDP. Browser background tabs throttle1fps; never infer humanGPUFPS. Need screenshot final proof save local andembed in final. Reset viewport after responsive checks.

Impeccable already used/announced previous task and context loaded once in session; do not rerun. Read craft-floor immediately before UI changes (read earlier this turn). Existing PRODUCT.md/DESIGN.md current SiegeX palette retained. No new design interview needed.

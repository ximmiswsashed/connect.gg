import {gzipSync,gunzipSync} from 'node:zlib';
import {MeshoptEncoder} from 'meshoptimizer';
await MeshoptEncoder.ready;
const streams=[['p',Float32Array,3],['n',Int8Array,3],['uv',Float32Array,2],['tile',Uint8Array,2],['color',Uint8Array,3]];
const align=n=>(n+3)&~3;
export function decodeBatch(bytes){
 const raw=gunzipSync(bytes),buffer=raw.buffer.slice(raw.byteOffset,raw.byteOffset+raw.byteLength),h=new Uint32Array(buffer,0,4);
 if(h[0]!==0x42504d31)throw Error('Invalid batch header');
 const b={};let offset=16;
 for(const [key,Type,size] of streams){b[key]=new Type(buffer,offset,h[1]*size);offset+=align(b[key].byteLength);}
 if(offset+h[2]*4!==buffer.byteLength)throw Error('Invalid batch length');
 b.idx=new Uint32Array(buffer,offset,h[2]);return b;
}
export function optimizeBatch(b){
 const idx=new Uint32Array(b.idx),[remap,count]=MeshoptEncoder.reorderMesh(idx,true,false),out={idx,remap};
 for(const [key,Type,size] of streams){
  const source=new Type(b[key]),target=new Type(count*size);
  if(source.length!==b.p.length/3*size)throw Error('Invalid '+key+' stream');
  for(let i=0;i<remap.length;i++)if(remap[i]!==0xffffffff)for(let j=0;j<size;j++)target[remap[i]*size+j]=source[i*size+j];
  out[key]=target;
 }
 return out;
}
export function encodeBatch(b){
 const arrays=[new Uint32Array([0x42504d31,b.p.length/3,b.idx.length,0]),...streams.map(([key,Type])=>new Type(b[key])),new Uint32Array(b.idx)],parts=[];
 for(const a of arrays){parts.push(Buffer.from(a.buffer,a.byteOffset,a.byteLength));if(a.byteLength%4)parts.push(Buffer.alloc(4-a.byteLength%4));}
 return gzipSync(Buffer.concat(parts),{level:9});
}

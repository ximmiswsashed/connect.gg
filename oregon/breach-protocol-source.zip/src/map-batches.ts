import * as THREE from 'three';
import {mapGeometry} from './map-variant';
type Entry={file:string,page:number,vertices:number,triangles:number,instances?:number[][],matrices?:number[][],colors?:number[][],cell?:string};
const align=(n:number)=>(n+3)&~3;

/** GPU-ready source-map batches; no glTF parsing or geometry merging at startup. */
export async function loadMapBatches(materials:THREE.Material[],progress:(s:string)=>void){
 const query=new URLSearchParams(location.search);
 const base=mapGeometry==='scratch'?'/assets/oregon/scratch/':query.get('batches')==='compact'?'/assets/oregon/browser-compact/':'/assets/oregon/browser/';
 const response=await fetch(base+'manifest.json');if(!response.ok)throw Error('Map manifest unavailable');
 const manifest=await response.json() as {version:number,entries:Entry[]};
 if(manifest.version!==1)throw Error('Unsupported map batch version');
 // Three caches the current object-dependent shader variant on each material.
 // Separate the two atlas variants so depth sorting cannot repeatedly switch them.
 const instanceMaterials=materials.map(m=>{const copy=m.clone();copy.onBeforeCompile=m.onBeforeCompile;copy.customProgramCacheKey=m.customProgramCacheKey;return copy;});
 const geometries=new Map<string,Promise<THREE.BufferGeometry>>();
 const geometry=(entry:Entry)=>{
  let promise=geometries.get(entry.file);
  if(!promise){promise=(async()=>{
   const response=await fetch(base+entry.file);if(!response.ok)throw Error('Missing map batch '+entry.file);
   const raw=await response.arrayBuffer(),magic=new Uint8Array(raw,0,2);
   const buffer=magic[0]===31&&magic[1]===139?await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer():raw;
   const header=new Uint32Array(buffer,0,4),vertices=header[1],indices=header[2];
   if(header[0]!==0x42504d31||vertices!==entry.vertices||indices!==entry.triangles*3)throw Error('Invalid map batch '+entry.file);
   const g=new THREE.BufferGeometry();let offset=16;
   g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(buffer,offset,vertices*3),3));offset+=vertices*12;
   g.setAttribute('normal',new THREE.BufferAttribute(new Int8Array(buffer,offset,vertices*3),3,true));offset+=align(vertices*3);
   g.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(buffer,offset,vertices*2),2));offset+=vertices*8;
   g.setAttribute('atlasTile',new THREE.BufferAttribute(new Uint8Array(buffer,offset,vertices*2),2));offset+=align(vertices*2);
   g.setAttribute('color',new THREE.BufferAttribute(new Uint8Array(buffer,offset,vertices*3),3,true));offset+=align(vertices*3);
   if(offset+indices*4!==buffer.byteLength)throw Error('Truncated map batch '+entry.file);
   const indexData=new Uint32Array(buffer,offset,indices);
   g.setIndex(new THREE.BufferAttribute(new URLSearchParams(location.search).get('indices')!=='long'&&vertices<=65535?new Uint16Array(indexData):indexData,1));
   // Diagnostic comparison for drivers that expand three-component byte inputs.
   const packing=new URLSearchParams(location.search).get('packing')??'padded';
   if(packing==='padded')for(const key of ['normal','color']){
    const a=g.getAttribute(key) as THREE.BufferAttribute,Type=key==='normal'?Int8Array:Uint8Array,values=new Type(a.count*4);
    for(let i=0;i<a.count;i++){values.set(a.array.slice(i*3,i*3+3),i*4);values[i*4+3]=key==='color'?255:0;}
    g.setAttribute(key,new THREE.BufferAttribute(values,4,true));
   }
   if(packing==='float')for(const key of ['normal','color','atlasTile']){
    const a=g.getAttribute(key),values=new Float32Array(a.count*a.itemSize);
    for(let i=0;i<a.count;i++)for(let j=0;j<a.itemSize;j++)values[i*a.itemSize+j]=a.getComponent(i,j);
    g.setAttribute(key,new THREE.BufferAttribute(values,a.itemSize));
   }
   g.computeBoundingBox();g.computeBoundingSphere();return g;
  })();geometries.set(entry.file,promise);}return promise;
 };
 const queue=[...manifest.entries],meshes:THREE.Mesh[]=[];let complete=0;
 await Promise.all(Array.from({length:4},async()=>{while(queue.length){const entry=queue.shift()!,g=await geometry(entry);let mesh:THREE.Mesh;
  if(entry.instances||entry.matrices){const placements=entry.matrices??entry.instances!,instances=new THREE.InstancedMesh(g,instanceMaterials[entry.page],placements.length),matrix=new THREE.Matrix4();placements.forEach((p,i)=>{if(entry.matrices)matrix.fromArray(p);else{matrix.makeScale(p[3]??1,p[4]??1,p[5]??1);matrix.setPosition(p[0],p[1],p[2]);}instances.setMatrixAt(i,matrix);if(entry.colors)instances.setColorAt(i,new THREE.Color().setRGB(...entry.colors[i] as [number,number,number]));});instances.instanceMatrix.needsUpdate=true;if(instances.instanceColor)instances.instanceColor.needsUpdate=true;instances.computeBoundingBox();instances.computeBoundingSphere();mesh=instances;}
  else mesh=new THREE.Mesh(g,materials[entry.page]);
  mesh.userData.importedSector=entry.file;mesh.userData.sourceMapBatch=true;mesh.matrixAutoUpdate=false;meshes.push(mesh);progress(`Preparing Oregon batches · ${++complete}/${manifest.entries.length}`);
 }}));return meshes;
}

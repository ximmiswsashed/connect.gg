import type {Game,Bot} from './game';
import type {VaultPlan} from './vault';
import {findSourceLadder,sweepVault,vaultPoint,vaultHeight} from './vault';
import {LadderWaypoint} from './map-action-navigation';

type Traversal={plan:VaultPlan,elapsed:number,retreat:boolean,waypoint:LadderWaypoint};
const states=new WeakMap<Bot,Traversal>();
export type BotMapPose={plan:VaultPlan,progress:number};
const remotePoses=new WeakMap<Bot,BotMapPose>();
export const botMapTraversal=(bot:Bot)=>states.get(bot);
export function botMapPose(bot:Bot):BotMapPose|null{
 const state=states.get(bot);return state?{plan:state.plan,progress:state.elapsed/state.plan.duration}:remotePoses.get(bot)??null;
}
export function applyBotMapPose(bot:Bot,pose:BotMapPose|null|undefined){
 remotePoses.delete(bot);
 if(!pose||pose.plan?.kind!=='ladder'||!Number.isFinite(pose.progress)||pose.progress<0||pose.progress>1)return;
 const p=pose.plan;if(!Array.isArray(p.points)||p.points.length!==4||p.points.some(point=>!Array.isArray(point)||point.length!==3||point.some(n=>!Number.isFinite(n))))return;
 if(!(p.duration>0&&p.duration<20&&p.startPose>=0&&p.startPose<=1&&p.height>=1&&p.height<=2))return;
 remotePoses.set(bot,structuredClone(pose));
}
export function updateBotMapTraversal(game:Game,bot:Bot,dt:number){
 let state=states.get(bot);const next=bot.path[0];
 if(!state&&!(next instanceof LadderWaypoint))return false;
 const occupied=(p:Bot['pos'],height:number)=>[game,...game.humans.map(h=>h.actor).filter(a=>a!==game)].some(a=>a.hp>0&&a.pos.y<p.y+height&&a.pos.y+1.82>p.y&&Math.hypot(a.pos.x-p.x,a.pos.z-p.z)<.57)||game.bots.some(b=>b!==bot&&b.hp>0&&b.pos.y<p.y+height&&b.pos.y+1.82>p.y&&Math.hypot(b.pos.x-p.x,b.pos.z-p.z)<.57);
 if(!state){
  const waypoint=next as LadderWaypoint,yaw=waypoint.up?0:Math.PI;
  const plan=findSourceLadder(game.world,bot.pos,yaw,occupied,bot.stanceAmount??0);
  if(!plan){if(bot.brain)bot.brain.decision=0;return true;}
  state={plan,elapsed:0,retreat:false,waypoint};states.set(bot,state);bot.mesh.rotation.y=yaw;
 }
 const steps=Math.max(1,Math.ceil(dt/.015));
 for(let i=0;i<steps;i++){
  const elapsed=Math.max(0,Math.min(state.plan.duration,state.elapsed+(state.retreat?-1:1)*dt/steps));
  const p=vaultPoint(state.plan,elapsed/state.plan.duration),height=Math.max(vaultHeight(state.plan,state.elapsed/state.plan.duration),vaultHeight(state.plan,elapsed/state.plan.duration));
  if(!sweepVault(game.world,bot.pos,p,height,occupied)){state.retreat=true;break;}
  bot.pos.copy(p);state.elapsed=elapsed;
  if(elapsed===state.plan.duration||state.retreat&&elapsed===0){
   states.delete(bot);if(!state.retreat&&bot.path[0]===state.waypoint)bot.path.shift();
   if(state.retreat){bot.path=[];if(bot.brain)bot.brain.decision=0;}break;
  }
 }
 bot.mesh.position.copy(bot.pos);bot.aiming=false;return true;
}

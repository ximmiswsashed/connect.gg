import type * as THREE from 'three';
import type {Game} from './game';
import {refreshGasCloud} from './gas-cloud';

// Vision uses the same clipped puff volumes as rendering. This is procedural
// opacity tuning, not a historical gas damage radius or a bullet obstruction.
const obscuringDepth=.75;
export function visualSight(game:Game,from:THREE.Vector3,to:THREE.Vector3){
 if(!game.world.sight(from,to))return false;
 const dx=to.x-from.x,dy=to.y-from.y,dz=to.z-from.z,length=Math.hypot(dx,dy,dz);
 if(length<1e-6)return true;
 const ux=dx/length,uy=dy/length,uz=dz/length,intervals:[number,number][]=[];
 for(const d of [...game.devices,...game.externalDevices]){
  if(d.type!=='gas'||!d.active||d.time<=0||!d.mesh.visible)continue;
  const cx=d.pos.x-from.x,cy=d.pos.y-from.y,cz=d.pos.z-from.z;
  const projection=Math.max(0,Math.min(length,cx*ux+cy*uy+cz*uz));
  if((cx-projection*ux)**2+(cy-projection*uy)**2+(cz-projection*uz)**2>16)continue;
  refreshGasCloud(game.world,d.mesh,d.pos);
  const puffs=d.mesh.geometry.userData.puffs as {offset:number[],radius:number}[]|undefined;
  for(const puff of puffs??[]){
   const x=cx+puff.offset[0],y=cy+puff.offset[1],z=cz+puff.offset[2],along=x*ux+y*uy+z*uz;
   const perpendicular=Math.max(0,x*x+y*y+z*z-along*along),radius=puff.radius*.8;
   if(perpendicular>=radius*radius)continue;
   const half=Math.sqrt(radius*radius-perpendicular),start=Math.max(0,along-half),end=Math.min(length,along+half);
   if(end<=start)continue;
   if(end-start>=obscuringDepth)return false;
   intervals.push([start,end]);
  }
 }
 // Union prevents overlapping puffs or duplicate replicated records counting
 // the same transparent edge repeatedly. Several small puffs can still obscure.
 intervals.sort((a,b)=>a[0]-b[0]);
 let start=0,end=0,depth=0;
 for(const interval of intervals){
  if(interval[0]>end){depth+=end-start;start=interval[0];end=interval[1];}
  else end=Math.max(end,interval[1]);
  if(depth+end-start>=obscuringDepth)return false;
 }
 return true;
}

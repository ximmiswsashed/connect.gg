export {botMapTraversal};
import {contactFromHit,type DamageContact} from './replay-damage';
import {routeForActorAsync} from './map-action-navigation';
import {botMapTraversal,updateBotMapTraversal} from './map-bot-traversal';
import {PenetrationPath} from './penetration';import {gunHandling,coneDirection} from './ballistics';import type {Panel} from './world';
import {considerPathBreach,considerBotJammerClearance,updateBotBreaches,botBreaching} from './bot-breaching';
import {updateBotSmoke,updateBotSmokeThrows} from './smoke';
import {updateBotJammer} from './jammer';
import {observationHidden,ercCapacity,ercRechargeRate,ercActivationRatio} from './erc';
import {firearmDamage} from './ballistic-damage';
import * as THREE from 'three';import type {Game,Bot} from './game';import {sites,operators} from './data';import {objectiveConfig} from './objectives';
type Target={interference?:number,ercGlitch?:number,id:string,team:number,pos:THREE.Vector3,hp:number,height:number,getMesh:()=>THREE.Group,damage:(n:number,killer?:string,team?:number,head?:boolean,contact?:DamageContact)=>void};
import {perceptionTuning,soundClue} from './ai-perception';
import {style,patrolGoal,trackAim} from './ai-tactics';
import {visibleAimPoint,firingPosition} from './ai-aim';
import {visualSight} from './visual-sight';
import {botPosture,choosePosture,holdAngle,turnBot} from './ai-posture';
export function updateBotErc(game:Game,dt:number){
 // Resource clocks run for every bot, independently of expensive sensing decisions.
 for(const b of game.bots){
  b.ercGlitch=Math.max(0,(b.ercGlitch??0)-dt);
  b.ercThreat=Math.max(0,(b.ercThreat??0)-dt);b.ercSense=Math.max(0,(b.ercSense??0)-dt);
  if(b.operator!==5||b.hp<=0){b.ercActive=false;b.interference=0;continue;}
  b.ercEnergy??=ercCapacity;
  if(b.ercActive){const used=Math.min(dt,b.ercEnergy);b.ercEnergy=Math.max(0,b.ercEnergy-used);if(b.ercEnergy===0){b.ercActive=false;b.ercEnergy=Math.min(ercCapacity,(dt-used)*ercRechargeRate);}}
  else b.ercEnergy=Math.min(ercCapacity,b.ercEnergy+dt*ercRechargeRate);
  b.interference=b.ercActive?b.ercEnergy:0;
 }
}
export function considerBotErc(game:Game,b:Bot){
 if(b.operator!==5||b.hp<=0||!['prep','action'].includes(game.phase)||(b.ercSense??0)>0)return;
 b.ercSense=.25;
 const eye=b.pos.clone().add(new THREE.Vector3(0,botPosture(b).eye,0));
 const candidates=[{team:game.team,drone:game.droneUnit},...game.humans.filter(h=>h.actor!==game).map(h=>({team:h.actor.team,drone:h.actor.droneUnit})),...game.bots.filter(other=>other.drone).map(other=>({team:other.team,drone:other.drone!}))];
 const forward=new THREE.Vector3(-Math.sin(b.mesh.rotation.y),0,-Math.cos(b.mesh.rotation.y));
 const threat=candidates.some(({team,drone:d})=>team!==b.team&&d.alive&&d.deployed&&d.pos.distanceTo(b.pos)<12&&(d.pos.distanceTo(b.pos)<3||forward.dot(d.pos.clone().sub(b.pos).setY(0).normalize())>0)&&visualSight(game,eye,d.eye()));
 if(threat)b.ercThreat=1;
 if((b.ercThreat??0)>0){
  if(!b.ercActive&&(b.ercEnergy??ercCapacity)>ercCapacity*ercActivationRatio){b.ercActive=true;b.interference=b.ercEnergy??ercCapacity;b.ercGlitch=0;b.mesh.userData.spotted=0;game.emitSound('erc-on',b.pos,.16);}
 }else if(b.ercActive){b.ercActive=false;b.interference=0;b.ercGlitch=0;game.emitSound('erc-off',b.pos,.16);}
}
export function updateBotDrones(game:Game,dt:number){
 // Physics advances independently of the round-robin tactical decision cursor.
 for(const b of game.bots){const d=b.drone;if(!d)continue;const jammed=game.jammed(d.pos);let forward=0;
  if(game.phase==='prep'&&b.hp>0&&b.team===0&&d.alive&&d.deployed&&!jammed){const path=b.mesh.userData.dronePath as THREE.Vector3[]|undefined,next=path?.[0];if(next){const delta=next.clone().sub(d.pos);delta.y=0;if(delta.length()<.25)path!.shift();else{d.lookYaw=d.yaw=Math.atan2(-delta.x,-delta.z);forward=1;}}}
  d.update(dt,forward,0,jammed);
 }
}
export function updateTacticalBots(game:Game,dt:number){updateBotDrones(game,dt);updateBotErc(game,dt);updateBotSmokeThrows(game,dt);updateBotBreaches(game,dt);const world=game.world,t=perceptionTuning(game.rules.difficulty,game.rules.aiPerception);const targets:Target[]=[];
 const addHuman=(actor:Game,id:string)=>{if(actor.hp>0)targets.push({id,interference:actor.interference,ercGlitch:actor.ercGlitch,team:actor.team,pos:actor.pos,hp:actor.hp,height:actor.stance==='prone'?.48:actor.stance==='crouch'?1.08:1.68,getMesh:()=>actor.getCollisionMesh(),damage:(n,killer,team,head,contact)=>{actor.takeDamage(n,killer??'bot',team??1-actor.team,head,contact);}});};
 addHuman(game,'local');for(const h of game.humans)if(h.actor!==game)addHuman(h.actor,h.id);for(const b of game.bots)if(b.hp>0)targets.push({id:'bot'+b.id,interference:b.interference,ercGlitch:b.ercGlitch,team:b.team,pos:b.pos,hp:b.hp,height:botPosture(b).eye,getMesh:()=>b.mesh,damage:(n,killer,team,_head,contact)=>game.damageBot(b,n,killer??'bot',team??1-b.team,contact)});
 const cursor=((game as Game&{aiCursor?:number}).aiCursor??0)%Math.max(1,game.bots.length);(game as Game&{aiCursor?:number}).aiCursor=cursor+1;for(const b of game.bots)b.mesh.userData.aiTime=(b.mesh.userData.aiTime??0)+dt;
 for(const b of game.bots.slice(cursor,cursor+1)){if(b.hp<=0)continue;dt=b.mesh.userData.aiTime;b.mesh.userData.aiTime=0;if(botMapTraversal(b)){updateBotMapTraversal(game,b,dt);continue;}considerBotErc(game,b);
  const brain=b.brain??={mode:'patrol',lastSeen:null,memory:0,reaction:0,burst:0,decision:0,lastHp:100,targetId:'',objectiveHold:0};
  if((b.smokeThrow??0)>0||botBreaching(b)){brain.objectiveHold=0;delete b.mesh.userData.objectiveHoldStart;continue;}
  b.cool-=dt;brain.decision-=dt;brain.memory-=dt;if(b.mesh.userData.spotted)b.mesh.userData.spotted-=dt;
  if(updateBotJammer(game,b,dt,()=>walk(game,b,dt),goal=>requestRoute(game,b,goal),dt*t.turnSpeed)){brain.objectiveHold=0;delete b.mesh.userData.objectiveHoldStart;continue;}if(game.phase==='prep'){
   if(b.team===0&&b.drone?.alive&&b.drone.deployed){const eye=b.drone.eye();if(!game.jammed(b.drone.pos))for(const target of targets)if(target.team!==b.team&&!observationHidden({team:b.team,observing:true},{...target,interference:target.interference??0})&&target.pos.distanceTo(eye)<18&&visualSight(game,eye,target.pos.clone().add(new THREE.Vector3(0,.8,0)))){brain.lastSeen=target.pos.clone();brain.memory=1.5;break;}}
   if(b.team===1&&(b.mesh.userData.reinforcements??2)>0){const eye=b.pos.clone().add(new THREE.Vector3(0,1.4,0));const panel=world.panels.find(p=>p.reinforceEligible&&!p.reinforced&&!p.broken&&p.mesh.position.distanceTo(eye)<2.8&&world.sight(eye,eye.clone().clamp(p.min,p.max).lerp(eye,.04)));if(panel){if(b.mesh.userData.reinforcePanel!==panel){b.mesh.userData.reinforcePanel=panel;b.mesh.userData.reinforceTime=0;}b.mesh.userData.reinforceTime+=dt;if(b.mesh.userData.reinforceTime>=3&&world.reinforce(panel)){b.mesh.userData.reinforcements=(b.mesh.userData.reinforcements??2)-1;b.mesh.userData.reinforceTime=0;}}}
   continue;
  }if(game.phase!=='action')continue;
  const eye=b.pos.clone().add(new THREE.Vector3(0,botPosture(b).eye,0));let visible:Target|null=null;let nearest=t.range;
  for(const target of targets){const distance=target.pos.distanceTo(b.pos);if(target.team!==b.team&&distance<nearest&&(distance<3||new THREE.Vector3(-Math.sin(b.mesh.rotation.y),0,-Math.cos(b.mesh.rotation.y)).dot(target.pos.clone().sub(b.pos).setY(0).normalize())>t.peripheralCos)&&visualSight(game,eye,target.pos.clone().add(new THREE.Vector3(0,target.height*.85,0)))){visible=target;nearest=distance;}}
  if(!visible&&considerBotJammerClearance(game,b,dt))continue;
  if(visible){const fresh=!brain.visible||brain.targetId!==visible.id;if(fresh){brain.targetId=visible.id;brain.reaction=t.reaction+Math.random()*.18;brain.acquisition=t.acquisition;brain.burst=t.burst;}else{brain.reaction-=dt;brain.acquisition=Math.max(0,(brain.acquisition??t.acquisition)-dt);}brain.visible=true;b.aiming=true;brain.lastSeen=visible.pos.clone();brain.memory=t.memory;brain.mode='engage';
   const exposed=visibleAimPoint(game,b,visible,dt,fresh);b.aiming=!!exposed;
   const tracked=trackAim(b,exposed??visible.pos.clone().add(new THREE.Vector3(0,visible.height*.9,0)),dt,t.error,fresh);const angle=Math.atan2(b.pos.x-tracked.x,b.pos.z-tracked.z);b.pitch=THREE.MathUtils.clamp(Math.atan2(tracked.y-eye.y,Math.hypot(tracked.x-eye.x,tracked.z-eye.z)),-1.1,1.1);const diff=THREE.MathUtils.euclideanModulo(angle-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI;const turnStart=b.mesh.rotation.y;turnBot(game,b,THREE.MathUtils.clamp(diff,-dt*t.turnSpeed,dt*t.turnSpeed));const remainingTurn=Math.max(0,dt*t.turnSpeed-Math.abs(b.mesh.rotation.y-turnStart));
   if(!exposed&&brain.decision<=0){const peek=firingPosition(game,b,visible);if(peek){b.goal=peek;requestRoute(game,b,peek);brain.mode='reposition';b.mesh.userData.coverGoal=true;b.mesh.userData.aiPeekGoal=true;}brain.decision=2;}
   else if(exposed&&brain.decision<=0&&(b.hp<brain.lastHp||nearest<18)&&Math.random()<t.reposition*style(b).coverChance){const cover=findCover(game,b,visible.pos);if(cover){b.goal=cover;requestRoute(game,b,cover);brain.mode='reposition';b.mesh.userData.coverGoal=true;b.mesh.userData.aiPeekGoal=false;brain.decision=3;}}
   const smokeHandling=updateBotSmoke(game,b,visible,brain.reaction<=0&&(brain.acquisition??t.acquisition)<=0,dt,remainingTurn);if(exposed&&!smokeHandling&&brain.reaction<=0&&(brain.acquisition??t.acquisition)<=0&&b.cool<=0&&Math.abs(diff)<.18){fireBotWeapon(game,b,visible,targets);brain.burst--;b.cool=brain.burst>0?.13:.65+Math.random()*.35;if(brain.burst<=0)brain.burst=t.burst;}
  }else {updateBotSmoke(game,b,null,false);brain.visible=false;b.aiming=false;brain.acquisition=t.acquisition;}if(!visible&&brain.memory>0&&brain.lastSeen){brain.mode=b.role==='anchor'?'hold':'investigate';if(brain.decision<=0&&b.role!=='anchor'){b.goal=brain.lastSeen.clone();requestRoute(game,b,b.goal);brain.decision=1;}}
  else if(!visible&&brain.decision<=0){brain.targetId='';const noise=game.noises.find(n=>n.team!==b.team&&n.time>0&&n.pos.distanceTo(b.pos)<n.radius);if(noise){brain.mode='investigate';b.goal=soundClue(noise,b.id,t.soundUncertainty);brain.decision=2.5;}else{b.goal=patrolGoal(game,b);brain.decision=style(b).hold;}requestRoute(game,b,b.goal);}
  if((b.smokeThrow??0)>0||botBreaching(b)){if(b.brain)b.brain.objectiveHold=0;delete b.mesh.userData.objectiveHoldStart;continue;}
  if(updateBotObjectiveHold(game,b,!!visible,dt)){brain.lastHp=b.hp;continue;}
  if(b.mesh.userData.coverGoal&&(brain.decision<=0||b.goal.distanceTo(b.pos)<(b.mesh.userData.aiPeekGoal?.15:.6)))b.mesh.userData.coverGoal=false;if(visible&&b.mesh.userData.coverGoal)brain.mode='reposition';choosePosture(game,b,visible?.pos??(brain.memory>0?brain.lastSeen:null),dt);if(!visible||brain.mode==='reposition')walk(game,b,dt);holdAngle(game,b,dt);brain.lastHp=b.hp;

 }
}
export function updateBotObjectiveHold(game:Game,b:Bot,visible:boolean,dt:number){
 const brain=b.brain!,o=game.objectiveState,actor=game.objectiveActors.find(a=>a.actorId==='bot:'+b.id)!;
 if(b.team===0&&o.dropped&&b.pos.distanceTo(o.dropped)<objectiveConfig.pickupDistance)o.pickup(actor);
 const start=b.mesh.userData.objectiveHoldStart as THREE.Vector3|undefined;
 if(start&&start.distanceTo(b.pos)>=.15){brain.objectiveHold=0;delete b.mesh.userData.objectiveHoldStart;}
 if(visible||!(b.team===0?o.canPlant(actor)&&(game.timer>0||brain.objectiveHold>0):o.canDisable(actor))){brain.objectiveHold=0;delete b.mesh.userData.objectiveHoldStart;return false;}
 if(!b.mesh.userData.objectiveHoldStart){brain.objectiveHold=0;b.mesh.userData.objectiveHoldStart=b.pos.clone();}
 brain.mode=b.team===0?'plant':'disable';b.aiming=false;b.mesh.position.copy(b.pos);brain.objectiveHold+=dt;
 if(brain.objectiveHold>=(b.team===0?objectiveConfig.plantSeconds:objectiveConfig.disableSeconds)){o.complete(actor,b.team===0?'plant':'disable',Math.min(dt,.05));brain.objectiveHold=0;delete b.mesh.userData.objectiveHoldStart;}
 return true;
}
function requestRoute(game:Game,b:Bot,goal:THREE.Vector3){if(b.mesh.userData.routePending||botMapTraversal(b))return;const target=goal.clone();b.mesh.userData.routePending=true;routeForActorAsync(game.world,b.pos.clone(),target,'bot').then(path=>{b.mesh.userData.routePending=false;if(b.mesh.parent&&b.hp>0&&!botMapTraversal(b)&&b.goal.distanceTo(target)<.6)b.path=path;});}
export function walk(game:Game,b:Bot,dt:number){if(updateBotMapTraversal(game,b,dt)||botBreaching(b))return;if(dt>.034){const n=Math.ceil(dt/.034);for(let i=0;i<n;i++)walk(game,b,dt/n);return;}const floor=game.world.ground(b.pos.x,b.pos.z,b.pos.y,.02)+.015;if(b.pos.y>floor+.06){const speed=(b.mesh.userData.fallSpeed??0)-9.8*dt;b.mesh.userData.fallSpeed=speed;const fromY=b.pos.y,y=Math.max(floor,fromY+speed*dt),steps=Math.max(1,Math.ceil(Math.abs(y-fromY)/.08));for(let i=1;i<=steps;i++){const candidate=b.pos.clone();candidate.y=THREE.MathUtils.lerp(fromY,y,i/steps);const value=b.stanceAmount??(b.stance==='prone'?2:b.stance==='crouch'?1:0);if(game.postureBlocked(candidate,value,b.mesh.rotation.y)){b.mesh.userData.fallSpeed=0;break;}b.pos.y=candidate.y;}}else b.mesh.userData.fallSpeed=0;const next=b.path[0];if(!next){b.mesh.position.copy(b.pos);return;}const delta=next.clone().sub(b.pos),vertical=delta.y;delta.y=0;if(delta.length()<.08){if(Math.abs(vertical)<.35)b.path.shift();b.mesh.position.copy(b.pos);return;}if(considerPathBreach(game,b,next,dt)){b.mesh.position.copy(b.pos);return;}const travel=Math.min(delta.length(),dt*style(b).speed*(b.stance==='prone'?.35:b.stance==='crouch'?.65:1));delta.normalize();const old=b.pos.clone();game.move(b.pos,delta.x*travel,delta.z*travel,botPosture(b).height);if((b.stanceAmount??0)>1&&game.postureBlocked(b.pos,b.stanceAmount!,b.mesh.rotation.y))b.pos.copy(old);if(old.distanceTo(b.pos)<.01){const panel=game.world.panels.find(p=>!p.broken&&p.kind==='barricade'&&p.mesh.position.distanceTo(b.pos.clone().add(new THREE.Vector3(0,1.1,0)))<2);if(panel){b.mesh.userData.barricadeWait=Math.max(0,(b.mesh.userData.barricadeWait??0)-dt);if(b.mesh.userData.barricadeWait<=0){const serial=(b.mesh.userData.barricadeSwing??0)+1;b.mesh.userData.barricadeSwing=serial;b.mesh.userData.barricadeWait=.55;const point=b.pos.clone().add(new THREE.Vector3(0,1.1,0)).clamp(panel.min,panel.max);game.world.barricadeHit(panel,'melee',[{point,distance:point.distanceTo(b.pos)}],'bot:'+b.id+':melee:'+serial);game.emitSound('barricade',b.pos,.15);}}else{const side=new THREE.Vector3(delta.z,0,-delta.x);const beforeSide=b.pos.clone();game.move(b.pos,side.x*dt*.8,side.z*dt*.8,botPosture(b).height);if((b.stanceAmount??0)>1&&game.postureBlocked(b.pos,b.stanceAmount!,b.mesh.rotation.y))b.pos.copy(beforeSide);if(b.brain)b.brain.decision=Math.min(b.brain.decision,.4);}}b.mesh.position.copy(b.pos);if(!b.brain?.visible){const angle=Math.atan2(-delta.x,-delta.z),diff=THREE.MathUtils.euclideanModulo(angle-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI;turnBot(game,b,THREE.MathUtils.clamp(diff,-dt*3,dt*3));}b.mesh.userData.foot=(b.mesh.userData.foot??0)+old.distanceTo(b.pos);if(b.mesh.userData.foot>1.8){b.mesh.userData.foot=0;game.emitSound('footstep',b.pos.clone().add(new THREE.Vector3(0,.08,0)),.25);game.noises.push({pos:b.pos.clone(),team:b.team,time:1.5,radius:b.stance==='stand'?6:3});}}
function findCover(game:Game,b:Bot,threat:THREE.Vector3){let best:THREE.Vector3|null=null,distance=8;for(const p of game.world.nearPanels(b.pos.x,b.pos.z,8)){if(p.broken||p.mesh.userData.walkable||p.max.y-b.pos.y<.8||p.max.y-b.pos.y>2.3||p.max.x-p.min.x>4||p.max.z-p.min.z>4)continue;const center=p.min.clone().add(p.max).multiplyScalar(.5);center.y=b.pos.y;const away=center.clone().sub(threat);away.y=0;away.normalize();const candidate=center.clone().addScaledVector(away,Math.max(p.max.x-p.min.x,p.max.z-p.min.z)*.5+.65);const d=candidate.distanceTo(b.pos);if(d<distance&&!game.world.collide(candidate.x,candidate.y,candidate.z,.28,1.7)&&!game.world.sight(candidate.clone().add(new THREE.Vector3(0,.75,0)),threat.clone().add(new THREE.Vector3(0,1.5,0)))){best=candidate;distance=d;}}return best;}
export function fireBotWeapon(game:Game,b:Bot,target:Target,targets:Target[]=[target]){
 if(!game.authority||game.phase!=='action')return;
 const from=b.pos.clone().add(new THREE.Vector3(0,Math.max(.27,botPosture(b).eye-.16),0)),forward=(b.mesh.userData.aiAim as THREE.Vector3).clone().sub(from).normalize(),weapon=operators[b.operator??(b.team?4:0)].weapon,handling=gunHandling[weapon],pellets=handling.pellets;
 // Cosmetic/skinned meshes and hidden equipment are not damage targets. Testing
 // them before filtering to hitboxes made each pellet skin/raycast whole actors.
 const objects=targets.filter(t=>t.id!=='bot'+b.id&&t.hp>0).flatMap(t=>{const root=t.getMesh(),hitboxes:THREE.Object3D[]=[];root.updateWorldMatrix(true,true);root.traverse(o=>{if(o.userData.hitbox){o.userData.aiTarget=t;hitboxes.push(o);}});return hitboxes;}),impacts=new Map<Panel,{point:THREE.Vector3,distance:number}[]>(),barricadeImpacts=new Map<Panel,{point:THREE.Vector3,distance:number}[]>();
 if(b.ercActive)b.ercGlitch=.25;b.shotSerial=(b.shotSerial??0)+1;game.emitSound(weapon===1?'shotgun':'shot',from,.65);game.noises.push({pos:b.pos.clone(),team:b.team,time:1.5,radius:30});
 for(let pellet=0;pellet<pellets;pellet++){
  const dir=pellets>1?coneDirection(forward,handling.aim):forward,path=new PenetrationPath(),seen=new Set<Panel>(),ray=game.world.ray;ray.set(from,dir);ray.far=50;
  const hits=[...game.world.trace(from,dir,50),...ray.intersectObjects(objects,false)].sort((a,b)=>a.distance-b.distance);
  for(const hit of hits){const actor=hit.object.userData.aiTarget as Target|undefined;if(actor){actor.damage(path.damage(firearmDamage(14/pellets,pellets>1,!!hit.object.userData.head,hit.distance,actor.hp),!!hit.object.userData.head),'bot:'+b.id,b.team,!!hit.object.userData.head&&pellets===1,contactFromHit(hit,operators[b.operator??(b.team?4:0)].weapon,path.surfaces.size>0));b.mesh.userData.flash=.05;break;}
   const panel=hit.object.userData.panel as Panel|undefined;if(!panel)break;
   game.onImpact(hit.point,hit.face?.normal.clone().transformDirection(hit.object.matrixWorld)??dir.clone().negate());
   if(weapon===1&&panel.grid&&panel.kind!=='barricade'&&!panel.reinforced&&!seen.has(panel)){seen.add(panel);const values=impacts.get(panel)??[];values.push({point:hit.point.clone(),distance:hit.distance});impacts.set(panel,values);}
   if(panel.kind==='barricade'&&!panel.reinforced&&!seen.has(panel)){seen.add(panel);const values=barricadeImpacts.get(panel)??[];values.push({point:hit.point.clone(),distance:hit.distance});barricadeImpacts.set(panel,values);}
   if(!path.cross({id:panel.mesh.userData.panelOrder,remaining:!panel.broken,penetrable:!!panel.surfaceRule?.penetrable||panel.kind==='barricade'||panel.mesh.userData.penetration===true,reinforced:panel.reinforced}))break;
  }
 }
 for(const [p,hits] of barricadeImpacts)game.world.barricadeHit(p,weapon===1?'shotgun':'bullet',hits,'bot:'+b.id+':shot:'+b.shotSerial);
 if(impacts.size)game.world.shotgunDamage(impacts);
}

export function botBreachTool(b:Bot){if((b.gadgetCharges??0)<=0)return null;return b.operator===0?'ash':b.operator===2?'hammer':b.operator===3?'thermite':null;}

import * as THREE from 'three';

/** Walkable support, or the finite top edge of an explicitly permitted low lip. */
export function triangleFootprintSupport(triangle:THREE.Triangle,x:number,z:number,radius:number,ceiling:number,allowLowEdge=false):THREE.Vector3|null{
 const normal=triangle.getNormal(new THREE.Vector3());if(normal.y<=.45&&(!allowLowEdge||Math.max(triangle.a.y,triangle.b.y,triangle.c.y)>ceiling))return null;
 const source=[triangle.a,triangle.b,triangle.c],polygon:THREE.Vector3[]=[];
 // Clip at the permitted step height before intersecting the footprint.
 for(let i=0;i<3;i++){const a=source[i],b=source[(i+1)%3],inside=a.y<=ceiling,other=b.y<=ceiling;if(inside)polygon.push(a);if(inside!==other)polygon.push(a.clone().lerp(b,(ceiling-a.y)/(b.y-a.y)));}
 if(polygon.length<3)return null;
 let best:THREE.Vector3|null=null;const accept=(p:THREE.Vector3)=>{if(p.y<=ceiling+1e-8&&(p.x-x)**2+(p.z-z)**2<=radius*radius+1e-10&&(!best||p.y>best.y))best=p.clone();};
 for(let i=0;i<polygon.length;i++){
  const a=polygon[i],b=polygon[(i+1)%polygon.length];accept(a);
  const dx=b.x-a.x,dz=b.z-a.z,ox=a.x-x,oz=a.z-z,A=dx*dx+dz*dz,B=2*(ox*dx+oz*dz),C=ox*ox+oz*oz-radius*radius,discriminant=B*B-4*A*C;
  if(A>1e-16&&discriminant>=-1e-12)for(const t of [(-B-Math.sqrt(Math.max(0,discriminant)))/(2*A),(-B+Math.sqrt(Math.max(0,discriminant)))/(2*A)])if(t>=0&&t<=1)accept(a.clone().lerp(b,t));
 }
 // A sloped face may reach its highest supported point on the disk rim,
 // between triangle edges; a flat face can cover the entire disk.
 if(Math.abs(normal.y)>1e-9){const gx=-normal.x/normal.y,gz=-normal.z/normal.y,length=Math.hypot(gx,gz),px=x+(length?radius*gx/length:0),pz=z+(length?radius*gz/length:0),py=triangle.a.y+gx*(px-triangle.a.x)+gz*(pz-triangle.a.z),extreme=new THREE.Vector3(px,py,pz);if(triangle.containsPoint(extreme))accept(extreme);}
 return best;
}

import * as THREE from 'three';
import type {World} from './world';
import {roundActorContact} from './round-actor-contact';
import {roundUtilityContact,roundUtilityRoots} from './round-utility-contact';
import type {Game,Device} from './game';

export const breachingRoundSpeed=70,breachingRoundRange=60;
// Conservative capsule: .13 m fins, .20 m body and -.16 m nose tip.
export const breachingRoundRadius=.066,breachingRoundFront=.1,breachingRoundRear=.1;
// Prototype delay; public operator descriptions do not establish an exact Y9S4 value.
export const breachingRoundFuseSeconds=1.5;
// Direct-impact magnitude follows dated round tuning; consume-on-actor lifecycle remains a prototype inference.
export const breachingRoundActorDamage=50;
// Authority-only contact anchor; existing position/orientation snapshots carry the result to peers.
const utilityAnchors=new WeakMap<Device,{root:THREE.Object3D,point:THREE.Vector3,normal:THREE.Vector3,rotation:THREE.Quaternion}>();
// A continuous segment sweep observes current geometry, including changes after launch.
export function advanceBreachingRound(world:World,d:Device,dt:number,game?:Game){
 if(game&&!game.authority)return;
 if(!d.mesh.visible||!d.active||dt<=0)return;
 if(d.attached&&d.roundImpact){
  const anchor=utilityAnchors.get(d);
  const panel=world.panels[d.panelId??-1];
  // An attachment cannot outlive its physical support. Exact Ash-on-utility
  // response remains a prototype; this prevents orphaned armed rounds.
  if(anchor&&(!anchor.root.visible||!anchor.root.parent||game&&!roundUtilityRoots(game,d).includes(anchor.root))||panel?.broken){
   utilityAnchors.delete(d);d.mesh.visible=false;d.active=false;d.type='destroyed';d.time=0;d.roundRange=0;d.attached=false;d.roundImpact=false;d.panelId=-1;return;
  }
  if(anchor?.root.visible){anchor.root.updateWorldMatrix(true,false);d.pos.copy(anchor.point).applyMatrix4(anchor.root.matrixWorld);d.mesh.position.copy(d.pos);d.blastNormal=anchor.normal.clone().transformDirection(anchor.root.matrixWorld);anchor.root.getWorldQuaternion(d.mesh.quaternion).multiply(anchor.rotation);}
  d.time=Math.max(0,d.time-dt);return;
 }
 if(!d.roundDirection){
  const delta=d.pos.clone().sub(d.mesh.position);
  d.roundDirection=delta.lengthSq()>1e-10?delta.normalize():new THREE.Vector3(0,0,-1).applyQuaternion(d.mesh.quaternion);
  d.roundRange=Math.max(d.mesh.position.distanceTo(d.pos),d.time*breachingRoundSpeed);
 }
 const distance=Math.min(d.roundRange??breachingRoundRange,dt*breachingRoundSpeed),from=d.mesh.position.clone();
 const hit=world.sweepSphere(from.clone().addScaledVector(d.roundDirection,-breachingRoundRear),d.roundDirection,distance+breachingRoundRear+breachingRoundFront,breachingRoundRadius);
 const utility=game?roundUtilityContact(game,d,from.clone().addScaledVector(d.roundDirection,-breachingRoundRear),d.roundDirection,hit?.distance??distance+breachingRoundRear+breachingRoundFront,breachingRoundRadius):null;
 const utilityFirst=utility&&(!hit||utility.distance<hit.distance-1e-9);
 if(game){
  const owner=d.owner??game.actorId,team=d.team??game.team;
  const firstDistance=utilityFirst?utility.distance:hit?.distance;
  const actor=roundActorContact(game,owner,from.clone().addScaledVector(d.roundDirection,-breachingRoundRear),d.roundDirection,firstDistance??distance+breachingRoundRear+breachingRoundFront,breachingRoundRadius);
  if(actor&&(firstDistance===undefined||actor.distance<firstDistance-1e-9)){
   let damaged=false;if(actor.human)damaged=actor.human.actor.takeDamage(breachingRoundActorDamage,owner,team);
   else if(actor.bot){const hp=actor.bot.hp;game.damageBot(actor.bot,breachingRoundActorDamage,owner,team);damaged=actor.bot.hp<hp;}
   if(damaged){const shooter=game.humans.find(h=>h.id===owner)?.actor??(game.actorId===owner?game:null);if(shooter)shooter.hit=.16;}
   d.pos.copy(actor.point);d.mesh.position.copy(d.pos);d.mesh.visible=false;d.active=false;d.time=0;d.roundRange=0;d.roundImpact=false;d.attached=false;d.panelId=-1;
   game.emitSound('gadget',d.pos,.22);return;
  }
 }
 if(utilityFirst){
  d.pos.copy(utility.point);d.mesh.position.copy(d.pos);d.panelId=-1;d.roundImpact=true;d.attached=true;d.blastNormal=utility.normal.clone();d.roundRange=0;
  d.time=Math.max(0,breachingRoundFuseSeconds-(dt-Math.max(0,utility.distance-breachingRoundRear-breachingRoundFront)/breachingRoundSpeed));
  const inverse=utility.root.matrixWorld.clone().invert();utilityAnchors.set(d,{root:utility.root,point:utility.point.clone().applyMatrix4(inverse),normal:utility.normal.clone().transformDirection(inverse),rotation:utility.root.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(d.mesh.quaternion)});
  return;
 }
 if(hit)hit.distance=Math.max(0,hit.distance-breachingRoundRear-breachingRoundFront);
 if(hit){
  d.pos.copy(hit.point);d.mesh.position.copy(d.pos);const panel=hit.object.userData.panel;
  d.panelId=panel?world.panels.indexOf(panel):-1;d.roundImpact=true;d.attached=true;d.blastNormal=hit.face.normal.clone().normalize();if(d.blastNormal.dot(d.roundDirection)>0)d.blastNormal.negate();d.roundRange=0;d.time=Math.max(0,breachingRoundFuseSeconds-(dt-hit.distance/breachingRoundSpeed));return;
 }
 d.mesh.position.addScaledVector(d.roundDirection,distance);d.pos.copy(d.mesh.position);
 d.roundRange=Math.max(0,(d.roundRange??breachingRoundRange)-distance);d.time=d.roundRange/breachingRoundSpeed;
 if(d.roundRange<=1e-8){d.panelId=-1;d.roundImpact=false;d.time=0;}
}

import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import type {Game} from './game';
import {hammerContact,canHammerContact,strikeHammerContact,hammerDurabilityCost} from './hammer-contact';
// Ubisoft's pre-Y11S3.1 baseline is a one-second swing. Earlier version continuity is inferred.
// Mid-swing contact timing is our procedural animation choice, not a documented Siege event time.
export const hammerSeconds=1,hammerImpactSeconds=.5,hammerHead=new THREE.Vector3(0,.85,0);
export const hammerReach=(stance:number,pitch=0)=>1.4-.45*THREE.MathUtils.clamp(stance-1,0,1)-.35*Math.max(0,Math.sin(pitch));
export function hammerModel(){
 const root=new THREE.Group(),dark=new THREE.MeshLambertMaterial({color:0x303931}),metal=new THREE.MeshLambertMaterial({color:0x89918c}),pieces:THREE.BufferGeometry[]=[];
 pieces.push(new THREE.CylinderGeometry(.019,.024,1.14,10).translate(0,.22,0));for(const y of [-.22,.05])pieces.push(new THREE.CylinderGeometry(.028,.028,.12,10).translate(0,y,0));const handle=mergeGeometries(pieces)!;pieces.forEach(g=>g.dispose());root.add(new THREE.Mesh(handle,dark));const head=new THREE.BoxGeometry(.28,.12,.14);head.translate(0,.85,0);root.add(new THREE.Mesh(head,metal));return root;
}
export function disposeHammer(root:THREE.Group){root.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();for(const m of Array.isArray(o.material)?o.material:[o.material])m.dispose();}});root.removeFromParent();}
export const hammerGrip=(side:number)=>new THREE.Vector3(side*.052,side<0?.05:-.22,0);
export const hammerWrist=(side:number)=>new THREE.Vector3(side*.044,-.045,.075);
export function hammerHand(side:number,sleeve=true){
 const root=new THREE.Group(),parts:THREE.BufferGeometry[]=[];
 const add=(g:THREE.BufferGeometry)=>{parts.push(g.toNonIndexed());g.dispose();};
 const link=(from:THREE.Vector3,to:THREE.Vector3,r:number)=>{const d=to.clone().sub(from),g=new THREE.CapsuleGeometry(r,d.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize()));g.translate(...from.clone().add(to).multiplyScalar(.5).toArray());add(g);};
 const palm=new THREE.SphereGeometry(1,8,6);palm.scale(.012,.036,.025);add(palm);
 for(const y of [.044,.021,-.003,-.028]){const points=[[.052,y,.008],[.043,y,-.027],[.008,y,-.042],[-.025,y,-.027]].map(p=>new THREE.Vector3(side*p[0],p[1],p[2]).sub(new THREE.Vector3(side*.052,0,0)));for(let i=1;i<points.length;i++)link(points[i-1],points[i],.006);}
 link(new THREE.Vector3(0,.032,.015),new THREE.Vector3(-side*.022,.045,.042),.008);link(new THREE.Vector3(-side*.022,.045,.042),new THREE.Vector3(-side*.055,.032,.040),.007);link(new THREE.Vector3(side*.005,-.027,.015),hammerWrist(side),.020);
 const geometry=mergeGeometries(parts)!;parts.forEach(g=>g.dispose());root.add(new THREE.Mesh(geometry,new THREE.MeshLambertMaterial({color:0x30392f})));
 if(sleeve){const from=hammerWrist(side),to=from.clone().add(new THREE.Vector3(side*.08,-.08,.16)),delta=to.clone().sub(from),g=new THREE.CapsuleGeometry(.03,delta.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()));g.translate(...from.add(to).multiplyScalar(.5).toArray());root.add(new THREE.Mesh(g,new THREE.MeshLambertMaterial({color:0x526048})));}return root;
}
export function hammerPose(eye:THREE.Vector3,camera:THREE.Quaternion,target:THREE.Vector3,remaining:number,stance:number){
 const progress=1-remaining/hammerSeconds,impact=hammerImpactSeconds/hammerSeconds,prone=THREE.MathUtils.clamp(stance-1,0,1),wind=THREE.MathUtils.smoothstep(progress,0,.2),stroke=THREE.MathUtils.smoothstep(progress,.2,impact),follow=THREE.MathUtils.smoothstep(progress,impact,1),origin=new THREE.Vector3(.12,-.23*(1-.65*prone),-.34+.12*prone).applyQuaternion(camera).add(eye),anchor=new THREE.Vector3(.08,-.23*(1-.65*prone),-.43+.25*prone).applyQuaternion(camera).add(eye),direction=target.clone().sub(anchor).normalize(),q=camera.clone().multiply(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),direction.clone().applyQuaternion(camera.clone().invert()))),hit=target.clone().sub(hammerHead.clone().applyQuaternion(q)),idle=camera.clone().multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(-.6-.3*wind,0,-.3)));
 return {position:origin.clone().lerp(hit,stroke).lerp(origin,follow),quaternion:idle.clone().slerp(q,stroke).slerp(idle,follow)};
}
export function beginHammerSwing(game:Game){
 if(!game.authority||game.gadgetCount<=0||game.phase==='prep'&&game.team===0)return false;const hit=hammerContact(game,game.eye(),game.face(),hammerReach(game.stanceAmount,game.pitch+game.recoilPitch));
 if(!hit||!canHammerContact(game,hit)){game.tell('MOVE CLOSE TO A SOFT PANEL, DEVICE OR ENEMY');return false;}
 game.hammerSwing=hammerSeconds;game.hammerHit=false;game.hammerPanel=hit.panel??null;game.hammerObject=hit.object;game.hammerTarget=hit.point;game.inspect=0;game.ads=false;return true;
}
export function updateHammerSwing(game:Game,dt:number){
 if(game.hammerSwing<=0)return;
 if(game.hp<=0||game.downed||game.observing||game.operator!==2||!['prep','action'].includes(game.phase)){game.cancelHammerSwing();return;}
 game.hammerSwing=Math.max(0,game.hammerSwing-dt);
 if(!game.hammerHit&&game.hammerSwing<=hammerSeconds-hammerImpactSeconds){game.hammerHit=true;if(game.authority){const hit=hammerContact(game,game.eye(),game.face(),hammerReach(game.stanceAmount,game.pitch+game.recoilPitch));if(hit&&hit.object===game.hammerObject&&game.gadgetCount>0&&strikeHammerContact(game,hit)){game.hammerTarget=hit.point;game.gadgetCount=Math.max(0,game.gadgetCount-hammerDurabilityCost(hit));}else game.cancelHammerSwing();}}
}

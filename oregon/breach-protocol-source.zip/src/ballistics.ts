import * as THREE from 'three';
export const gunHandling=[
 {hip:.060,aim:.0012,move:1.6,bloom:.0028,maxBloom:.019,recover:.040,sprint:.24,pitchRecover:6,yawRecover:8,switchTime:.19,pellets:1},
 {hip:.095,aim:.039,move:1.35,bloom:.009,maxBloom:.03,recover:.08,sprint:.31,pitchRecover:4.4,yawRecover:6.2,switchTime:.27,pellets:8},
 {hip:.085,aim:.0028,move:1.9,bloom:.0034,maxBloom:.026,recover:.050,sprint:.20,pitchRecover:5.4,yawRecover:7.1,switchTime:.16,pellets:1},
 {hip:.063,aim:.0014,move:1.65,bloom:.003,maxBloom:.021,recover:.043,sprint:.29,pitchRecover:5.7,yawRecover:7.5,switchTime:.23,pellets:1},
 {hip:.055,aim:.0015,move:1.5,bloom:.0025,maxBloom:.017,recover:.047,sprint:.22,pitchRecover:6.6,yawRecover:8.7,switchTime:.19,pellets:1},
 {hip:.045,aim:.002,move:1.6,bloom:.003,maxBloom:.015,recover:.05,sprint:.16,pitchRecover:8.2,yawRecover:10,switchTime:.14,pellets:1}
];
// Uniform solid-angle cone: cos(theta), not x/y offsets, is sampled uniformly.
export function coneDirection(forward:THREE.Vector3,angle:number,random=Math.random){const cos=1-random()*(1-Math.cos(angle)),sin=Math.sqrt(Math.max(0,1-cos*cos)),phi=random()*Math.PI*2;const right=new THREE.Vector3().crossVectors(forward,Math.abs(forward.y)>.95?new THREE.Vector3(1,0,0):new THREE.Vector3(0,1,0)).normalize(),up=new THREE.Vector3().crossVectors(right,forward).normalize();return forward.clone().multiplyScalar(cos).addScaledVector(right,sin*Math.cos(phi)).addScaledVector(up,sin*Math.sin(phi)).normalize();}

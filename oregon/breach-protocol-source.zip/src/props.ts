import type {World} from './world';
import {planX,planZ} from './map-plan';
export type MapProp={id:string,room:string,floor:number,x:number,z:number,width:number,depth:number,height:number,type:'counter'|'table'|'bunk'|'washer'|'bed'|'foosball',reference:string};
// Individual plan-space footprints. Heights and metric scale remain provisional.
// The 2020 plan is a historical baseline; only Games is corroborated by the 2025 tour.
export const mapProps:MapProp[]=[
 
 
 {id:'dining-table',room:'dining',floor:0,x:223,z:291,width:30,depth:28,height:.8,type:'table',reference:'2020 ground cutaway, dining table footprint'},
 {id:'meeting-table',room:'meeting',floor:0,x:542,z:298,width:60,depth:20,height:.85,type:'table',reference:'2020 ground cutaway, meeting table footprint'},
 
 {id:'dorm-north-bunk',room:'dorms',floor:1,x:366,z:384,width:16,depth:27,height:1.95,type:'bunk',reference:'2020 upper cutaway, north dorm bunk'},
 {id:'dorm-south-bunk',room:'dorms',floor:1,x:333,z:421,width:16,depth:27,height:1.95,type:'bunk',reference:'2020 upper cutaway, south dorm bunk'},
 {id:'kids-south-bunk',room:'kids',floor:1,x:374,z:333,width:16,depth:27,height:1.95,type:'bunk',reference:'2020 upper cutaway, south kids bunk'},
 {id:'laundry-washer-west',room:'laundry',floor:-1,x:484,z:359,width:20,depth:16,height:1,type:'washer',reference:'Inherited laundry appliance footprint; exact size unverified'},
 {id:'laundry-washer-middle',room:'laundry',floor:-1,x:509,z:359,width:20,depth:16,height:1,type:'washer',reference:'Inherited laundry appliance footprint; exact size unverified'},
 {id:'laundry-washer-east',room:'laundry',floor:-1,x:534,z:359,width:20,depth:16,height:1,type:'washer',reference:'Inherited laundry appliance footprint; exact size unverified'},
 {id:'games-foosball',room:'games',floor:1,x:487,z:420,width:34,depth:18,height:.96,type:'foosball',reference:'2020 upper cutaway footprint; Poxonlox 2025 at 3:07 confirms red foosball table'},
 {id:'master-bed',room:'master',floor:1,x:565,z:460,width:31,depth:42,height:.65,type:'bed',reference:'2020 upper cutaway, master bed footprint; 2025 continuity unverified'}
];
export function buildProps(w:World){for(const p of mapProps){const x=planX(p.x),z=planZ(p.z),y=p.floor*4,W=p.width*.075,D=p.depth*.075;
 const box=(dx:number,dy:number,dz:number,width:number,height:number,depth:number,mat:string,solid=true)=>{const m=w.box(x+dx,y+dy,z+dz,width,height,depth,mat,solid);m.userData.propId=p.id;m.userData.bulletMaterial=mat==='wood'?'wood':mat==='metal'?'metal':'stone';m.userData.penetration=solid&&mat==='wood'&&Math.min(width,height,depth)<.20;m.userData.reference=p.reference;if(solid&&p.type!=='bunk'&&dy+height/2>=p.height-.02&&dy+height/2<=p.height+.1){m.userData.walkable=true;w.supports.push(m.userData.panel);}return m;};
 if(p.type==='bunk'){for(const level of [.28,1.3]){box(0,level,0,W,.13,D,'wood');box(0,level+.13,0,W-.08,.13,D-.1,'white');box(0,level+.22,-D*.34,W*.78,.10,.4,'white',false);}for(const dx of [-W/2+.035,W/2-.035]){box(dx,.98,0,.07,1.96,D,'metal');box(dx,1.72,D*.46,.06,.08,.06,'metal',false);}for(const dy of [.45,.8,1.15])box(W/2+.02,dy,-D*.3,.06,.055,.45,'metal');}
 else if(p.type==='bed'){box(0,.19,0,W,.38,D,'wood');box(0,.5,0,W-.08,.24,D-.1,'white');box(0,.65,-D*.34,W*.78,.12,.5,'white',false);box(0,.85,-D/2+.04,W,.9,.08,'wood');}
 else if(p.type==='table'||p.type==='foosball'){box(0,p.height-.08,0,W,.16,D,'wood');for(const dx of [-W/2+.13,W/2-.13])for(const dz of [-D/2+.13,D/2-.13])box(dx,(p.height-.16)/2,dz,.13,p.height-.16,.13,'wood');if(p.type==='foosball'){box(0,p.height+.03,0,W-.12,.025,D-.12,'green',false);for(const dz of [-D/2+.04,D/2-.04])box(0,p.height+.12,dz,W,.2,.08,'orange');for(const dx of [-W/2+.04,W/2-.04])box(dx,p.height+.12,0,.08,.2,D,'orange');for(let i=0;i<6;i++){const dx=(i-2.5)*W/7;box(dx,p.height+.16,0,.025,.025,D+.3,'metal',false);for(const dz of [-D*.25,0,D*.25])box(dx,p.height+.11,dz,.065,.13,.065,i%2?'blue':'white',false);}}}
 else{box(0,p.height/2,0,W,p.height,D,p.type==='washer'?'white':p.room==='kitchen'?'metal':'wood');box(0,p.height+.02,0,W+.03,.04,D+.03,'metal',false);if(p.type==='washer'){box(0,p.height*.47,D/2+.015,W*.45,p.height*.46,.025,'metal',false);box(0,p.height*.47,D/2+.032,W*.31,p.height*.31,.013,'blue',false);box(0,p.height*.86,D/2+.025,W*.55,.055,.03,'metal',false);}else for(let i=0;i<Math.max(1,Math.round(W/.8));i++)box(-W*.4+i*.8,p.height*.74,D/2+.015,.2,.025,.025,'metal',false);}
}}

import * as THREE from 'three';
import type {World,Panel} from './world';
import {sites} from './data';
export class BombModels{
 models:{root:THREE.Group,panels:Panel[],site:number,index:number}[]=[];active=-1;
 constructor(public world:World){
  const frame=new THREE.MeshLambertMaterial({color:0x596365}),tank=new THREE.MeshLambertMaterial({color:0x8e998c}),orange=new THREE.MeshLambertMaterial({color:0xb27c36}),screen=new THREE.MeshBasicMaterial({color:0x527e8b});
  for(let site=0;site<sites.length;site++)for(let index=0;index<2;index++){
   const p=sites[site].bombs[index],root=new THREE.Group(),panels:Panel[]=[];root.position.set(p.x,((p as typeof p & {y?:number}).y??p.floor*4),p.z);root.rotation.y=p.yaw;world.scene.add(root);
   const add=(geo:THREE.BufferGeometry,x:number,y:number,z:number,m:THREE.Material,collision=false)=>{const o=new THREE.Mesh(geo,m);o.position.set(x,y,z);o.userData.dynamic=true;root.add(o);root.updateMatrixWorld(true);if(collision){const panel=world.register(o,'solid');panel.mesh.userData.bomb=true;panel.defaultBroken=true;panels.push(panel);}return o;};
   const box=(x:number,y:number,z:number,w:number,h:number,d:number,m:THREE.Material=frame,collision=false)=>add(new THREE.BoxGeometry(w,h,d),x,y,z,m,collision);
   box(0,.1,0,1.05,.2,.76,frame,true);box(0,.75,0,.75,1.15,.5,tank,true);
   for(const x of [-.48,.48]){box(x,.76,0,.06,1.38,.73);box(x,1.45,0,.06,.06,.73);box(x,.29,0,.06,.07,.73);}
   for(const z of [-.32,.32]){box(0,1.45,z,1.02,.06,.06);box(0,.25,z,1.02,.05,.05);}
   for(const x of [-.24,0,.24])add(new THREE.CylinderGeometry(.1,.1,1.12,12),x,.78,.05,tank);
   box(0,.93,-.32,.53,.34,.1,orange);box(-.05,.95,-.382,.25,.16,.02,screen);
   for(let i=0;i<4;i++)box(.18,.86+i*.055,-.388,.055,.025,.015,frame);
   for(const x of [-.37,.37])box(x,.6,-.28,.05,.66,.06,orange);
   const label=document.createElement('canvas');label.width=label.height=64;const c=label.getContext('2d')!;c.fillStyle='#dfbd68';c.fillRect(0,0,64,64);c.fillStyle='#182421';c.font='bold 44px Arial';c.textAlign='center';c.fillText(index?'B':'A',32,49);const t=new THREE.CanvasTexture(label);t.colorSpace=THREE.SRGBColorSpace;const badge=new THREE.Mesh(new THREE.PlaneGeometry(.2,.2),new THREE.MeshBasicMaterial({map:t,side:THREE.DoubleSide}));badge.position.set(0,1.27,-.29);badge.userData.dynamic=true;root.add(badge);
   this.models.push({root,panels,site,index});
  }this.select(0);
 }
 select(site:number){this.active=site;for(const model of this.models){const active=model.site===site;model.root.visible=active;for(const p of model.panels){p.broken=!active;p.mesh.visible=active;p.defaultBroken=!active;}}}
 position(site:number,index:number){const p=sites[site].bombs[index];return new THREE.Vector3(p.x,((p as typeof p & {y?:number}).y??p.floor*4)+.7,p.z);}
}

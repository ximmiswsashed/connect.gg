import * as THREE from 'three';

/** Pull out, unfold, fasten, then recover; animation never completes gameplay actions. */
export function installationPose(progress:number,reinforce:boolean,hatch:boolean){
 const p=THREE.MathUtils.clamp(progress,0,1),ease=(a:number,b:number)=>THREE.MathUtils.smoothstep(p,a,b);
 const present=ease(0,.16),recover=ease(.88,1),work=THREE.MathUtils.clamp((p-.23)/.59,0,1);
 const stroke=Math.sin(work*Math.PI*(reinforce?8:6))**4*(p>.23&&p<.82?1:0);
 return {position:new THREE.Vector3(0,-.25*(1-present)-.22*recover+(hatch?-.1:.04),-.08+.2*(1-present)+.12*recover),
  rotation:new THREE.Euler(hatch?-.65:.14,0,(1-present)*-.55+recover*.35),
  panelScale:new THREE.Vector3(1,reinforce?THREE.MathUtils.lerp(.35,3,ease(.13,.55)):1,1),
  left:new THREE.Vector3(-.25,-.02,-.46),right:new THREE.Vector3(.20,-.015+stroke*.045,-.45-stroke*.065),stroke};
}

// Receiver-space socket calibration for the original R4-C rail. Source sight
// bounds are translated, never scaled; the measured lens follows the same socket.
// All other supported guns have modeled integral irons, with no removable optic.
export const weaponAttachmentSockets=[
 {iron:{mountY:0,rearZ:0},holo:{mountY:.0704,rearZ:-.08},reddot:{mountY:.0704,rearZ:-.08},reflex:{mountY:.0704,rearZ:-.08},acog:{mountY:.0704,rearZ:-.08}},
 {iron:{mountY:0,rearZ:0}},{iron:{mountY:0,rearZ:0}},
 {iron:{mountY:0,rearZ:0}},{iron:{mountY:0,rearZ:0}},{iron:{mountY:0,rearZ:0}},
] as const;
export function attachmentSocket(weapon:number,optic:string){if(weapon===0&&typeof location!=='undefined'&&new URLSearchParams(location.search).get('sights')==='reference'){const heights:Record<string,number>={holo:.0704,reddot:.06920451175,reflex:.06791192583,acog:.07006283575};if(heights[optic]!==undefined)return {mountY:heights[optic],rearZ:-.08};}if(weapon!==0&&optic!=='iron'&&['holo','acog'].includes(optic))return {mountY:[.0704,.055,.069,.061,.065,.043][weapon]??.0704,rearZ:weapon===5?.015:-.08};return (weaponAttachmentSockets[weapon] as Record<string,{mountY:number,rearZ:number}>|undefined)?.[optic];}

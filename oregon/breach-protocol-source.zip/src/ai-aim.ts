import * as THREE from 'three';
import type {Game,Bot} from './game';
import {botPosture} from './ai-posture';
import {visualSight} from './visual-sight';
type SeenTarget={pos:THREE.Vector3,height:number};
const fractions=[.7,.9,.45];
export function visibleAimPoint(game:Game,b:Bot,target:SeenTarget,dt:number,fresh:boolean){
 const data=b.mesh.userData;
 const from=b.pos.clone().add(new THREE.Vector3(0,Math.max(.27,botPosture(b).eye-.16),0));
 data.aimExposureTime=(data.aimExposureTime??0)-dt;
 if(fresh||data.aimExposureTime<=0){
  data.aimExposureTime=.2;data.aimExposedFraction=null;
  for(const fraction of fractions){const point=target.pos.clone().add(new THREE.Vector3(0,target.height*fraction,0));if(visualSight(game,from,point)){data.aimExposedFraction=fraction;break;}}
 }
 const point=data.aimExposedFraction===null?null:target.pos.clone().add(new THREE.Vector3(0,target.height*data.aimExposedFraction,0));
 return point&&visualSight(game,from,point)?point:null;
}
export function firingPosition(game:Game,b:Bot,target:SeenTarget){
 const forward=target.pos.clone().sub(b.pos).setY(0).normalize(),side=new THREE.Vector3(forward.z,0,-forward.x),height=botPosture(b).height;
 const directions=[side,side.clone().negate(),forward,forward.clone().negate(),side.clone().add(forward).normalize(),side.clone().sub(forward).normalize(),side.clone().negate().add(forward).normalize(),side.clone().negate().sub(forward).normalize()];
 for(const radius of [1,1.8,2.8])for(const direction of directions){
  const candidate=b.pos.clone().addScaledVector(direction,radius);candidate.y=game.world.ground(candidate.x,candidate.z,b.pos.y,.06)+.015;
  if(Math.abs(candidate.y-b.pos.y)>.36||game.world.collide(candidate.x,candidate.y,candidate.z,.27,height))continue;
  const from=candidate.clone().add(new THREE.Vector3(0,Math.max(.27,botPosture(b).eye-.16),0));
  if(fractions.some(f=>visualSight(game,from,target.pos.clone().add(new THREE.Vector3(0,target.height*f,0)))))return candidate;
 }
 return null;
}

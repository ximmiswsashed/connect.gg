import type {ReplayClip} from './replay';

export const replayEncoding='gzip-base64-v1';
export const replayPartSize=12000,replayMaxParts=48;
const maxExpandedBytes=8*1024*1024;

async function boundedBytes(stream:ReadableStream<Uint8Array>,limit:number){
 const reader=stream.getReader(),chunks:Uint8Array[]=[];let length=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;length+=value.byteLength;if(length>limit){await reader.cancel();throw Error('Replay exceeds transport budget');}chunks.push(value);}}
 finally{reader.releaseLock();}
 const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}return bytes;
}

/** Compress recorded data, never meshes, without blocking on synchronous gzip. */
export async function encodeReplay(clip:ReplayClip){
 const raw=new TextEncoder().encode(JSON.stringify(clip));if(raw.length>maxExpandedBytes)throw Error('Replay exceeds expanded budget');
 const bytes=await boundedBytes(new Blob([raw]).stream().pipeThrough(new CompressionStream('gzip')),replayPartSize*replayMaxParts*3/4);
 let binary='';for(let i=0;i<bytes.length;i+=16384)binary+=String.fromCharCode(...bytes.subarray(i,i+16384));
 return {data:btoa(binary),rawBytes:raw.length,compressedBytes:bytes.length};
}

export async function decodeReplay(data:string,id:string):Promise<ReplayClip>{
 if(data.length>replayPartSize*replayMaxParts)throw Error('Replay exceeds packet budget');
 const binary=atob(data),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
 const raw=await boundedBytes(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip')),maxExpandedBytes);
 const clip=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(raw)) as ReplayClip;
 if(clip.id!==id||clip.duration!==3.5||!Array.isArray(clip.frames)||clip.frames.length<1||clip.frames.length>90)throw Error('Invalid replay');
 return clip;
}

import {installationBeats} from './installation-pose';
import {leanPose,leanedEye,limitLean,dampLean,operatorMobility,movementState as resolveMovementState} from './player-motion';
import {adsDuration,aimPrecision,blendFov} from './aiming-profile';
import {bindUtilityWorld,useUtility,activateUtility,updateUtilities,utilitySlow,utilityCameras,recoverUtility,meleeUtility} from './secondary-gadgets';
import {weaponCatalog} from './weapon-catalog';import {validatedSecondary,validatedUtility,utilityCapacity,type Utility} from './loadouts';
import {firearmDamage} from './ballistic-damage';
import {sourceRappelSpan} from './rappel-span';
import {PenetrationPath} from './penetration';
import {strikeMelee} from './melee';

import {diagonalFootprintSupport} from './footprint-support';

import {cancelBotBreach} from './bot-breaching';

import {throwSmoke,releaseSmoke,pendingSmoke,smokeReleasePosition,smokeThrowDuration,smokeReleaseTime,cancelBotSmokeThrow} from './smoke';

import {beginHammerSwing,updateHammerSwing} from './breaching-hammer';

import {fireBreachingLauncher,launcherDrawSeconds} from './breaching-launcher';

import {advanceBreachingRound} from './breaching-round';

import {detonateBreachingDevice} from './breaching-blast';

import {placeJammer,jammerPlacement,jammerPosture,jammerPlacementSeconds} from './jammer';

import {refreshGasCloud} from './gas-cloud';

import {advanceThrowable} from './throwable';

import {ercCapacity,ercRechargeRate,ercActivationRatio,observationHidden} from './erc';

import {gasDamage,jammerRadius,jammerWarningRadius,pendingCharge} from './gadget-effects';

import {visualSight} from './visual-sight';

import type {PerceptionTuning} from './ai-perception';

import {weaponMuzzle} from './weapon-geometry';

import {findVault,sweepVault,vaultPoint,vaultHeight,vaultPosture,type VaultPlan} from './vault';import {posture,stanceValue,stride} from './pose';

import {deviceRoot,deviceMesh,disposeDevice} from './devices';

import {ReplayHistory,type ReplayClip} from './replay';
import {RoundSequence,type RoundResult} from './round-sequence';
import {contactFromHit,type DamageContact} from './replay-damage';

import {AudioSystem,SoundKind,SoundEvent} from './audio';import {integrateMovement} from './movement';

import {cancelReloadAmmo,completeReloadAmmo} from './ammunition';

import {securityCameras} from './map-plan';

import * as THREE from 'three';

import {BombObjective,objectiveConfig,DefuserView} from './objectives';import {validatedWeapon,isSecondaryOnly} from './loadouts';import {attackerSpawns} from './map-plan';

import {World,Panel} from './world';import {MovementMachine,MovementState,movementConfig as motion} from './movement';import {gunHandling,coneDirection} from './ballistics';import {CharacterRig} from './characters';import {weapons,operators,sites} from './data';import {Drone} from './drone';import {adsFov,adsAlignment,opticCenter,hipOffsetX,hipOffsetY,hipOffsetZ,Optic} from './optics';import {updateTacticalBots,advanceBotMotion} from './bots';

export type Phase='menu'|'selection'|'prep'|'action'|'aftermath'|'replay'|'result'|'complete';

export type Bot={objectiveHold?:number,shotSerial?:number,id:number,name:string,team:number,role?:'breacher'|'support'|'anchor'|'roamer',operator?:number,gadgetCharges?:number,hammerSwing?:number,hammerHit?:boolean,hammerTarget?:THREE.Vector3|null,launcherEquipped?:boolean,launcherDraw?:number,launcherReload?:number,launcherShot?:number,chargeHold?:number,breachWait?:number,breachRetreat?:boolean,breachCooldown?:number,breachPanel?:Panel,breachPoint?:THREE.Vector3,breachStart?:THREE.Vector3,breachDevice?:Device,smokeThrow?:number,smokeReleased?:boolean,jammerHold?:number,jammerTarget?:THREE.Vector3|null,ercEnergy?:number,ercActive?:boolean,ercGlitch?:number,interference?:number,ercSense?:number,ercThreat?:number,stance?:Game['stance'],stanceAmount?:number,pitch?:number,aiming?:boolean,drone?:Drone,hp:number,kills:number,mesh:THREE.Group,pos:THREE.Vector3,goal:THREE.Vector3,cool:number,path:THREE.Vector3[],brain?:{mode:string,lastSeen:THREE.Vector3|null,memory:number,reaction:number,burst:number,decision:number,lastHp:number,targetId:string,objectiveHold:number,visible?:boolean,acquisition?:number}};

export type Device={type:string,pos:THREE.Vector3,mesh:THREE.Mesh,time:number,active:boolean,team?:number,owner?:string,panelId?:number,deploying?:boolean,disabledTime?:number,flightVelocity?:THREE.Vector3,attached?:boolean,roundDirection?:THREE.Vector3,roundRange?:number,roundImpact?:boolean,blastNormal?:THREE.Vector3};

export type Human={id:string,name:string,actor:Game,mesh:THREE.Group};

export type LobbyRules={aiEnabled:boolean,enemyCount:number,allyCount:number,difficulty:'Easy'|'Normal'|'Hard',playerLimit:number,selectionSeconds?:number,aiPerception?:Partial<PerceptionTuning>,reloadCancelBullet?:boolean,dbno?:boolean,friendlyFire?:boolean,teammateDamage?:number};

export class Game{

 playerName='Player';roundSequence=new RoundSequence();onRoundResult=(result:RoundResult)=>{void result;};
 onRecordedDamage=(victim:string,attacker:string,amount:number,healthLoss:number,contact?:DamageContact)=>this.history.damage(victim,attacker,amount,healthLoss,contact);
 history=new ReplayHistory();replayClip:ReplayClip|null=null;replayElapsed=0;onReplay=(clip:ReplayClip)=>{void clip;};onConfirmedKill=(killer:string,victim:string)=>this.recordElimination(killer,victim);onRecordedSound=(event:SoundEvent)=>{if(this.phase==='action')this.history.sound(event);};

 rappelInverted=false;observationDrone:Drone|null=null;observationYaw=0;observationPitch=0;impactCooldown=0;actionPosition=new THREE.Vector3();rappelAnchor:{axis:'x'|'z',plane:number,side:number,roof:number,min:number,max:number}|null=null;

 get viewDrone():Drone{return this.observationDrone??this.droneUnit;}

 get canPickupDrone(){const d=this.droneUnit;return this.team===0&&this.hp>0&&!this.downed&&!this.observing&&!this.rappel&&!this.vaultFrom&&this.action<=0&&this.reload<=0&&d.alive&&d.deployed&&!d.airborne&&this.pos.distanceTo(d.pos)<1.4&&this.world.sight(this.eye(),d.eye());}

 pickupDrone(){if(!this.authority||!this.canPickupDrone)return false;this.droneUnit.stow();this.observationDrone=null;this.ads=false;this.inspect=0;this.emitSound('gadget',this.pos,.15);this.tell('DRONE RECOVERED');return true;}

 droneDeploymentPoint(){

  const d=this.droneUnit;if(this.team!==0||this.hp<=0||this.downed||this.observing||this.rappel||this.vaultFrom||this.action>0||this.reload>0||!d.alive||d.deployed)return null;

  const target=this.pos.clone().add(new THREE.Vector3(-Math.sin(this.yaw)*.7,0,-Math.cos(this.yaw)*.7));

  target.y=Math.max(...[[0,0],[.14,.14],[-.14,.14],[.14,-.14],[-.14,-.14]].map(([dx,dz])=>this.world.ground(target.x+dx,target.z+dz,this.pos.y,.32)))+.015;

  if(Math.abs(target.y-this.pos.y)>.38||!this.world.sight(this.eye(),target.clone().add(new THREE.Vector3(0,.12,0)))||this.occupied(target,.17))return null;

  for(let i=0;i<=18;i++){const p=this.pos.clone().lerp(target,i/18);if(this.world.collide(p.x,p.y,p.z,.14,.17))return null;}

  return target;

 }

 deployDrone(){if(!this.authority)return false;const target=this.droneDeploymentPoint();if(!target){this.tell('DRONE DEPLOYMENT BLOCKED');return false;}this.droneUnit.place(target,this.yaw);this.observationDrone=null;this.ads=false;this.inspect=0;this.emitSound('gadget',target,.15);this.tell('DRONE DEPLOYED');return true;}

 get droneInterference():boolean{return this.observing&&this.cameraIndex<0&&[...this.humans.map(h=>h.actor),...this.bots].some(a=>a.team!==this.team&&a.hp>0&&(a.interference??0)>0&&a.pos.distanceTo(this.viewDrone.pos)<12);}

 get availableDrones():Drone[]{const humans=[this,...this.humans.map(h=>h.actor).filter(a=>a!==this&&a.team===this.team)].sort((a,b)=>a.actorId.localeCompare(b.actorId)).map(a=>a.droneUnit),bots=this.bots.filter(b=>b.team===this.team).sort((a,b)=>a.id-b.id).flatMap(b=>b.drone?[b.drone]:[]);return [...new Set([...humans,...bots])].filter(d=>d.alive&&d.deployed);}

 get staticCameraCount(){return securityCameras.length;}
 get observationCameras(){return [...securityCameras,...utilityCameras(this).map(d=>{const n=new THREE.Vector3(0,0,1).applyQuaternion(d.mesh.quaternion),p=d.pos.clone().addScaledVector(n,.09);return {name:'Bulletproof camera',x:p.x,y:p.y,z:p.z,yaw:Math.atan2(-n.x,-n.z),pitch:.05};})];}
 cameraLocation(index:number){return this.observationCameras[index];}
 cameraAlive(index:number){if(index>=securityCameras.length){const d=utilityCameras(this)[index-securityCameras.length];return !!d&&d.mesh.visible&&!d.disabledTime;}const p=this.world.panels.find(p=>p.mesh.userData.securityId===index);return !!p&&!p.broken;}

 cycleObservation(direction=1){this.viewInputGate=true;this.velocity.set(0,0,0);this.ads=false;this.adsProgress=0;const step=direction<0?-1:1;if(this.team===1){const list=this.observationCameras.map((_,i)=>i).filter(i=>this.cameraAlive(i)),current=list.indexOf(this.cameraIndex);this.cameraIndex=list.length?list[(current<0?(step>0?0:list.length-1):(current+step+list.length)%list.length)]:-1;if(this.cameraIndex<0)this.setObservation(false);}else{const list=this.availableDrones,current=list.indexOf(this.viewDrone);this.cameraIndex=-1;this.observationDrone=list.length?list[current<0?(step>0?0:list.length-1):(current+step+list.length)%list.length]:null;if(this.observationDrone){this.observationYaw=this.viewDrone.lookYaw;this.observationPitch=this.viewDrone.pitch;}else this.setObservation(false);}}

 collisionRig:CharacterRig|null=null;
 getCollisionMesh(){const human=this.humans.find(h=>h.actor===this);if(human){(human.mesh.userData.rig as CharacterRig)?.update(this,0);return human.mesh;}if(!this.collisionRig||this.collisionRig.operator!==this.operator){this.collisionRig?.dispose();this.collisionRig=new CharacterRig(this.operator);this.collisionRig.root.visible=false;this.world.scene.add(this.collisionRig.root);}this.collisionRig.update(this,0);return this.collisionRig.root;}
 baseFov=78;shakeScale=1;downed=false;wasDowned=false;bleed=0;downedHealth=40;reviveTarget:Game|null=null;lastDamager='';spectatorId='';pingCooldown=0;scanCooldown=0;pingTime=0;spottedUntil=0;shotAge=1;burstIndex=0;

 deathReplay:ReplayClip|null=null;deathSkipped=false;deathReplayAt=0;deathWaitingAt=0;onDeathReplay=(victim:string,clip:ReplayClip)=>{void victim;void clip;};
 acceptDeathReplay(clip:ReplayClip){if(this.deathSkipped||clip.victim!==this.actorId||this.deathReplay?.id===clip.id)return;this.deathReplay=clip;this.deathReplayAt=0;}
 recordElimination(killer:string,victim:string){this.history.kill(killer,victim);if(victim!==this.actorId&&!this.humans.some(h=>h.id===victim))return;const clip=this.history.deathClip(this,killer,victim);if(!clip)return;if(victim===this.actorId)this.acceptDeathReplay(clip);this.onDeathReplay(victim,clip);}
 resetHealth(){this.switchRemaining=this.switchTotal=0;this.pendingTrigger=false;this.firingLastStep=false;this.triggerHeld=false;this.leanVelocity=0;this.deathSkipped=false;this.deathReplay=null;this.deathReplayAt=0;this.deathWaitingAt=0;this.hp=100;this.downed=false;this.wasDowned=false;this.bleed=0;this.downedHealth=40;this.reviveTarget=null;this.spectatorId='';this.lastDamager='';this.pingCooldown=0;this.scanCooldown=0;this.pingTime=0;this.spottedUntil=0;}

 takeDamage(amount:number,attacker:string,attackerTeam:number,head=false,contact?:DamageContact){if(!this.authority||this.phase!=='action'||this.hp<=0||!Number.isFinite(amount)||amount<=0)return false;if(attackerTeam===this.team&&attacker!==this.actorId){if(!this.rules.friendlyFire)return false;amount*=THREE.MathUtils.clamp(this.rules.teammateDamage??.5,0,1);}this.onRecordedDamage(this.actorId,attacker,amount,Math.min(amount,this.downed?this.downedHealth:this.hp),contact);this.lastDamager=attacker;this.hurt=.3;if(this.downed){this.downedHealth-=amount;if(head||this.downedHealth<=0)this.die(attacker);return true;}if(amount<this.hp){this.hp-=amount;if(this.ercActive)this.ercGlitch=.25;return true;}const teammate=this.humans.some(h=>h.actor!==this&&h.actor.team===this.team&&h.actor.hp>0&&!h.actor.downed)||this.bots.some(b=>b.team===this.team&&b.hp>0);if(!head&&!this.wasDowned&&this.rules.dbno!==false&&teammate&&amount-this.hp<50){this.interrupt();this.action=0;this.hp=1;this.downed=true;this.wasDowned=true;this.bleed=30;this.downedHealth=40;this.stance='prone';this.lean=this.leanTarget=this.leanVelocity=0;this.ads=false;this.observing=false;this.finishVaultIfNeeded();this.stance=this.postureBlocked(this.pos,2)?'crouch':'prone';this.emitSound('stance-prone',this.pos,.16);this.tell('DOWNED · Hold on for a teammate');}else this.die(attacker);return true;}

 finishVaultIfNeeded(){if(this.vaultFrom)this.finishVault(true);}

 die(killer:string){if(this.hp<=0)return;this.deathWaitingAt=performance.now();this.hp=0;this.cancelHammerSwing();this.stowLauncher();this.cancelSmokeThrow();this.ercActive=false;this.interference=0;this.ercGlitch=0;this.downed=false;this.bleed=0;this.action=0;this.reload=0;this.ads=false;this.lean=this.leanTarget=this.leanVelocity=0;this.observing=false;this.onConfirmedKill(killer,this.actorId);const shooter=this.humans.find(h=>h.actor.actorId===killer)?.actor;if(shooter)shooter.kills++;this.tell('ELIMINATED · Killcam, then live teammate view · 2 cycles teammates');}

 get reviveCandidate(){return this.humans.map(h=>h.actor).filter(a=>a!==this&&a.team===this.team&&a.downed&&a.hp>0&&this.canRevive(a)).sort((a,b)=>a.pos.distanceToSquared(this.pos)-b.pos.distanceToSquared(this.pos))[0]??null;}

 canRevive(a:Game){const target=a.pos.clone().add(new THREE.Vector3(0,.35,0)),d=target.clone().sub(this.eye());return !this.downed&&this.hp>0&&a.team===this.team&&a.downed&&d.length()<2.2&&d.normalize().dot(this.face())>.55&&this.world.sight(this.eye(),target);}

 get spectator():Game|null{return this.hp<=0?this.humans.find(h=>h.actor.actorId===this.spectatorId&&h.actor.team===this.team&&h.actor.hp>0)?.actor??this.humans.find(h=>h.actor!==this&&h.actor.team===this.team&&h.actor.hp>0)?.actor??null:null;}

 world:World;camera:THREE.PerspectiveCamera;audio=new AudioSystem();phase:Phase='menu';paused=false;operator=0;weapon=0;secondary=13;utility:Utility='breach';utilityCount=3;utilityCooldown=0;triggerHeld=false;switchRemaining=0;switchTotal=0;private firingLastStep=false;private pendingTrigger=false;leanVelocity=0;flashTime=0;empUntil=0;slot=0;ammo=[30,32];reserve=[150,160];hp=100;kills=0;score=[0,0];round=1;team=0;timer=20;prepDeadline=0;site=0;spawn=0;pos=new THREE.Vector3(0,0,22);yaw=Math.PI;pitch=0;stance:'stand'|'crouch'|'prone'='stand';movement=new MovementMachine();ads=false;lean=0;recoil=0;gadgetCount=2;smokeThrow=0;smokeReleased=false;reinforcements=2;reloadEmpty=false;reload=0;cool=0;action=0;actionKind='';planted=false;plantTimer=45;bots:Bot[]=[];devices:Device[]=[];observing=false;drone=new THREE.Vector3(0,0,20);cameraIndex=-1;interference=0;ercEnergy=ercCapacity;ercActive=false;ercGlitch=0;hit=0;hurt=0;message='';messageTime=0;ping:THREE.Vector3|null=null;botTick=0;foot=0;nextRound=0;aim=new THREE.Vector3();aimPanel:Panel|null=null;rappel=false;vaultTime=0;enemyIntel:THREE.Vector3|null=null;scouts:{pos:THREE.Vector3,path:THREE.Vector3[],mesh:THREE.Mesh}[]=[];actionPanel:Panel|null=null;defuserPos=new THREE.Vector3();rules:LobbyRules={aiEnabled:true,enemyCount:5,allyCount:4,difficulty:'Normal',playerLimit:10};authority=true;actorOnly=false;networked=false;teamOverride:number|null=null;humans:Human[]=[];droneUnit:Drone;externalDrones:Drone[]=[];externalDevices:Device[]=[];optics:Record<number,Optic>={};shake=0;shotSerial=0;noises:{pos:THREE.Vector3,team:number,time:number,radius:number}[]=[];onImpact=(p:THREE.Vector3,n:THREE.Vector3,material='stone')=>{void p;void n;void material;};onChange=()=>{};

 stanceAmount=0;stanceSerial=0;travelDistance=0;gaitCycle=0;actualVelocity=new THREE.Vector3();vaultPlan:VaultPlan|null=null;vaultSerial=0;completedVaultSerial=0;vaultProgress=0;vaultRetreat=false;vaultReturnStance:'stand'|'crouch'='stand';landingBlend=0;

 soundNonce=crypto.randomUUID();soundSerial=0;soundEvents:SoundEvent[]=[];installationAudioProgress=0;installationAudioKind="";audioClock=0;droneSoundClock=0;viewInputGate=false;prepAnchor=new THREE.Vector3();previousPhase:Phase='menu';

 emitSound(kind:SoundKind,pos=this.pos,gain=.3){const event={id:this.actorId+':'+this.soundNonce+':'+(++this.soundSerial),actor:this.actorId,kind,pos:pos.clone().toArray(),gain};this.audio.play(kind,pos,gain,event.id);if(this.authority)this.onRecordedSound(event);if(this.authority&&this.networked)this.soundEvents.push(event);}

 setObservation(open:boolean){if(open){this.stowLauncher();this.cancelSmokeThrow();}if(this.downed)return false;if(open&&this.team===0&&(!this.viewDrone.alive||!this.viewDrone.deployed)&&this.availableDrones.length)this.observationDrone=this.availableDrones[0];if(open&&this.team===0&&(!this.viewDrone.alive||!this.viewDrone.deployed)){this.tell(this.droneUnit.alive?'DRONE STOWED · Deploy before observing':'DRONE DESTROYED');return false;}this.interrupt();this.action=0;this.actionPanel=null;this.leanTarget=0;this.lean=this.leanVelocity=0;this.velocity.set(0,0,0);this.ads=false;this.adsProgress=0;this.viewInputGate=true;this.observing=open;this.cameraIndex=this.team===1&&open?this.observationCameras.findIndex((_,i)=>this.cameraAlive(i)):-1;if(open&&this.team===1&&this.cameraIndex<0){this.observing=false;this.tell('NO CAMERAS AVAILABLE');return false;}this.tell(open?'OBSERVATION OPEN':'OPERATOR VIEW');return true;}

 actorId='local';objectiveState=new BombObjective();defuserView:DefuserView;actionStart=new THREE.Vector3();recoilPitch=0;recoilYaw=0;recoilSerial=0;actionTotal=0;leanTarget=0;leanMode:'Hold'|'Toggle'='Toggle';leanHeldSide=1;reloadTotal=0;inspect=0;weaponSkins:Record<number,string>={};attachmentSkins:Record<number,string>={};

 visualY=0;cameraForward=0;velocity=new THREE.Vector3();verticalSpeed=0;cameraHeight=motion.stand.eye;adsProgress=0;spreadBloom=0;sprintLock=0;sprintFatigue=0;gadgetTime=0;vaultFrom:THREE.Vector3|null=null;vaultTo:THREE.Vector3|null=null;vaultElapsed=0;vaultLift=0;lastPellets:THREE.Vector3[]=[];

 get objectiveActors():Game[]{const humans=[this,...this.humans.map(h=>h.actor).filter(a=>a!==this)];return [...humans,...this.bots.map(b=>{const a=b.mesh.userData.objectiveActor??Object.create(this) as Game;b.mesh.userData.objectiveActor=a;Object.assign(a,{actorId:'bot:'+b.id,team:b.team,hp:b.hp,pos:b.pos,observing:false,rappel:false,vaultFrom:null,visualY:b.pos.y,cameraHeight:1.35,cameraForward:0,lean:0,actionKind:b.team===0?'plant':'disable',action:b.brain?.objectiveHold??0,actionTotal:7});return a as Game;})];}

 get handling(){return gunHandling[this.slot===0?this.weapon:this.secondary];}

 get spreadAngle(){const h=this.handling,precision=aimPrecision(this.slot===1?this.secondary:this.weapon,this.adsProgress),moving=Math.min(1,this.actualVelocity.length()/motion.stand.speed),base=THREE.MathUtils.lerp(h.hip,h.aim,precision);return base*(1+moving*(h.move-1)) + (this.spreadBloom+this.sprintFatigue*h.hip*.7)*(1-precision);}

 get muzzle(){const weapon=this.slot===1?this.secondary:this.weapon,alignment=adsAlignment(weapon,this.optic),near=this.world.trace(this.eye(),this.face(),.85)[0]?.distance??.85,offset=Math.max(0,.65-near),position=new THREE.Vector3(THREE.MathUtils.lerp(hipOffsetX(weapon),alignment.x,this.adsProgress),THREE.MathUtils.lerp(hipOffsetY(weapon),alignment.y,this.adsProgress)-offset*.45*(1-this.adsProgress),THREE.MathUtils.lerp(hipOffsetZ(weapon),alignment.z,this.adsProgress)+offset*.25*(1-this.adsProgress)),roll=-this.lean*(leanPose.bodyRoll-leanPose.cameraRoll),point=new THREE.Vector3(...weaponMuzzle(weapon)).applyAxisAngle(new THREE.Vector3(0,0,1),roll);if(this.optic!=='iron'){const c=opticCenter(weapon,this.optic),pivot=new THREE.Vector3(c.x,c.y,c.z);point.addScaledVector(pivot.clone().sub(pivot.clone().applyAxisAngle(new THREE.Vector3(0,0,1),roll)),this.adsProgress);}return this.eye().add(position.add(point).applyQuaternion(new THREE.Quaternion().setFromEuler(new THREE.Euler(this.pitch+this.recoilPitch,this.yaw+this.recoilYaw,-this.lean*leanPose.cameraRoll,'YXZ'))));}


 postureBlocked(pos:THREE.Vector3,value:number,yaw=this.yaw){const p=posture(value),r=p.prone>0?motion.prone.radius:motion.stand.radius;const offsets=p.prone>0?[-.55*p.prone,0,.55*p.prone,.85*p.prone]:[0];return offsets.some(d=>this.world.collide(pos.x+Math.sin(yaw)*d,pos.y,pos.z+Math.cos(yaw)*d,r,p.height));}

 bodyBlocked(pos:THREE.Vector3,stance=this.stance){return this.postureBlocked(pos,stanceValue(stance));}

 setYaw(yaw:number){if(this.stance==='prone'||this.stanceAmount>1){const delta=THREE.MathUtils.euclideanModulo(yaw-this.yaw+Math.PI,Math.PI*2)-Math.PI,n=Math.max(1,Math.ceil(Math.abs(delta)/.05));for(let i=1;i<=n;i++)if(this.postureBlocked(this.pos,Math.max(this.stanceAmount,stanceValue(this.stance)),this.yaw+delta*i/n))return;}this.yaw=yaw;}

 occupied(pos:THREE.Vector3,height:number){return this.humans.some(h=>h.actor!==this&&h.actor.hp>0&&h.actor.pos.y<pos.y+height&&h.actor.pos.y+motion[h.actor.stance].height>pos.y&&Math.hypot(h.actor.pos.x-pos.x,h.actor.pos.z-pos.z)<.57)||this.bots.some(b=>b.hp>0&&b.pos.y<pos.y+height&&b.pos.y+posture(b.stanceAmount??0).height>pos.y&&Math.hypot(b.pos.x-pos.x,b.pos.z-pos.z)<.57);}

 get vaultCandidate(){if(this.downed||this.hp<=0||this.observing||this.rappel||this.vaultFrom||this.stance==='prone'||this.action>0||this.gadgetTime>0)return null;const p=findVault(this.world,this.pos,this.yaw,(p,h)=>this.occupied(p,h),Math.min(this.stanceAmount,stanceValue(this.stance)));if(p&&this.phase==='prep'&&this.team===0){const to=new THREE.Vector3().fromArray(p.points[3]);if(!this.world.room(to.x,to.y,to.z).startsWith('EXT')||to.distanceTo(this.prepAnchor)>18)return null;}return p;}

 beginVault(){const p=this.vaultCandidate;if(!p)return false;this.interrupt();this.vaultPlan=p;this.vaultFrom=this.pos.clone();this.vaultTo=new THREE.Vector3().fromArray(p.points[3]);this.vaultReturnStance=this.stance==='crouch'?'crouch':p.landing;this.vaultElapsed=0;this.vaultProgress=0;this.vaultRetreat=false;this.vaultTime=p.duration;this.vaultSerial++;this.velocity.set(0,0,0);this.actualVelocity.set(0,0,0);this.leanTarget=0;this.lean=this.leanVelocity=0;this.ads=false;this.adsProgress=0;this.state='vault';if(this.ercActive)this.ercGlitch=.25;this.emitSound('stance-vault',this.pos,.14);return true;}

 finishVault(blocked=false){if(!blocked&&this.vaultPlan)this.completedVaultSerial=Math.max(this.completedVaultSerial,this.vaultSerial);const falling=!!this.vaultPlan?.dropLanding;this.vaultFrom=null;this.vaultTo=null;this.vaultPlan=null;this.vaultTime=0;this.vaultProgress=0;this.vaultElapsed=0;this.vaultRetreat=false;this.velocity.set(0,0,0);this.verticalSpeed=0;this.stance=this.bodyBlocked(this.pos,this.vaultReturnStance)?'crouch':this.vaultReturnStance;this.stanceAmount=1;this.cameraHeight=motion.crouch.eye;this.state=this.stance;this.landingBlend=blocked||falling?0:1;if(!blocked&&!falling)this.emitSound('stance-land',this.pos,.18);}

 advanceVault(dt:number){const p=this.vaultPlan;if(!p)return;const count=Math.max(1,Math.ceil(dt/.015));for(let i=0;i<count;i++){const elapsed=Math.max(0,Math.min(p.duration,this.vaultElapsed+(this.vaultRetreat?-dt/count:dt/count))),next=vaultPoint(p,elapsed/p.duration);if(!sweepVault(this.world,this.pos,next,Math.max(vaultHeight(p,this.vaultElapsed/p.duration),vaultHeight(p,elapsed/p.duration)),(v,h)=>this.occupied(v,h))){if(this.vaultElapsed<=1e-8){this.finishVault(true);this.tell('VAULT BLOCKED · Move clear and try again');return;}this.vaultRetreat=true;this.tell('VAULT BLOCKED · Returning to cover');return;}this.pos.copy(next);this.vaultElapsed=elapsed;this.vaultProgress=elapsed/p.duration;this.state='vault';this.velocity.set(0,0,0);this.stanceAmount=vaultPosture(p,this.vaultProgress);this.cameraHeight=this.rappel&&this.rappelInverted?.3:posture(this.stanceAmount).eye;if(this.vaultRetreat&&elapsed===0){this.finishVault(true);break;}else if(elapsed>=p.duration){this.finishVault();break;}}}

 changeStance(next:Game['stance']){if(this.downed)return false;if(next===this.stance||this.observing||this.vaultFrom||this.rappel||this.action>0)return false;const target=stanceValue(next),from=this.stanceAmount;for(let i=0;i<=8;i++)if(this.postureBlocked(this.pos,THREE.MathUtils.lerp(from,target,i/8)))return false;const old=this.stance;this.stance=next;this.stanceSerial++;this.foot=0;this.emitSound(next==='prone'?'stance-prone':old==='prone'?'stance-rise':next==='crouch'?'stance-crouch':'stance-stand',this.pos.clone().add(new THREE.Vector3(0,.4,0)),next==='prone'?.16:.11);return true;}

 get state(){return this.movement.state;} set state(next:MovementState){this.movement.transition(next,this.stance);}

 constructor(world:World,camera:THREE.PerspectiveCamera){this.world=world;this.camera=camera;bindUtilityWorld(this);this.defuserView=new DefuserView(world.scene);this.droneUnit=new Drone(world);this.drone=this.droneUnit.pos;}

 tell(text:string){this.message=text;this.messageTime=3;}

 start(op:number,weapon:number,site:number,spawn:number){this.operator=Number.isInteger(op)&&op>=0&&op<operators.length?op:0;this.weapon=validatedWeapon(this.operator,weapon);this.secondary=validatedSecondary(this.operator,this.secondary);this.site=site;this.spawn=spawn;this.team=this.teamOverride??(operators[op].role==='ATTACK'?0:1);this.score=[0,0];this.round=1;this.kills=0;this.begin();}

 begin(){this.completedVaultSerial=0;this.collisionRig?.dispose();this.collisionRig=null;this.cancelHammerSwing();this.stowLauncher();this.launcherReload=0;this.launcherShot=0;this.rappelInverted=false;this.observationDrone=null;this.rappelAnchor=null;this.history.reset();this.roundSequence.reset();this.replayClip=null;this.replayElapsed=0;this.resetHealth();this.firingLastStep=false;this.triggerHeld=false;this.leanVelocity=0;this.shotAge=1;this.burstIndex=0;this.world.reset();this.world.selectSite(this.site);this.leanTarget=0;this.inspect=0;this.reloadTotal=0;this.ping=null;this.defuserPos.set(0,0,0);for(const scout of this.scouts)this.world.scene.remove(scout.mesh);this.scouts=[];this.enemyIntel=null;for(const b of this.bots){(b.mesh.userData.rig as CharacterRig|undefined)?.dispose();b.drone?.dispose();}for(const d of this.devices)disposeDevice(d.mesh);this.devices=[];this.bots=[];this.phase='prep';this.timer=20;this.prepDeadline=performance.now()+20000;this.planted=false;this.hp=100;this.stance='stand';this.stanceAmount=0;this.travelDistance=0;this.gaitCycle=0;this.foot=0;this.stanceSerial=0;this.vaultPlan=null;this.vaultProgress=0;this.landingBlend=0;this.actualVelocity.set(0,0,0);this.movement=new MovementMachine();this.velocity.set(0,0,0);this.verticalSpeed=0;this.cameraHeight=motion.stand.eye;this.adsProgress=0;this.lean=0;this.spreadBloom=0;this.sprintLock=0;this.vaultFrom=null;this.vaultTo=null;this.reload=0;this.cool=0;this.gadgetTime=0;this.smokeThrow=0;this.smokeReleased=false;this.vaultTime=0;this.sprintFatigue=0;this.action=0;this.observing=false;this.rappel=false;this.weapon=validatedWeapon(this.operator,this.weapon);this.slot=0;this.ammo=[weapons[this.weapon].mag,weapons[this.secondary].mag];this.reserve=[weapons[this.weapon].reserve,weapons[this.secondary].reserve];this.recoilPitch=0;this.recoilYaw=0;this.gadgetCount=operators[this.operator].count;this.reinforcements=2;this.utility=validatedUtility(this.operator,this.utility);this.utilityCount=utilityCapacity[this.utility];this.utilityCooldown=0;this.flashTime=0;this.empUntil=0;this.interference=0;this.ercEnergy=ercCapacity;this.ercActive=false;this.ercGlitch=0;

  const spawns=attackerSpawns.map(s=>new THREE.Vector3(s.x,0,s.z));this.pos.copy(this.team===0?spawns[this.spawn]:this.world.point(sites[this.site].a,sites[this.site].floor));this.yaw=this.team===0?0:Math.PI;this.pitch=0;this.world.safeSpawn(this.pos,motion.stand.height);this.prepAnchor.copy(this.pos);this.previousPhase='prep';this.viewInputGate=false;this.soundEvents=[];this.visualY=this.pos.y;this.cameraForward=0;this.droneUnit.reset(spawns[this.spawn].clone().add(new THREE.Vector3(0,0,-1)));this.observing=this.team===0;

  for(let t=0;t<2;t++)for(let i=0;i<(this.rules.aiEnabled?Math.min(t===this.team?this.rules.allyCount:this.rules.enemyCount,Math.max(0,5-(t===this.team?1:0)-this.humans.filter(h=>h.actor!==this&&h.actor.team===t).length)):0);i++){

   const p=t===0?spawns[(i+this.spawn)%3].clone().add(new THREE.Vector3((i%2)*2,0,(i%3)*2)):this.world.point([sites[this.site].a,sites[this.site].b,1,7,10][i],sites[this.site].floor);

   this.world.safeSpawn(p,motion.stand.height);const botOperator=(t===0?[0,2,3]:[1,4,5])[i%3];const mesh=new CharacterRig(botOperator).root;this.world.scene.add(mesh);mesh.position.copy(p);const b:Bot={id:this.bots.length,name:['FALCON','ROOK','NOMAD','GHOST','ECHO'][i],team:t,operator:botOperator,gadgetCharges:operators[botOperator].count,role:t===0?(i%2?'support':'breacher'):(botOperator===5?'roamer':'anchor'),hp:100,kills:0,mesh,pos:p,goal:p.clone(),cool:1+i*.4,path:[]};mesh.traverse(o=>{if(o.userData.hitbox)o.userData.bot=b;});(mesh.userData.rig as CharacterRig).setTeam(t===this.team);if(t===0){b.drone=new Drone(this.world);b.drone.reset(p.clone());b.mesh.userData.dronePath=this.route(p,this.objective);}this.bots.push(b);

  }

  if(!this.actorOnly)this.objectiveState.reset(this.objectiveActors);

  this.history.prepare(this);
  this.tell(this.team===0?'PREPARATION · Scout with V. Breach entry barricades.':'PREPARATION · Reinforce with T. Set your defenses.');this.onChange();

 }

 get optic(){const optic=this.optics[this.slot===0?this.weapon:this.secondary]??'holo';return this.team!==0&&(optic==='acog'||optic==='rusacog')?'holo':optic;}

 configure(rules:LobbyRules){this.rules={...rules};if(!rules.aiEnabled){for(const b of this.bots){(b.mesh.userData.rig as CharacterRig|undefined)?.dispose();b.drone?.dispose();}this.bots=[];for(const scout of this.scouts)this.world.scene.remove(scout.mesh);this.scouts=[];}}

 look(dx:number,dy:number){if(this.observing&&this.cameraIndex<0){if(this.viewDrone===this.droneUnit){this.droneUnit.lookYaw-=dx;this.droneUnit.pitch=THREE.MathUtils.clamp(this.droneUnit.pitch-dy,-1.1,1.1);}else{this.observationYaw-=dx;this.observationPitch=THREE.MathUtils.clamp(this.observationPitch-dy,-1.1,1.1);}}else{this.setYaw(this.yaw-dx);this.pitch=THREE.MathUtils.clamp(this.pitch-dy,-1.45,1.45);}}

 get competitive(){return (this.team===0||this.humans.some(h=>h.actor.team===0)||this.bots.some(b=>b.team===0))&&(this.team===1||this.humans.some(h=>h.actor.team===1)||this.bots.some(b=>b.team===1));}

 get gun(){return weapons[this.slot===1?validatedSecondary(this.operator,this.secondary):validatedWeapon(this.operator,this.weapon)];}

 cancelReload(){if(this.reload<=0)return;const a=this.rules.reloadCancelBullet===false?{magazine:this.ammo[this.slot],reserve:this.reserve[this.slot]}:cancelReloadAmmo(this.ammo[this.slot],this.reserve[this.slot]);this.ammo[this.slot]=a.magazine;this.reserve[this.slot]=a.reserve;this.reload=0;this.reloadTotal=0;this.state=this.stance;}

 interrupt(){this.inspect=0;this.cancelReload();this.cancelSmokeThrow();this.cancelJammerPlacement();this.cancelChargeInstallation();this.cancelHammerSwing();}

 cancelChargeInstallation(){if(['charge','charge-pickup'].includes(this.actionKind)){this.action=0;this.actionKind='';this.actionPanel=null;this.actionDevice=null;this.gadgetTime=0;}}

 canInstallCharge(){const panel=this.actionPanel;return this.operator===3&&this.hp>0&&!this.downed&&!this.observing&&['prep','action'].includes(this.phase)&&!(this.phase==='prep'&&this.team===0)&&this.gadgetCount>0&&!pendingCharge(this.devices,this.actorId)&&!!panel&&this.world.panels.includes(panel)&&this.world.canBreach(panel,'thermite')&&this.pos.distanceTo(this.actionStart)<.15&&this.eye().distanceTo(this.actionPosition)<3&&this.actionPosition.distanceTo(this.actionPosition.clone().clamp(panel.min,panel.max))<.05&&this.world.sight(this.eye(),this.actionPosition.clone().lerp(this.eye(),.03));}

 cancelJammerPlacement(){if(['jammer','jammer-pickup'].includes(this.actionKind)&&this.action>0){this.action=0;this.gadgetTime=0;this.actionDevice=null;}}

 hammerSwing=0;hammerHit=false;hammerTarget:THREE.Vector3|null=null;hammerPanel:Panel|null=null;hammerObject:THREE.Object3D|null=null;

 cancelHammerSwing(){if(this.hammerSwing>0)this.gadgetTime=0;this.hammerSwing=0;this.hammerHit=false;this.hammerTarget=null;this.hammerPanel=null;this.hammerObject=null;}

 launcherEquipped=false;launcherDraw=0;launcherReload=0;launcherShot=0;launcherTrigger=false;

 stowLauncher(){this.launcherEquipped=false;this.launcherDraw=0;this.launcherTrigger=false;}

 toggleLauncher(){if(this.launcherEquipped){this.stowLauncher();return false;}if(this.gadgetCount<=0){this.tell('NO GADGET CHARGES');return false;}this.interrupt();this.launcherEquipped=true;this.launcherDraw=launcherDrawSeconds;this.launcherTrigger=false;this.ads=false;this.inspect=0;this.tell('BREACHING LAUNCHER · FIRE TO LAUNCH · G STOW');return true;}

 updateLauncher(dt:number,fire:boolean){if(!this.launcherEquipped)return;if(this.operator!==0||this.hp<=0||this.downed||this.observing||this.vaultFrom||!['prep','action'].includes(this.phase)){this.stowLauncher();return;}this.launcherDraw=Math.max(0,this.launcherDraw-dt);this.launcherReload=Math.max(0,this.launcherReload-dt);if(fire&&!this.launcherTrigger)fireBreachingLauncher(this);this.launcherTrigger=fire;}

 jammerYaw=0;jammerPoseStart=0;

 actionDevice:Device|null=null;

 canRecoverCharge(d:Device){if(![...this.devices,...this.externalDevices].includes(d))return false;const eye=this.eye(),delta=d.pos.clone().sub(eye),panel=this.world.panels[d.panelId??-1];return this.operator===3&&this.team===0&&this.hp>0&&!this.downed&&!this.observing&&!this.rappel&&!this.vaultFrom&&this.phase==='action'&&this.gadgetCount<operators[3].count&&d.type==='charge'&&!d.active&&d.mesh.visible&&d.owner===this.actorId&&d.team===this.team&&!!panel&&!panel.broken&&Math.hypot(this.pos.x-d.pos.x,this.pos.z-d.pos.z)<1.35&&delta.length()<1.5&&delta.normalize().dot(this.face())>.85&&this.world.sight(eye,d.pos);}

 get pendingCharge(){return pendingCharge(this.devices,this.actorId);}

 get chargePickupCandidate(){if(this.action>0||this.reload>0)return null;return [...this.devices,...this.externalDevices].filter(d=>this.canRecoverCharge(d)).sort((a,b)=>a.pos.distanceToSquared(this.pos)-b.pos.distanceToSquared(this.pos))[0]??null;}

 beginChargeRecovery(){if(!this.authority)return false;const d=this.chargePickupCandidate;if(!d)return false;this.actionDevice=d;this.actionPosition.copy(d.pos);this.actionPanel=null;this.actionKind='charge-pickup';this.actionTotal=this.action=.75;this.actionStart.copy(this.pos);this.state='gadget';this.ads=false;this.tell('RECOVER CHARGE · Hold F');return true;}

 finishChargeRecovery(){const d=this.actionDevice;if(this.authority&&d&&[...this.devices,...this.externalDevices].includes(d)&&this.canRecoverCharge(d)&&d.pos.distanceTo(this.actionPosition)<.05&&this.pos.distanceTo(this.actionStart)<.15){d.mesh.visible=false;d.type='recovered';d.active=false;d.time=0;this.gadgetCount++;this.emitSound('device-place',d.pos,.2);this.tell('CHARGE RECOVERED');}this.cancelChargeInstallation();}

 canRecoverJammer(d:Device){const eye=this.eye(),delta=d.pos.clone().sub(eye);return this.operator===4&&this.team===1&&this.hp>0&&!this.downed&&!this.observing&&!this.rappel&&!this.vaultFrom&&['prep','action'].includes(this.phase)&&this.gadgetCount<operators[4].count&&d.type==='jammer'&&d.mesh.visible&&!d.disabledTime&&d.owner===this.actorId&&d.team===this.team&&this.pos.distanceTo(d.pos)<1.35&&delta.length()<2&&delta.normalize().dot(this.face())>.85&&this.world.sight(eye,d.pos);}

 get jammerPickupCandidate(){if(this.action>0||this.reload>0)return null;return [...this.devices,...this.externalDevices].filter(d=>this.canRecoverJammer(d)).sort((a,b)=>a.pos.distanceToSquared(this.pos)-b.pos.distanceToSquared(this.pos))[0]??null;}

 canRecoverSmoke(d:Device){const eye=this.eye(),delta=d.pos.clone().sub(eye);return [...this.devices,...this.externalDevices].includes(d)&&this.operator===1&&this.team===1&&this.hp>0&&!this.downed&&!this.observing&&!this.rappel&&!this.vaultFrom&&['prep','action'].includes(this.phase)&&this.gadgetCount<operators[1].count&&d.type==='gas'&&!d.active&&!d.flightVelocity&&d.attached===true&&d.time>0&&d.mesh.visible&&d.owner===this.actorId&&d.team===this.team&&Math.hypot(this.pos.x-d.pos.x,this.pos.z-d.pos.z)<1.35&&delta.length()<2&&delta.normalize().dot(this.face())>.85&&this.world.sight(eye,d.pos);}

 get smokePickupCandidate(){if(this.action>0||this.reload>0||this.smokeThrow>0)return null;return [...this.devices,...this.externalDevices].filter(d=>this.canRecoverSmoke(d)).sort((a,b)=>a.pos.distanceToSquared(this.pos)-b.pos.distanceToSquared(this.pos))[0]??null;}

 beginSmokeRecovery(){if(!this.authority)return false;const d=this.smokePickupCandidate;if(!d)return false;this.actionDevice=d;this.actionPosition.copy(d.pos);this.actionPanel=null;this.actionKind='gas-pickup';this.actionTotal=this.action=.75;this.actionStart.copy(this.pos);this.state='gadget';this.ads=false;this.tell('RECOVER CANISTER · Hold F');return true;}

 finishSmokeRecovery(){const d=this.actionDevice;if(this.authority&&d&&this.canRecoverSmoke(d)&&d.pos.distanceTo(this.actionPosition)<.05&&this.pos.distanceTo(this.actionStart)<.15){d.mesh.visible=false;d.type='recovered';d.active=false;d.time=0;this.gadgetCount=Math.min(operators[1].count,this.gadgetCount+1);this.emitSound('device-place',d.pos,.2);this.tell('CANISTER RECOVERED');}this.actionDevice=null;this.action=0;this.actionKind='';}

 beginJammerRecovery(){if(!this.authority)return false;const d=this.jammerPickupCandidate;if(!d)return false;const start=this.stanceAmount;if(Array.from({length:9},(_,i)=>this.postureBlocked(this.pos,jammerPosture(start,i/8))).some(Boolean))return false;this.actionDevice=d;this.jammerPoseStart=start;this.jammerYaw=d.mesh.rotation.y;this.actionPosition.copy(d.pos);this.actionPanel=null;this.actionKind='jammer-pickup';this.actionTotal=this.action=.75;this.actionStart.copy(this.pos);this.state='gadget';this.ads=false;this.tell('RECOVER JAMMER · Hold F');return true;}

 finishJammerRecovery(){const d=this.actionDevice;if(this.authority&&d&&[...this.devices,...this.externalDevices].includes(d)&&this.canRecoverJammer(d)&&d.pos.distanceTo(this.actionPosition)<.05){d.mesh.visible=false;d.type='recovered';d.active=false;d.time=0;this.gadgetCount++;this.emitSound('device-place',d.pos,.2);this.tell('JAMMER RECOVERED');}this.actionDevice=null;this.action=0;this.actionKind='';}

 get jammerDistance(){return Math.hypot(this.actionPosition.x-this.actionStart.x,this.actionPosition.z-this.actionStart.z); }

 beginJammerPlacement(){if(!this.authority||this.phase==='prep'&&this.team===0)return false;if(this.gadgetCount<=0){this.tell('NO GADGET CHARGES');return false;}const start=this.stanceAmount,distance=start>1.5?.8:.65;const blocked=Array.from({length:9},(_,i)=>this.postureBlocked(this.pos,jammerPosture(start,i/8))).some(Boolean);const pos=blocked?null:jammerPlacement(this.world,this.pos,this.eye(),this.yaw,distance,[...this.devices,...this.externalDevices]);if(!pos){this.tell('PLACEMENT BLOCKED');return false;}this.jammerPoseStart=start;this.jammerYaw=this.yaw;this.actionPosition.copy(pos);this.actionPanel=null;this.actionKind='jammer';this.actionTotal=this.action=jammerPlacementSeconds;this.actionStart.copy(this.pos);this.state='gadget';this.ads=false;this.tell('PLACE JAMMER · Hold G');return true;}

 cancelSmokeThrow(){if(this.actionKind==='gas-pickup'){this.action=0;this.actionKind='';this.actionDevice=null;this.gadgetTime=0;}if(this.smokeThrow>0){this.smokeThrow=0;this.smokeReleased=false;this.gadgetTime=0;}}

 beginSmokeThrow(){if(!this.authority)return false;if(pendingSmoke([...this.devices,...this.externalDevices],this.actorId)){this.tell('CANISTER READY · G / B RELEASE · F RECOVER');return false;}if(this.gadgetCount<=0){this.tell('NO GADGET CHARGES');return false;}if(!smokeReleasePosition(this.world,this.eye(),this.face())){this.tell('THROW BLOCKED');return false;}this.smokeThrow=smokeThrowDuration;this.smokeReleased=false;this.inspect=0;return true;}

 updateSmokeThrow(dt:number){if(this.smokeThrow<=0)return;if(this.hp<=0||this.downed||this.observing||this.operator!==1||!['prep','action'].includes(this.phase)){this.cancelSmokeThrow();return;}this.smokeThrow=Math.max(0,this.smokeThrow-dt);if(!this.smokeReleased&&this.smokeThrow<=smokeThrowDuration-smokeReleaseTime){this.smokeReleased=true;if(this.authority&&!this.gadget()){this.cancelSmokeThrow();this.smokeThrow=0;this.smokeReleased=false;this.gadgetTime=0;}}}



 get objective(){return this.world.bombPosition(this.site,0);}

 eye(){const eye=leanedEye(new THREE.Vector3(this.pos.x,this.visualY+this.cameraHeight,this.pos.z),this.yaw,this.lean,this.cameraForward);const up=new THREE.Vector3(0,1,0);const obstruction=this.world.trace(this.pos.clone().add(new THREE.Vector3(0,.08,0)),up,this.cameraHeight+.04)[0];if(obstruction)eye.y=Math.min(eye.y,this.pos.y+obstruction.distance);return eye;}

 face(){return new THREE.Vector3(-Math.sin(this.yaw+this.recoilYaw)*Math.cos(this.pitch+this.recoilPitch),Math.sin(this.pitch+this.recoilPitch),-Math.cos(this.yaw+this.recoilYaw)*Math.cos(this.pitch+this.recoilPitch));}

 aimAt(){const hit=this.world.trace(this.eye(),this.face(),3,true)[0];this.aimPanel=hit?.object.userData.panel??null;this.aim.copy(hit?.point??this.eye().addScaledVector(this.face(),3));}

 move(p:THREE.Vector3,dx:number,dz:number,height:number){const w=this.world,r=height<.3?.14:height<=motion.prone.height+.05?motion.prone.radius:motion.stand.radius;for(const axis of [0,1]){const x=p.x+(axis===0?dx:0),z=p.z+(axis===1?dz:0);const floor=Math.max(w.ground(x,z,p.y),w.ground(x+(r+.03),z,p.y),w.ground(x-(r+.03),z,p.y),w.ground(x,z+(r+.03),p.y),w.ground(x,z-(r+.03),p.y));if(floor-p.y>.36)continue;let y=floor<p.y-.36&&height>=.3?p.y:floor+.015;if(y<p.y&&w.collide(x,y,z,r,height)&&!w.collide(x,p.y,z,r,height))y=p.y;let blocked=w.collide(x,y,z,r,height);if(height>=.3&&blocked){const support=Math.max(floor,diagonalFootprintSupport(w,x,z,p.y,r+.03));if(support>floor&&support-p.y<=.36){const supportedY=support+.015;if(!w.collide(x,supportedY,z,r,height)){y=supportedY;blocked=false;}}}if(blocked&&height>=.6){for(const rise of [.08,.18,motion.maxStep]){const stepY=p.y+rise;if(w.collide(p.x,stepY,p.z,r,height)||w.collide(x,stepY,z,r,height))continue;const support=w.ground(x,z,stepY,.02);y=Math.max(p.y,Math.min(stepY,support+.015));if(w.collide(x,y,z,r,height))y=stepY;blocked=false;break;}}if(!blocked){p.x=x;p.z=z;p.y=y;}}p.x=THREE.MathUtils.clamp(p.x,-69,69);p.z=THREE.MathUtils.clamp(p.z,-59,59);}

 update(dt:number,keys:Set<string>,bindings:Record<string,string>,fire:boolean,ads:boolean,clockDt=dt){if(!Number.isFinite(dt)||dt<=0)return;const count=Math.max(1,Math.ceil(dt*120-1e-8));for(let i=0;i<count;i++)this.updatePlayerStep(dt/count,keys,bindings,fire,ads,clockDt/count);}

 private updatePlayerStep(dt:number,keys:Set<string>,bindings:Record<string,string>,fire:boolean,ads:boolean,clockDt:number){const triggerEdge=fire&&!this.triggerHeld||this.pendingTrigger;const requested=fire||this.pendingTrigger;this.pendingTrigger=false;this.triggerHeld=fire;fire=requested;if(!weaponCatalog[this.slot===1?this.secondary:this.weapon].automatic&&!triggerEdge)fire=false;if(this.actionKind==='gas-pickup'&&this.action>0&&(this.operator!==1||this.hp<=0||this.downed||!['prep','action'].includes(this.phase)))this.cancelSmokeThrow();if(['charge','charge-pickup'].includes(this.actionKind)&&this.action>0&&(this.operator!==3||this.hp<=0||this.downed||!['prep','action'].includes(this.phase)))this.cancelChargeInstallation();if(this.phase!=='action')for(const b of this.bots)cancelBotBreach(b);if(!['prep','action'].includes(this.phase))this.cancelHammerSwing();if(this.phase==='selection')return;if(this.roundSequence.result&&['aftermath','result','replay'].includes(this.phase)){const oldPhase=this.phase,stage=this.roundSequence.advance(performance.now());this.replayElapsed=this.roundSequence.replayElapsed;this.phase=stage==='banner'?'aftermath':stage==='replay'?'replay':'result';if(oldPhase!==this.phase)this.onChange();if(stage==='done'&&this.authority&&!this.actorOnly){if(this.score.some(s=>s>=3)){this.phase='complete';this.onChange();}else{this.round++;if(this.round===4){this.team=1-this.team;this.tell('SIDES SWAPPED');}this.begin();}}if(stage!=='banner')return;}if(this.phase==='aftermath'){fire=false;this.action=0;}if(this.phase==='replay'){this.replayElapsed=Math.min(3.5,this.replayElapsed+clockDt);if(!this.actorOnly){if(this.replayElapsed>=3.5){this.phase='result';this.nextRound=7;this.tell(this.replayClip?.reason??'ROUND COMPLETE');this.onChange();}}return;}if(this.actorOnly&&(this.phase==='result'||this.phase==='complete'))return;this.pingCooldown=Math.max(0,this.pingCooldown-dt);this.scanCooldown=Math.max(0,this.scanCooldown-dt);this.pingTime=Math.max(0,this.pingTime-dt);if(this.pingTime===0)this.ping=null;this.spottedUntil=Math.max(0,this.spottedUntil-dt);this.shotAge+=dt;this.impactCooldown=Math.max(0,this.impactCooldown-dt);if(this.downed){fire=false;ads=false;if(this.authority){this.bleed=Math.max(0,this.bleed-clockDt);if(this.bleed===0)this.die(this.lastDamager);}}if(this.phase==='menu'||(this.paused&&!this.networked))return;this.messageTime-=dt;this.hit=Math.max(0,this.hit-dt);this.hurt=Math.max(0,this.hurt-dt);this.cool-=dt;this.switchRemaining=Math.max(0,this.switchRemaining-dt);this.recoilPitch*=Math.exp(-dt*this.handling.pitchRecover);this.recoilYaw*=Math.exp(-dt*this.handling.yawRecover);this.recoil=this.recoilPitch;this.shake*=Math.exp(-dt*26);this.vaultTime=Math.max(0,this.vaultTime-dt);this.utilityCooldown=Math.max(0,this.utilityCooldown-dt);this.flashTime=Math.max(0,this.flashTime-clockDt);updateUtilities(this,dt,clockDt);this.updateErc(dt);this.nextRound-=dt;this.landingBlend=Math.max(0,this.landingBlend-dt*5);

  if(!this.actorOnly&&this.phase==='result'){if(this.nextRound<=0){if(this.score.some(s=>s>=3)){this.phase='complete';this.onChange();}else{this.round++;if(this.round===4){this.team=1-this.team;this.tell('SIDES SWAPPED');}this.begin();}}return;}if(this.phase==='complete')return;

  if(!this.actorOnly){if(this.phase==='prep'&&this.networked)this.timer=Math.max(0,(this.prepDeadline-performance.now())/1000);else this.timer-=clockDt;if(this.phase==='prep'&&this.timer<=.000001){this.phase='action';this.timer=150+this.timer;this.tell('ACTION PHASE · '+(this.team===0?'Plant the defuser at A or B.':'Protect the bomb sites.'));}

  if(this.phase==='action'&&!this.competitive)this.timer=150;

  }else if(this.phase==='prep')this.timer=Math.max(0,this.timer-clockDt);

  if(this.previousPhase==='prep'&&this.phase==='action'&&this.observing){this.setObservation(false);}this.previousPhase=this.phase;if(this.observing&&this.cameraIndex<0&&(!this.viewDrone.alive||!this.viewDrone.deployed))this.cycleObservation();

  this.inspect=Math.max(0,this.inspect-dt);if(ads||fire)this.inspect=0;

  if(this.hp<=0){this.cancelSmokeThrow();if(this.vaultFrom)this.finishVault(true);this.leanTarget=0;this.lean=this.leanVelocity=0;this.inspect=0;this.reload=0;}

  const wasVaulting=!!this.vaultFrom;const down=(k:string)=>!this.paused&&keys.has(bindings[k])&&(!this.downed||!['sprint','gadget','reinforce','interact'].includes(k));let f=Number(down('forward'))-Number(down('back')),s=Number(down('right'))-Number(down('left'));const len=Math.hypot(f,s)||1;f/=len;s/=len;const target=this.observing?this.drone:this.pos;const moveStart=this.pos.clone(),droneStart=this.drone.clone();if(this.viewInputGate){if(f===0&&s===0&&!fire&&!ads)this.viewInputGate=false;f=0;s=0;fire=false;ads=false;}

  if(this.hp>0){if(down('sprint')&&f>0)this.stowLauncher();if(fire||down('sprint')&&f>0)this.interrupt();if(ads){this.cancelSmokeThrow();this.cancelJammerPlacement();this.cancelChargeInstallation();this.cancelHammerSwing();}

   if(this.reload>0){this.reload=Math.max(0,this.reload-dt);this.state='reload';if(this.reload===0){const a=completeReloadAmmo(this.ammo[this.slot],this.reserve[this.slot],this.gun.mag);this.ammo[this.slot]=a.magazine;this.reserve[this.slot]=a.reserve;this.reloadTotal=0;this.emitSound('reload',this.pos,.12);}}

   this.sprintLock=Math.max(0,this.sprintLock-dt);this.gadgetTime=Math.max(0,this.gadgetTime-dt);this.spreadBloom=Math.max(0,this.spreadBloom-this.handling.recover*dt);this.sprintFatigue=Math.max(0,this.sprintFatigue-dt*2);

   const sprint=utilitySlow(this,this.pos,this.team)===1&&down('sprint')&&f>0&&this.stance==='stand'&&!this.observing&&this.action<=0&&this.reload<=0&&!this.rappel&&!this.vaultFrom;

   if(sprint){if(this.ercActive)this.ercGlitch=.25;this.inspect=0;this.sprintLock=this.handling.sprint;this.sprintFatigue=1;}this.ads=ads&&this.switchRemaining<=0&&!sprint&&!this.observing&&this.reload<=0&&this.action<=0&&this.gadgetTime<=0&&!this.vaultFrom;

   const desired=this.ads?1:0;this.adsProgress=THREE.MathUtils.clamp(this.adsProgress+Math.sign(desired-this.adsProgress)*dt/(adsDuration(this.slot===1?this.secondary:this.weapon,this.optic)*(desired?1:.7)),0,1);

   if(['jammer','jammer-pickup'].includes(this.actionKind)&&this.action>0){const next=jammerPosture(this.jammerPoseStart,1-Math.max(0,this.action-dt)/this.actionTotal);if(this.postureBlocked(this.pos,next))this.cancelJammerPlacement();else this.stanceAmount=next;}else this.stanceAmount=THREE.MathUtils.damp(this.stanceAmount,stanceValue(this.stance),motion.stanceBlend,dt);this.cameraHeight=this.rappel&&this.rappelInverted?.3:posture(this.stanceAmount).eye;

   const pose=posture(this.stanceAmount),postureSpeed=THREE.MathUtils.lerp(motion.stand.speed,motion.crouch.speed,pose.crouch)*(1-pose.prone)+motion.prone.speed*pose.prone,stanceSpeed=Math.min(postureSpeed,motion[this.stance].speed),hipSpeed=(this.stance!=='stand'?stanceSpeed:down('slow')?motion.slowSpeed:sprint?motion.sprintSpeed:stanceSpeed)*operatorMobility(this.operator),adsSpeed=Math.min(motion.adsSpeed,this.stance!=='stand'?stanceSpeed:down('slow')?motion.slowSpeed:Infinity);const speed=THREE.MathUtils.lerp(hipSpeed,adsSpeed,this.adsProgress);

   const desiredVelocity=new THREE.Vector3((-Math.sin(this.yaw)*f+Math.cos(this.yaw)*s)*speed,0,(-Math.cos(this.yaw)*f-Math.sin(this.yaw)*s)*speed);if(this.hammerSwing>0){desiredVelocity.set(0,0,0);this.velocity.set(0,0,0);}desiredVelocity.multiplyScalar(utilitySlow(this,this.pos,this.team));const integrated=integrateMovement([this.velocity.x,this.velocity.z],[desiredVelocity.x,desiredVelocity.z],dt);this.velocity.set(integrated.velocity[0],0,integrated.velocity[1]);const dx=integrated.travel[0]*(this.downed?.36:1),dz=integrated.travel[1]*(this.downed?.36:1);

   if(this.vaultPlan&&this.vaultFrom){this.advanceVault(dt);}

   else if(this.observing){this.velocity.set(0,0,0);if(this.cameraIndex<0){if(this.viewDrone===this.droneUnit&&this.hp>0)this.droneUnit.update(dt,f,s,this.jammed(this.drone));}}

   else if(this.action<=0){if(this.rappel){this.velocity.set(0,0,0);const anchor=this.rappelAnchor;if(anchor){const next=this.pos.clone(),lateral=anchor.axis==='x'?'z':'x';next.y=THREE.MathUtils.clamp(this.pos.y+f*dt*motion.rappelSpeed,.015,anchor.roof-.65);next[anchor.axis]=anchor.plane+anchor.side*.52;next[lateral]=THREE.MathUtils.clamp(next[lateral]+s*dt*1.5*(anchor.axis==="x"?-Math.sin(this.yaw):Math.cos(this.yaw)),anchor.min+.32,anchor.max-.32);if(sweepVault(this.world,this.pos,next,motion.stand.height,(p,h)=>this.occupied(p,h)))this.pos.copy(next);}}else{const before=this.pos.clone();const dest=this.pos.clone().add(new THREE.Vector3(dx,0,dz));const candidateGround=this.world.ground(dest.x,dest.z,this.pos.y);if(candidateGround>=this.pos.y-.36)dest.y=candidateGround+.015;if(!this.postureBlocked(dest,Math.max(this.stanceAmount,stanceValue(this.stance)))){this.move(this.pos,dx,dz,Math.max(posture(this.stanceAmount).height,motion[this.stance].height));}else{this.move(this.pos,dx,0,Math.max(posture(this.stanceAmount).height,motion[this.stance].height));if(this.postureBlocked(this.pos,Math.max(this.stanceAmount,stanceValue(this.stance))))this.pos.copy(before);const mid=this.pos.clone();this.move(this.pos,0,dz,Math.max(posture(this.stanceAmount).height,motion[this.stance].height));if(this.postureBlocked(this.pos,Math.max(this.stanceAmount,stanceValue(this.stance))))this.pos.copy(mid);}const r=motion[this.stance].radius+.03,w=this.world,x=this.pos.x,z=this.pos.z;const ground=Math.max(w.ground(x,z,this.pos.y,0),w.ground(x+r,z,this.pos.y,0),w.ground(x-r,z,this.pos.y,0),w.ground(x,z+r,this.pos.y,0),w.ground(x,z-r,this.pos.y,0))+.015;if(this.pos.y>ground+.03){this.verticalSpeed-=motion.gravity*dt;const fromY=this.pos.y,nextY=Math.max(ground,fromY+this.verticalSpeed*dt),verticalSteps=Math.max(1,Math.ceil(Math.abs(nextY-fromY)/.08));for(let i=1;i<=verticalSteps;i++){const candidate=this.pos.clone();candidate.y=THREE.MathUtils.lerp(fromY,nextY,i/verticalSteps);if(this.postureBlocked(candidate,Math.max(this.stanceAmount,stanceValue(this.stance)))){this.verticalSpeed=0;break;}this.pos.y=candidate.y;}}else this.verticalSpeed=0;}}

   if(this.phase==='prep'&&this.team===0&&!this.observing){if(!this.world.room(this.pos.x,this.pos.y,this.pos.z).startsWith('EXT')){this.pos.copy(moveStart);this.velocity.set(0,0,0);this.tell('PREPARATION · Wait outside for action phase');}if(this.pos.distanceTo(this.prepAnchor)>18){this.pos.copy(moveStart);this.velocity.set(0,0,0);}}

   this.state=resolveMovementState({observing:this.observing,vault:!!this.vaultFrom,action:this.action,actionKind:this.actionKind,gadget:this.gadgetTime,reload:this.reload,rappel:this.rappel,sprint,slow:down('slow'),stance:this.stance,moving:Math.hypot(f,s)>.01});

   if(this.leanMode==='Hold'){const left=down('leanLeft'),right=down('leanRight');this.leanTarget=left&&right?this.leanHeldSide:left?-1:right?1:0;}
   if(sprint||this.vaultFrom||this.observing||this.action>0||this.rappel)this.leanTarget=0;const leaning=dampLean(this.lean,this.leanVelocity,this.leanTarget,dt),base=new THREE.Vector3(this.pos.x,this.visualY+this.cameraHeight,this.pos.z),limited=limitLean(this.world,base,this.yaw,leaning.value,this.cameraForward);this.lean=limited;this.leanVelocity=Math.abs(limited-leaning.value)>.00001?0:leaning.velocity;

   this.visualY=Math.abs(this.visualY-this.pos.y)>1?this.pos.y:THREE.MathUtils.damp(this.visualY,this.pos.y,18,dt);this.cameraForward=THREE.MathUtils.damp(this.cameraForward,this.stance==='prone'?.45:0,12,dt);this.actualVelocity.copy(this.pos).sub(moveStart).setY(0).divideScalar(Math.max(dt,.001));const firing=fire&&!sprint&&!this.paused&&!wasVaulting&&this.reload<=0&&this.action<=0&&!this.observing&&this.sprintLock<=0&&this.gadgetTime<=0&&this.movement.canShoot;if(!this.firingLastStep||!firing)this.cool=Math.max(0,this.cool);if(firing){for(let shot=0;shot<8&&this.cool<=1e-8;shot++){const before=this.shotSerial;this.shoot();if(this.shotSerial===before)break;}}this.firingLastStep=firing&&this.ammo[this.slot]>0;const traveled=Math.hypot(this.pos.x-moveStart.x,this.pos.z-moveStart.z);if(traveled>.0001&&!this.observing&&!this.vaultFrom){this.travelDistance+=traveled;const step=stride(this.state,this.stance);this.gaitCycle+=traveled/step*Math.PI;this.foot+=traveled;if(this.foot>=step){this.foot%=step;const volume=sprint?.6:down('slow')?.07:this.stance==='stand'?.3:this.stance==='prone'?.045:.10;this.emitSound('footstep',this.pos.clone().add(new THREE.Vector3(0,.08,0)),volume);if(this.authority)this.noises.push({pos:this.pos.clone(),team:this.team,time:1.5,radius:sprint?16:this.stance==='stand'?6:3});}}

  }

  if(!this.observing||this.cameraIndex>=0||this.viewDrone!==this.droneUnit||this.hp<=0)this.droneUnit.update(dt,0,0,this.jammed(this.droneUnit.pos));

  if(this.action>0){const jammerPos=this.actionKind==='jammer'?jammerPlacement(this.world,this.pos,this.eye(),this.jammerYaw,this.jammerDistance,[...this.devices,...this.externalDevices]):null;const valid=(this.actionKind!=='gas-pickup'||!this.authority||!!this.actionDevice&&this.canRecoverSmoke(this.actionDevice)&&this.actionDevice.pos.distanceTo(this.actionPosition)<.05)&&(this.actionKind!=='charge-pickup'||!this.authority||!!this.actionDevice&&this.canRecoverCharge(this.actionDevice)&&this.actionDevice.pos.distanceTo(this.actionPosition)<.05)&&(this.actionKind!=='charge'||!this.authority||this.canInstallCharge())&&(this.actionKind!=='jammer-pickup'||!this.authority||!!this.actionDevice&&this.canRecoverJammer(this.actionDevice)&&this.actionDevice.pos.distanceTo(this.actionPosition)<.05)&&(this.actionKind!=='jammer'||this.operator===4&&!this.downed&&Math.abs(THREE.MathUtils.euclideanModulo(this.yaw-this.jammerYaw+Math.PI,Math.PI*2)-Math.PI)<=.3&&['prep','action'].includes(this.phase)&&!!jammerPos&&jammerPos.distanceTo(this.actionPosition)<.05)&&(!this.actionPanel||this.eye().distanceTo(this.eye().clone().clamp(this.actionPanel.min,this.actionPanel.max))<3&&this.world.sight(this.eye(),this.eye().clone().clamp(this.actionPanel.min,this.actionPanel.max).lerp(this.eye(),.03)))&&(this.actionKind!=='revive'||!!this.reviveTarget&&this.canRevive(this.reviveTarget))&&this.hp>0&&!this.observing&&this.pos.distanceTo(this.actionStart)<.15&&(this.actionKind!=='plant'||this.objectiveState.canPlant(this))&&(this.actionKind!=='disable'||this.objectiveState.canDisable(this));if(!down(this.actionKind==='charge'||this.actionKind==='jammer'?'gadget':this.actionKind==='reinforce'?'reinforce':this.actionKind==='barricade'||this.actionKind==='remove'?'barricade':'interact')||!valid){if(this.actionKind==='gas-pickup')this.cancelSmokeThrow();else if(['charge','charge-pickup'].includes(this.actionKind))this.cancelChargeInstallation();else this.action=0;this.tell('ACTION CANCELLED');}else{const withinFrame=this.action;this.action-=dt;if(this.action<=0)this.finishAction(withinFrame);}}

   if(!this.actorOnly&&this.authority&&this.phase!=='aftermath')for(const d of [...this.devices,...this.externalDevices]){if(!d.mesh.visible||d.type.startsWith('utility:'))continue;if(d.flightVelocity&&!d.active&&advanceThrowable(this.world,d,dt))this.emitSound('gadget',d.pos,.12);if(!d.active)continue;const effectDt=Math.min(dt,Math.max(0,d.time));if(d.type==='round')advanceBreachingRound(this.world,d,dt,this);else d.time-=dt;if(d.type==='gas'){const cloud=d.pos.clone();const exposed=(p:THREE.Vector3)=>p.distanceTo(d.pos)<4&&this.world.sight(cloud,p.clone().add(new THREE.Vector3(0,.4,0)));for(const b of this.bots){const damage=gasDamage(d,b,effectDt,b.hp>0&&b.operator!==1&&exposed(b.pos)&&(b.team!==d.team||!!this.rules.friendlyFire));if(damage)this.damageBot(b,damage,d.owner??'gas',d.team??1);}for(const a of [this,...this.humans.map(h=>h.actor).filter(a=>a!==this)]){const damage=gasDamage(d,a,effectDt,a.hp>0&&a.operator!==1&&exposed(a.pos));if(damage)a.takeDamage(damage,d.owner??'gas',d.team??1);}}if(d.time<=0){if(d.type==='charge'||d.type==='round'){detonateBreachingDevice(this,d);}d.mesh.visible=false;d.active=false;}}

  if(!this.actorOnly&&this.phase==='prep')for(const scout of this.scouts){if(!scout.mesh.visible||this.jammed(scout.pos))continue;const next=scout.path[0];if(next){const d=next.clone().sub(scout.pos);d.y=0;if(d.length()<.3)scout.path.shift();else{d.normalize().multiplyScalar(dt*3.8);this.move(scout.pos,d.x,d.z,.15);}}scout.mesh.position.copy(scout.pos).add(new THREE.Vector3(0,.12,0));if(this.interference<=0&&this.hp>0&&scout.pos.distanceTo(this.pos)<10&&this.world.sight(scout.pos.clone().add(new THREE.Vector3(0,.2,0)),this.eye())){if(!this.enemyIntel)this.tell('ENEMY DRONE SPOTTED YOU · Destroy it or use interference');this.enemyIntel=this.pos.clone();}}

  for(const d of [...this.devices,...this.externalDevices])if(d.type==='gas'&&d.active&&d.mesh.visible)refreshGasCloud(this.world,d.mesh,d.pos);

  this.droneSoundClock-=dt;if(this.observing&&this.cameraIndex<0&&this.drone.distanceTo(droneStart)>.001&&this.droneSoundClock<=0){this.emitSound('drone',this.droneUnit.eye(),.16);this.droneSoundClock=.16;}this.audioClock-=dt;const installing=this.action>0&&['reinforce','barricade'].includes(this.actionKind);if(installing){const p=1-this.action/this.actionTotal;if(this.installationAudioKind!==this.actionKind||p<this.installationAudioProgress)this.installationAudioProgress=0;const reinforce=this.actionKind==='reinforce';for(const beat of installationBeats(reinforce))if(beat>this.installationAudioProgress&&beat<=p)this.emitSound(beat<.48?'device-place':reinforce?'impact-metal':'barricade',this.actionPanel?.mesh.position??this.pos,beat<.48?.12:.22);this.installationAudioProgress=p;this.installationAudioKind=this.actionKind;}else{this.installationAudioProgress=0;this.installationAudioKind='';}if(this.action>0&&!installing&&this.audioClock<=0){this.emitSound(this.actionKind==='barricade'||this.actionKind==='remove'?'barricade':this.actionKind==='plant'||this.actionKind==='disable'?'plant':'gadget',this.actionPanel?.mesh.position??this.pos,.2);this.audioClock=.35;}if(!this.actorOnly&&this.objectiveState.planted&&this.audioClock<=0){this.emitSound('defuser',this.objectiveState.position,.12);this.audioClock=1;}

  if(!this.actorOnly){for(const noise of this.noises)noise.time-=dt;this.noises=this.noises.filter(n=>n.time>0);this.botTick+=dt;if(this.phase!=='aftermath'&&this.botTick>.012&&this.bots.length){this.updateBots(this.botTick,false);this.botTick=0;}if(this.phase!=='aftermath'&&this.bots.length)advanceBotMotion(this,dt);}

  if(!this.actorOnly&&!this.networked&&this.phase!=='aftermath')this.objectiveState.step(clockDt,this,this.objectiveActors);this.planted=this.objectiveState.planted;this.plantTimer=this.objectiveState.remaining;this.defuserPos.copy(this.objectiveState.position);if(!this.actorOnly)this.defuserView.update(this.objectiveState);

  if(!this.actorOnly&&!this.networked&&this.phase==='action'&&this.competitive){const attack=this.bots.some(b=>b.team===0&&b.hp>0)||(this.team===0&&this.hp>0)||this.humans.some(h=>h.actor.team===0&&h.actor.hp>0),defend=this.bots.some(b=>b.team===1&&b.hp>0)||(this.team===1&&this.hp>0)||this.humans.some(h=>h.actor.team===1&&h.actor.hp>0);if(!defend)this.end(0,'DEFENDERS ELIMINATED');else if(!attack&&!this.planted)this.end(1,'ATTACKERS ELIMINATED');}

  updateHammerSwing(this,dt);this.updateLauncher(dt,fire&&!this.paused);this.updateSmokeThrow(dt);this.aimAt();if(this.observing&&this.cameraIndex>=0&&!this.cameraAlive(this.cameraIndex))this.cycleObservation();if(this.observing&&this.cameraIndex<0&&(!this.viewDrone.alive||!this.viewDrone.deployed))this.cycleObservation();const security=this.cameraIndex>=0?this.cameraLocation(this.cameraIndex):null;const camPos=this.observing?(security?new THREE.Vector3(security.x,security.y,security.z):this.viewDrone.eye()):this.eye();this.camera.position.copy(camPos);this.camera.rotation.set(this.observing?(security?security.pitch+THREE.MathUtils.clamp(this.pitch,-.6,.6):this.viewDrone===this.droneUnit?this.droneUnit.pitch:this.observationPitch):this.pitch+this.recoilPitch,this.observing?(security?security.yaw+THREE.MathUtils.clamp(this.yaw,-1,1):this.viewDrone===this.droneUnit?this.droneUnit.lookYaw:this.observationYaw):this.yaw+this.recoilYaw,this.observing?0:this.rappel&&this.rappelInverted?Math.PI:-this.lean*leanPose.cameraRoll,'YXZ');this.camera.fov=blendFov(this.baseFov,this.launcherEquipped?this.baseFov/1.15:adsFov(this.optic,this.baseFov),this.adsProgress);this.camera.updateProjectionMatrix();

 }

 shoot(){if(this.launcherEquipped)return;this.cancelSmokeThrow();if(this.downed||!['action','prep'].includes(this.phase))return;this.inspect=0;this.cancelReload();this.slot=this.slot===1?1:0;this.weapon=validatedWeapon(this.operator,this.weapon);if(this.hp<=0||this.phase==='prep'&&this.team===0||this.cool>0||this.reload>0||this.action>0||this.observing||!this.movement.canShoot||this.phase==='result'||this.vaultTime>0||this.sprintLock>0||this.gadgetTime>0)return;if(this.ammo[this.slot]<=0){this.cool=.25;this.audio.sound(500,.02,.04);return;}this.ammo[this.slot]--;if(this.ercActive)this.ercGlitch=.25;this.cool+=60/this.gun.rpm;if(this.shotAge>.25)this.burstIndex=0;this.burstIndex++;this.recoilPitch=0;this.recoilYaw=0;this.shotAge=0;this.recoilSerial++;this.recoil=this.recoilPitch;this.shake=.018*this.shakeScale;this.shotSerial++;this.emitSound(this.handling.pellets>1?'shotgun':weaponCatalog[this.slot===1?this.secondary:this.weapon].automatic?'shot':'pistol',this.muzzle,.8);

  this.spreadBloom=Math.min(this.handling.maxBloom,this.spreadBloom+this.handling.bloom);this.lastPellets=[];if(!this.authority)return;this.noises.push({pos:this.pos.clone(),team:this.team,time:2,radius:35});const barricadeImpacts=new Map<Panel,{point:THREE.Vector3,distance:number}[]>(),shotgunImpacts=new Map<Panel,{point:THREE.Vector3,distance:number}[]>(),ray=this.world.ray;for(let pellet=0;pellet<this.handling.pellets;pellet++){const pelletSurfaces=new Set<Panel>(),dir=coneDirection(this.face(),this.spreadAngle);this.lastPellets.push(dir.clone());ray.set(this.eye(),dir);ray.far=100;const objects=[...this.bots.filter(b=>b.hp>0).map(b=>b.mesh),...this.humans.filter(h=>h.actor!==this&&h.actor.hp>0).map(h=>h.mesh),...(this.droneUnit.alive&&this.droneUnit.deployed?[this.droneUnit.mesh]:[]),...this.externalDrones.filter(d=>d.alive&&d.deployed).map(d=>d.mesh),...this.bots.flatMap(b=>b.drone?.alive?[b.drone.mesh]:[]),...[...this.devices,...this.externalDevices].filter(d=>d.mesh.visible&&!(['gas','utility:smoke'].includes(d.type)&&d.active)).map(d=>d.mesh),...this.scouts.filter(s=>s.mesh.visible).map(s=>s.mesh)];for(const object of objects)object.updateWorldMatrix(true,true);const muzzle=this.muzzle,path=new PenetrationPath(),neck=muzzle.clone().sub(this.eye());let neckBlocked=false;for(const near of this.world.trace(this.eye(),neck.clone().normalize(),neck.length())){const panel=near.object.userData.panel as Panel;if(!panel||!path.cross({id:panel.mesh.userData.panelOrder,remaining:!panel.broken,penetrable:!!panel.surfaceRule?.penetrable||panel.kind==='barricade'||panel.mesh.userData.penetration===true,reinforced:panel.reinforced})){this.onImpact(near.point,near.face.normal);if(panel?.kind==='barricade')this.world.barricadeHit(panel,this.handling.pellets>1?'shotgun':'bullet',[{point:near.point,distance:near.distance}],this.actorId+':shot:'+this.shotSerial);neckBlocked=true;break;}}if(neckBlocked)continue;const shotOrigin=this.eye(),shotDir=dir;ray.set(shotOrigin,shotDir);const hits=[...this.world.trace(shotOrigin,shotDir,100),...ray.intersectObjects(objects,true)].sort((a,b)=>a.distance-b.distance);for(const h of hits){const normal=h.face?.normal.clone().transformDirection(h.object.matrixWorld)??dir.clone().negate();const material=h.object.userData.bulletMaterial??(h.object.userData.panel?.reinforced?'metal':['soft','barricade'].includes(h.object.userData.panel?.kind)?'wood':'stone');this.onImpact(h.point,normal,material);if(this.impactCooldown===0){this.emitSound(material==='wood'?'impact-wood':material==='metal'?'impact-metal':'impact-stone',h.point,.12);this.impactCooldown=.06;}const drone=h.object.userData.droneUnit as Drone|undefined;if(drone){drone.destroy();this.tell('DRONE DESTROYED');break;}if(h.object.userData.securityId!==undefined){const cameraPanel=h.object.userData.panel as Panel;cameraPanel.broken=true;cameraPanel.hp=0;cameraPanel.mesh.visible=false;this.tell('CAMERA DESTROYED');break;}const human=h.object.userData.human as Human|undefined;if(human){if(this.phase==='action'&&human.actor.takeDamage(path.damage(firearmDamage(this.gun.damage,this.handling.pellets>1,!!h.object.userData.head,h.distance,human.actor.hp),!!h.object.userData.head),this.actorId,this.team,!!h.object.userData.head&&this.handling.pellets===1,contactFromHit(h,this.slot?this.secondary:this.weapon,path.surfaces.size>0)))this.hit=.16;break;}const scout=this.scouts.find(s=>s.mesh===h.object);if(scout){scout.mesh.visible=false;this.tell('DRONE DESTROYED');break;}const device=[...this.devices,...this.externalDevices].find(d=>d.mesh===deviceRoot(h.object));if(device){if(device.type==='utility:shield'||device.type==='utility:wire'||device.type==='utility:camera'&&new THREE.Vector3(0,0,1).applyQuaternion(device.mesh.quaternion).dot(dir)<-.3)break;device.mesh.visible=false;device.type='destroyed';device.active=false;break;}const b=h.object.userData.bot as Bot|undefined,p=h.object.userData.panel as Panel|undefined;if(b){if((b.team!==this.team||this.rules.friendlyFire)&&this.phase==='action'){this.damageBot(b,path.damage(firearmDamage(this.gun.damage,this.handling.pellets>1,!!h.object.userData.head,h.distance,b.hp),!!h.object.userData.head),this.actorId,this.team,contactFromHit(h,this.slot?this.secondary:this.weapon,path.surfaces.size>0));this.hit=.16;}break;}if(p){if(this.handling.pellets>1&&p.grid&&p.kind!=='barricade'&&!p.reinforced&&!pelletSurfaces.has(p)){pelletSurfaces.add(p);const entries=shotgunImpacts.get(p)??[];if(!entries.some(e=>e.point.distanceToSquared(h.point)<.000001))entries.push({point:h.point.clone(),distance:h.point.distanceTo(this.eye())});shotgunImpacts.set(p,entries);}if(p.kind==='barricade'&&!p.reinforced&&!pelletSurfaces.has(p)){pelletSurfaces.add(p);const values=barricadeImpacts.get(p)??[];values.push({point:h.point.clone(),distance:h.distance});barricadeImpacts.set(p,values);}if(!path.cross({id:p.mesh.userData.panelOrder,remaining:!p.broken,penetrable:!!p.surfaceRule?.penetrable||p.kind==='barricade'||p.mesh.userData.penetration===true,reinforced:p.reinforced}))break;}}}for(const [p,hits] of barricadeImpacts)this.world.barricadeHit(p,this.handling.pellets>1?'shotgun':'bullet',hits,this.actorId+':shot:'+this.shotSerial);if(shotgunImpacts.size)this.world.shotgunDamage(shotgunImpacts);
 }

 damageBot(b:Bot,n:number,killer=this.actorId,team=this.team,contact?:DamageContact){if(b.hp<=0||this.phase!=='action'||!Number.isFinite(n)||n<=0)return;if(b.team===team&&killer!=='bot:'+b.id){if(!this.rules.friendlyFire)return;n*=this.rules.teammateDamage??.5;}this.onRecordedDamage('bot:'+b.id,killer,n,Math.min(n,b.hp),contact);b.hp-=n;if(b.ercActive&&b.hp>0)b.ercGlitch=.25;if(b.hp<=0){cancelBotSmokeThrow(b);cancelBotBreach(b);b.jammerHold=0;delete b.mesh.userData.jammerPreparation;b.ercActive=false;b.interference=0;b.ercGlitch=0;b.mesh.rotation.z=Math.PI/2;b.mesh.position.y+=.2;if(killer===this.actorId)this.kills++;else {const a=this.humans.find(h=>h.id===killer)?.actor;if(a)a.kills++;}this.onConfirmedKill(killer,'bot:'+b.id);this.tell(b.name+' ELIMINATED');}}



 command(action:string){if(this.phase==='aftermath'&&!['forward','back','left','right','crouch','prone','leanLeft','leanRight','leanReset','vault','sprint','slow'].includes(action))return;if(this.phase==='replay')return;if(this.phase==='menu'||this.paused||this.phase==='result'||this.phase==='complete')return;if(this.vaultFrom)return;if(action==='melee'&&this.cool>0)return;/* Fresh movement key-downs are already sent as commands to authority. Held keys do not bypass the view-change gate. */if(['forward','back','left','right'].includes(action)){this.viewInputGate=false;return;}if(action==='gadget'&&this.operator!==5&&this.gadgetTime>0)return;if(action==='exitDrone'){if(this.observing)this.setObservation(false);return;}if(action==='utilityActivate'&&this.observing){activateUtility(this);return;}if(action==='observe'){this.setObservation(!this.observing);return;}if(this.observing&&(action==='leanLeft'||action==='leanRight')){this.cycleObservation(action==='leanLeft'?-1:1);return;}if(this.hp<=0){if(action==='switch'){this.deathSkipped=true;this.observing=false;const team=[...this.humans.filter(h=>h.actor!==this&&h.actor.team===this.team&&h.actor.hp>0).map(h=>h.id),...this.bots.filter(b=>b.team===this.team&&b.hp>0).map(b=>'bot:'+b.id)];const index=team.indexOf(this.spectatorId);this.spectatorId=team[(index+1)%Math.max(1,team.length)]??'';if(this.deathReplay)this.deathReplayAt=performance.now()-3600;this.deathWaitingAt=0;}return;}if(this.downed)return;if(action==='firePress'){this.pendingTrigger=true;return;}if(action==='utility'){useUtility(this);return;}if(action==='utilityActivate'){activateUtility(this);return;}

  if(action==='leanReset'){this.leanTarget=0;return;}if(action==='leanLeft'||action==='leanRight'){if(!this.observing){const value=action==='leanLeft'?-1:1;this.leanHeldSide=value;this.leanTarget=this.leanMode==='Hold'?value:this.leanTarget===value?0:value;}return;}

  if(action==='inspect'){if(this.launcherEquipped)return;if(!this.observing&&this.reload<=0&&this.action<=0)this.inspect=this.inspect>0?0:3.2;return;}

  if(['switch','reload','gadget','melee','vault','interact','reinforce','barricade'].includes(action))this.inspect=0;if(['switch','melee','vault','interact','reinforce','barricade','deployDrone'].includes(action))this.stowLauncher();if(action==='reload'&&this.launcherEquipped)return;if(['switch','reload','melee','vault','interact','reinforce','barricade'].includes(action)){this.cancelHammerSwing();this.cancelSmokeThrow();this.cancelJammerPlacement();this.cancelChargeInstallation();}

  if(['switch','gadget','melee','vault','interact'].includes(action))this.cancelReload();

  if(action==='switch'){if(this.observing){this.cycleObservation();}else if(this.action<=0){this.slot=1-this.slot;this.ads=false;this.switchRemaining=this.switchTotal=this.handling.switchTime;this.cool=this.handling.switchTime;} return;}

  if(action==='crouch'||action==='prone'){const next=action==='crouch'?(this.stance==='crouch'?'stand':'crouch'):(this.stance==='prone'?'stand':'prone');this.changeStance(next);return;}

  if(action==='reload'&&this.reload<=0&&this.ammo[this.slot]<this.gun.mag&&this.reserve[this.slot]>0&&this.action<=0&&!this.observing){this.reloadEmpty=this.ammo[this.slot]===0;this.reload=this.gun.reload+(this.reloadEmpty&&this.weapon!==1?.25:0);this.reloadTotal=this.reload;this.ads=false;this.inspect=0;this.emitSound('reload',this.pos,.22);}

  if(action==='ping'||action==='scan'){if(this.observing&&this.cameraIndex<0&&this.jammed(this.viewDrone.pos))return;const origin=this.camera.position.clone(),direction=new THREE.Vector3(0,0,-1).applyQuaternion(this.camera.quaternion);if(action==='ping'){if(this.pingCooldown>0)return;this.ping=this.world.trace(origin,direction,40)[0]?.point.clone()??origin.clone().addScaledVector(direction,12);this.pingCooldown=1;this.pingTime=5;this.tell('LOCATION PING · No enemy confirmation');}else{if(this.scanCooldown>0)return;this.scanCooldown=3;let count=0;for(const b of this.bots){const p=b.pos.clone().add(new THREE.Vector3(0,1,0));if(b.hp>0&&b.team!==this.team&&!observationHidden(this,b)&&p.distanceTo(origin)<30&&p.clone().sub(origin).normalize().dot(direction)>.96&&visualSight(this,origin,p)){b.mesh.userData.spotted=2;count++;}}if(this.authority)for(const h of this.humans){const a=h.actor,p=a.eye();if(a.team!==this.team&&a.hp>0&&!observationHidden(this,a)&&p.distanceTo(origin)<30&&p.clone().sub(origin).normalize().dot(direction)>.96&&visualSight(this,origin,p)){a.spottedUntil=2;count++;}}this.tell(count?'CONFIRMED ENEMY · '+count:'NO VISIBLE TARGET');}return;}

  if(action==='rappelRotate'&&this.rappel){this.rappelInverted=!this.rappelInverted;this.emitSound('stance-crouch',this.pos,.1);return;}if(this.observing){if(!this.droneUnit.alive&&this.cameraIndex<0){this.tell('DRONE DESTROYED');return;}if(action==='vault'&&this.cameraIndex<0&&this.viewDrone===this.droneUnit&&this.hp>0&&!this.jammed(this.droneUnit.pos))this.droneUnit.jump();return;}if(this.reload>0||this.action>0)return;this.aimAt();

  if(action==='interact'&&recoverUtility(this))return;if(action==='melee'&&meleeUtility(this))return;
 if(action==='deployDrone'){this.deployDrone();return;}

  if(action==='melee'){if(this.phase==='prep'&&this.team===0)return;strikeMelee(this);if(this.ercActive)this.ercGlitch=.25;this.cool=.55;}

  if(action==='reinforce'&&this.team===1&&this.aimPanel&&this.aimPanel.reinforceEligible&&['soft','floor'].includes(this.aimPanel.kind)&&!this.aimPanel.reinforced&&this.reinforcements>0){this.actionPanel=this.aimPanel;this.action=3;this.actionTotal=3;this.actionStart.copy(this.pos);this.actionKind='reinforce';this.state='reinforce';}

  if(action==='drop'){if(this.authority)this.objectiveState.drop(this);return;}

  if(action==='barricade'&&this.team===1){const opening=this.world.nearOpening(this.eye(),this.face());if(opening&&this.eye().distanceTo(opening.mesh.position)<2.5){this.actionPanel=opening;this.actionKind=opening.broken?'barricade':'remove';this.actionTotal=opening.broken?2.5:1.5;this.action=this.actionTotal;this.actionStart.copy(this.pos);this.state='gadget';this.ads=false;}return;}

  if(action==='interact'){const revive=this.reviveCandidate;if(revive){this.actionPanel=null;this.reviveTarget=revive;this.actionKind='revive';this.actionTotal=this.action=3;this.actionStart.copy(this.pos);this.ads=false;return;}if(this.rappel){if(this.pos.y<=.35){this.rappel=false;this.rappelAnchor=null;this.verticalSpeed=0;this.tell('RAPPEL DETACHED');}else this.exitRappel();}else if(this.authority&&this.objectiveState.pickup(this)){return;}else if(this.pickupDrone()){return;}else if(this.beginSmokeRecovery()){return;}else if(this.beginChargeRecovery()){return;}else if(this.beginJammerRecovery()){return;}else if(this.objectiveState.canPlant(this)&&this.timer>0||this.objectiveState.canDisable(this)){this.actionPanel=null;this.actionKind=this.team===0?'plant':'disable';this.actionTotal=this.team===0?objectiveConfig.plantSeconds:objectiveConfig.disableSeconds;this.action=this.actionTotal;this.actionStart.copy(this.pos);this.state=this.team===0?'plant':'disable';this.ads=false;}else this.beginRappel();}

   if(action==='vault'){if(this.rappel)this.exitRappel();else this.beginVault();}

  if(action==='gadget'&&(this.operator===1&&pendingSmoke(this.devices,this.actorId)||this.operator===3&&pendingCharge(this.devices,this.actorId))){this.activateGadgets();return;}if(action==='gadget'&&this.operator===0){this.toggleLauncher();return;}if(action==='gadget'&&(this.operator===1?this.beginSmokeThrow():this.operator===4?this.beginJammerPlacement():this.operator===2?beginHammerSwing(this):this.gadget())){this.gadgetTime=[.5,.55,1,.8,.7,.35][this.operator];this.ads=false;}if(action==='activate')this.activateGadgets();

 }

 activateGadgets(){

  if(!this.authority||![1,3].includes(this.operator))return false;

  const type=this.operator===1?'gas':'charge';let activated=0,jammed=false;

  for(const d of this.devices){if(d.type!==type||d.active||!d.mesh.visible||d.time<=0||d.owner&&d.owner!==this.actorId)continue;

   if(type==='charge'){if(this.jammed(d.pos)){jammed=true;continue;}d.active=true;d.time=3;this.emitSound('charge-ignite',d.pos,.35);}

   else{if(!releaseSmoke(this.world,d))continue;this.emitSound('gas-release',d.pos,.35);}

   activated++;break;

  }

  if(activated)this.tell(type==='gas'?'GAS RELEASED · 10s':'CHARGE IGNITED · 3s');else this.tell(jammed?'CHARGE JAMMED':'NO REMOTE DEVICE READY');return activated>0;

 }

 beginRappel(){if(this.downed||this.observing||this.team!==0||this.phase!=='action'||this.pos.y<0||!this.world.room(this.pos.x,this.pos.y,this.pos.z).startsWith('EXT'))return false;const hit=this.world.trace(this.eye(),this.face(),2.2).find(h=>{const p=h.object.userData.panel as Panel;return p.max.y-p.min.y>1.4&&Math.min(p.max.x-p.min.x,p.max.z-p.min.z)<.3;});if(!hit)return false;const p=hit.object.userData.panel as Panel,axis=p.max.x-p.min.x<p.max.z-p.min.z?'x':'z',side=Math.sign(this.pos[axis]-p.mesh.position[axis])||1,lateral=axis==='x'?'z':'x',next=this.pos.clone();next[axis]=p.mesh.position[axis]+side*.52;if(!sweepVault(this.world,this.pos,next,1.82,(p,h)=>this.occupied(p,h)))return false;const roof=Math.max(p.max.y,...(this.world.imported?this.world.imported.colliders.flatMap(c=>c.objects):this.world.panels).filter(q=>Math.abs(q.mesh.position[axis]-p.mesh.position[axis])<.15&&this.pos[lateral]>q.min[lateral]&&this.pos[lateral]<q.max[lateral]&&q.max.y-q.min.y>.3).map(q=>q.max.y));this.pos.copy(next);const span=sourceRappelSpan(this.world,p,axis);this.rappelAnchor={axis,plane:p.mesh.position[axis],side,roof,min:span.min,max:span.max};this.rappel=true;this.rappelInverted=false;this.stance='stand';this.leanTarget=0;this.tell('RAPPEL · W/S climb · A/D traverse · Space or F at clear window / roof');return true;}

 exitRappel(){const anchor=this.rappelAnchor;if(!anchor)return false;const aimYaw=anchor.axis==='x'?(anchor.side>0?Math.PI/2:-Math.PI/2):(anchor.side>0?0:Math.PI);const window=findVault(this.world,this.pos,aimYaw,(p,h)=>this.occupied(p,h),0);let plan=window;if(!plan&&this.pos.y>=anchor.roof-.9){const top=anchor.roof+.1,a=this.pos.clone().setY(top),to=a.clone();to[anchor.axis]=anchor.plane-anchor.side*.7;const support=this.world.ground(to.x,to.z,top+.1);if(Math.abs(support-top)<.3){to.y=support+.015;plan={points:[this.pos.toArray(),a.toArray(),to.toArray(),to.toArray()],duration:.85,height:1.12,kind:'ledge',landing:'crouch',surface:-1,startPose:0};let prev=this.pos.clone();for(let i=1;i<=36;i++){const next=vaultPoint(plan,i/36);if(!sweepVault(this.world,prev,next,vaultHeight(plan,i/36),(p,h)=>this.occupied(p,h))){plan=null;break;}prev=next;}}}if(!plan){this.tell('RAPPEL EXIT BLOCKED · Find a clear window or roof edge');return false;}this.interrupt();this.rappel=false;this.rappelAnchor=null;this.vaultPlan=plan;this.vaultFrom=this.pos.clone();this.vaultTo=new THREE.Vector3().fromArray(plan.points[3]);this.vaultReturnStance=plan.landing;this.vaultElapsed=this.vaultProgress=0;this.vaultRetreat=false;this.vaultTime=plan.duration;this.vaultSerial++;this.ads=false;this.lean=this.leanTarget=this.leanVelocity=0;this.state='vault';if(this.ercActive)this.ercGlitch=.25;this.emitSound('stance-vault',this.pos,.14);return true;}

 nearObjective(){return this.team===0?this.objectiveState.canPlant(this):this.objectiveState.canDisable(this);}

 finishAction(withinFrame=0){if(!this.authority)return;if(this.actionKind==='gas-pickup'){this.finishSmokeRecovery();return;}if(this.actionKind==='charge-pickup'){this.finishChargeRecovery();return;}if(this.actionKind==='jammer-pickup'){this.finishJammerRecovery();return;}if(this.actionKind==='jammer'){const pos=jammerPlacement(this.world,this.pos,this.eye(),this.jammerYaw,this.jammerDistance,[...this.devices,...this.externalDevices]);if(this.operator===4&&this.hp>0&&!this.downed&&['prep','action'].includes(this.phase)&&this.gadgetCount>0&&pos&&pos.distanceTo(this.actionPosition)<.05){const d=placeJammer(this.world,this.devices,this.pos,this.eye(),this.jammerYaw,this.team,this.actorId,this.jammerDistance,[...this.devices,...this.externalDevices]);if(d){this.gadgetCount--;this.emitSound('device-place',d.pos,.25);this.tell('JAMMER ACTIVE · 2.25m radius');}}this.action=0;this.actionKind='';return;}if(this.actionKind==='charge'){if(this.actionPanel&&this.canInstallCharge()){const pos=this.actionPosition.clone(),mesh=deviceMesh('charge');mesh.position.copy(pos);mesh.lookAt(this.eye());this.world.scene.add(mesh);this.devices.push({type:'charge',pos,mesh,time:3,active:false,team:this.team,owner:this.actorId,panelId:this.world.panels.indexOf(this.actionPanel)});this.gadgetCount--;this.emitSound('device-place',pos,.3);this.tell('CHARGE PLACED · B ignite');}this.cancelChargeInstallation();return;}if(this.actionKind==='revive'&&this.reviveTarget&&this.canRevive(this.reviveTarget)){const a=this.reviveTarget;a.downed=false;a.bleed=0;a.hp=50;a.stance='crouch';a.tell('REVIVED · 50 HEALTH');this.reviveTarget=null;this.tell('TEAMMATE REVIVED');}this.emitSound(this.actionKind==='barricade'||this.actionKind==='remove'?'barricade':this.actionKind==='plant'||this.actionKind==='disable'?'plant':'gadget',this.actionPanel?.mesh.position??this.pos,.3);if(this.actionKind==='reinforce'&&this.actionPanel&&!this.actionPanel.broken&&this.actionPanel.reinforceEligible){if(this.world.reinforce(this.actionPanel)){this.reinforcements--;this.tell('WALL REINFORCED');}}if(this.actionKind==='barricade'&&this.actionPanel){this.tell(this.world.rebuildBarricade(this.actionPanel,this.objectiveActors)?'BARRICADE PLACED':'OPENING BLOCKED');}if(this.actionKind==='remove'&&this.actionPanel){this.world.removeBarricade(this.actionPanel);this.tell('BARRICADE REMOVED');}if(this.actionKind==='plant'||this.actionKind==='disable')this.objectiveState.complete(this,this.actionKind,withinFrame);}

 updateErc(dt:number){

  this.ercGlitch=Math.max(0,this.ercGlitch-dt);

  if(this.operator!==5||this.hp<=0||this.downed){this.ercActive=false;this.interference=0;return;}

  if(this.ercActive){if(this.vaultFrom)this.ercGlitch=.25;const used=Math.min(dt,this.ercEnergy);this.ercEnergy=Math.max(0,this.ercEnergy-used);if(this.ercEnergy===0){this.ercActive=false;this.ercEnergy=Math.min(ercCapacity,(dt-used)*ercRechargeRate);}}

  else this.ercEnergy=Math.min(ercCapacity,this.ercEnergy+dt*ercRechargeRate);

  this.interference=this.ercActive?this.ercEnergy:0;

 }

 toggleErc(){

  if(this.ercActive){this.ercActive=false;this.interference=0;this.ercGlitch=0;this.tell('ERC OFF · Recharging');this.emitSound('erc-off',this.pos,.16);return true;}

  if(this.ercEnergy<=ercCapacity*ercActivationRatio){this.tell('ERC RECHARGING · Requires over 20%');return false;}

  this.ercActive=true;this.interference=this.ercEnergy;this.ercGlitch=0;this.enemyIntel=null;this.spottedUntil=0;this.tell('ERC ACTIVE · Drone concealment');this.emitSound('erc-on',this.pos,.16);return true;

 }

  jammed(p:THREE.Vector3){return [...this.devices,...this.externalDevices].some(d=>d.type==='jammer'&&d.mesh.visible&&!d.disabledTime&&d.pos.distanceTo(p)<jammerRadius);}

  jammerWarning(p:THREE.Vector3){return [...this.devices,...this.externalDevices].some(d=>d.type==='jammer'&&d.mesh.visible&&!d.disabledTime&&d.pos.distanceToSquared(p)<jammerWarningRadius*jammerWarningRadius);}

 gadget(){if(!this.authority||this.phase==='prep'&&this.team===0)return false;if(this.operator===5)return this.toggleErc();if(this.gadgetCount<=0){this.tell('NO GADGET CHARGES');return false;}const name=operators[this.operator].name;const p=this.aimPanel;

  if(name==='ASH'){const h=this.world.trace(this.eye(),this.face(),60,true)[0];const target=h?.object.userData.panel as Panel;if(target&&this.world.canBreach(target,'ash')){const mesh=deviceMesh('round'),pos=h.point.clone();mesh.position.copy(this.muzzle);mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,-1),pos.clone().sub(mesh.position).normalize());this.world.scene.add(mesh);this.devices.push({type:'round',pos,mesh,time:Math.max(.12,h.distance/70),active:true,roundDirection:pos.clone().sub(mesh.position).normalize(),roundRange:60,team:this.team,owner:this.actorId,panelId:this.world.panels.indexOf(target)});this.gadgetCount--;this.tell('BREACH ROUND FIRED');this.emitSound('launcher',this.muzzle,.5);return true;}else this.tell('Aim at a soft wall or barricade');}

  if(name==='SLEDGE'){if(p&&this.eye().distanceTo(this.aim)<2.8&&this.world.canBreach(p,'hammer')){if(this.world.breach(p,'hammer',this.aim)){this.gadgetCount--;this.emitSound('hammer',this.aim,.5);this.emitSound('breach',this.aim,.7);return true;}}else this.tell('Move close to a soft panel');}

  if(name==='THERMITE'){if(pendingCharge(this.devices,this.actorId)){this.tell('CHARGE PLACED · G / B ignite or F recover');return false;}if(p&&this.world.canBreach(p,'thermite')&&this.eye().distanceTo(this.aim)<3){this.actionPanel=p;this.actionPosition.copy(this.aim);this.actionKind='charge';this.actionTotal=this.action=2.5;this.actionStart.copy(this.pos);this.ads=false;this.tell('INSTALL CHARGE · Hold G');this.emitSound('gadget',this.pos,.18);return true;}else this.tell('Move close to a breachable panel');}

  if(name==='SMOKE'){const device=throwSmoke(this.world,this.devices,this.eye(),this.face(),this.team,this.actorId);if(!device){this.tell('THROW BLOCKED');return false;}this.gadgetCount--;this.tell('CANISTER THROWN · B to release gas');this.emitSound('gadget',device.pos,.18);return true;}

  if(name==='MUTE'){const device=placeJammer(this.world,this.devices,this.pos,this.eye(),this.yaw,this.team,this.actorId,.65,[...this.devices,...this.externalDevices]);if(!device){this.tell('PLACEMENT BLOCKED');return false;}this.gadgetCount--;this.tell('JAMMER ACTIVE · 2.25m radius');this.emitSound('device-place',device.pos,.25);return true;}

  return false;

 }

 route(start:THREE.Vector3,goal:THREE.Vector3){return this.world.route(start,goal);}

 updateBots(dt:number,advance=true){updateTacticalBots(this,dt,advance);}

 acceptRoundResult(result:RoundResult){if(result.round!==this.round||!['action','aftermath','result','replay'].includes(this.phase)||!this.roundSequence.accept(result))return false;this.score=[...result.score];this.phase='aftermath';this.paused=false;this.replayElapsed=0;this.tell(result.reason);this.onChange();this.roundSequence.shown(performance.now());return true;}
 end(team:number,reason:string){if(!this.authority||this.phase!=='action'||![0,1].includes(team))return;this.score[team]++;const clip=reason.includes('ELIMINATED')?this.history.clip(this,team,reason):null;this.replayClip=clip;if(clip)this.onReplay(clip);const result={id:crypto.randomUUID(),round:this.round,winner:team,reason,score:[...this.score],replayId:clip?.id??null};this.acceptRoundResult(result);this.onRoundResult(result);}

}


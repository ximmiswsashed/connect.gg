import {bombNavigation} from './bomb-navigation';
import {browserNavigation,navigationCandidate} from './map-variant';
import {movementConfig} from './movement';
import * as THREE from 'three';

import {World} from './world';import {ImportedOregon} from './imported-oregon';import {BombModels} from './bomb-model';

import {rooms,bombLocations,attackerSpawns,doors,stairs,softSurfaces,hatches,securityCameras} from './map-plan';

import {importedRooms,importedBombs,importedSpawns} from './imported-plan';

export async function nativeMap(progress:(s:string)=>void){

 const world=new World(false);world.imported=new ImportedOregon(world);await world.imported.load(progress);

 rooms.splice(0,rooms.length,...importedRooms);attackerSpawns.splice(0,attackerSpawns.length,...importedSpawns);

 // Never carry metadata from the differently scaled legacy building into the imported model.

 doors.length=stairs.length=softSurfaces.length=hatches.length=securityCameras.length=0;

 for(const [id,value] of Object.entries(importedBombs))Object.assign(bombLocations[id as keyof typeof bombLocations],value);

 world.scene.traverse(o=>{if(o instanceof THREE.HemisphereLight)o.intensity=2.1;if(o instanceof THREE.DirectionalLight)o.intensity=1.8;});

 // The supplied mesh has 29 exterior barricades, with two draw meshes per opening.

 // Replace both static draws with one host-synchronized panel at the original bounds.

 const originals=[...world.imported.sourceObjects.entries()].filter(([name])=>{const id=Number(name.replace('mesh_',''));return id>=12159&&id<=12187;}).sort(([a],[b])=>a.localeCompare(b));

 for(const [name,parts] of originals){const source=parts[0],size=source.max.clone().sub(source.min),center=source.min.clone().add(source.max).multiplyScalar(.5),axis=size.x<size.z?'x':'z',window=Number(name.slice(5))>=12167;

  const mesh=world.box(center.x,center.y,center.z,size.x,size.y,size.z,'barricade'),panel=world.register(mesh,'barricade');mesh.userData.exterior=true;mesh.userData.openingId=name;mesh.userData.window=window;panel.reinforceEligible=false;panel.defaultBroken=false;const opening=new THREE.Box3(source.min.clone(),source.max.clone());opening.min[axis]-=.5;opening.max[axis]+=.5;world.imported!.destructionVolumes.push({panel,box:opening,axis});

  const f=center.y<0?-1:center.y<3.4?0:center.y<8?1:2;doors.push({id:name,f,axis,at:center[axis],c:center[axis==='x'?'z':'x'],width:size[axis==='x'?'z':'x'],y:center.y,exterior:true,window,verified:'Bounds of supplied exterior barricade mesh '+name});

 }

 const proxy=(box:THREE.Box3,kind:'solid'|'floor'|'soft',axis:'x'|'y'|'z',renderBox=box)=>{const size=renderBox.getSize(new THREE.Vector3()),center=renderBox.getCenter(new THREE.Vector3()),mesh=world.box(center.x,center.y,center.z,size.x,size.y,size.z,'soft');const mat=(mesh.material as THREE.MeshLambertMaterial).clone();mat.transparent=true;mat.opacity=0;mat.depthWrite=false;mesh.material=mat;mesh.userData.nativeSurface=true;mesh.userData.dynamic=true;const panel=world.register(mesh,kind);mesh.visible=false;world.imported!.destructionVolumes.push({panel,box,axis});return panel;};

 // Authored wooden wall cores carry independent source seams (mesh_9466..9519).

 // Do not stretch room annotations across adjacent concrete, windows or doorways.

 const cores=[...world.imported.sourceObjects.entries()].filter(([name,parts])=>{const n=Number(name.slice(5)),p=parts[0],size=p.max.clone().sub(p.min);return n>=9466&&n<=9519&&p.mesh.userData.surfaceMaterial==='mat_79.003'&&size.y>2.9&&size.y<3.1&&Math.min(size.x,size.z)<.2;}).sort(([a],[b])=>a.localeCompare(b));

 if(cores.length!==54)throw Error('Source soft-wall core inventory changed: '+cores.length);

 for(const [name,parts] of cores){const source=parts[0],size=source.max.clone().sub(source.min),axis=size.x<size.z?'x':'z',lateral=axis==='x'?'z':'x',box=new THREE.Box3(source.min.clone(),source.max.clone());

  box.min[axis]-=.20;box.max[axis]+=.20;box.min[lateral]-=.006;box.max[lateral]+=.006;

  // Preserve supporting floors while removing all face/backing layers within this source panel.

  const center=box.getCenter(new THREE.Vector3()),floors=[-1,1].map(side=>{const q=center.clone();q[axis]+=side*.65;return world.ground(q.x,q.z,source.min.y+.6,0);}).filter(y=>Math.abs(y-source.min.y)<.5);

  if(floors.length)box.min.y=Math.min(...floors)+.035;

  const renderBox=new THREE.Box3(source.min.clone(),source.max.clone());renderBox.min[axis]-=.035;renderBox.max[axis]+=.035;

  const p=proxy(box,'soft',axis,renderBox);p.reinforceEligible=true;world.configureGrid(p,box,axis,size[axis]);p.mesh.userData.surfaceId='source-wall-'+name;p.mesh.userData.sourceBounds=[source.min.toArray(),source.max.toArray()];p.mesh.userData.designationEvidence='Discrete wooden wall core and independent seams in supplied Y9S4 model; exact game eligibility still requires footage corroboration';

  const f=source.min.y<0?-1:source.min.y<3?0:1;

  softSurfaces.push({id:p.mesh.userData.surfaceId,f,axis,at:center[axis],lo:source.min[lateral],hi:source.max[lateral],reinforce:true,reference:p.mesh.userData.designationEvidence});

 }

 // Six hatch covers have discrete square geometry in the source (material 77).

 for(const [i,name] of ['mesh_5091','mesh_5103','mesh_5117','mesh_5118','mesh_5119','mesh_5120'].entries()){const source=world.imported.sourceObjects.get(name)?.[0];if(!source)throw Error('Missing source hatch '+name);const box=new THREE.Box3(source.min.clone(),source.max.clone());box.min.y-=.48;box.max.y+=.025;const panel=proxy(box,'floor','y',new THREE.Box3(source.min.clone(),source.max.clone()));panel.mesh.userData.sourceBounds=[source.min.toArray(),source.max.toArray()];panel.mesh.userData.surfaceId='source-hatch-'+name;panel.mesh.userData.reference='Discrete hatch cover and underside in supplied mesh';panel.reinforceEligible=true;world.configureGrid(panel,box,'y');hatches.push({id:panel.mesh.userData.surfaceId,f:source.max.y>3?1:0,x:(box.min.x+box.max.x)/2,z:(box.min.z+box.max.z)/2});}

 // The eight matching dome-camera meshes are retained visually; only their state proxy is added.

 for(const [index,name] of Array.from({length:8},(_,i)=>'mesh_'+(12151+i)).entries()){const source=world.imported.sourceObjects.get(name)?.[0];if(!source)throw Error('Missing source camera '+name);const box=new THREE.Box3(source.min.clone(),source.max.clone()).expandByScalar(.004),center=box.getCenter(new THREE.Vector3()),panel=proxy(box,'solid','y');panel.mesh.userData.securityId=index;const room=rooms.filter(r=>Math.abs((r.y??r.f*4)-(center.y-2.6))<1.8).sort((a,b)=>Math.hypot(center.x-(a.x0+a.x1)/2,center.z-(a.z0+a.z1)/2)-Math.hypot(center.x-(b.x0+b.x1)/2,center.z-(b.z0+b.z1)/2))[0];const target=room?new THREE.Vector3((room.x0+room.x1)/2,room.y??room.f*4,(room.z0+room.z1)/2):new THREE.Vector3(15,0,0),d=target.sub(center);securityCameras.push({name:(room?.name??'Exterior')+' · source camera',x:center.x,y:box.min.y-.025,z:center.z,yaw:Math.atan2(-d.x,-d.z),pitch:-.3});}

 for(const value of Object.values(bombLocations)){const p=value as typeof value&{y?:number};const safe=world.safeSpawn(new THREE.Vector3(p.x,p.y??p.floor*4,p.z));p.x=safe.x;p.y=safe.y-.015;p.z=safe.z;}world.bombModels=new BombModels(world);


 const data=await fetch(navigationCandidate?'/assets/oregon/scratch/navigation-candidate.json.gz':browserNavigation?'/assets/oregon/browser/navigation.json.gz':'/assets/oregon/navigation.json.gz').then(async r=>{if(!r.ok)throw Error('Map navigation unavailable');const b=await r.arrayBuffer(),v=new Uint8Array(b);return JSON.parse(await (v[0]===31&&v[1]===139?new Response(new Blob([b]).stream().pipeThrough(new DecompressionStream('gzip'))):new Response(b)).text());});world.navNodes=data.nodes.map((n:{pos:number[],links:number[]})=>({pos:new THREE.Vector3().fromArray(n.pos),links:n.links}));

 const sourceNodes=world.navNodes,remap=new Int32Array(sourceNodes.length).fill(-1);world.navNodes=sourceNodes.filter((n,i)=>{if(world.imported!.collide(n.pos.x,n.pos.y,n.pos.z,movementConfig.stand.radius,movementConfig.stand.height)||world.imported!.collide(n.pos.x,n.pos.y,n.pos.z,.14,.17))return false;remap[i]=0;return true;});let navId=0;for(let i=0;i<remap.length;i++)if(remap[i]===0)remap[i]=navId++;for(const n of world.navNodes)n.links=n.links.map(i=>remap[i]).filter(i=>i>=0);

 const nodes=world.navNodes,grid=new Map<string,number[]>();nodes.forEach((n,i)=>{const key=Math.floor(n.pos.x/2)+':'+Math.floor(n.pos.z/2),list=grid.get(key)??[];list.push(i);grid.set(key,list);});

 const activeBombs=bombNavigation(world,nodes,grid);

 const nearest=(p:THREE.Vector3)=>{const blocked=activeBombs().blocked;let best=-1,distance=Infinity;const x=Math.floor(p.x/2),z=Math.floor(p.z/2);for(let ring=0;ring<16;ring++){for(let dx=-ring;dx<=ring;dx++)for(let dz=-ring;dz<=ring;dz++){if(ring&&Math.max(Math.abs(dx),Math.abs(dz))!==ring)continue;for(const i of grid.get((x+dx)+':'+(z+dz))??[]){if(blocked.has(i))continue;const d=nodes[i].pos.distanceToSquared(p);if(d<distance){distance=d;best=i;}}}const outside=Math.min(p.x-(x-ring)*2,(x+ring+1)*2-p.x,p.z-(z-ring)*2,(z+ring+1)*2-p.z);if(best>=0&&outside*outside>distance)return best;}if(best<0)for(let i=0;i<nodes.length;i++){if(blocked.has(i))continue;const d=nodes[i].pos.distanceToSquared(p);if(d<distance){distance=d;best=i;}}return best;};

 // Directed step/drop links need weak connectivity for this early rejection.
 // A traversal along outgoing links alone can assign different component IDs
 // to nodes that still have a valid directed route. A* checks direction later.
 const components=Int32Array.from(nodes,(_,i)=>i);
 const componentRoot=(i:number):number=>{while(components[i]!==i){components[i]=components[components[i]];i=components[i];}return i;};
 for(let i=0;i<nodes.length;i++)for(const j of nodes[i].links){const a=componentRoot(i),b=componentRoot(j);if(a!==b)components[b]=a;}
 for(let i=0;i<nodes.length;i++)components[i]=componentRoot(i);

 // Refine room elevation labels from the modal walkable source height, never fixed 4 m spacing.

 for(const r of rooms){const histogram=new Map<number,number>();for(const n of nodes)if(n.pos.x>=r.x0&&n.pos.x<=r.x1&&n.pos.z>=r.z0&&n.pos.z<=r.z1&&Math.abs(n.pos.y-(r.y??r.f*4))<1.5){const y=Math.round(n.pos.y/.05)*.05;histogram.set(y,(histogram.get(y)??0)+1);}const mode=[...histogram].sort((a,b)=>b[1]-a[1])[0];if(mode)r.y=mode[0]-.015;}

 // Connected collision-clear navigation edges provide actual opening/stair sound paths.

 const portalCells=new Set<string>();for(let i=0;i<nodes.length;i+=3)for(const j of nodes[i].links){if(j<i)continue;const a=nodes[i].pos,b=nodes[j].pos,ra=world.room(a.x,a.y,a.z),rb=world.room(b.x,b.y,b.z);if(ra===rb&&Math.abs(a.y-b.y)<.12)continue;if(ra.startsWith('EXT')&&rb.startsWith('EXT'))continue;const p=a.clone().add(b).multiplyScalar(.5);p.y+=1.1;const key=Math.round(p.x/1.5)+':'+Math.round(p.y/1.5)+':'+Math.round(p.z/1.5);if(!portalCells.has(key)){portalCells.add(key);world.soundPortals.push(p);}}

 const worker=new Worker(new URL('./navigation-worker.ts',import.meta.url),{type:'module'}),positions=new Float32Array(nodes.flatMap(n=>n.pos.toArray())),offsets=new Uint32Array(nodes.length+1);let linkCount=0;nodes.forEach((n,i)=>{offsets[i]=linkCount;linkCount+=n.links.length;});offsets[nodes.length]=linkCount;const links=new Uint32Array(nodes.flatMap(n=>n.links));worker.postMessage({kind:'init',positions,offsets,links},[positions.buffer,offsets.buffer,links.buffer]);let jobId=0;const jobs=new Map<number,{resolve:(v:THREE.Vector3[])=>void,goal:THREE.Vector3}>();worker.onmessage=e=>{const job=jobs.get(e.data.id);if(job){jobs.delete(e.data.id);job.resolve(e.data.ids.map((id:number)=>nodes[id].pos.clone()).concat(e.data.ids.length?[job.goal]:[]));}};worker.onerror=()=>{for(const j of jobs.values())j.resolve([]);jobs.clear();};world.disposeNavigation=()=>{worker.terminate();for(const job of jobs.values())job.resolve([]);jobs.clear();};

 const navigationCells=grid;
 let openingKey='',cachedOpeningEdges:[number,number][]=[];

 const openingEdges=()=>{const active=world.imported!.destructionVolumes.filter(v=>(v.panel.broken||!!v.panel.grid?.removed)&&['soft','floor'].includes(v.panel.kind)),key=active.map(v=>v.panel.mesh.userData.surfaceId+':'+(v.panel.grid?.revision??0)).join('|')+':'+world.bombModels.models.filter(m=>m.root.visible).map(m=>m.site+','+m.index).join(';');if(key===openingKey)return cachedOpeningEdges;openingKey=key;const extra:[number,number][]=[];

  for(const v of active){const center=v.box.getCenter(new THREE.Vector3()),grid=v.panel.grid;
   if(v.axis==='y'){
    const points=[center.clone()];if(grid)for(let y=0;y<grid.ny;y++)for(let x=0;x<grid.nx;x++)if(grid.health[y*grid.nx+x]===0)points.push(new THREE.Vector3(grid.minU+(x+.5)*grid.dx,center.y,grid.minV+(y+.5)*grid.dy));
    points.sort((a,b)=>a.distanceToSquared(center)-b.distanceToSquared(center));
    for(const point of points){if(!world.imported!.hole(point,movementConfig.stand.radius,movementConfig.stand.height,point.x,v.box.min.y,point.z))continue;const above=point.clone().setY(v.box.max.y+.06),below=point.clone(),floor=world.ground(point.x,point.z,v.box.min.y-.05,0);if(floor===-25)continue;below.y=floor+.015;if(world.collide(below.x,below.y,below.z,movementConfig.stand.radius,movementConfig.stand.height))continue;const i=nearest(above),j=nearest(below);if(i>=0&&j>=0&&i!==j&&above.y-below.y>.5){extra.push([i,j]);break;}}
   }else{
    const lateral=v.axis==='x'?'z':'x',fractions=new Set([.5,.25,.75]);if(grid)for(let x=0;x<grid.nx;x++)if(Array.from({length:grid.ny},(_,y)=>grid.health[y*grid.nx+x]).some(h=>h===0))fractions.add((x+.5)/grid.nx);
    // A wall core can extend below a raised room floor. Consider the measured
    // walkable heights nearby instead of assuming its bottom is the floor.
    const levels=new Set<number>([v.box.min.y+.06]),gx=Math.floor(center.x/2),gz=Math.floor(center.z/2);
    for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++)for(const id of navigationCells.get((gx+dx)+':'+(gz+dz))??[]){const p=nodes[id].pos;if(p.y>=v.box.min.y-.4&&p.y<=v.box.max.y-movementConfig.stand.height+.05)levels.add(Math.round(p.y/.05)*.05);}
    let connected=false;
    for(const fraction of [...fractions].sort((a,b)=>Math.abs(a-.5)-Math.abs(b-.5))){
     center[lateral]=THREE.MathUtils.lerp(v.box.min[lateral],v.box.max[lateral],fraction);
     for(const level of [...levels].sort((a,b)=>a-b)){
      center.y=level;const left=center.clone(),right=center.clone();left[v.axis]-=.8;right[v.axis]+=.8;
      left.y=world.ground(left.x,left.z,level+.3,0)+.015;right.y=world.ground(right.x,right.z,level+.3,0)+.015;
      if(Math.abs(left.y-level)>.45||Math.abs(right.y-level)>.45||Math.abs(left.y-right.y)>.36)continue;
      const probe=center.clone().setY(Math.min(v.box.max.y-.001,Math.max(left.y,right.y)+.9));
      if(!world.imported!.hole(probe,movementConfig.stand.radius,movementConfig.stand.height,probe.x,Math.max(left.y,right.y),probe.z))continue;
      const i=nearest(left),j=nearest(right);if(i<0||j<0||i===j)continue;const a=nodes[i].pos,b=nodes[j].pos,n=Math.ceil(a.distanceTo(b)/.08);let clear=true;
      for(let step=0;step<=n;step++){const q=a.clone().lerp(b,step/n);if(world.collide(q.x,q.y,q.z,movementConfig.stand.radius,movementConfig.stand.height)){clear=false;break;}}
      if(clear){extra.push([i,j],[j,i]);connected=true;break;}
     }
     if(connected)break;
    }
   }
  }

  cachedOpeningEdges=extra;return extra;

 };

 world.routeAsync=(start,goal)=>{const obstacles=activeBombs(),a=nearest(start),b=nearest(goal);if(a<0||b<0)return Promise.resolve([]);return new Promise(resolve=>{const id=++jobId;jobs.set(id,{resolve,goal:obstacles.contains(goal)?nodes[b].pos.clone():goal.clone()});worker.postMessage({kind:'route',id,start:a,goal:b,extra:openingEdges(),blocked:obstacles.blockedIds,blockedLinks:obstacles.blockedLinks});});};

 world.route=(start,goal)=>{

  const obstacles=activeBombs(),a=nearest(start),b=nearest(goal);if(a<0||b<0)return [];const blockedLinks=new Set(obstacles.blockedLinks.map(([i,j])=>i*nodes.length+j)),extra=new Map<number,number[]>();

  for(const [i,j] of openingEdges())extra.set(i,[...(extra.get(i)??[]),j]);

  if(components[a]!==components[b]&&!extra.size)return [];const prev=new Int32Array(nodes.length).fill(-1),cost=new Float32Array(nodes.length).fill(Infinity),closed=new Uint8Array(nodes.length),heap:[number,number][]=[];

  const push=(id:number,f:number)=>{let i=heap.length;heap.push([id,f]);while(i){const p=(i-1)>>1;if(heap[p][1]<=f)break;heap[i]=heap[p];i=p;}heap[i]=[id,f];};

  const pop=()=>{const result=heap[0],last=heap.pop()!;if(heap.length){let i=0;while(i*2+1<heap.length){let j=i*2+1;if(j+1<heap.length&&heap[j+1][1]<heap[j][1])j++;if(heap[j][1]>=last[1])break;heap[i]=heap[j];i=j;}heap[i]=last;}return result[0];};

  cost[a]=0;prev[a]=a;push(a,0);while(heap.length){const i=pop();if(closed[i])continue;closed[i]=1;if(i===b)break;for(const j of [...nodes[i].links,...extra.get(i)??[]]){if(closed[j]||obstacles.blocked.has(j)||blockedLinks.has(i*nodes.length+j))continue;const c=cost[i]+nodes[i].pos.distanceTo(nodes[j].pos);if(c<cost[j]){cost[j]=c;prev[j]=i;push(j,c+nodes[j].pos.distanceTo(nodes[b].pos));}}}

  if(!closed[b])return [];const ids=[b];while(ids.at(-1)!==a)ids.push(prev[ids.at(-1)!]);ids.reverse();return ids.map(i=>nodes[i].pos.clone()).concat(obstacles.contains(goal)?nodes[b].pos.clone():goal.clone());

 };

 world.scene.updateMatrixWorld(true);return world;

}





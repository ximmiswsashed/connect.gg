import * as T from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {realizeModel,surfaceMaterial} from './realism-materials';
import {weaponRail,weaponPoint,weaponModel} from './weapon-catalog';

export function beveledBox(w:number,h:number,d:number){const g=new RoundedBoxGeometry(w,h,d,1,Math.min(.0025,w*.12,h*.12,d*.12));g.setIndex(Array.from({length:g.attributes.position.count},(_,i)=>i));return g;}
/** Base models own their hardware; a generic overlay used to put duplicate posts and pins in mid-air. */
export function firearmDetail(root:T.Group,id:number){
 if(root.userData.realisticModel)return root;root.userData.realisticModel=true;
 realizeModel(root);root.userData.visualVersion='fitted-weapons-v19';return root;
}

export function deviceDetail(root:T.Mesh,type:string){
 if(root.userData.realisticModel)return root;root.userData.realisticModel=true;const geometry=root.geometry;if(geometry.getAttribute('position')){
  geometry.computeBoundingBox();const b=geometry.boundingBox!,w=b.max.x-b.min.x,h=b.max.y-b.min.y,d=b.max.z-b.min.z,parts:T.BufferGeometry[]=[];
  if(w>.08&&h>.05&&d<.6){for(const x of [-1,1])for(const y of [-1,1])parts.push(new T.CylinderGeometry(.0028,.0028,.002,10).rotateX(Math.PI/2).translate(x*w*.38,y*h*.36,b.max.z+.002));for(let i=0;i<4;i++)parts.push(beveledBox(w*.18,.002,.003).translate(w*.22,-h*.16+i*.009,b.max.z+.002));
   const merged=mergeGeometries(parts)!;parts.forEach(g=>g.dispose());const m=surfaceMaterial(new T.MeshLambertMaterial({color:0x6c7578}),'metal'),mesh=new T.Mesh(merged,m);mesh.name='Fasteners and housing vents';mesh.userData.realismDetail=true;root.add(mesh);
  }
 }
 realizeModel(root);root.traverse(o=>{o.userData.deviceRoot=root;});return root;
}

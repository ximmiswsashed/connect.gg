export type BreachTool='ash'|'thermite'|'hammer'|'shotgun';
export type SurfaceRule={material:'wood-core'|'hatch-core'|'structural'|'barricade',thickness:number,penetrable:boolean,reinforceEligible:boolean,cellStrength:number};
export const breachFootprints={
 // Candidate: taller than a standing body, with a narrower span than Thermite.
 // Browser-game calibration; exact current Siege X dimensions remain unverified.
 ash:{width:1.5,height:2.4,shape:'ellipse'},
 // Bounds used to gather contiguous hatch layers; each struck hatch clears completely.
 ashFloor:{width:1.1,height:1.1,shape:'ellipse'},
 thermite:{width:1.8,height:2.25,shape:'rounded',wallVerticalOffset:-.55},
 hammer:{width:.65,height:.65,shape:'ellipse'},
 shotgun:{maxRange:12,fullRange:2,radius:.30,maxCellsPerShot:18,strength:220}
} as const;
export type CellChange=[number,number];
export type GridDelta={revision:number,cells:CellChange[]};

// A cell describes remaining material through the complete surface thickness.
// The same lattice is consumed by visual clipping, clearance and bullet paths.
// No triangulation or CSG runs for individual pellets.
export class PanelGrid{
 readonly nx:number;readonly ny:number;readonly dx:number;readonly dy:number;
 readonly health:Uint8Array;revision=0;removed=0;
 constructor(public minU:number,public maxU:number,public minV:number,public maxV:number,public rule:SurfaceRule,cellSize=.125){
  if(!(maxU>minU&&maxV>minV&&cellSize>0))throw Error('Invalid panel lattice bounds');
  this.nx=Math.min(64,Math.ceil((maxU-minU)/cellSize));this.ny=Math.min(64,Math.ceil((maxV-minV)/cellSize));
  this.dx=(maxU-minU)/this.nx;this.dy=(maxV-minV)/this.ny;
  this.health=new Uint8Array(this.nx*this.ny).fill(255);
 }
 bullet(u:number,v:number){const i=this.index(u,v);return this.rule.material!=='barricade'||i<0?{revision:this.revision,cells:[]}:this.commit(new Map([[i,this.health[i]-128]]));}
 clearAll(){return this.commit(new Map(Array.from(this.health,(_,i)=>[i,0])));}
 get damaged(){return this.health.some(v=>v!==255);}
 index(u:number,v:number){if(u<this.minU||u>=this.maxU||v<this.minV||v>=this.maxV)return -1;return Math.floor((v-this.minV)/this.dy)*this.nx+Math.floor((u-this.minU)/this.dx);}
 materialAt(u:number,v:number){const i=this.index(u,v);return i<0||this.health[i]!==0;}
 // Clearance is conservative: every overlapping cell must be absent. Testing
 // just the center would admit a drone/player whose body still hits an edge.
 clear(u0:number,u1:number,v0:number,v1:number){
  if(u0<this.minU-1e-6||u1>this.maxU+1e-6||v0<this.minV-1e-6||v1>this.maxV+1e-6||u1<u0||v1<v0)return false;
  if(u0===u1&&v0===v1)return !this.materialAt(u0,v0);
  const x0=Math.max(0,Math.floor((u0-this.minU)/this.dx)),x1=Math.min(this.nx-1,Math.ceil((u1-this.minU)/this.dx)-1);
  const y0=Math.max(0,Math.floor((v0-this.minV)/this.dy)),y1=Math.min(this.ny-1,Math.ceil((v1-this.minV)/this.dy)-1);
  for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)if(this.health[y*this.nx+x]!==0)return false;
  return true;
 }
 private commit(changes:Map<number,number>):GridDelta{
  const cells:CellChange[]=[];
  for(const [i,value] of changes){const old=this.health[i],next=Math.max(0,Math.min(255,Math.round(value)));if(next===old)continue;this.health[i]=next;if(old>0&&next===0)this.removed++;cells.push([i,next]);}
  if(cells.length)this.revision++;return {revision:this.revision,cells};
 }
 breach(tool:Exclude<BreachTool,'shotgun'>,u:number,v:number,reinforced=false):GridDelta{
  if(this.rule.material==='structural'||reinforced&&tool!=='thermite')return {revision:this.revision,cells:[]};
  if(tool==='ash'&&this.rule.material==='hatch-core')return this.clearAll();
  const f=breachFootprints[tool],a=f.width/2,b=f.height/2,changes=new Map<number,number>();
  for(let y=0;y<this.ny;y++)for(let x=0;x<this.nx;x++){
   const du=(this.minU+(x+.5)*this.dx-u)/a,dv=(this.minV+(y+.5)*this.dy-v)/b;
   if(f.shape==='ellipse'?du*du+dv*dv<=1:Math.abs(du)<=1&&Math.abs(dv)<=1&&Math.pow(Math.abs(du),4)+Math.pow(Math.abs(dv),4)<=1.45)changes.set(y*this.nx+x,0);
  }
  return this.commit(changes);
 }
 shotgun(impacts:{u:number,v:number,distance:number}[],reinforced=false,maxCells:number=breachFootprints.shotgun.maxCellsPerShot):GridDelta{
  if(reinforced||this.rule.material==='structural')return {revision:this.revision,cells:[]};
  const f=breachFootprints.shotgun,pending=new Map<number,number>();
  for(const hit of impacts){
   if(!Number.isFinite(hit.distance)||hit.distance<0||hit.distance>f.maxRange)continue;
   const force=f.strength*Math.max(0,(f.maxRange-hit.distance)/(f.maxRange-f.fullRange));
   const strength=Math.min(f.strength,force)/this.rule.cellStrength;
   const i=this.index(hit.u,hit.v);if(i<0)continue;
   const ix=i%this.nx,iy=Math.floor(i/this.nx);
   const weights:{cell:number,weight:number}[]=[];
   for(let y=Math.max(0,iy-Math.ceil(f.radius/this.dy));y<=Math.min(this.ny-1,iy+Math.ceil(f.radius/this.dy));y++)for(let x=Math.max(0,ix-Math.ceil(f.radius/this.dx));x<=Math.min(this.nx-1,ix+Math.ceil(f.radius/this.dx));x++){
    const d=Math.hypot(this.minU+(x+.5)*this.dx-hit.u,this.minV+(y+.5)*this.dy-hit.v);if(d>f.radius)continue;weights.push({cell:y*this.nx+x,weight:Math.max(.3,1-d/f.radius)});
   }
   for(const {cell,weight} of weights)pending.set(cell,Math.max(0,(pending.get(cell)??this.health[cell])-strength*weight));
  }
  // Bound new destruction independently of pellet count. Existing damage and
  // repeated shots can accumulate; a distant shot cannot wipe a large panel.
  let destroyed=0;const changes=new Map<number,number>();
  for(const [i,next] of [...pending].sort((a,b)=>a[1]-b[1]||a[0]-b[0])){
   if(this.health[i]>0&&next<.5&&destroyed++>=Math.max(0,maxCells))continue;changes.set(i,next);
  }
  return this.commit(changes);
 }
 apply(delta:GridDelta){
  if(delta.revision!==this.revision+1)return false;
  for(const [i,hp] of delta.cells)if(!Number.isInteger(i)||i<0||i>=this.health.length||!Number.isInteger(hp)||hp<0||hp>255)throw Error('Invalid panel damage event');
  for(const [i,hp] of delta.cells)this.health[i]=hp;
  this.removed=this.health.reduce((n,hp)=>n+Number(hp===0),0);this.revision=delta.revision;return true;
 }
 applyFrom(base:number,delta:GridDelta){
  if(this.revision!==base||delta.revision<=base)return false;
  for(const [i,hp] of delta.cells)if(!Number.isInteger(i)||i<0||i>=this.health.length||!Number.isInteger(hp)||hp<0||hp>255)throw Error('Invalid panel damage event');
  for(const [i,hp] of delta.cells)this.health[i]=hp;
  this.removed=this.health.reduce((n,hp)=>n+Number(hp===0),0);this.revision=delta.revision;return true;
 }
 reset(){this.health.fill(255);this.removed=0;this.revision++;}
 snapshot(){const cells:CellChange[]=[];this.health.forEach((hp,i)=>{if(hp!==255)cells.push([i,hp]);});return {revision:this.revision,cells};}
 restore(state:GridDelta){
  for(const [i,hp] of state.cells)if(!Number.isInteger(i)||i<0||i>=this.health.length||!Number.isInteger(hp)||hp<0||hp>255)throw Error('Invalid panel snapshot');
  this.health.fill(255);for(const [i,hp] of state.cells)this.health[i]=hp;
  this.removed=this.health.reduce((n,hp)=>n+Number(hp===0),0);this.revision=state.revision;
 }
 clone(){const copy=new PanelGrid(this.minU,this.maxU,this.minV,this.maxV,{...this.rule});copy.restore(this.snapshot());return copy;}
 remainingRectangles(){
  const used=new Uint8Array(this.health.length),rectangles:number[][]=[];
  for(let y=0;y<this.ny;y++)for(let x=0;x<this.nx;x++){
   const start=y*this.nx+x;if(used[start]||this.health[start]===0)continue;
   let width=1;while(x+width<this.nx&&!used[start+width]&&this.health[start+width]!==0)width++;
   let height=1;outer:while(y+height<this.ny){for(let j=0;j<width;j++)if(used[(y+height)*this.nx+x+j]||this.health[(y+height)*this.nx+x+j]===0)break outer;height++;}
   for(let dy=0;dy<height;dy++)used.fill(1,(y+dy)*this.nx+x,(y+dy)*this.nx+x+width);
   rectangles.push([this.minU+x*this.dx,this.minU+(x+width)*this.dx,this.minV+y*this.dy,this.minV+(y+height)*this.dy]);
  }return rectangles;
 }
}

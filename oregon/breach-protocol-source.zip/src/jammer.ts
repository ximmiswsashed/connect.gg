import * as THREE from 'three';
import {OBB} from 'three/addons/math/OBB.js';
import type {World} from './world';
import type {Game,Bot,Device} from './game';
import {deviceMesh} from './devices';
import {botPosture,turnBot} from './ai-posture';

// Two sampled 2024 placements commit inventory about 2.5s after placement progress begins.
// This single held action includes lowering/release; the original equip/input clock is unverified.
export const jammerPlacementSeconds=2.5;
export const jammerPosture=(start:number,progress:number)=>Math.max(start,1.6*THREE.MathUtils.smoothstep(progress,.05,.65));
// Deployment clearance uses the actual model envelope, including its antennae.
// Oriented bounds avoid treating a rotated device as a much larger axis-aligned box.
export function jammerDeviceBlocked(pos:THREE.Vector3,yaw:number,devices:readonly Device[]){
 if(!devices.length)return false;
 const local=new THREE.Box3(new THREE.Vector3(-.14,-.1475,-.10),new THREE.Vector3(.14,.385,.1155));
 const candidate=new OBB().fromBox3(local).applyMatrix4(new THREE.Matrix4().compose(pos,new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),yaw),new THREE.Vector3(1,1,1)));
 for(const d of new Set(devices)){
  if(!d.mesh.visible||!d.mesh.parent||['destroyed','recovered'].includes(d.type)||d.type==='gas'&&d.active)continue;
  d.mesh.updateWorldMatrix(true,true);let blocked=false;
  d.mesh.traverseVisible(o=>{if(blocked||!(o instanceof THREE.Mesh))return;const geometry=o.geometry;if(!geometry.boundingBox)geometry.computeBoundingBox();if(geometry.boundingBox&&candidate.intersectsOBB(new OBB().fromBox3(geometry.boundingBox).applyMatrix4(o.matrixWorld)))blocked=true;});
  if(blocked)return true;
 }
 return false;
}
export function jammerPlacement(world:World,feet:THREE.Vector3,eye:THREE.Vector3,yaw:number,distance=.65,devices:readonly Device[]=[]){
 const pos=feet.clone().addScaledVector(new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw)),distance);
 const floor=world.ground(pos.x,pos.z,feet.y);
 // A floor on another storey or below a ledge is outside placement reach.
 if(Math.abs(floor-feet.y)>.1)return null;
 pos.y=floor+.18;
 return world.collide(pos.x,pos.y-.15,pos.z,.22,.535)||!world.sight(eye,pos)||jammerDeviceBlocked(pos,yaw,devices)?null:pos;
}
export function placeJammer(world:World,devices:Device[],feet:THREE.Vector3,eye:THREE.Vector3,yaw:number,team:number,owner:string,distance=.65,blockers:readonly Device[]=devices){
 const pos=jammerPlacement(world,feet,eye,yaw,distance,blockers);if(!pos)return null;
 const mesh=deviceMesh('jammer');mesh.position.copy(pos);mesh.rotation.y=yaw;world.scene.add(mesh);
 const device:Device={type:'jammer',pos,mesh,time:1000,active:false,team,owner};devices.push(device);return device;
}
type Preparation={goal:THREE.Vector3,yaw:number,elapsed:number,start?:number,target?:THREE.Vector3};
export function updateBotJammer(game:Game,b:Bot,dt:number,move:()=>void,route:(goal:THREE.Vector3)=>void,turnAllowance=dt*2.4){
 const state=b.mesh.userData;b.jammerHold=0;b.jammerTarget=null;
 if(b.operator!==4||b.team!==1||b.hp<=0||game.phase!=='prep'||(b.gadgetCharges??0)<=0){delete state.jammerPreparation;return false;}
 if((state.jammerRecovery??0)>0){state.jammerRecovery=Math.max(0,state.jammerRecovery-dt);b.stanceAmount=THREE.MathUtils.damp(b.stanceAmount??0,1,12,dt);return true;}
 const eye=()=>b.pos.clone().add(new THREE.Vector3(0,botPosture(b).eye,0));
 const spaced=(pos:THREE.Vector3)=>![...game.devices,...game.externalDevices].some(d=>d.type==='jammer'&&d.mesh.visible&&d.pos.distanceTo(pos)<3);
 const key=(goal:THREE.Vector3)=>goal.toArray().map(n=>n.toFixed(1)).join(',');
 const reject=(goal:THREE.Vector3)=>{(state.jammerRejected??=[]).push(key(goal));delete state.jammerPreparation;state.jammerTravel=0;};
 let plan=state.jammerPreparation as Preparation|undefined;
 if(!plan){
  if(state.routePending)return false;
  state.jammerDecision=Math.max(0,(state.jammerDecision??0)-dt);if(state.jammerDecision>0)return false;state.jammerDecision=1;
  const panels=game.world.nearPanels(game.objective.x,game.objective.z,12).filter(p=>!p.broken&&(p.reinforceEligible||p.kind==='barricade'));
  const candidates:{goal:THREE.Vector3,yaw:number}[]=[];
  for(const panel of panels){
   const center=panel.min.clone().add(panel.max).multiplyScalar(.5),size=panel.max.clone().sub(panel.min);
   if(Math.abs(center.y-b.pos.y)>2.5)continue;
   const axis=size.x<size.z?'x':'z';
   // Try the current reachable position first, then both sides of the protected surface.
   const goals=[b.pos.clone(),...[-1,1].map(side=>{const p=center.clone();p[axis]+=side*(size[axis]/2+1.7);p.y=b.pos.y;return p;})];
   for(const goal of goals){
    goal.y=game.world.ground(goal.x,goal.z,b.pos.y)+.015;
    if((state.jammerRejected??[]).includes(key(goal))||Math.abs(goal.y-b.pos.y)>.5||game.world.collide(goal.x,goal.y,goal.z,.27,1.82))continue;
    const yaw=Math.atan2(goal.x-center.x,goal.z-center.z),pos=jammerPlacement(game.world,goal,goal.clone().add(new THREE.Vector3(0,1.04,0)),yaw,.65,[...game.devices,...game.externalDevices]);
    if(pos&&spaced(pos)&&pos.distanceTo(pos.clone().clamp(panel.min,panel.max))<2.25)candidates.push({goal,yaw});
   }
  }
  candidates.sort((a,c)=>a.goal.distanceToSquared(b.pos)-c.goal.distanceToSquared(b.pos));
  const chosen=candidates[0];if(!chosen)return false;
  plan=state.jammerPreparation={...chosen,elapsed:0};b.goal.copy(plan.goal);b.path=[];route(plan.goal);
 }
 if(b.pos.distanceTo(plan.goal)>.35){
  if(!state.routePending&&!b.path.length){reject(plan.goal);return false;}
  b.stance='stand';b.stanceAmount=THREE.MathUtils.damp(b.stanceAmount??0,0,12,dt);
  move();state.jammerTravel=(state.jammerTravel??0)+dt;
  if(state.jammerTravel>5)reject(plan.goal);
  return true;
 }
 state.jammerTravel=0;
 plan.start??=b.stanceAmount??0;
 if(Array.from({length:9},(_,i)=>game.postureBlocked(b.pos,jammerPosture(plan!.start!,i/8),plan!.yaw)).some(Boolean)){reject(plan.goal);return true;}
 const diff=THREE.MathUtils.euclideanModulo(plan.yaw-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI;
 const turn=THREE.MathUtils.clamp(diff,-turnAllowance,turnAllowance),before=b.mesh.rotation.y;
 turnBot(game,b,turn);
 if(Math.abs(THREE.MathUtils.euclideanModulo(plan.yaw-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI)>.01){
  // An obstructed intermediate prone orientation cannot be skipped, even if the final pose fits.
  if(Math.abs(turn)>0&&b.mesh.rotation.y===before)reject(plan.goal);
  return true;
 }
 b.aiming=false;b.stance='crouch';
 b.stanceAmount=jammerPosture(plan.start,Math.min(1,(plan.elapsed+dt)/jammerPlacementSeconds));
 const pos=jammerPlacement(game.world,b.pos,eye(),plan.yaw,.65,[...game.devices,...game.externalDevices]);
 if(!pos||!spaced(pos)||plan.target&&plan.target.distanceTo(pos)>.05){delete state.jammerPreparation;state.jammerRecovery=.25;return true;}
 plan.target??=pos.clone();b.jammerTarget=plan.target;
 plan.elapsed+=dt;b.jammerHold=Math.max(0,jammerPlacementSeconds-plan.elapsed);
 if(plan.elapsed>=jammerPlacementSeconds){
  const placed=placeJammer(game.world,game.devices,b.pos,eye(),plan.yaw,b.team,'bot:'+b.id,.65,[...game.devices,...game.externalDevices]);
  if(placed){b.gadgetCharges!--;game.emitSound('device-place',placed.pos,.25);}
  delete state.jammerPreparation;
  state.jammerRecovery=.25;
 }
 return true;
}

import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {barricadeMaterial} from './barricades';
export const barricadeMaterials=()=>barricadeMaterial();
const wood=new THREE.Color(0x927650),paintCorner=new THREE.Color('#38563e');
// Edge vertices sample one unpainted texture corner. Linear vertex color restores
// their wood tone, sharing the paint material and one draw with both broad faces.
const woodTint=[wood.r/paintCorner.r,wood.g/paintCorner.g,wood.b/paintCorner.b];

// Eight physical boards retain the source panel's outer dimensions. Paint UVs
// span the complete opening, so the yellow X remains continuous across seams.
export function barricadeGeometry(size:THREE.Vector3,holes:{u:number,v:number,radius:number}[]=[],remaining?:number[][]){
 const axis=size.x<size.z?'x':'z',width=axis==='x'?size.z:size.x,height=size.y,thickness=axis==='x'?size.x:size.z;
 const geos:THREE.BufferGeometry[]=[];
 const cuts=holes.flatMap((h,i)=>{
  const core=[h.u-h.radius,h.u+h.radius,h.v-h.radius,h.v+h.radius],extra:number[][]=[];
  for(let k=0;k<4;k++){const step=h.radius/2,a=h.u-h.radius+k*step,b=a+step,chip=.005+((i*7+k*3)%5)*.002;
   if(k%2)extra.push([a,b,core[2]-chip,core[2]]);else extra.push([a,b,core[3],core[3]+chip]);
  }return [core,...extra];
 });
 for(let board=0;board<8;board++){
  const low=-height/2+board*height/8+(board?.001:0),high=-height/2+(board+1)*height/8-(board<7?.001:0);
  let rectangles=remaining?remaining.map(([a,b,c,d])=>[Math.max(-width/2,a),Math.min(width/2,b),Math.max(low,c),Math.min(high,d)]).filter(([a,b,c,d])=>b>a&&d>c):[[-width/2,width/2,low,high]];
  for(const [a,b,c,d] of cuts)rectangles=rectangles.flatMap(([x0,x1,y0,y1])=>{
   if(b<=x0||a>=x1||d<=y0||c>=y1)return [[x0,x1,y0,y1]];
   const l=Math.max(x0,a),r=Math.min(x1,b),bottom=Math.max(y0,c),top=Math.min(y1,d);
   return [[x0,l,y0,y1],[r,x1,y0,y1],[l,r,y0,bottom],[l,r,top,y1]].filter(q=>q[1]-q[0]>.0001&&q[3]-q[2]>.0001);
  });
  for(const [a,b,c,d] of rectangles){
   const geo=new THREE.BoxGeometry(axis==='x'?thickness:b-a,d-c,axis==='x'?b-a:thickness),uv=geo.getAttribute('uv');
   const colors=new Float32Array(uv.count*3);
   for(let k=0;k<uv.count;k++){const face=Math.floor(k/4),painted=axis==='x'?face<2:face>=4;
    if(painted){const positions=geo.getAttribute('position'),x=axis==='x'?positions.getZ(k):positions.getX(k);uv.setXY(k,((a+b)/2+x+width/2)/width,((c+d)/2+positions.getY(k)+height/2)/height);colors.set([1,1,1],k*3);}
    else{uv.setXY(k,.5/256,1-16.5/256);colors.set(woodTint,k*3);}
   }
   geo.setAttribute('color',new THREE.BufferAttribute(colors,3));
   geo.translate(axis==='x'?0:(a+b)/2,(c+d)/2,axis==='x'?(a+b)/2:0);
   geos.push(geo);
  }
 }
 const merged=geos.length?mergeGeometries(geos)!:new THREE.BufferGeometry();merged.clearGroups();geos.forEach(g=>g.dispose());merged.userData.boardCount=8;merged.userData.fractureCuts=cuts.length;return merged;
}

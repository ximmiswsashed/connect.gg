import type {RecordedDamage} from './replay-damage';
import type {Game} from './game';
import type {SoundEvent} from './audio';

export type RecordedEquipment={launcher:boolean,draw:number,launcherReload:number,launcherShot:number,hammer:number,hammerHit:boolean,hasHammerTarget:boolean,hammerTarget:number[],smoke:number,released:boolean,jammerYaw:number,actionPosition:number[],reloadTotal:number,reloadEmpty:boolean,rappel:boolean};
export type RecordedActor={id:string,name?:string,equipment?:RecordedEquipment,team:number,op:number,weapon:number,slot:number,optic:string,skin:string,attachment:string,p:number[],yaw:number,pitch:number,hp:number,stance:Game['stance'],amount:number,lean:number,ads:number,recoil:number[],shot:number,gait:number,velocity:number[],state:Game['state'],height:number,forward:number,reload:number,inspect:number,action:number,actionKind:string,actionTotal:number,gadget:number,vault:Game['vaultPlan'],vaultProgress:number,ammo:number[],reserve:number[],inverted:boolean};
export type RecordedPanel={id:number,hp:number,broken:boolean,reinforced:boolean,holes:number[][],grid?:{revision:number,cells:[number,number][]}};
export type RecordedDevice={id:string,type:string,p:number[],q:number[],active:boolean,visible:boolean};
export type ReplayFrame={t:number,actors:RecordedActor[],panels:RecordedPanel[],devices:RecordedDevice[],sounds:SoundEvent[]};
export type ReplayClip={id:string,duration:3.5,killer:string,victim:string,reason:string,winner:number,padded:number,frames:ReplayFrame[],damage?:RecordedDamage[],damageComplete?:boolean};
export {ReplayHistory} from './replay-history';

export {ReplayView} from './replay-view';

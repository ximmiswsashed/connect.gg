import * as THREE from 'three';
import type {World} from './world';
import type {NavNode} from './oregon';
import {movementConfig} from './movement';

const inside=(p:THREE.Vector3,b:THREE.Box3)=>p.x>b.min.x&&p.x<b.max.x&&p.y>b.min.y&&p.y<b.max.y&&p.z>b.min.z&&p.z<b.max.z;
function crosses(a:THREE.Vector3,b:THREE.Vector3,box:THREE.Box3){
 let enter=0,exit=1;
 for(const axis of ['x','y','z'] as const){
  const d=b[axis]-a[axis],lo=box.min[axis],hi=box.max[axis];
  if(Math.abs(d)<1e-12){if(a[axis]<=lo||a[axis]>=hi)return false;continue;}
  const t0=(lo-a[axis])/d,t1=(hi-a[axis])/d;enter=Math.max(enter,Math.min(t0,t1));exit=Math.min(exit,Math.max(t0,t1));if(enter>=exit)return false;
 }
 return exit>0&&enter<1;
}
// Imported navigation is static. Selected-site bombs are separate physical props.
// Use the existing 2 m bins and cache node/edge exclusions until those props change.
export function bombNavigation(world:World,nodes:NavNode[],grid:Map<string,number[]>){
 let reach=0;
 for(const n of nodes)for(const i of n.links)reach=Math.max(reach,Math.abs(n.pos.x-nodes[i].pos.x),Math.abs(n.pos.z-nodes[i].pos.z));
 let key='',cached={blocked:new Set<number>(),blockedIds:[] as number[],blockedLinks:[] as [number,number][],contains:(_p:THREE.Vector3)=>false};
 return ()=>{
  const models=world.bombModels.models.filter(m=>m.root.visible),next=models.map(m=>m.site+':'+m.index+':'+m.panels.map(p=>Number(p.broken)).join('')).join('|');
  if(next===key)return cached;key=next;
  const {radius,height}=movementConfig.stand,boxes=models.flatMap(m=>m.panels.filter(p=>!p.broken).map(p=>new THREE.Box3(new THREE.Vector3(p.min.x-radius,p.min.y+.05-height,p.min.z-radius),new THREE.Vector3(p.max.x+radius,p.max.y-.05,p.max.z+radius))));
  const candidates=new Set<number>();
  for(const box of boxes)for(let x=Math.floor((box.min.x-reach)/2);x<=Math.floor((box.max.x+reach)/2);x++)for(let z=Math.floor((box.min.z-reach)/2);z<=Math.floor((box.max.z+reach)/2);z++)for(const i of grid.get(x+':'+z)??[])candidates.add(i);
  const contains=(p:THREE.Vector3)=>boxes.some(box=>inside(p,box)),blocked=new Set<number>();
  for(const i of candidates)if(contains(nodes[i].pos))blocked.add(i);
  const blockedLinks:[number,number][]=[];
  for(const i of candidates)if(!blocked.has(i))for(const j of nodes[i].links)if(!blocked.has(j)&&boxes.some(box=>crosses(nodes[i].pos,nodes[j].pos,box)))blockedLinks.push([i,j]);
  cached={blocked,blockedIds:[...blocked],blockedLinks,contains};return cached;
 };
}

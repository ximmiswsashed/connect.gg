import type {Game,Bot} from './game';
import type {SoundEvent} from './audio';
import type {VaultPlan} from './vault';
import type {RecordedActor,RecordedPanel,RecordedDevice,ReplayFrame,ReplayClip} from './replay';
import {lethalEncounter,type DamageContact,type RecordedDamage} from './replay-damage';
import {botCharacterState} from './bot-presentation';
import {botPosture} from './ai-posture';
import {stride} from './pose';

const capacity=85;
type Slot={frame:ReplayFrame,actors:RecordedActor[],devices:RecordedDevice[]};
function actor():RecordedActor{return {id:'',name:'',equipment:{launcher:false,draw:0,launcherReload:0,launcherShot:0,hammer:0,hammerHit:false,hasHammerTarget:false,hammerTarget:[0,0,0],smoke:0,released:false,jammerYaw:0,actionPosition:[0,0,0],reloadTotal:0,reloadEmpty:false,rappel:false},team:0,op:0,weapon:0,slot:0,optic:'iron',skin:'Factory',attachment:'Factory',p:[0,0,0],yaw:0,pitch:0,hp:0,stance:'stand',amount:0,lean:0,ads:0,recoil:[0,0,0],shot:0,gait:0,velocity:[0,0,0],state:'stand',height:0,forward:0,reload:0,inspect:0,action:0,actionKind:'',actionTotal:0,gadget:0,vault:null,vaultProgress:0,ammo:[0,0],reserve:[0,0],inverted:false};}
function vector(target:number[],source:{x:number,y:number,z:number}){target[0]=source.x;target[1]=source.y;target[2]=source.z;}

/** Fixed chronological history. Pose/vector storage is reused after a frame expires. */
export class ReplayHistory{
 readonly capacity=capacity;
 private slots:Slot[]=Array.from({length:capacity},()=>({frame:{t:0,actors:[],panels:[],devices:[],sounds:[]},actors:[],devices:[]}));
 private head=0;private count=0;private panelBaseline=new Map<number,RecordedPanel>();private panelStates=new Map<number,RecordedPanel>();private vaults=new WeakMap<RecordedActor,VaultPlan>();
 private damageSlots:RecordedDamage[]=Array.from({length:1024},()=>({t:0,victim:'',attacker:'',amount:0,healthLoss:0,point:[0,0,0]}));private damageHead=0;private damageCount=0;
 damageOverflow=false;clock=0;accumulator=0;pending:SoundEvent[]=[];lastKill:{killer:string,victim:string,t:number}|null=null;
 get damageEvents(){const events:RecordedDamage[]=[];for(let i=0;i<this.damageCount;i++)events.push(this.damageSlots[(this.damageHead-this.damageCount+i+1024)%1024]);return events;}
 damage(victim:string,attacker:string,amount:number,healthLoss:number,contact:DamageContact={}){
  if(!Number.isFinite(amount)||amount<=0)return;
  const event=this.damageSlots[this.damageHead];this.damageHead=(this.damageHead+1)%1024;
  if(this.damageCount<1024)this.damageCount++;else this.damageOverflow=true;
  event.t=this.clock;event.victim=victim;event.attacker=attacker;event.amount=amount;event.healthLoss=healthLoss;event.region=contact.region;event.weapon=contact.weapon;event.penetrated=contact.penetrated;
  if(contact.point){event.point??=[0,0,0];for(let i=0;i<3;i++)event.point[i]=contact.point[i];}else event.point=undefined;
 }
 get frames(){
  const frames:ReplayFrame[]=[];for(let i=0;i<this.count;i++)frames.push(this.slots[(this.head-this.count+i+capacity)%capacity].frame);
  if(frames.length){const states=new Map(this.panelBaseline);for(const state of frames[0].panels)states.set(state.id,state);frames[0]={...frames[0],panels:[...states.values()]};}
  return frames;
 }
 get storage(){return {capacity,frames:this.count,actorSlots:this.slots.reduce((n,s)=>n+s.actors.length,0),deviceSlots:this.slots.reduce((n,s)=>n+s.devices.length,0),damageSlots:1024};}
 prepare(root:Game){const size=1+root.humans.filter(h=>h.actor!==root).length+root.bots.length;for(const slot of this.slots)while(slot.actors.length<size)slot.actors.push(actor());}
 roster(root:Game){const result:RecordedActor[]=[];const own=actor();this.human(own,root,root.humans.find(h=>h.actor===root)?.name??root.playerName);result.push(own);for(const h of root.humans)if(h.actor!==root){const pose=actor();this.human(pose,h.actor,h.name);result.push(pose);}for(const b of root.bots){const pose=actor();this.bot(pose,b,root,undefined);result.push(pose);}return result;}
 reset(){this.head=0;this.count=0;this.clock=0;this.accumulator=0;this.pending.length=0;this.damageHead=0;this.damageCount=0;this.damageOverflow=false;this.lastKill=null;this.panelBaseline.clear();this.panelStates.clear();for(const slot of this.slots){slot.frame.actors.length=0;slot.frame.panels.length=0;slot.frame.devices.length=0;slot.frame.sounds.length=0;}}
 sound(e:SoundEvent){this.pending.push({...e,pos:[...e.pos]});}
 kill(killer:string,victim:string){this.lastKill={killer,victim,t:this.clock};}
 private vault(target:RecordedActor,source:VaultPlan|null){
  if(!source){target.vault=null;return;}
  let stored=this.vaults.get(target);if(!stored){stored={...source,points:Array.from({length:4},()=>[0,0,0])};this.vaults.set(target,stored);}
  stored.points.length=source.points.length;for(let i=0;i<source.points.length;i++){stored.points[i]??=[0,0,0];for(let j=0;j<3;j++)stored.points[i][j]=source.points[i][j];}
  stored.duration=source.duration;stored.height=source.height;stored.kind=source.kind;stored.landing=source.landing;stored.surface=source.surface;stored.startPose=source.startPose;
  if(source.action!==undefined)stored.action=source.action;else delete stored.action;
  if(source.arc!==undefined)stored.arc=source.arc;else delete stored.arc;
  if(source.route!==undefined)stored.route=source.route;else delete stored.route;
  if(source.dropLanding){stored.dropLanding??=[0,0,0];for(let i=0;i<3;i++)stored.dropLanding[i]=source.dropLanding[i];}else delete stored.dropLanding;
  target.vault=stored;
 }
 private human(target:RecordedActor,a:Game,name:string){
  target.id=a.actorId;target.name=name;target.team=a.team;target.op=a.operator;target.weapon=a.weapon;target.slot=a.slot;target.optic=a.optic;target.skin=a.weaponSkins[a.slot?5:a.weapon]??'Factory';target.attachment=a.attachmentSkins[a.slot?5:a.weapon]??'Factory';
  vector(target.p,a.pos);target.yaw=a.yaw;target.pitch=a.pitch;target.hp=a.hp;target.stance=a.stance;target.amount=a.stanceAmount;target.lean=a.lean;target.ads=a.adsProgress;
  target.recoil[0]=a.recoilPitch;target.recoil[1]=a.recoilYaw;target.recoil[2]=a.shake;target.shot=a.shotSerial;target.gait=a.gaitCycle;vector(target.velocity,a.actualVelocity);target.state=a.state;target.height=a.cameraHeight;target.forward=a.cameraForward;
  target.reload=a.reload;target.inspect=a.inspect;target.action=a.action;target.actionKind=a.actionKind;target.actionTotal=a.actionTotal;target.gadget=a.gadgetTime;this.vault(target,a.vaultPlan);target.vaultProgress=a.vaultProgress;
  for(let i=0;i<2;i++){target.ammo[i]=a.ammo[i];target.reserve[i]=a.reserve[i];}target.inverted=a.rappel&&a.rappelInverted;
  const e=target.equipment!;e.launcher=a.launcherEquipped;e.draw=a.launcherDraw;e.launcherReload=a.launcherReload;e.launcherShot=a.launcherShot;e.hammer=a.hammerSwing;e.hammerHit=a.hammerHit;e.hasHammerTarget=!!a.hammerTarget;if(a.hammerTarget)vector(e.hammerTarget,a.hammerTarget);e.smoke=a.smokeThrow;e.released=a.smokeReleased;e.jammerYaw=a.jammerYaw;vector(e.actionPosition,a.actionPosition);e.reloadTotal=a.reloadTotal;e.reloadEmpty=a.reloadEmpty;e.rappel=a.rappel;
 }
 private bot(target:RecordedActor,b:Bot,root:Game,previous:ReplayFrame|undefined){
  const pose=botCharacterState(b,root.phase),old=previous?.actors.find(a=>a.id==='bot:'+b.id),elapsed=previous?this.clock-previous.t:0;
  target.id='bot:'+b.id;target.name=b.name;target.team=b.team;target.op=b.operator??(b.team?4:0);target.weapon=pose.weapon;target.slot=0;target.optic='iron';target.skin=target.attachment='Factory';vector(target.p,b.pos);
  target.yaw=pose.yaw;target.pitch=pose.pitch;target.hp=b.hp;target.stance=pose.stance;target.amount=pose.stanceAmount;target.lean=0;target.ads=pose.adsProgress;target.recoil.fill(0);target.shot=pose.shotSerial;
  target.gait=(old?.gait??0)+(old?Math.hypot(b.pos.x-old.p[0],b.pos.z-old.p[2])/stride(pose.state,pose.stance)*Math.PI:0);
  for(let i=0;i<3;i++)target.velocity[i]=old&&elapsed>0?(target.p[i]-old.p[i])/elapsed:0;
  target.state=pose.state;target.height=botPosture(b).eye;target.forward=0;target.reload=0;target.inspect=0;target.action=pose.action;target.actionKind=pose.actionKind;target.actionTotal=pose.actionTotal;target.gadget=0;this.vault(target,pose.vaultPlan);target.vaultProgress=pose.vaultProgress;
  target.ammo[0]=30;target.ammo[1]=12;target.reserve[0]=150;target.reserve[1]=60;target.inverted=false;
  const e=target.equipment!;e.launcher=!!b.launcherEquipped;e.draw=b.launcherDraw??0;e.launcherReload=b.launcherReload??0;e.launcherShot=b.launcherShot??0;e.hammer=b.hammerSwing??0;e.hammerHit=!!b.hammerHit;e.hasHammerTarget=!!b.hammerTarget;if(b.hammerTarget)vector(e.hammerTarget,b.hammerTarget);e.smoke=b.smokeThrow??0;e.released=!!b.smokeReleased;e.jammerYaw=pose.jammerYaw;vector(e.actionPosition,pose.actionPosition??b.pos);e.reloadTotal=0;e.reloadEmpty=false;e.rappel=false;
 }
 record(root:Game,dt:number,force=false){
  this.clock+=dt;this.accumulator+=dt;if(!force&&this.accumulator<.05)return;this.accumulator=0;
  const previous=this.count?this.slots[(this.head-1+capacity)%capacity].frame:undefined,slot=this.slots[this.head],frame=slot.frame;
  if(this.count===capacity)for(const state of frame.panels)this.panelBaseline.set(state.id,state);else this.count++;
  this.head=(this.head+1)%capacity;frame.t=this.clock;frame.actors.length=0;frame.panels.length=0;frame.devices.length=0;frame.sounds.length=0;
  const nextActor=()=>{const i=frame.actors.length,target=slot.actors[i]??(slot.actors[i]=actor());frame.actors.push(target);return target;};
  this.human(nextActor(),root,root.humans.find(h=>h.actor===root)?.name??root.playerName);
  for(const h of root.humans)if(h.actor!==root)this.human(nextActor(),h.actor,h.name);
  for(const b of root.bots)this.bot(nextActor(),b,root,previous);
  for(let id=0;id<root.world.panels.length;id++){
   const panel=root.world.panels[id];if(panel.kind==='solid'&&panel.mesh.userData.securityId===undefined)continue;
   const old=this.panelStates.get(id),holes=panel.holes??[];
   const same=old&&old.hp===panel.hp&&old.broken===panel.broken&&old.reinforced===panel.reinforced&&old.grid?.revision===panel.grid?.revision&&old.holes.length===holes.length&&holes.every((h,i)=>{const p=old.holes[i];return p[0]===h.point.x&&p[1]===h.point.y&&p[2]===h.point.z&&p[3]===h.radius;});
   if(same)continue;
   const state={id,hp:panel.hp,broken:panel.broken,reinforced:panel.reinforced,holes:holes.map(h=>[h.point.x,h.point.y,h.point.z,h.radius]),grid:panel.grid?.snapshot()};this.panelStates.set(id,state);frame.panels.push(state);
  }
  const devices=(a:Game)=>{for(let i=0;i<a.devices.length;i++){const d=a.devices[i],index=frame.devices.length,target=slot.devices[index]??(slot.devices[index]={id:'',type:'',p:[0,0,0],q:[0,0,0,1],active:false,visible:false});target.id=d.mesh.userData.id??a.actorId+':'+i;target.type=d.type;vector(target.p,d.pos);target.q[0]=d.mesh.quaternion.x;target.q[1]=d.mesh.quaternion.y;target.q[2]=d.mesh.quaternion.z;target.q[3]=d.mesh.quaternion.w;target.active=d.active;target.visible=d.mesh.visible;frame.devices.push(target);}};
  devices(root);for(const h of root.humans)if(h.actor!==root)devices(h.actor);
  for(const event of this.pending)frame.sounds.push(event);this.pending.length=0;
 }
 clip(root:Game,winner:number,reason:string):ReplayClip|null{
  const kill=this.lastKill;if(!kill||this.clock-kill.t>.25||!this.count)return null;
  this.record(root,0,true);const all=this.frames,end=this.clock,start=end-3.5,first=all.findIndex(f=>f.t>=start),before=Math.max(0,first-1),states=new Map<number,RecordedPanel>();
  for(let i=0;i<=before;i++)for(const state of all[i].panels)states.set(state.id,state);
  const frames=structuredClone(all.slice(before));frames[0].panels=structuredClone([...states.values()]);const padded=Math.max(0,frames[0].t-start);
  for(const frame of frames)frame.t=Math.max(0,frame.t-start);
  if(frames[0].t>0)frames.unshift({...structuredClone(frames[0]),t:0,sounds:[]});else frames[0].t=0;
  if(!frames.some(f=>f.actors.some(a=>a.id===kill.killer)))return null;
  const damage=lethalEncounter(this.damageEvents,kill.victim,kill.t).map(e=>({...e,point:e.point?[...e.point]:undefined,t:e.t-start}));
  return {id:crypto.randomUUID(),duration:3.5,killer:kill.killer,victim:kill.victim,reason,winner,padded,frames,damage,damageComplete:!this.damageOverflow};
 }
}

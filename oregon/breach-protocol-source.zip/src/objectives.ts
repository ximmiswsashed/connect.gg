import * as THREE from 'three';
import type {Game} from './game';
import {rooms} from './oregon';
import {sites} from './data';
export const objectiveConfig={plantSeconds:7,disableSeconds:7,fuseSeconds:45,pickupDistance:1.6,disableDistance:1.5,plantMargin:.35};
export type ObjectiveSnapshot={carrier:string|null,dropped:number[]|null,planted:boolean,position:number[],remaining:number,clock:number,resolved:boolean};
export class BombObjective{
 carrier:string|null=null;dropped:THREE.Vector3|null=null;planted=false;position=new THREE.Vector3();remaining=objectiveConfig.fuseSeconds;clock=0;resolved=false;
 requests:{actor:Game,kind:string,at:number,pos:THREE.Vector3}[]=[];
 reset(actors:Game[]){this.carrier=actors.filter(a=>a.team===0&&a.hp>0).sort((a,b)=>Number(a.actorId.startsWith('bot:'))-Number(b.actorId.startsWith('bot:'))||a.actorId.localeCompare(b.actorId))[0]?.actorId??null;this.dropped=null;this.planted=false;this.position.set(0,0,0);this.remaining=objectiveConfig.fuseSeconds;this.clock=0;this.resolved=false;this.requests=[];}
 zone(g:Game){const ids=sites[g.site].bombs.flatMap(b=>[b.room,...('zoneRooms' in b?b.zoneRooms as string[]:[])]);const p=g.pos;return rooms.filter(r=>ids.includes(r.id)).some(r=>{return Math.abs(p.y-(r.y??r.f*4))<.12&&p.x>r.x0+objectiveConfig.plantMargin&&p.x<r.x1-objectiveConfig.plantMargin&&p.z>r.z0+objectiveConfig.plantMargin&&p.z<r.z1-objectiveConfig.plantMargin;})&&!g.world.collide(p.x,p.y,p.z,.3,.35)&&Math.abs(g.world.ground(p.x,p.z,p.y)-p.y)<.04&&!g.rappel&&!g.vaultFrom;}
 canPlant(g:Game){return g.phase==='action'&&g.team===0&&g.hp>0&&!g.observing&&!this.planted&&!this.resolved&&this.carrier===g.actorId&&this.zone(g);}
 canDisable(g:Game){return g.phase==='action'&&g.team===1&&g.hp>0&&!g.observing&&this.planted&&!this.resolved&&g.pos.distanceTo(this.position)<objectiveConfig.disableDistance&&g.world.sight(g.eye(),this.position.clone().add(new THREE.Vector3(0,.2,0)));}
 drop(g:Game){if(!this.planted&&this.carrier===g.actorId){this.dropped=g.pos.clone();this.carrier=null;g.tell('DEFUSER DROPPED');}}
 pickup(g:Game){if((g.phase==='prep'||g.phase==='action')&&g.team===0&&g.hp>0&&!g.downed&&!g.observing&&!this.planted&&!this.carrier&&this.dropped&&g.pos.distanceTo(this.dropped)<objectiveConfig.pickupDistance&&g.world.sight(g.eye(),this.dropped.clone().add(new THREE.Vector3(0,.2,0)))){this.carrier=g.actorId;this.dropped=null;g.tell('DEFUSER RECOVERED');return true;}return false;}
 complete(g:Game,kind:string,withinFrame:number){this.requests.push({actor:g,kind,at:this.clock+withinFrame,pos:g.pos.clone()});}
 step(dt:number,root:Game,actors:Game[]){const currentCarrier=actors.find(a=>a.actorId===this.carrier);if(currentCarrier&&currentCarrier.hp<=0)this.drop(currentCarrier);if(this.resolved||root.phase!=='action')return;const end=this.clock+dt;const expiry=this.planted?this.clock+this.remaining:Infinity;const carrier=actors.find(a=>a.actorId===this.carrier);if(this.carrier&&(!carrier||carrier.hp<=0)){if(carrier)this.drop(carrier);else this.carrier=null;}
  // Deterministic ties: fuse completion wins at its deadline. Valid completions before it win.
  for(const q of this.requests.sort((a,b)=>a.at-b.at||a.actor.actorId.localeCompare(b.actor.actorId))){if(q.at>=expiry-1e-7)continue;if(q.kind==='plant'&&this.canPlant(q.actor)){this.planted=true;this.position.copy(q.pos);this.carrier=null;this.dropped=null;this.remaining=objectiveConfig.fuseSeconds-Math.max(0,end-q.at);root.tell('DEFUSER ACTIVE');}else if(q.kind==='disable'&&this.canDisable(q.actor)){this.resolved=true;root.end(1,'DEFUSER DISABLED');break;}}
  this.requests=[];if(!this.resolved){if(expiry!==Infinity){this.remaining=Math.max(0,expiry-end);if(this.remaining<=0){this.resolved=true;root.end(0,'DEFUSER SUCCESSFUL');}}else if(!this.planted&&root.timer<=0&&!actors.some(a=>a.action>0&&a.actionKind==='plant'&&this.canPlant(a))&&root.competitive){this.resolved=true;root.end(1,'TIME EXPIRED');}}
  this.clock=end;root.planted=this.planted;root.plantTimer=this.remaining;root.defuserPos.copy(this.position);
 }
 snapshot():ObjectiveSnapshot{return {carrier:this.carrier,dropped:this.dropped?.toArray()??null,planted:this.planted,position:this.position.toArray(),remaining:this.remaining,clock:this.clock,resolved:this.resolved};}
 apply(s:ObjectiveSnapshot){this.carrier=s.carrier;this.dropped=s.dropped?new THREE.Vector3().fromArray(s.dropped):null;this.planted=s.planted;this.position.fromArray(s.position);this.remaining=s.remaining;this.clock=s.clock;this.resolved=s.resolved;}
}
export class DefuserView{
 root=new THREE.Group();screen:THREE.Mesh;
 constructor(scene:THREE.Scene){const metal=new THREE.MeshLambertMaterial({color:0x414f43}),dark=new THREE.MeshLambertMaterial({color:0x17211e}),yellow=new THREE.MeshBasicMaterial({color:0xc4b84f});const box=(x:number,y:number,z:number,w:number,h:number,d:number,m:THREE.Material=metal)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);this.root.add(o);return o;};box(0,.12,0,.48,.2,.34);box(0,.23,0,.5,.045,.36,dark);this.screen=box(-.08,.258,-.025,.19,.01,.14,yellow);for(const x of [-.21,.21])for(const z of [-.14,.14])box(x,.15,z,.035,.18,.035,dark);box(.13,.26,.01,.08,.015,.19,dark);box(0,.12,.2,.17,.05,.05,dark);scene.add(this.root);this.root.visible=false;}
 update(o:BombObjective){this.root.visible=!!o.dropped||o.planted;if(this.root.visible)this.root.position.copy(o.planted?o.position:o.dropped!);this.screen.visible=o.planted;}
}

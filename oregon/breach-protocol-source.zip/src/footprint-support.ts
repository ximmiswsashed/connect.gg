import type {World} from './world';

// Cardinal probes can miss a small ridge underneath the round player footprint.
// Query its diagonals only when the normal movement candidate is obstructed.
export function diagonalFootprintSupport(world:World,x:number,z:number,y:number,radius:number){
 const offset=radius/Math.SQRT2;
 return Math.max(world.imported?.footprintGround(x,z,y,radius,.36)??-25,...[[-1,-1],[-1,1],[1,-1],[1,1]].map(([dx,dz])=>world.ground(x+dx*offset,z+dz*offset,y)));
}

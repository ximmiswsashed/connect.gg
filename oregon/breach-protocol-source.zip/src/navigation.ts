import * as THREE from 'three';
import type {World} from './world';
// Keep authored portals/stair links; detour flat segments around real cover and floor holes.
export function refineRoute(w:World,path:THREE.Vector3[]){
 const result:THREE.Vector3[]=[];
 const clear=(p:THREE.Vector3)=>{const ground=Math.max(w.ground(p.x,p.z,p.y),w.ground(p.x+.3,p.z,p.y),w.ground(p.x-.3,p.z,p.y),w.ground(p.x,p.z+.3,p.y),w.ground(p.x,p.z-.3,p.y)),y=ground+.015;return Math.abs(ground-p.y)<.05&&!w.nearPanels(p.x,p.z,.29).some(s=>!s.broken&&s.kind!=='barricade'&&!(s.mesh.userData.step&&s.max.y<=y+.36)&&p.x+.29>s.min.x&&p.x-.29<s.max.x&&p.z+.29>s.min.z&&p.z-.29<s.max.z&&y+1.7>s.min.y+.05&&y<s.max.y-.05);};
 const straight=(a:THREE.Vector3,b:THREE.Vector3)=>{const steps=Math.ceil(a.distanceTo(b)/.25);for(let i=0;i<=steps;i++)if(!clear(a.clone().lerp(b,i/Math.max(1,steps))))return false;return true;};
 for(let i=0;i<path.length;i++){const goal=path[i];if(!result.length||Math.abs(result.at(-1)!.y-goal.y)>.4){result.push(goal);continue;}const start=result.at(-1)!;if(straight(start,goal)){result.push(goal);continue;}
  const cell=.3,y=goal.y,x0=Math.min(start.x,goal.x)-7,z0=Math.min(start.z,goal.z)-7,nx=Math.ceil((Math.abs(start.x-goal.x)+14)/cell)+1,nz=Math.ceil((Math.abs(start.z-goal.z)+14)/cell)+1;
  const pos=(id:number)=>new THREE.Vector3(x0+(id%nx)*cell,y,z0+Math.floor(id/nx)*cell),cache=new Map<number,boolean>();const valid=(id:number)=>{if(id<0||id>=nx*nz)return false;if(!cache.has(id))cache.set(id,clear(pos(id)));return cache.get(id)!;};
  const nearest=(p:THREE.Vector3)=>{let id=-1,best=Infinity;const ix=Math.round((p.x-x0)/cell),iz=Math.round((p.z-z0)/cell);for(let dz=-4;dz<=4;dz++)for(let dx=-4;dx<=4;dx++){const x=ix+dx,z=iz+dz,n=z*nx+x;if(x<0||x>=nx||z<0||z>=nz||!valid(n))continue;const d=pos(n).distanceToSquared(p);if(d<best){best=d;id=n;}}return id;};
  const a=nearest(start),b=nearest(goal),open=new Set<number>(a<0?[]:[a]),cost=new Map([[a,0]]),previous=new Map<number,number>(),closed=new Set<number>();let found=false;
  for(let tries=0;open.size&&tries<4000;tries++){let current=-1,best=Infinity;for(const n of open){const f=cost.get(n)!+pos(n).distanceTo(pos(b));if(f<best){best=f;current=n;}}open.delete(current);if(current===b){found=true;break;}closed.add(current);const x=current%nx,z=Math.floor(current/nx);for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){const xx=x+dx,zz=z+dz,n=zz*nx+xx;if(xx<0||xx>=nx||zz<0||zz>=nz||closed.has(n)||!valid(n)||dx&&dz&&(!valid(z*nx+xx)||!valid(zz*nx+x)))continue;const next=cost.get(current)!+Math.hypot(dx,dz)*cell;if(next<(cost.get(n)??Infinity)){cost.set(n,next);previous.set(n,current);open.add(n);}}}
  if(!found){result.push(goal);continue;}const ids=[b];while(ids[0]!==a)ids.unshift(previous.get(ids[0])!);const points=ids.map(pos);let anchor=0;while(anchor<points.length-1){let next=anchor+1;while(next+1<points.length&&straight(points[anchor],points[next+1]))next++;result.push(points[next]);anchor=next;}if(clear(goal)&&straight(result.at(-1)!,goal))result.push(goal);
 }
 return result;
}

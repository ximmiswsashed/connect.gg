import * as THREE from 'three';
let material:THREE.MeshLambertMaterial|undefined;
export function barricadeMaterial(){
 if(material)return material;const cv=document.createElement('canvas');cv.width=cv.height=256;const c=cv.getContext('2d')!;
 c.fillStyle='#31513b';c.fillRect(0,0,256,256);
 for(let i=0;i<8;i++){c.fillStyle=i%2?'#456449':'#38563e';c.fillRect(0,i*32,256,31);c.fillStyle='#182c21';c.fillRect(0,i*32+30,256,2);}
 c.strokeStyle='#f6cf33';c.lineWidth=21;c.lineCap='square';c.beginPath();c.moveTo(34,25);c.lineTo(222,231);c.moveTo(222,25);c.lineTo(34,231);c.stroke();
 for(let i=0;i<8;i++)for(const x of [12,244]){c.fillStyle='#879077';c.fillRect(x,i*32+14,3,3);}
 const map=new THREE.CanvasTexture(cv);map.colorSpace=THREE.SRGBColorSpace;map.userData.shared=true;
 material=new THREE.MeshLambertMaterial({color:0xffffff,map,vertexColors:true});material.userData.shared=true;return material;
}

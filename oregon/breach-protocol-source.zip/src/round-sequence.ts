export const roundTiming={banner:3,replay:3.5,hold:2} as const;
export type RoundResult={id:string,round:number,winner:number,reason:string,score:number[],replayId:string|null};
export type ResultStage='idle'|'banner'|'replay'|'hold'|'done';

/** Each recipient anchors the sequence to its first visible result, never packet arrival order. */
export class RoundSequence{
 result:RoundResult|null=null;shownAt:number|null=null;stage:ResultStage='idle';elapsed=0;replayElapsed=0;
 reset(){this.result=null;this.shownAt=null;this.stage='idle';this.elapsed=0;this.replayElapsed=0;}
 accept(result:RoundResult){if(this.result?.id===result.id)return false;this.result={...result,score:[...result.score]};this.shownAt=null;this.stage='banner';this.elapsed=0;this.replayElapsed=0;return true;}
 shown(now:number){if(this.result&&this.shownAt===null)this.shownAt=now;}
 advance(now:number){
  if(!this.result||this.shownAt===null)return this.stage;
  this.elapsed=Math.max(this.elapsed,(now-this.shownAt)/1000);
  const replayEnd=roundTiming.banner+(this.result.replayId?roundTiming.replay:0);
  this.replayElapsed=Math.min(roundTiming.replay,Math.max(0,this.elapsed-roundTiming.banner));
  this.stage=this.elapsed<roundTiming.banner?'banner':this.elapsed<replayEnd?'replay':this.elapsed<replayEnd+roundTiming.hold?'hold':'done';
  return this.stage;
 }
 get pending(){return this.stage!=='idle'&&this.stage!=='done';}
}

import * as THREE from 'three';
import type {Game} from './game';

/** A single draw call and fixed storage, independent of how many rounds are played. */
export class TracerPool{
 private points=new Float32Array(32*6);private colors=new Float32Array(32*6);private life=new Float32Array(32);
 private serials=new Map<string,number>();private next=0;
 readonly mesh:THREE.LineSegments;
 constructor(scene:THREE.Scene){const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(this.points,3).setUsage(THREE.DynamicDrawUsage));geometry.setAttribute('color',new THREE.BufferAttribute(this.colors,3).setUsage(THREE.DynamicDrawUsage));this.mesh=new THREE.LineSegments(geometry,new THREE.LineBasicMaterial({vertexColors:true,transparent:true,opacity:.34,depthWrite:false}));this.mesh.frustumCulled=false;scene.add(this.mesh);}
 update(game:Game,dt:number){
  let dirty=false;for(let i=0;i<32;i++)if(this.life[i]>0){this.life[i]=Math.max(0,this.life[i]-dt);const intensity=this.life[i]/.055;for(let j=0;j<6;j++)this.colors[i*6+j]=intensity*(j%3===2?.66:.9);if(!intensity)this.points.fill(0,i*6,i*6+6);dirty=true;}
  const live=new Set<string>();const shot=(id:string,serial:number,start:THREE.Vector3,direction:THREE.Vector3)=>{live.add(id);const old=this.serials.get(id);this.serials.set(id,serial);if(old===undefined||old===serial||serial<old)return;const end=game.world.trace(start,direction,70,true)[0]?.point??start.clone().addScaledVector(direction,70),length=Math.min(9,start.distanceTo(end));if(length<.3)return;const i=this.next++%32;const tip=end.clone(),tail=tip.clone().addScaledVector(direction,-length);this.points.set([...tail.toArray(),...tip.toArray()],i*6);this.colors.set([.9,.9,.66,.9,.9,.66],i*6);this.life[i]=.055;dirty=true;};
  shot(game.actorId,game.shotSerial,game.muzzle,game.lastPellets[0]??game.face());for(const h of game.humans)if(h.actor!==game)shot(h.id,h.actor.shotSerial,h.actor.muzzle,h.actor.face());for(const b of game.bots)if(b.hp>0){const yaw=b.mesh.rotation.y,pitch=Number(b.mesh.userData.pitch??0);shot('bot:'+b.id,Number(b.mesh.userData.shotSerial??0),b.pos.clone().add(new THREE.Vector3(0,1.4,0)),new THREE.Vector3(-Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),-Math.cos(yaw)*Math.cos(pitch)));}for(const key of this.serials.keys())if(!live.has(key))this.serials.delete(key);
  this.mesh.visible=['prep','action'].includes(game.phase)&&!game.observing;if(dirty){this.mesh.geometry.getAttribute('position').needsUpdate=true;this.mesh.geometry.getAttribute('color').needsUpdate=true;}
 }
 dispose(){this.mesh.removeFromParent();this.mesh.geometry.dispose();(this.mesh.material as THREE.Material).dispose();}
}

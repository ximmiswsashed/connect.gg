import * as THREE from 'three';
const markerMaterial=new THREE.MeshBasicMaterial({color:0x4bdd62,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});markerMaterial.userData.shared=true;
// Clip markings to the supplied rear-sight faces, offset only 0.15 mm to avoid z fighting.
export function sourceIronMarkers(root:THREE.Group){
 root.updateWorldMatrix(true,true);const inverse=root.matrixWorld.clone().invert(),vertices:number[]=[];
 const clip=(points:THREE.Vector3[],axis:'x'|'y',edge:number,sign:number)=>{const out:THREE.Vector3[]=[];for(let i=0;i<points.length;i++){const a=points[i],b=points[(i+1)%points.length],da=sign*(a[axis]-edge),db=sign*(b[axis]-edge);if(da>=0)out.push(a);if((da>=0)!==(db>=0))out.push(a.clone().lerp(b,da/(da-db)));}return out;};
 root.traverse(o=>{if(!(o instanceof THREE.Mesh))return;const a=o.geometry.getAttribute('position'),index=o.geometry.index,matrix=inverse.clone().multiply(o.matrixWorld);for(let i=0;i<(index?.count??a.count);i+=3){const p=[0,1,2].map(j=>new THREE.Vector3().fromBufferAttribute(a,index?index.getX(i+j):i+j).applyMatrix4(matrix));if(p.some(q=>q.z<-.04))continue;const normal=p[1].clone().sub(p[0]).cross(p[2].clone().sub(p[0])).normalize();if(normal.z<.5)continue;for(const sign of [-1,1]){let patch=p.map(q=>q.clone());for(const [axis,edge,side]of [['x',sign<0?-.006:.003,1],['x',sign<0?-.003:.006,-1],['y',.0921,1],['y',.0931,-1]]as const)patch=clip(patch,axis,edge,side);for(let k=1;k<patch.length-1;k++)for(const q of [patch[0],patch[k],patch[k+1]])vertices.push(q.x,q.y,q.z+.00015);}}});
 // Exported duplicate face layers can face the same way. Project onto the visible layer.
 const direction=new THREE.Vector3(0,0,-1).transformDirection(root.matrixWorld),ray=new THREE.Raycaster();
 for(let i=0;i<vertices.length;i+=3){ray.set(root.localToWorld(new THREE.Vector3(vertices[i],vertices[i+1],.1)),direction);const hits=ray.intersectObject(root,true).map(h=>h.point.clone().applyMatrix4(inverse)).filter(q=>q.z>-.04);if(hits.length)vertices[i+2]=Math.max(...hits.map(q=>q.z))+.00015;}
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geometry.computeVertexNormals();const mesh=new THREE.Mesh(geometry,markerMaterial);mesh.name='source-iron-green-markings';mesh.userData.surfaceOffset=.00015;root.add(mesh);return mesh;
}

/** Retain fractional callback time so 144/240 Hz displays do not lose every other frame. */
export class FramePacer {
 private next=0;private limit=-1;
 private callback=0;private samples:number[]=[];refreshRate=60;
 ready(now:number,limit:number){
  const delta=now-this.callback;this.callback=now;
  if(delta>=2&&delta<100){this.samples.push(delta);if(this.samples.length===30){
   this.samples.sort((a,b)=>a-b);
   // Retain the fastest sustained display cadence observed, rather than treating
   // a slow rendered frame as proof that the monitor itself has slowed down.
   this.refreshRate=Math.max(this.refreshRate,Math.round(1000/this.samples[7]));this.samples=[];
  }}
  if(limit!==this.limit){this.limit=limit;this.next=now;}
  if(!limit)return true;
  const interval=1000/limit;
  if(now+.05<this.next)return false;
  // Skip missed deadlines after a stall; never run a catch-up render burst.
  this.next+=Math.max(1,Math.floor((now-this.next+.05)/interval)+1)*interval;
  return true;
 }
}

import type {Game} from './game';
const swings=new WeakMap<Game,number>();
import {hammerContact} from './hammer-contact';

// Share physical nearest-contact resolution; ordinary melee never uses breaching logic.
export function strikeMelee(game:Game){
 if(game.cool>0||!game.authority||game.hp<=0||game.downed||game.observing||!['prep','action'].includes(game.phase)||game.phase==='prep'&&game.team===0)return false;
 const origin=game.eye(),hit=hammerContact(game,origin,game.face(),2.4);
 if(!hit)return false;
 if(hit.panel?.kind==='barricade'){
  if(hit.panel.reinforced)return false;
  const serial=(swings.get(game)??0)+1;swings.set(game,serial);game.world.barricadeHit(hit.panel,'melee',[{point:hit.point,distance:origin.distanceTo(hit.point)}],game.actorId+':melee:'+serial);game.emitSound('barricade',hit.point,.4);return true;
 }
 if(origin.distanceTo(hit.point)>1.8)return false;
 if(hit.device){hit.device.mesh.visible=false;hit.device.active=false;hit.device.type='destroyed';hit.device.flightVelocity=undefined;}
 else if(hit.drone)hit.drone.destroy();
 else if(hit.scout)hit.scout.mesh.visible=false;
 else if(hit.panel?.mesh.userData.securityId!==undefined){hit.panel.broken=true;hit.panel.hp=0;hit.panel.mesh.visible=false;}
 else if(hit.human){if(game.phase!=='action'||!hit.human.actor.takeDamage(100,game.actorId,game.team))return false;}
 else if(hit.bot){const hp=hit.bot.hp;game.damageBot(hit.bot,100,game.actorId,game.team);if(hit.bot.hp===hp)return false;}
 else return false;
 game.emitSound('impact-metal',hit.point,.25);return true;
}

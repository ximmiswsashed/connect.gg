// No rounds are removed during the timer. Cancellation redistributes the existing total.
export function cancelReloadAmmo(magazine:number,reserve:number){
 const total=Math.max(0,Math.floor(magazine))+Math.max(0,Math.floor(reserve));
 return {magazine:Math.min(1,total),reserve:Math.max(0,total-1)};
}
export function completeReloadAmmo(magazine:number,reserve:number,capacity:number){
 const total=Math.max(0,Math.floor(magazine))+Math.max(0,Math.floor(reserve));
 const loaded=Math.min(capacity,total);return {magazine:loaded,reserve:total-loaded};
}

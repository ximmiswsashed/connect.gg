import * as THREE from 'three';
import type {World} from './world';
import {rooms,doors,stairs} from './map-plan';
export type SoundKind='round-win'|'round-loss'|'impact-wood'|'impact-metal'|'impact-stone'|'shot'|'shotgun'|'pistol'|'footstep'|'reload'|'drone'|'barricade'|'breach'|'gadget'|'gas-release'|'launcher'|'hammer'|'device-place'|'charge-ignite'|'erc-on'|'erc-off'|'plant'|'defuser'|'interface'|'stance-crouch'|'stance-prone'|'stance-stand'|'stance-rise'|'stance-vault'|'stance-land';
export type SoundEvent={id:string,actor:string,kind:SoundKind,pos:number[],gain:number};
// Original PCM sound designs generated locally; no game recordings or third-party samples.
export class AudioSystem{
 ctx:AudioContext|null=null;enabled=true;volume=.4;effectsVolume=1;ambienceVolume=.18;interfaceVolume=.6;
 position=new THREE.Vector3();forward=new THREE.Vector3(0,0,-1);up=new THREE.Vector3(0,1,0);world:World|null=null;
 private stanceVoices=new Map<string,{source:AudioBufferSourceNode,gain:GainNode}>();private buses:Record<string,GainNode>={};private mixed:Record<string,number>={};private buffers=new Map<string,AudioBuffer>();private voices=new Set<AudioBufferSourceNode>();private heard=new Set<string>();
 diagnostics:{kind:SoundKind,position:number[],occlusion:number,cutoff:number,distance:number,path:string}[]=[];
 init(){if(!this.ctx){this.ctx=new AudioContext();for(const name of ['effects','ambience','interface']){this.buses[name]=this.ctx.createGain();this.buses[name].connect(this.ctx.destination);}const ambient=this.ctx.createBufferSource();ambient.buffer=this.buffer('ambience');ambient.loop=true;ambient.connect(this.buses.ambience);ambient.start();}this.buffer('round-win');this.buffer('round-loss');this.mix();void this.ctx.resume();}
 mix(){if(!this.ctx)return;const t=this.ctx.currentTime;for(const [name,value] of Object.entries({effects:this.effectsVolume,ambience:this.ambienceVolume,interface:this.interfaceVolume})){const target=this.enabled?this.volume*value:0;if(this.mixed[name]===target)continue;this.mixed[name]=target;this.buses[name].gain.cancelScheduledValues(t);this.buses[name].gain.setTargetAtTime(target,t,.015);}}
 listener(camera:THREE.Camera,world:World){this.world=world;camera.updateWorldMatrix(true,false);this.position.copy(camera.position);camera.getWorldDirection(this.forward);this.up.set(0,1,0).applyQuaternion(camera.quaternion);if(!this.ctx)return;this.mix();const l=this.ctx.listener,t=this.ctx.currentTime;for(const [param,v] of [[l.positionX,this.position.x],[l.positionY,this.position.y],[l.positionZ,this.position.z],[l.forwardX,this.forward.x],[l.forwardY,this.forward.y],[l.forwardZ,this.forward.z],[l.upX,this.up.x],[l.upY,this.up.y],[l.upZ,this.up.z]] as [AudioParam,number][])param.setValueAtTime(v,t);}
 surface(pos:THREE.Vector3){const r=rooms.find(r=>(r.y===undefined?Math.floor((pos.y+.12)/4)===r.f:Math.abs(pos.y-r.y)<.5)&&pos.x>=r.x0&&pos.x<=r.x1&&pos.z>=r.z0&&pos.z<=r.z1);return r?.mat==='wood'||r?.mat==='laminate'?'wood':r?.mat==='metal'?'metal':r?'concrete':'earth';}
 acoustic(source:THREE.Vector3){const w=this.world,origin=this.position,distance=source.distanceTo(origin);if(!w||distance<.2)return {occlusion:0,cutoff:18000,distance,path:'direct',gain:1};
  const blockers=(a:THREE.Vector3,b:THREE.Vector3)=>{const dir=b.clone().sub(a),length=dir.length();if(length<.02)return 0;const hits=w.trace(a,dir.normalize(),length-.02);return new Set(hits.filter(h=>h.distance>.08).map(h=>h.object.userData.panel)).size;};
  const count=blockers(origin,source);if(!count)return {occlusion:0,cutoff:18000,distance,path:'direct',gain:1};
  // One-door / stair transmission approximates sound bending around an accessible opening.
  const portals=[...w.soundPortals,...doors.map(d=>new THREE.Vector3(d.axis==='x'?d.at:d.c,d.y??d.f*4+1.1,d.axis==='z'?d.at:d.c)),...stairs.flatMap(s=>[new THREE.Vector3((s.x0+s.x1)/2,s.lower*4+.8,(s.z0+s.z1)/2),new THREE.Vector3((s.x0+s.x1)/2,(s.lower+1)*4+.8,(s.z0+s.z1)/2)])].map(p=>({p,d:p.distanceTo(origin)+p.distanceTo(source)})).filter(p=>p.d<distance+8).sort((a,b)=>a.d-b.d).slice(0,6);
  for(const {p,d} of portals)if(blockers(origin,p)===0&&blockers(p,source)===0)return {occlusion:.35,cutoff:6500,distance:d,path:'opening',gain:.68*Math.min(1,distance/d)};
  const floor=(p:THREE.Vector3)=>{if(!w.imported)return Math.floor((p.y+.1)/4);return rooms.filter(r=>p.x>=r.x0&&p.x<=r.x1&&p.z>=r.z0&&p.z<=r.z1).sort((a,b)=>Math.abs((a.y??a.f*4)+1.1-p.y)-Math.abs((b.y??b.f*4)+1.1-p.y))[0]?.f??0;};const floors=Math.abs(floor(source)-floor(origin)),occlusion=Math.min(3,count+floors*.6);return {occlusion,cutoff:Math.max(650,5500/(1+occlusion*2.4)),distance,path:floors?'floor':'wall',gain:Math.max(.08,Math.pow(.38,occlusion))};
 }
 private buffer(kind:string){const cached=this.buffers.get(kind);if(cached)return cached;const c=this.ctx!,duration=kind.startsWith('round-')?.7:kind==='charge-ignite'?.6:kind==='launcher'?.3:kind==='hammer'?.3:kind==='device-place'?.25:kind.startsWith('erc-')?.22:kind==='gas-release'?.7:kind==='stance-prone'?.28:kind==='stance-rise'?.23:kind.startsWith('stance-')?.18:kind==='ambience'?3:kind==='breach'?1:kind==='reload'?.42:kind==='barricade'?.25:kind==='shotgun'?.38:kind==='shot'?.24:kind==='drone'?.18:kind==='defuser'?.18:.14;
  const b=c.createBuffer(1,Math.ceil(c.sampleRate*duration),c.sampleRate),out=b.getChannelData(0);let seed=kind.split('').reduce((a,s)=>a*31+s.charCodeAt(0),7)>>>0,low=0;
  for(let i=0;i<out.length;i++){const t=i/c.sampleRate;seed=(Math.imul(seed,1664525)+1013904223)>>>0;const noise=seed/4294967296*2-1;low=low*.88+noise*.12;let v=0;
   if(kind.startsWith('round-')){const won=kind==='round-win',step=Math.min(2,Math.floor(t/.16)),notes=won?[392,494,587]:[330,294,247],tone=notes[step],envelope=Math.sin(Math.PI*Math.min(1,t/.7))**2;v=(Math.sin(t*tone*2*Math.PI)*.15+Math.sin(t*tone*4*Math.PI)*.025)*envelope;}
   else if(kind==='ambience')v=low*.024;
   else if(['shot','shotgun','pistol','breach'].includes(kind)){const bass=kind==='breach'?45:kind==='shotgun'?72:kind==='pistol'?165:110;v=noise*Math.exp(-t*(kind==='breach'?8:kind==='shotgun'?24:45))*.65+Math.sin(t*2*Math.PI*bass*Math.exp(-t*3))*Math.exp(-t*26)*.45+low*Math.exp(-t*9)*.25;}
   else if(kind==='ambience')v=low*.015*Math.sin(Math.PI*t/3)**2;
   else if(kind.startsWith('impact-')){const metal=kind==='impact-metal',freq=metal?2100:kind==='impact-wood'?180:95;v=(noise*.4*Math.exp(-t*60)+Math.sin(t*freq*2*Math.PI)*Math.exp(-t*(metal?28:55))*.3);}
   else if(kind.startsWith('footstep')){const mat=kind.split(':')[1],freq=mat==='wood'?160:mat==='metal'?550:mat==='earth'?65:95;v=(Math.sin(t*freq*2*Math.PI)*.35+low*.7+noise*(mat==='earth'?.22:.09))*Math.exp(-t*45);}
   else if(kind.startsWith('stance-')){const prone=kind==='stance-prone'||kind==='stance-land',cloth=low*Math.sin(Math.PI*t/duration)**2*.48,contact=prone?Math.sin(t*58*2*Math.PI)*Math.exp(-t*27)*.22:0,gear=(t>.065&&t<.1?noise*.10:0)*Math.exp(-t*10);v=cloth+contact+gear;}
   else if(kind==='launcher')v=(noise*.32+Math.sin(t*85*2*Math.PI)*.6)*Math.exp(-t*21);
   else if(kind==='hammer')v=(low*.65+Math.sin(t*95*2*Math.PI)*.5)*Math.exp(-t*23)+noise*.4*Math.exp(-t*65);
   else if(kind==='device-place')v=noise*.3*Math.exp(-t*42)+Math.sin(t*1300*2*Math.PI)*Math.exp(-t*55)*.18;
   else if(kind==='charge-ignite')v=(noise*.2+low*.6)*Math.exp(-t*4)+Math.sin(t*1650*2*Math.PI)*Math.exp(-t*70)*.15;
   else if(kind.startsWith('erc-')){const frequency=kind==='erc-on'?550+1300*t:850-1500*t;v=Math.sin(t*frequency*2*Math.PI)*Math.sin(Math.PI*t/duration)*.18;}
   else if(kind==='gas-release')v=(noise*.22+low*.65)*Math.exp(-t*4)+Math.sin(t*900*2*Math.PI)*Math.exp(-t*65)*.15;
   else if(kind==='drone')v=(Math.sin(t*390*2*Math.PI)+Math.sin(t*780*2*Math.PI)*.25+noise*.08)*.13*Math.sin(Math.PI*t/duration);
   else if(kind==='plant'||kind==='defuser'||kind==='gadget'||kind==='interface')v=Math.sin(t*(kind==='defuser'?1750:kind==='plant'?720:kind==='gadget'?440:880)*2*Math.PI)*.17*Math.exp(-t*22);
   else{const click=t<.035||t>.12&&t<.155||kind==='reload'&&t>.29&&t<.33;v=click?(noise*.45+Math.sin(t*1200*2*Math.PI)*.2)*Math.exp(-(t% .12)*60):low*.08;}
   out[i]=THREE.MathUtils.clamp(v,-1,1);
  }this.buffers.set(kind,b);return b;
 }
 play(kind:SoundKind,pos?:THREE.Vector3,gain=.3,id?:string){if(id){if(this.heard.has(id))return;this.heard.add(id);if(this.heard.size>512)this.heard.delete(this.heard.values().next().value!);}if(!this.ctx||!this.enabled)return;
  const c=this.ctx,source=c.createBufferSource(),g=c.createGain(),filter=c.createBiquadFilter();source.buffer=this.buffer(kind==='footstep'?'footstep:'+this.surface(pos??this.position):kind);filter.type='lowpass';filter.Q.value=.5;const acoustic=pos?this.acoustic(pos):{occlusion:0,cutoff:18000,distance:0,path:'interface',gain:1};g.gain.value=gain*acoustic.gain;filter.frequency.value=acoustic.cutoff;source.connect(filter);filter.connect(g);
  let pan:PannerNode|undefined;if(pos){pan=c.createPanner();pan.panningModel='HRTF';pan.distanceModel='inverse';pan.refDistance=2;pan.maxDistance=90;pan.rolloffFactor=1.2;pan.positionX.value=pos.x;pan.positionY.value=pos.y;pan.positionZ.value=pos.z;g.connect(pan);pan.connect(this.buses.effects);}else g.connect(this.buses.interface);
  this.diagnostics.push({kind,position:(pos??this.position).toArray(),...acoustic});if(this.diagnostics.length>128)this.diagnostics.shift();this.voices.add(source);if(this.voices.size>32){const oldest=this.voices.values().next().value!;oldest.stop();this.voices.delete(oldest);}source.onended=()=>{this.voices.delete(source);source.disconnect();filter.disconnect();g.disconnect();pan?.disconnect();};if(kind.startsWith('stance-')){const key=id?.split(':')[0]??'local',previous=this.stanceVoices.get(key);if(previous){previous.gain.gain.setTargetAtTime(0,c.currentTime,.006);previous.source.stop(c.currentTime+.025);}this.stanceVoices.set(key,{source,gain:g});const ended=source.onended;source.onended=e=>{if(this.stanceVoices.get(key)?.source===source)this.stanceVoices.delete(key);ended?.call(source,e);};}source.start();
 }
 // Legacy callers are interface-only until migrated; spatial effects use named events.
 sound(_freq:number,_duration=.08,gain=.2,pos?:THREE.Vector3,_listener?:THREE.Vector3){this.play(pos?'gadget':'interface',pos,gain);}
}

export {applyBotMapPose} from './map-bot-traversal';
import {botMapPose} from './map-bot-traversal';
import type {Bot,Phase} from './game';
import {operators} from './data';
import {jammerPlacementSeconds} from './jammer';
import {objectiveConfig} from './objectives';

// Objective holds count upward in the AI; character actions count down.
export function botObjectiveAction(b:Bot,phase:Phase){
 const total=b.team===0?objectiveConfig.plantSeconds:objectiveConfig.disableSeconds;
 const elapsed=b.brain?.objectiveHold??b.objectiveHold??0;
 const active=phase==='action'&&b.hp>0&&elapsed>0&&elapsed<total;
 return {action:active?total-elapsed:0,actionTotal:active?total:0,actionKind:active?(b.team===0?'plant':'disable'):''};
}
export function botCharacterState(b:Bot,phase:Phase){
 const traversal=botMapPose(b),objective=botObjectiveAction(b,phase),charge=(b.chargeHold??0)>0,jammer=(b.jammerHold??0)>0;
 return {pos:b.pos,yaw:b.mesh.rotation.y,stance:b.stance??'stand',stanceAmount:b.stanceAmount??0,
  pitch:b.pitch??0,lean:0,adsProgress:b.aiming&&!objective.action&&!traversal?1:0,
  vaultFrom:traversal?b.pos.clone().fromArray(traversal.plan.points[0]):null,vaultPlan:traversal?.plan??null,vaultProgress:traversal?.progress??0,
  state:traversal?'vault' as const:objective.action?b.team===0?'plant' as const:'disable' as const:b.stance??'stand',
  reload:0,hp:b.hp,weapon:operators[b.operator??(b.team===0?0:4)].weapon,shotSerial:b.shotSerial??0,
  action:objective.action||b.chargeHold||b.jammerHold||0,
  actionKind:objective.actionKind||(charge?'charge':jammer?'jammer':''),
  actionTotal:objective.actionTotal||(charge?2.5:jammer?jammerPlacementSeconds:0),
  actionPosition:b.jammerTarget??undefined,jammerYaw:b.mesh.rotation.y,
  hammerSwing:b.hammerSwing,hammerHit:b.hammerHit,hammerTarget:b.hammerTarget,
  launcherEquipped:b.launcherEquipped,launcherDraw:b.launcherDraw,launcherReload:b.launcherReload,
  launcherShot:b.launcherShot,smokeThrow:b.smokeThrow,smokeReleased:b.smokeReleased};
}

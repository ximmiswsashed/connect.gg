export type BulletSurface={id:number|string,remaining:boolean,penetrable:boolean,reinforced:boolean};
export class PenetrationPath{
 readonly surfaces=new Set<number|string>();blocked=false;
 cross(surface:BulletSurface){
  if(this.blocked)return false;
  if(!surface.remaining)return true;
  if(surface.reinforced||!surface.penetrable){this.blocked=true;return false;}
  this.surfaces.add(surface.id);return true;
 }
 damage(normalCalculatedDamage:number,headshot:boolean){
  if(this.blocked||!Number.isFinite(normalCalculatedDamage)||normalCalculatedDamage<0)return 0;
  return headshot?normalCalculatedDamage:normalCalculatedDamage*Math.pow(.70,this.surfaces.size);
 }
}

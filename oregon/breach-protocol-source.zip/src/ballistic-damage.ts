/** Shotgun pellets use a range-adjusted head modifier, never rifle instant kills. */
export function firearmDamage(base:number,shotgun:boolean,head:boolean,distance:number,victimHealth=100){
 const ranged=base*(shotgun?Math.max(.12,1-Math.max(0,distance)/25):1);
 return head?(shotgun?ranged*1.5:Math.max(150,victimHealth)):ranged;
}

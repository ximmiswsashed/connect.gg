import * as THREE from 'three';

export type PerceptionTuning = {
  reaction:number; acquisition:number; error:number; burst:number; memory:number;
  reposition:number; range:number; peripheralCos:number; turnSpeed:number;
  soundUncertainty:number;
};
export const perceptionPresets:Record<'Easy'|'Normal'|'Hard',PerceptionTuning> = {
  Easy:{reaction:.65,acquisition:.35,error:.032,burst:2,memory:1,reposition:.25,range:24,peripheralCos:0,turnSpeed:2.2,soundUncertainty:3.5},
  Normal:{reaction:.4,acquisition:.24,error:.018,burst:3,memory:1.7,reposition:.6,range:32,peripheralCos:-.1,turnSpeed:2.8,soundUncertainty:2.7},
  Hard:{reaction:.24,acquisition:.16,error:.009,burst:4,memory:2.2,reposition:.85,range:38,peripheralCos:-.2,turnSpeed:3.2,soundUncertainty:2},
};
export function perceptionTuning(difficulty:keyof typeof perceptionPresets,override:Partial<PerceptionTuning>={}) {
  const result={...perceptionPresets[difficulty]};
  for(const key of Object.keys(result) as (keyof PerceptionTuning)[]){
    const value=override[key];if(value!==undefined&&Number.isFinite(value))result[key]=key==='peripheralCos'?THREE.MathUtils.clamp(value,-1,1):Math.max(0,value);
  }
  result.burst=Math.max(1,Math.round(result.burst));return result;
}

type Noise={pos:THREE.Vector3;radius:number};
// One uncertain clue per listener/event: repeated polling cannot triangulate the true source.
const clues=new WeakMap<Noise,Map<number,THREE.Vector3>>();
export function soundClue(noise:Noise,listener:number,uncertainty:number){
  let listeners=clues.get(noise);if(!listeners){listeners=new Map();clues.set(noise,listeners);}
  let clue=listeners.get(listener);
  if(!clue){const angle=Math.random()*Math.PI*2,radius=Math.max(.75,uncertainty)*(.55+Math.random()*.45);clue=noise.pos.clone().add(new THREE.Vector3(Math.sin(angle)*radius,0,Math.cos(angle)*radius));listeners.set(listener,clue);}
  return clue.clone();
}

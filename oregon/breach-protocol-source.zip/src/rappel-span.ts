import type {World,Panel} from './world';

/** Source facades are split into many mesh objects, including separate jambs.
 * Join their lateral annotations across measured exterior openings. This only
 * expands the rope's traversal bounds; the existing swept collision still
 * checks every movement step and exit. Legacy box maps retain their own bounds.
 */
export function sourceRappelSpan(world:World,hit:Panel,axis:'x'|'z'){
 const lateral=axis==='x'?'z':'x',plane=hit.mesh.position[axis];
 let min=hit.min[lateral],max=hit.max[lateral];
 if(!world.imported)return {min,max};
 const parts=[...world.imported.sourceObjects.values()].flat().filter(p=>
  p.max.y-p.min.y>1.4&&p.max[axis]-p.min[axis]<.3&&
  Math.abs(p.mesh.position[axis]-plane)<.03&&
  p.min.y<hit.max.y&&p.max.y>hit.min.y);
 const openings=world.panels.filter(p=>p.kind==='barricade'&&p.mesh.userData.exterior&&
  (p.max.x-p.min.x<p.max.z-p.min.z?'x':'z')===axis&&
  Math.abs(p.mesh.position[axis]-plane)<.54&&p.min.y<hit.max.y&&p.max.y>hit.min.y);
 const bridges=(lo:number,hi:number)=>hi<=lo||openings.some(p=>{
  const center=p.mesh.position[lateral],width=p.max[lateral]-p.min[lateral];
  return center>=lo&&center<=hi&&hi-lo<=width+2*.27;
 });
 let changed=true;
 while(changed){changed=false;for(const p of parts){
  const lo=p.min[lateral],hi=p.max[lateral];
  if(lo>max&&!bridges(max,lo)||hi<min&&!bridges(hi,min))continue;
  if(lo<min||hi>max){min=Math.min(min,lo);max=Math.max(max,hi);changed=true;}
 }}
 return {min,max};
}

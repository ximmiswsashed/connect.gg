import {bombLocations} from './map-plan';
export const weapons = [
 {name:'R4-C',damage:39,rpm:860,mag:30,reload:2.5,ads:.22,spread:.06,recoil:.0032,reserve:150},
 {name:'M590A1',damage:18,rpm:85,mag:7,reload:3.1,ads:.25,spread:.09,recoil:.015,reserve:35},
 {name:'SMG-12',damage:28,rpm:1270,mag:32,reload:2.7,ads:.19,spread:.085,recoil:.0048,reserve:160},
 {name:'556XI',damage:46,rpm:690,mag:30,reload:2.8,ads:.28,spread:.063,recoil:.0037,reserve:150},
 {name:'MP5K',damage:30,rpm:800,mag:30,reload:2.3,ads:.2,spread:.055,recoil:.0028,reserve:150},
 {name:'USP-style',damage:38,rpm:360,mag:12,reload:1.8,ads:.16,spread:.045,recoil:.002,reserve:60}
];
export const operators = [
 {name:'ASH',role:'ATTACK',gadget:'BREACHING LAUNCHER',desc:'Open soft walls from a distance.',weapon:0,count:2,icon:'↗'},
 {name:'SMOKE',role:'DEFENSE',gadget:'REMOTE GAS',desc:'Throw sticky canisters. Activate to deny an area.',weapon:1,count:3,icon:'☣'},
 {name:'SLEDGE',role:'ATTACK',gadget:'BREACHING HAMMER',desc:'Hammer breaches unreinforced soft surfaces; ordinary melee cannot.',weapon:1,count:25,icon:'╱'},
 {name:'THERMITE',role:'ATTACK',gadget:'EXOTHERMIC CHARGE',desc:'Attach charges to reinforced walls.',weapon:3,count:2,icon:'▥'},
 {name:'MUTE',role:'DEFENSE',gadget:'SIGNAL JAMMER',desc:'Jam drones and electronic breaching charges.',weapon:4,count:4,icon:'≋'},
 {name:'VIGIL',role:'DEFENSE',gadget:'ERC INTERFERENCE',desc:'Toggle rechargeable drone concealment. 12 seconds active, 6 seconds to refill.',weapon:2,count:1,icon:'◈'}
];
export const defaults:Record<string,string>={forward:'KeyW',back:'KeyS',left:'KeyA',right:'KeyD',sprint:'ShiftLeft',crouch:'ControlLeft',prone:'KeyZ',slow:'AltLeft',leanLeft:'KeyQ',leanRight:'KeyE',reload:'KeyR',vault:'Space',gadget:'KeyG',activate:'KeyB',deployDrone:'Digit6',observe:'KeyV',exitDrone:'KeyN',melee:'KeyC',interact:'KeyF',reinforce:'KeyT',ping:'KeyX',scan:'KeyY',rappelRotate:'KeyO',leanReset:'Unbound',drop:'KeyH',barricade:'KeyJ',inspect:'KeyI',switch:'Digit2',scoreboard:'Tab'};
export const sites=[{name:'Laundry / Supply',floor:-1,a:5,b:6,rooms:['laundry','supply'],bombs:[bombLocations.laundry,bombLocations.supply]},{name:'Kitchen / Dining',floor:0,a:6,b:5,rooms:['kitchen','dining'],bombs:[bombLocations.kitchen,bombLocations.dining]},{name:'Meeting / Kitchen',floor:0,a:7,b:6,rooms:['meeting','kitchen'],bombs:[bombLocations.meeting,bombLocations.kitchen]},{name:'Kids / Dorms',floor:1,a:5,b:6,rooms:['kids','dorms'],bombs:[bombLocations.kids,bombLocations.dorms]}];
export const roomNames=[['Freezer','Laundry Stairs','Electrical','Boiler','Blue Bunker','Laundry','Supply','Construction','Storage','Basement Hall','Pillar','Back Stairs'],['Small Tower','Dining Hall','Kitchen','Big Tower','White Stairs','Lobby','Meeting Hall','Rear Hall','Garage','Main Entrance','Classroom','Showers'],['Small Tower','Master Bedroom','Walk-in','Big Tower','White Stairs','Kids Dorms','Dorms Main Hall','Attic','Roof Landing','Armory','Trophy','Tower Landing']];

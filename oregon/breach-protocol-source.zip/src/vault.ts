import {posture} from './pose';
import {movementConfig} from './movement';
import * as THREE from 'three';
import type {World,Panel} from './world';
export type VaultPlan={points:number[][],duration:number,height:number,kind:'cover'|'ledge'|'window'|'ladder',action?:'over'|'onto',landing:'stand'|'crouch',surface:number,startPose:number,dropLanding?:number[],arc?:number,route?:'entrance-hood'|'entrance-awning'};
const radius=.27,clearance=.055;
const smooth=(t:number)=>t*t*(3-2*t);
export const vaultPosture=(plan:VaultPlan,t:number)=>plan.kind==='ladder'?plan.startPose:THREE.MathUtils.lerp(plan.startPose,1,smooth(Math.min(1,t/.20)));
export const vaultHeight=(plan:VaultPlan,t:number)=>posture(vaultPosture(plan,t)).height;
// Lift, traverse, settle. Feet clear the complete silhouette before crossing it.
export function vaultPoint(plan:VaultPlan,t:number){if(plan.arc){const f=THREE.MathUtils.clamp(t,0,1),from=new THREE.Vector3().fromArray(plan.points[0]),to=new THREE.Vector3().fromArray(plan.points[3]);return from.lerp(to,smooth(f)).setY(THREE.MathUtils.lerp(plan.points[0][1],to.y,f)+4*plan.arc*f*(1-f));}const times=plan.kind==='ladder'?[0,.10,.90,1]:[0,.30,.70,1];let i=0;while(i<2&&t>times[i+1])i++;return new THREE.Vector3().fromArray(plan.points[i]).lerp(new THREE.Vector3().fromArray(plan.points[i+1]),smooth(THREE.MathUtils.clamp((t-times[i])/(times[i+1]-times[i]),0,1)));}
export function sweepVault(world:World,from:THREE.Vector3,to:THREE.Vector3,height:number,occupied:(p:THREE.Vector3,h:number)=>boolean){const n=Math.max(1,Math.ceil(from.distanceTo(to)/.04));for(let i=1;i<=n;i++){const p=from.clone().lerp(to,i/n);if(world.collide(p.x,p.y,p.z,radius,height)||occupied(p,height))return false;}return true;}
function support(world:World,x:number,z:number,ceiling:number){if(world.imported)return world.ground(x,z,ceiling,0);let top=-Infinity;for(const p of world.nearPanels(x,z,.001)){if(p.broken||(!p.mesh.userData.walkable&&p.kind!=='solid')||x<p.min.x||x>p.max.x||z<p.min.z||z>p.max.z)continue;const y=p.mesh.userData.ramp?p.mesh.userData.ramp.height(x,z):p.max.y;if(y<=ceiling&&y>top)top=y;}return top;}
export type VaultDiagnostic={surface:string,reason:string,point?:number[]};

function entranceSources(world:World){
 const car=world.imported?.sourceObjects.get('mesh_3174')?.find(p=>p.mesh.userData.surfaceMaterial==='mat_32.003'),awning=world.imported?.sourceObjects.get('mesh_2006')?.find(p=>p.mesh.userData.surfaceMaterial==='mat_25.003');
 if(!car||!awning||car.max.x-car.min.x<5||car.max.x-car.min.x>6||awning.max.z<car.min.z-3||awning.max.z>car.min.z-1)return null;
 return {car,awning};
}
function entranceSupport(world:World,x:number,z:number,ceiling:number){
 const heights=Array.from({length:8},(_,i)=>support(world,x+Math.cos(i*Math.PI/4)*radius,z+Math.sin(i*Math.PI/4)*radius,ceiling));heights.push(support(world,x,z,ceiling));
 if(heights.some(y=>!Number.isFinite(y)||y===-25)||Math.max(...heights)-Math.min(...heights)>.3)return null;
 const point=new THREE.Vector3(x,Math.max(...heights)+.015,z);return world.collide(point.x,point.y,point.z,radius,1.82)?null:point;
}
/** Measured offsets stay attached to the supplied van and awning; no helper colliders. */
export function sourceEntranceEndpoints(world:World){
 const sources=entranceSources(world);if(!sources)return null;const {car,awning}=sources,z=car.min.z+1.10;
 const road=entranceSupport(world,car.min.x-.57,z,car.min.y+.1),hood=entranceSupport(world,car.min.x+.43,z,car.max.y+.2);
 // Avoid relying on a needle-sized seam between supplied roof triangles.
 const roof=[0,.04,-.04,.08,-.08].map(dx=>entranceSupport(world,car.min.x+2.03+dx,car.min.z+.80,car.max.y+.2)).find(p=>p)??null;
 const landing=roof?entranceSupport(world,roof.x,awning.max.z-.28,awning.max.y+.1):null;
 return road&&hood&&roof&&landing?{...sources,road,hood,roof,awning:landing}:null;
}
export function findSourceEntrance(world:World,pos:THREE.Vector3,yaw:number,occupied:(p:THREE.Vector3,h:number)=>boolean=()=>false,startPose=0):VaultPlan|null{
 if(startPose>1)return null;const sources=entranceSources(world);if(!sources||pos.x<sources.car.min.x-1.2||pos.x>sources.car.max.x+.4||pos.z<sources.car.min.z-.2||pos.z>sources.car.max.z+.4)return null;
 const e=sourceEntranceEndpoints(world);if(!e)return null;
 const distance=(a:THREE.Vector3,b:THREE.Vector3)=>Math.hypot(a.x-b.x,a.z-b.z),direction=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));
 const hood=distance(pos,e.road)<=.4&&Math.abs(pos.y-e.road.y)<=.08&&direction.x>.92;
 const leap=distance(pos,e.roof)<=.32&&Math.abs(pos.y-e.roof.y)<=.08&&-direction.z>.92;
 if(!hood&&!leap||world.collide(pos.x,pos.y,pos.z,radius,posture(startPose).height))return null;
 const to=(hood?e.hood:e.awning).clone(),span=distance(pos,to),rise=to.y-pos.y;
 if(rise<.35||rise>(hood?1.4:1)||span>(hood?1.4:3.1)||occupied(to,1.82))return null;
 const duration=hood?.85:Math.max(.8,1.5*span/movementConfig.sprintSpeed),arc=leap?movementConfig.gravity*duration*duration/8:undefined;
 const top=arc?(pos.y+to.y)/2+arc:Math.max(pos.y,to.y)+clearance;
 const plan:VaultPlan={points:[pos.toArray(),pos.clone().setY(top).toArray(),to.clone().setY(top).toArray(),to.toArray()],duration,height:1.12,kind:'ledge',action:'onto',landing:'stand',surface:world.panels.indexOf(hood?e.car:sources.awning),startPose,arc,route:hood?'entrance-hood':'entrance-awning'};
 let previous=pos;for(let i=1;i<=100;i++){const next=vaultPoint(plan,i/100),height=Math.max(vaultHeight(plan,(i-1)/100),vaultHeight(plan,i/100));if(!sweepVault(world,previous,next,height,occupied))return null;previous=next;}
 return plan;
}
/** The authored tower ladder is the only connection to its third-floor platform.
 * Reuse the host-authoritative, swept traversal state so peers and replays agree. */
export function sourceLadderEndpoints(world:World){
 const source=world.imported?.sourceObjects.get('mesh_12007')?.find(p=>p.mesh.userData.surfaceMaterial==='mat_391.001');
 if(!source)return null;
 const x=(source.min.x+source.max.x)/2,bottomZ=source.max.z+.42,topZ=source.min.z-.60;
 const bottom=new THREE.Vector3(x,world.ground(x,bottomZ,source.min.y+.2,0)+.015,bottomZ);
 const top=new THREE.Vector3(x,world.ground(x,topZ,source.max.y+.2,0)+.015,topZ);
 return {bottom,top,upperFront:new THREE.Vector3(x,source.max.y+.45,bottomZ)};
}
export function findSourceLadder(world:World,pos:THREE.Vector3,yaw:number,occupied:(p:THREE.Vector3,h:number)=>boolean=()=>false,startPose=0):VaultPlan|null{
 if(startPose>1)return null;
 const source=world.imported?.sourceObjects.get('mesh_12007')?.[0];
 // Cheap bounds rejection keeps ladder checks out of normal movement costs.
 if(!source||pos.x<source.min.x-1.1||pos.x>source.max.x+1.1||pos.z<source.min.z-1.7||pos.z>source.max.z+1.5)return null;
 const endpoints=sourceLadderEndpoints(world);if(!endpoints)return null;
 const {bottom,top,upperFront}=endpoints,horizontal=(a:THREE.Vector3,b:THREE.Vector3)=>Math.hypot(a.x-b.x,a.z-b.z);
 const up=Math.abs(pos.y-bottom.y)<.35&&horizontal(pos,bottom)<1.05&&Math.cos(yaw)>.65;
 const down=Math.abs(pos.y-top.y)<.35&&horizontal(pos,top)<1.05&&Math.cos(yaw)<-.65;
 if(!up&&!down)return null;
 const destination=up?top:bottom.clone().add(new THREE.Vector3(0,0,.32));
 if(!up)destination.y=world.ground(destination.x,destination.z,bottom.y+.15,0)+.015;
 const plan:VaultPlan={points:[pos.toArray(),(up?bottom:upperFront).toArray(),(up?upperFront:bottom).toArray(),destination.toArray()],duration:.8+(top.y-bottom.y)/1.25,height:posture(startPose).height,kind:'ladder',action:'onto',landing:startPose>.5?'crouch':'stand',surface:-1,startPose};
 if(top.y-bottom.y<2||world.collide(destination.x,destination.y,destination.z,radius,plan.height))return null;
 let prior=pos;
 for(let i=1;i<=80;i++){const next=vaultPoint(plan,i/80);if(!sweepVault(world,prior,next,plan.height,occupied))return null;prior=next;}
 return plan;
}
export function findVault(world:World,pos:THREE.Vector3,yaw:number,occupied:(p:THREE.Vector3,h:number)=>boolean=()=>false,startPose=0,diagnostics?:VaultDiagnostic[]):VaultPlan|null{
 const entrance=findSourceEntrance(world,pos,yaw,occupied,startPose);if(entrance)return entrance;
 const ladder=findSourceLadder(world,pos,yaw,occupied,startPose);if(ladder)return ladder;
 const reject=(p:Panel,reason:string,point?:THREE.Vector3)=>diagnostics?.push({surface:p.mesh.userData.openingId??p.mesh.userData.sourceName??String(world.panels.indexOf(p)),reason,point:point?.toArray()});
 const dir=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));const candidates:{p:Panel,near:number,far:number,top:number,kind:VaultPlan['kind']}[]=[];
 // Open authored windows retain their opening bounds after destruction. Bullet holes are too small.
 for(const p of world.nearPanels(pos.x,pos.z,2.5))if(p.kind==='barricade'&&p.broken&&!p.mesh.userData.permanent&&p.mesh.userData.window){const axis=p.max.x-p.min.x<p.max.z-p.min.z?'x':'z',side=axis==='x'?'z':'x';if(Math.abs(dir[axis])<.65||pos[side]<p.min[side]+radius||pos[side]>p.max[side]-radius){reject(p,'approach angle or lateral clearance');continue;}const d=(p.mesh.position[axis]-pos[axis])/dir[axis];if(d<.15||d>1.4||Math.abs(p.min.y-pos.y)>.95){reject(p,'detection distance or sill height');continue;}const cross=pos.clone().addScaledVector(dir,d);if(cross[side]<p.min[side]+radius||cross[side]>p.max[side]-radius){reject(p,'crossing outside opening');continue;}candidates.push({p,near:d-.09/Math.abs(dir[axis]),far:d+.09/Math.abs(dir[axis]),top:world.imported?Math.max(p.min.y,world.ground(cross.x,cross.z,p.min.y+.3,0)):p.min.y,kind:'window'});}
 for(const height of [.42,.75,1.05]){for(const hit of world.trace(pos.clone().add(new THREE.Vector3(0,height,0)),dir,1.4)){const p=hit.object.userData.panel as Panel;const probe=hit.point.clone().addScaledVector(dir,.10),top=world.imported?world.ground(probe.x,probe.z,pos.y+1.3,0):p.max.y;if(p.kind!=='solid'||p.mesh.userData.step||p.mesh.userData.ramp||top-pos.y<.38||top-pos.y>1.25)continue;const size=p.max.clone().sub(p.min),lateral=Math.abs(dir.z)*size.x+Math.abs(dir.x)*size.z;if(lateral<radius*2+.06)continue;const near=world.imported?hit.distance:world.intersection(pos.clone().setY(Math.min(top-.02,pos.y+height)),dir,1.4,p)?.distance;if(near===undefined||near<radius+.02)continue;let far=Infinity;for(const axis of ['x','z'] as const)if(Math.abs(dir[axis])>.001)far=Math.min(far,((dir[axis]>0?p.max[axis]:p.min[axis])-pos[axis])/dir[axis]);if(!Number.isFinite(far))continue;if(world.imported){far=near;while(far<near+4){const q=pos.clone().addScaledVector(dir,far+.10),y=support(world,q.x,q.z,top+.10);if(!Number.isFinite(y)||Math.abs(y-top)>.16)break;far+=.10;}}const thickness=far-near;if(thickness<.18||thickness>4)continue;if(candidates.some(c=>c.p===p))continue;const landingOn=thickness>1.0;candidates.push({p,near,far:landingOn?near+.5:far,top,kind:landingOn?'ledge':'cover'});}}
 candidates.sort((a,b)=>Math.abs(a.near-b.near)<.12?(a.kind==='window'?-1:b.kind==='window'?1:a.near-b.near):a.near-b.near);
 for(const c of candidates){
  // Barricade bounds describe the outside board, not the complete wall or interior sill.
  // Measure the sill along the crossing, then try bounded landing offsets beyond the frame.
  if(c.kind==='window'&&world.imported){for(let d=c.near-.5;d<=c.far+.5;d+=.05){const q=pos.clone().addScaledVector(dir,d),y=support(world,q.x,q.z,pos.y+1.25);if(Number.isFinite(y)&&y-pos.y<=1.25)c.top=Math.max(c.top,y);}}
  for(const extra of c.kind==='window'?[0,.15,.30,.45,.60]:[0]){const to=pos.clone().addScaledVector(dir,c.far+radius+.18+extra);const heights=[[0,0],[radius,0],[-radius,0],[0,radius],[0,-radius]].map(([x,z])=>support(world,to.x+x,to.z+z,c.top+.15));if(heights.some(y=>!Number.isFinite(y))||Math.max(...heights)-Math.min(...heights)>.3){reject(c.p,'landing support variation');continue;}to.y=Math.max(...heights)+.015;if((c.kind!=='window'&&to.y-pos.y< -1.35)||to.y-pos.y>1.25){reject(c.p,'landing elevation');continue;}
  const landing=world.collide(to.x,to.y,to.z,radius,1.82)?'crouch':'stand';if(world.collide(to.x,to.y,to.z,radius,1.12)||occupied(to,landing==='stand'?1.82:1.12)){reject(c.p,'landing collision or occupied space',to);continue;}
  const top=Math.max(c.top+clearance,pos.y,to.y),dropLanding=c.kind==='window'&&to.y<pos.y-1.35?to.toArray():undefined;if(dropLanding){const exit=to.clone().setY(top);if(!sweepVault(world,exit,to,landing==='stand'?1.82:1.12,occupied)){reject(c.p,'drop path blocked',to);continue;}to.y=top;}const a=pos.clone().setY(top),b=to.clone().setY(top),plan:VaultPlan={points:[pos.toArray(),a.toArray(),b.toArray(),to.toArray()],height:1.12,startPose,duration:THREE.MathUtils.clamp(.58+pos.distanceTo(to)*.10+(top-pos.y)*.10,.65,1.05),kind:c.kind,dropLanding,action:c.kind==='ledge'?'onto':'over',landing,surface:world.panels.indexOf(c.p)};
  let prev=pos.clone(),valid=true;for(let i=1;i<=36;i++){const next=vaultPoint(plan,i/36);if(!sweepVault(world,prev,next,Math.max(vaultHeight(plan,(i-1)/36),vaultHeight(plan,i/36)),occupied)){reject(c.p,'swept path blocked',next);valid=false;break;}prev=next;}if(valid){reject(c.p,'eligible '+plan.action,to);return plan;}
 }}return null;
}

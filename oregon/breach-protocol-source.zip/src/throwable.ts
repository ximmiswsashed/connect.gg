import * as THREE from 'three';
import type {World} from './world';
export type Throwable={pos:THREE.Vector3,mesh:THREE.Object3D,flightVelocity?:THREE.Vector3,attached?:boolean};
const radius=.18;
// Continuous envelope catches face, edge and corner contacts between sampled rays.
export function throwHit(world:World,from:THREE.Vector3,to:THREE.Vector3){
 const delta=to.clone().sub(from),distance=delta.length();if(distance<1e-8)return null;delta.divideScalar(distance);
 return world.sweepSphere(from,delta,distance,radius);
}
export function advanceThrowable(world:World,device:Throwable,dt:number){
 const velocity=device.flightVelocity;if(!velocity)return false;
 const count=Math.max(1,Math.ceil(dt/.01)),step=dt/count;
 for(let i=0;i<count;i++){
  const next=device.pos.clone().addScaledVector(velocity,step);next.y-=4.9*step*step;
  const hit=throwHit(world,device.pos,next);
  if(hit){const normal=hit.face.normal.clone().normalize();if(normal.dot(velocity)>0)normal.negate();device.pos.copy(hit.point).addScaledVector(normal,radius+.005);device.mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),normal);device.flightVelocity=undefined;device.attached=true;device.mesh.position.copy(device.pos);return true;}
  device.pos.copy(next);velocity.y-=9.8*step;device.mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),velocity.clone().normalize());
  if(device.pos.y<-25){device.flightVelocity=undefined;device.mesh.visible=false;break;}
 }
 device.mesh.position.copy(device.pos);return false;
}

import * as THREE from 'three';
import type {World} from './world';

const cloudRadius=4,spacing=.9,puffRadius=.66,normalization=.18/cloudRadius;
const corners=[-1,1].flatMap(x=>[-1,1].flatMap(y=>[-1,1].map(z=>new THREE.Vector3(x,y,z))));
// Fit overlapping puffs into collision-free bounds and the source's visible region.
// This is sampled visual coverage; damage continues to use the authoritative LOS test.
export function buildGasCloud(world:World,origin:THREE.Vector3,orientation=new THREE.Quaternion()){
 const positions:number[]=[],centers:number[]=[],radii:number[]=[],uvs:number[]=[],puffs:{offset:number[],radius:number}[]=[];
 const inverse=orientation.clone().invert();
 let sightTests=0,collisionTests=0;
 const visible=(p:THREE.Vector3)=>{sightTests++;return world.sight(origin,p);};
 const fits=(p:THREE.Vector3,r:number)=>{collisionTests++;return !world.collide(p.x,p.y-r,p.z,r,2*r)&&corners.every(c=>visible(p.clone().addScaledVector(c,r)));};
 for(let x=-4;x<=4;x++)for(let y=-4;y<=4;y++)for(let z=-4;z<=4;z++){
  const offset=new THREE.Vector3(x*spacing,y*spacing,z*spacing),distance=offset.length();if(distance>=cloudRadius-.12)continue;
  const center=origin.clone().add(offset);if(!visible(center))continue;
  let radius=Math.min(puffRadius,cloudRadius-distance);while(radius>=.12&&!fits(center,radius))radius*=.6;if(radius<.12)continue;
  puffs.push({offset:offset.toArray(),radius});
  for(const [u,v] of [[-1,-1],[1,-1],[1,1],[-1,-1],[1,1],[-1,1]]){const center=offset.clone().applyQuaternion(inverse).multiplyScalar(normalization),vertex=offset.clone().add(new THREE.Vector3(u*radius,v*radius,0)).applyQuaternion(inverse).multiplyScalar(normalization);positions.push(...vertex.toArray());centers.push(...center.toArray());radii.push(radius);uvs.push(u,v);}
 }
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('puffCenter',new THREE.Float32BufferAttribute(centers,3));geometry.setAttribute('puffRadius',new THREE.Float32BufferAttribute(radii,1));geometry.setAttribute('puffUV',new THREE.Float32BufferAttribute(uvs,2));geometry.boundingSphere=new THREE.Sphere(new THREE.Vector3(),cloudRadius*normalization);
 geometry.userData={puffs,sightTests,collisionTests};return geometry;
}
export function refreshGasCloud(world:World,mesh:THREE.Mesh,origin:THREE.Vector3,force=false){
 const now=performance.now();const material=mesh.userData.cloudMaterial as THREE.ShaderMaterial|undefined;if(material)material.uniforms.cloudTime.value=now/1000;if(!force&&now<(mesh.userData.cloudNextCheck??0))return;mesh.userData.cloudNextCheck=now+250;
 const key=origin.toArray().concat(mesh.quaternion.toArray()).join(',')+'|'+world.nearPanels(origin.x,origin.z,cloudRadius).map(p=>Number(p.broken)+':'+Number(p.reinforced)+':'+(p.holes?.length??0)).join(',');
 if(!force&&mesh.userData.cloudKey===key)return;
 const previous=mesh.userData.occludedCloudGeometry as THREE.BufferGeometry|undefined,geometry=buildGasCloud(world,origin,mesh.quaternion);mesh.userData.occludedCloudGeometry=geometry;mesh.userData.cloudKey=key;mesh.geometry=geometry;previous?.dispose();
}

export function gasCloudMaterial(){return new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,uniforms:{cloudTime:{value:0}},
 vertexShader:`attribute vec3 puffCenter;attribute float puffRadius;attribute vec2 puffUV;varying vec2 vPuffUV;varying vec3 vCenter;
 void main(){vec3 center=(modelMatrix*vec4(puffCenter,1.0)).xyz;vec3 right=vec3(viewMatrix[0][0],viewMatrix[1][0],viewMatrix[2][0]),up=vec3(viewMatrix[0][1],viewMatrix[1][1],viewMatrix[2][1]);vec3 point=center+(right*puffUV.x+up*puffUV.y)*puffRadius;vPuffUV=puffUV;vCenter=center;gl_Position=projectionMatrix*viewMatrix*vec4(point,1.0);}`,
 fragmentShader:`uniform float cloudTime;varying vec2 vPuffUV;varying vec3 vCenter;
 void main(){float radius=length(vPuffUV);if(radius>=1.0)discard;float density=pow(1.0-radius*radius,1.4);float billow=.78+.22*sin(vPuffUV.x*7.0+vCenter.x*1.7+cloudTime*.6)*sin(vPuffUV.y*6.0+vCenter.z*1.3-cloudTime*.4);gl_FragColor=vec4(vec3(.62,.65,.27),density*billow*.65);}`});}

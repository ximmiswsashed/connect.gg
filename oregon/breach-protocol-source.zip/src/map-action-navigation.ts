import * as THREE from 'three';
import type {World} from './world';
import {findSourceLadder,sourceLadderEndpoints} from './vault';

export type NavigationActor='player'|'bot'|'drone';
export class LadderWaypoint extends THREE.Vector3 {
 constructor(readonly up:boolean){super();}
 override clone():this{return new LadderWaypoint(this.up).copy(this) as this;}
}

function connectors(world:World){
 const ends=sourceLadderEndpoints(world);
 if(!ends)return [];
 return [{from:ends.bottom,to:ends.top,up:true,yaw:0},{from:ends.top,to:ends.bottom.clone().add(new THREE.Vector3(0,0,.32)),up:false,yaw:Math.PI}];
}
function join(world:World,first:THREE.Vector3[],last:THREE.Vector3[],link:ReturnType<typeof connectors>[number]){
 if(!first.length||!last.length||!findSourceLadder(world,link.from,link.yaw))return [];
 return [...first,new LadderWaypoint(link.up).copy(link.to),...last];
}
// Walking remains the default capability. A ladder is an explicit action,
// never a vertical walking edge that a drone or generic consumer can follow.
export function routeForActor(world:World,start:THREE.Vector3,goal:THREE.Vector3,actor:NavigationActor){
 const direct=world.route(start,goal);if(direct.length||actor==='drone')return direct;
 for(const link of connectors(world)){
  const route=join(world,world.route(start,link.from),world.route(link.to,goal),link);
  if(route.length)return route;
 }return [];
}
export async function routeForActorAsync(world:World,start:THREE.Vector3,goal:THREE.Vector3,actor:NavigationActor){
 const walk=world.routeAsync?.bind(world)??((a:THREE.Vector3,b:THREE.Vector3)=>Promise.resolve(world.route(a,b)));
 const direct=await walk(start,goal);if(direct.length||actor==='drone')return direct;
 for(const link of connectors(world)){
  const [first,last]=await Promise.all([walk(start,link.from),walk(link.to,goal)]);
  const route=join(world,first,last,link);if(route.length)return route;
 }return [];
}

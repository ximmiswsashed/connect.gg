import {gadgetReference} from './gadget-reference';
import {beveledBox} from './model-detail';
import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
/** Original reference-based silhouettes. +Z is the mounting normal. */
export function operatorDeviceModel(type:string){
 const battery=type==='battery',selma=type==='selma',geometry=battery?beveledBox(.23,.20,.14):selma?new T.CylinderGeometry(.052,.052,.23,20).rotateX(Math.PI/2):new T.CylinderGeometry(.037,.043,.20,20).rotateX(Math.PI/2);
 const root=new T.Mesh(geometry,new T.MeshLambertMaterial({color:battery?0x404b3e:selma?0xb57553:0x303936}));
 const batches=new Map<number,T.BufferGeometry[]>(),add=(c:number,g:T.BufferGeometry,x=0,y=0,z=0)=>{g.translate(x,y,z);const a=batches.get(c)??[];a.push(g);batches.set(c,a);};
 const box=(c:number,w:number,h:number,d:number,x=0,y=0,z=0)=>add(c,beveledBox(w,h,d),x,y,z),ring=(c:number,r:number,t:number,z:number)=>add(c,new T.TorusGeometry(r,t,4,20),0,0,z),dark=0x182124,metal=0x929d9d;
 const cable=(points:T.Vector3[])=>add(dark,new T.TubeGeometry(new T.CatmullRomCurve3(points),14,.006,5,false));
 if(battery){
  box(dark,.245,.025,.155,0,.105);box(dark,.145,.014,.025,0,.14);for(const x of [-.073,.073]){box(dark,.025,.19,.15,x);add(metal,new T.CylinderGeometry(.011,.011,.025,10),x,.13,.025);}
  box(0xd5c58a,.10,.065,.003,0,.01,.073);box(dark,.073,.042,.004,0,.015,.076);
  for(const side of [-1,1])cable([new T.Vector3(side*.073,.145,.025),new T.Vector3(side*.15,.20,.04),new T.Vector3(side*.15,.23,-.02),new T.Vector3(side*.10,.24,-.04)]);
  for(let i=0;i<5;i++)add(metal,new T.TorusGeometry(.024,.004,4,12).rotateX(Math.PI/2),-.08+i*.04,.245,-.035);
 }else if(selma){
  for(const z of [-.105,.075])ring(metal,.055,.008,z);box(dark,.048,.02,.19,0,-.048);
  const petals:T.Group[]=[];for(let i=0;i<3;i++){const pivot=new T.Group(),angle=i*Math.PI*2/3;pivot.position.set(Math.cos(angle)*.05,Math.sin(angle)*.05,-.065);pivot.rotation.z=angle;const plate=new T.Mesh(beveledBox(.018,.060,.18),root.material);plate.position.set(.014,0,.075);pivot.add(plate);root.add(pivot);petals.push(pivot);box(metal,.012,.014,.17,Math.cos(angle)*.058,Math.sin(angle)*.058);}
  root.userData.petals=petals;
 }else{
  // Grzmot: perforated canister, orange collar, display and adhesive heel.
  ring(0xc87b37,.042,.007,-.055);for(const z of [-.095,.09])ring(dark,.038,.006,z);
  for(let row=0;row<4;row++)for(let i=0;i<10;i++){const a=i*Math.PI/5;add(dark,new T.SphereGeometry(.004,5,3),Math.cos(a)*.039,Math.sin(a)*.039,-.02+row*.022);}
  box(dark,.045,.018,.046,0,.037,-.025);box(0x9caa75,.031,.002,.021,0,.048,-.025);
  for(let i=0;i<8;i++){const a=i*Math.PI/4;add(0x877c61,new T.SphereGeometry(.020,6,4).scale(1,1,.5),Math.cos(a)*.035,Math.sin(a)*.035,-.11);}
 }
 for(const [color,parts] of batches){const merged=mergeGeometries(parts)!;parts.forEach(g=>g.dispose());root.add(new T.Mesh(merged,new T.MeshLambertMaterial({color})));}
 const signal=new T.Mesh(beveledBox(.020,.006,.003),new T.MeshBasicMaterial({color:0xd3ab57}));signal.position.set(0,battery?.025:selma?-.056:.049,battery?.078:selma?.02:-.025);root.add(signal);
 root.userData.signalMaterial=signal.material;root.userData.deviceGeometry=root.geometry;root.userData.deviceMaterial=root.material;root.traverse(o=>{o.userData.deviceRoot=root;o.userData.bulletMaterial='metal';});return root;
}
export function operatorDeviceFeedback(device:{type:string,mesh:T.Mesh,active:boolean,disabledTime?:number,stage?:number,stageClock?:number,armed?:boolean}){
 const material=device.mesh.userData.signalMaterial as T.MeshBasicMaterial|undefined;if(material)material.color.setHex(device.disabledTime||device.mesh.userData.jammed?0xc8a350:device.active||device.armed?0x69c7d5:0xbf6045);
 if(device.type==='selma'){const petals=device.mesh.userData.petals as T.Group[]|undefined;const duration=device.stage?gadgetReference.ace.nextSeconds:gadgetReference.ace.firstSeconds,elapsed=duration-(device.stageClock??duration),open=T.MathUtils.smoothstep(elapsed,0,.7);for(const p of petals??[])p.rotation.y=device.active?open*(device.stage?.8:.45):0;}
}

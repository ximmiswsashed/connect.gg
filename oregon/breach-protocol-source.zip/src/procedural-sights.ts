import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {opticalReticle} from './optical-reticle';

// Receiver-space meters. Measured source envelopes guide these original models;
// reference FOV/version uncertainty is independent of mechanical magnification.
export const rebuiltSightCenters={
 holo:{x:0,y:.120826,z:-.099072,mountY:.0704,zoom:1,reticle:'original-holo'},
 reddot:{x:-.00595,y:.115733,z:-.101494,mountY:.0704,zoom:1,reticle:'original-dot'},
 reflex:{x:.00198,y:.108004,z:-.119797,mountY:.0704,zoom:1,reticle:'original-triangle'},
 acog:{x:.000783,y:.115588,z:-.084339,mountY:.0704,zoom:2.5,reticle:'original-chevron'}
} as const;
type Sight=keyof typeof rebuiltSightCenters;
const dark=new THREE.MeshLambertMaterial({color:0x343b3e}),hardware=new THREE.MeshLambertMaterial({color:0x677078});
const glass=new THREE.MeshBasicMaterial({name:'Rebuilt Sight Lens',color:0x5e8d94,transparent:true,opacity:.075,depthWrite:false,side:THREE.DoubleSide});
const green=new THREE.MeshBasicMaterial({color:0x4bdd62}),fiber=new THREE.MeshLambertMaterial({color:0x853b3b});
for(const m of [dark,hardware,glass,green,fiber])m.userData.shared=true;
const templates=new Map<string,THREE.Group>(),textures=new Map<Sight,THREE.Texture>();

function reticleTexture(optic:Sight){
 let texture=textures.get(optic);if(texture)return texture;
 const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const c=canvas.getContext('2d')!;
 c.strokeStyle=c.fillStyle='#fff';c.lineWidth=3;c.lineCap='round';
 if(optic==='holo'){c.beginPath();c.arc(64,64,30,0,Math.PI*2);c.stroke();c.beginPath();c.arc(64,64,4,0,Math.PI*2);c.fill();for(const [x,y] of [[64,20],[64,108],[20,64],[108,64]]){c.beginPath();c.moveTo(x,y);c.lineTo(64+(x-64)*.78,64+(y-64)*.78);c.stroke();}}
 else if(optic==='reddot'){c.beginPath();c.arc(64,64,14,0,Math.PI*2);c.fill();}
 else if(optic==='reflex'){c.beginPath();c.moveTo(64,64);c.lineTo(44,98);c.lineTo(84,98);c.closePath();c.fill();}
 else{c.lineWidth=2.5;c.beginPath();c.moveTo(54,73);c.lineTo(64,64);c.lineTo(74,73);c.stroke();c.lineWidth=1.5;c.beginPath();c.moveTo(64,78);c.lineTo(64,118);for(const y of [88,100,112]){c.moveTo(64-(y-76)*.12,y);c.lineTo(64+(y-76)*.12,y);}c.stroke();}
 texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.userData.shared=true;textures.set(optic,texture);return texture;
}

function template(optic:Sight|'iron'){
 const existing=templates.get(optic);if(existing)return existing;
 const root=new THREE.Group(),parts=new Map<THREE.Material,THREE.BufferGeometry[]>();
 const add=(g:THREE.BufferGeometry,m:THREE.Material=dark)=>{if(!g.getAttribute('uv'))g.setAttribute('uv',new THREE.Float32BufferAttribute(new Float32Array(g.getAttribute('position').count*2),2));const original=g;if(g.index)g=g.toNonIndexed();if(g!==original)original.dispose();const list=parts.get(m)??[];list.push(g);parts.set(m,list);};
 const box=(x:number,y:number,z:number,w:number,h:number,d:number,m:THREE.Material=dark)=>add(new RoundedBoxGeometry(w,h,d,1,Math.min(.0015,Math.min(w,h,d)*.15)).translate(x,y,z),m);
 const cylinder=(x:number,y:number,z:number,r:number,h:number,m:THREE.Material=hardware)=>add(new THREE.CylinderGeometry(r,r,h,16).translate(x,y,z),m);
 const hollow=(sections:{z:number,outer:number,inner:number}[],cx:number,cy:number)=>{
  const positions:number[]=[];const segments=32,point=(s:typeof sections[number],ring:'outer'|'inner',i:number)=>[cx+Math.cos(i*Math.PI*2/segments)*s[ring],cy+Math.sin(i*Math.PI*2/segments)*s[ring],s.z];
  const tri=(a:number[],b:number[],c:number[])=>positions.push(...a,...b,...c);
  for(let j=0;j<sections.length-1;j++)for(let i=0;i<segments;i++){
   for(const ring of ['outer','inner'] as const){const a=point(sections[j],ring,i),b=point(sections[j],ring,i+1),c=point(sections[j+1],ring,i+1),d=point(sections[j+1],ring,i);if(ring==='outer'){tri(a,b,d);tri(b,c,d);}else{tri(a,d,b);tri(b,d,c);}}
  }
  for(const [j,reverse] of [[0,false],[sections.length-1,true]] as const)for(let i=0;i<segments;i++){const a=point(sections[j],'outer',i),b=point(sections[j],'outer',i+1),c=point(sections[j],'inner',i+1),d=point(sections[j],'inner',i);if(reverse){tri(a,b,d);tri(b,c,d);}else{tri(a,d,b);tri(b,d,c);}}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.computeVertexNormals();add(geo);
 };
 const frame=(outer:number[][],inner:number[][],depth:number,x:number,y:number,z:number,angle=0)=>{
  const shape=new THREE.Shape();outer.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();const hole=new THREE.Path();inner.forEach(([x,y],i)=>i?hole.lineTo(x,y):hole.moveTo(x,y));hole.closePath();shape.holes.push(hole);const geo=new THREE.ExtrudeGeometry(shape,{depth,steps:1,bevelEnabled:true,bevelThickness:.0006,bevelSize:.0006,bevelSegments:1});geo.rotateX(angle);geo.translate(x,y,z);add(geo);
 };
 if(optic==='iron'){
  box(0,.0734,.005,.020,.006,.025);box(0,.0814,.008,.015,.010,.010);
  hollow([{z:.006,outer:.0058,inner:.003},{z:.013,outer:.0058,inner:.003}],0,.092601);
  box(0,.0734,-.242,.018,.006,.018);box(0,.0836,-.242,.009,.014,.007);
  box(0,.089601,-.242,.0018,.006,.002,hardware);
  for(const x of [-.0043,.0043])box(x,.092601,.01315,.0014,.0014,.0003,green);
 }else{
  const c=rebuiltSightCenters[optic],front=optic==='acog'?-.217:optic==='holo'?-.168:optic==='reddot'?-.162:-.127,back=-.08,depth=back-front;
  // Flat mounting sole seats on rail teeth; side clamps wrap the rail shoulders.
  box(0,.0734,(front+back)/2,.026,.006,depth);
  for(const x of [-.016,.016]){box(x,.0712,(front+back)/2,.005,.009,Math.min(.060,depth));box(x,.078,(front+back)/2,.005,.007,.012,hardware);}
  if(optic==='holo'){
   box(0,.089,-.141,.051,.026,.049);box(0,.102,-.140,.045,.002,.043);
   frame([[-.023,-.018],[-.023,.012],[-.016,.019],[.016,.019],[.023,.012],[.023,-.018]],[[-.0175,-.0135],[.0175,-.0135],[.0175,.009],[.013,.0135],[-.013,.0135],[-.0175,.009]],.022,0,c.y,-.121);
   for(const x of [-.022,.022])cylinder(x,.103,-.147,.003,.003);
  }else if(optic==='reddot'){
   box(0,.084,-.128,.025,.019,.060);
   hollow([{z:-.157,outer:.0137,inner:.0095},{z:c.z+.001,outer:.0137,inner:.0095}],c.x,c.y);
   cylinder(.014,.111,-.129,.010,.016);cylinder(c.x,.133,-.133,.005,.005);
  }else if(optic==='reflex'){
   box(0,.087,-.107,.028,.021,.033);box(.011,.095,-.091,.007,.009,.014,hardware);
   frame([[-.016,-.013],[.016,-.013],[.010,.013],[-.010,.013]],[[-.0104,-.0093],[-.0065,.0093],[.0065,.0093],[.0104,-.0093]],.004,c.x,c.y,c.z-.003,-.085);
  }else{
   box(0,.085,-.152,.029,.022,.091);
   hollow([{z:-.229,outer:.0215,inner:.019},{z:-.205,outer:.024,inner:.0215},{z:-.140,outer:.017,inner:.0135},{z:c.z+.001,outer:.016,inner:.0125}],c.x,c.y);
   cylinder(c.x,.136,-.149,.008,.009);cylinder(.020,.115,-.150,.006,.014);
   const guide=new THREE.CylinderGeometry(.0018,.0018,.101,12);guide.rotateX(Math.PI/2);guide.translate(c.x,.143,-.149);add(guide,fiber);
  }
  const lensGeo=optic==='holo'?new THREE.PlaneGeometry(.035,.027):optic==='reflex'?(()=>{const s=new THREE.Shape();s.moveTo(-.0104,-.0093);s.lineTo(.0104,-.0093);s.lineTo(.0065,.0093);s.lineTo(-.0065,.0093);s.closePath();return new THREE.ShapeGeometry(s);})():new THREE.CircleGeometry(optic==='acog'?.0125:.0095,32);
  const lens=new THREE.Mesh(lensGeo,glass);lens.name='Rebuilt Rear Lens';lens.position.set(c.x,c.y,c.z);if(optic==='reflex')lens.rotation.x=-.085;lens.userData.sharedGeometry=true;root.add(lens);
 }
 for(const [mat,geos] of parts){const geometry=mergeGeometries(geos)!;geometry.computeVertexNormals();const mesh=new THREE.Mesh(geometry,mat);mesh.name=mat===dark?'Sight Housing':'Sight Hardware';mesh.userData.sharedGeometry=true;root.add(mesh);geos.forEach(g=>g.dispose());}
 root.userData.originalModel=true;root.userData.ready=true;templates.set(optic,root);return root;
}

export function rebuiltSight(optic:Sight|'iron',showReticle=false){
 const root=template(optic).clone(true);root.name='Original '+optic+' sight';
 if(optic!=='iron'){
  const c=rebuiltSightCenters[optic];root.userData.opticalCenter=[c.x,c.y,c.z];root.userData.mountY=c.mountY;
  if(showReticle){const lens=root.getObjectByName('Rebuilt Rear Lens') as THREE.Mesh,image=opticalReticle(reticleTexture(optic),optic,new THREE.Vector2(.5,.5));image.geometry.dispose();image.geometry=lens.geometry;image.userData.sharedGeometry=true;lens.add(image);root.userData.reticle=image;}
 }
 return root;
}

declare const __MAP_COMPARISON__: boolean;

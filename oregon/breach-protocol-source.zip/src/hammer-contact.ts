import * as THREE from 'three';
import type {Game,Device,Bot,Human} from './game';
import type {Panel} from './world';
import type {Drone} from './drone';
import {deviceRoot} from './devices';

export type HammerContact={object:THREE.Object3D,point:THREE.Vector3,panel?:Panel,device?:Device,drone?:Drone,scout?:{mesh:THREE.Mesh},human?:Human,bot?:Bot};
export function hammerContact(game:Game,origin:THREE.Vector3,direction:THREE.Vector3,range:number,ignore?:THREE.Object3D):HammerContact|null{
 const devices=[...new Set([...game.devices,...game.externalDevices])].filter(d=>d.mesh.visible&&d.type!=='destroyed'&&!(d.type==='gas'&&d.active));
 const drones=[...new Set([game.droneUnit,...game.externalDrones,...game.humans.map(h=>h.actor.droneUnit),...game.bots.flatMap(b=>b.drone?[b.drone]:[])])].filter(d=>d.alive&&d.deployed);
 const scouts=game.scouts.filter(s=>s.mesh.visible),actors=[...game.bots.filter(b=>b.hp>0).map(b=>b.mesh),...game.humans.filter(h=>(h.actor!==game||!!ignore)&&h.actor.hp>0).map(h=>h.mesh)].filter(o=>o!==ignore);
 const objects=[...devices.map(d=>d.mesh),...drones.map(d=>d.mesh),...scouts.map(s=>s.mesh),...actors];for(const o of objects)o.updateWorldMatrix(true,true);
 const ray=new THREE.Raycaster(origin,direction,0,range),hits=[...game.world.trace(origin,direction,range,true),...ray.intersectObjects(objects,true).filter(h=>h.object.userData.hitbox||h.object.userData.droneUnit||deviceRoot(h.object)||scouts.some(s=>s.mesh===h.object))].sort((a,b)=>a.distance-b.distance);
 const hit=hits[0];if(!hit)return null;
 const device=devices.find(d=>d.mesh===deviceRoot(hit.object)),drone=hit.object.userData.droneUnit as Drone|undefined,scout=scouts.find(s=>s.mesh===hit.object),panel=hit.object.userData.panel as Panel|undefined,human=hit.object.userData.hitbox?hit.object.userData.human as Human|undefined:undefined,bot=hit.object.userData.hitbox?hit.object.userData.bot as Bot|undefined:undefined;
 return {object:device?.mesh??drone?.mesh??scout?.mesh??human?.mesh??bot?.mesh??panel?.mesh??hit.object,point:hit.point.clone(),panel,device,drone,scout,human,bot};
}
// Prototype direct-hit tuning; no dated Y9S4 damage value has been verified.
export const hammerActorDamage=200;
// Evaluate only after a successful strike: downing and custom nonlethal damage cost one.
export function hammerDurabilityCost(hit:HammerContact){
 const actor=hit.human?.actor??hit.bot;return actor&&actor.hp<=0?2:1;
}
export function canHammerContact(game:Game,hit:HammerContact,team=game.team){
 const actor=hit.human?.actor??hit.bot;
 if(actor)return game.phase==='action'&&actor.hp>0&&(actor.team!==team||!!game.rules.friendlyFire);
 return !!(hit.device||hit.drone||hit.scout||hit.panel&&(hit.panel.mesh.userData.securityId!==undefined||game.world.canBreach(hit.panel,'hammer')));
}
export function strikeHammerContact(game:Game,hit:HammerContact,owner=game.actorId,team=game.team){
 if(!game.authority||!canHammerContact(game,hit,team))return false;
 if(hit.human){if(!hit.human.actor.takeDamage(hammerActorDamage,owner,team))return false;}
 else if(hit.bot){const hp=hit.bot.hp;game.damageBot(hit.bot,hammerActorDamage,owner,team);if(hit.bot.hp===hp)return false;}
 else if(hit.device){hit.device.mesh.visible=false;hit.device.active=false;hit.device.type='destroyed';hit.device.flightVelocity=undefined;}
 else if(hit.drone)hit.drone.destroy();else if(hit.scout)hit.scout.mesh.visible=false;
 else if(hit.panel?.mesh.userData.securityId!==undefined){hit.panel.broken=true;hit.panel.hp=0;hit.panel.mesh.visible=false;}
 else if(!hit.panel||!game.world.breach(hit.panel,'hammer',hit.point))return false;
 game.emitSound('hammer',hit.point,.5);if(!hit.human&&!hit.bot)game.emitSound('breach',hit.point,.7);return true;
}

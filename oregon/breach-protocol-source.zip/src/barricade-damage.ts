/** Candidate resistance from dated Y9S4 player reports (17 February 2025).
 * Selected-version footage comparison remains pending; these are not certified Siege values. */
export const barricadeResistance={health:100,bullet:5,melee:34,shotgunPellet:5,shotgunMaximum:50,meleeInterval:.55} as const;
export type BarricadeImpact={point:import('three').Vector3,distance:number};

export type HitRegion='head'|'torso'|'arms'|'legs';
export type DamageContact={region?:HitRegion,point?:number[],weapon?:number,penetrated?:boolean};
export type RecordedDamage=DamageContact&{t:number,attacker:string,victim:string,amount:number,healthLoss:number};
export function contactFromHit(hit:{object:{userData:Record<string,any>},point:{toArray:()=>number[]}},weapon:number,penetrated:boolean):DamageContact{
 const region=hit.object.userData.hitRegion as HitRegion|undefined;
 return {region,point:hit.point.toArray(),weapon,penetrated};
}
export function damageTotals(events:RecordedDamage[]){
 const totals={head:0,torso:0,arms:0,legs:0,unlocalized:0,penetrated:0};
 for(const e of events){totals[e.region??'unlocalized']+=e.amount;if(e.penetrated)totals.penetrated+=e.amount;}
 return totals;
}
/** A five-second break ends an encounter; include every recorded attacker. */
export function lethalEncounter(events:RecordedDamage[],victim:string,endingAt:number){
 const selected:RecordedDamage[]=[];let last=endingAt;
 for(let i=events.length-1;i>=0;i--){const event=events[i];if(event.victim!==victim||event.t>endingAt)continue;if(last-event.t>5)break;selected.push(event);last=event.t;}
 return selected.reverse();
}

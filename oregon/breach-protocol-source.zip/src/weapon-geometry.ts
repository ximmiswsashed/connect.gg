// Receiver-space dimensions in metres. Visual muzzle and obstruction rays share these points.
// Legacy profiles are retained until each procedural weapon has been rebuilt and measured.
export const weaponMuzzle=(weapon:number):[number,number,number]=>[
 [0,.046,-.303*.95],[0,.025,-.580],[0,.010,-.250],
 [0,.012,-.500],[0,.018,-.240],[0,.014,-.126],
][weapon] as [number,number,number];
export const ironHeight=(weapon:number)=>weapon===0?.092601:weapon===1?.057:weapon===5?.037:weapon===4?.050:weapon===3?.070:weapon===2?.053:.132;
export const magazineExtraction=(weapon:number)=>weapon===5?{down:.13,left:.06}:weapon===4?{down:.18,left:.08}:weapon===3?{down:.20,left:.09}:weapon===2?{down:.18,left:.06}:{down:.25,left:.10};
export const shotgunPumpStroke=(remaining:number)=>remaining>0?Math.sin(Math.PI*Math.max(0,Math.min(1,((1-remaining/.48)-.12)/.76)))*.075:0;

// Grip-fed magazines clear the firing fingers vertically before canting sideways.
export function magazineReloadMotion(weapon:number,p:number){const out=p<.22?p/.22:p<.58?1:p<.78?1-(p-.58)/.2:0,travel=magazineExtraction(weapon),t=Math.max(0,Math.min(1,(out-.7)/.3)),side=weapon===2?t*t*(3-2*t):out;return {out,left:side*travel.left,down:out*travel.down,angle:-side*.35};}

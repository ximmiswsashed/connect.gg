import * as THREE from 'three';
import type {Game,Bot,Device} from './game';
import type {Panel} from './world';
import {botPosture,turnBot} from './ai-posture';
import {hammerSeconds,hammerImpactSeconds,hammerReach} from './breaching-hammer';
import {fireBreachingLauncher,launcherDrawSeconds,launcherTrajectory} from './breaching-launcher';
import {deviceMesh} from './devices';
import {planBreachRetreat,startBreachRetreat,updateBreachRetreat} from './breach-retreat';
import {breachingRoundFuseSeconds} from './breaching-round';
import {hammerContact,canHammerContact,strikeHammerContact,hammerDurabilityCost} from './hammer-contact';
import {jammerRadius,pendingCharge} from './gadget-effects';
import {visualSight} from './visual-sight';

const eye=(b:Bot)=>b.pos.clone().add(new THREE.Vector3(0,botPosture(b).eye,0));
const face=(b:Bot)=>new THREE.Vector3(-Math.sin(b.mesh.rotation.y)*Math.cos(b.pitch??0),Math.sin(b.pitch??0),-Math.cos(b.mesh.rotation.y)*Math.cos(b.pitch??0));
export function botBreaching(b:Bot){return !!b.breachRetreat||(b.hammerSwing??0)>0||!!b.launcherEquipped||(b.chargeHold??0)>0||(b.breachWait??0)>0;}
export function cancelBotBreach(b:Bot){b.breachRetreat=false;delete b.mesh.userData.breachRetreat;delete b.mesh.userData.hammerObject;delete b.mesh.userData.supportCharge;delete b.mesh.userData.supportEscape;b.hammerSwing=0;b.hammerHit=false;b.hammerTarget=null;b.launcherEquipped=false;b.launcherDraw=0;b.chargeHold=0;b.breachWait=0;b.breachPanel=undefined;b.breachPoint=undefined;b.breachStart=undefined;}
function checkedPanel(game:Game,b:Bot,range:number){const origin=eye(b),hit=game.world.trace(origin,face(b),range,true)[0];return hit?.object.userData.panel===b.breachPanel?hit:null;}
// Called only for the current tactical cursor, after enemy perception. A nearby
// visible jammer blocking a teammate's pending charge is worth a support strike.
export function considerBotJammerClearance(game:Game,b:Bot,dt:number){
 if(!game.authority||game.phase!=='action'||b.team!==0||b.operator!==2||b.hp<=0||(b.gadgetCharges??0)<=0||botBreaching(b)||(b.breachCooldown??0)>0)return false;
 const state=b.mesh.userData,devices=[...game.devices,...game.externalDevices];
 state.utilitySense=Math.max(0,(state.utilitySense??0)-dt);
 if(state.utilitySense===0){
  state.utilitySense=.25;
  const charges=devices.filter(d=>d.type==='charge'&&d.mesh.visible&&!d.active&&d.team===b.team);
  state.utilityTarget=devices.filter(d=>d.type==='jammer'&&d.mesh.visible&&d.team!==b.team&&d.pos.distanceTo(b.pos)<1.2&&visualSight(game,eye(b),d.pos)&&charges.some(c=>c.pos.distanceToSquared(d.pos)<jammerRadius*jammerRadius)).sort((a,c)=>a.pos.distanceToSquared(b.pos)-c.pos.distanceToSquared(b.pos))[0];
 }
 const device=state.utilityTarget as Device|undefined;
 if(!device||!device.mesh.visible||device.type!=='jammer'||device.pos.distanceTo(b.pos)>=1.2||!visualSight(game,eye(b),device.pos)||!devices.some(c=>c.type==='charge'&&c.mesh.visible&&!c.active&&c.team===b.team&&c.pos.distanceToSquared(device.pos)<jammerRadius*jammerRadius))return false;
 const floor=game.world.ground(b.pos.x,b.pos.z,b.pos.y,.02)+.015;
 if(Math.abs(floor-b.pos.y)>.08)return false;
 const origin=eye(b),delta=device.pos.clone().sub(origin),yaw=Math.atan2(-delta.x,-delta.z);
 if(Array.from({length:9},(_,i)=>game.postureBlocked(b.pos,THREE.MathUtils.lerp(b.stanceAmount??0,1,i/8),yaw)).some(Boolean))return false;
 b.stance='crouch';b.stanceAmount=THREE.MathUtils.damp(b.stanceAmount??0,1,12,dt);b.aiming=false;
 turnBot(game,b,THREE.MathUtils.clamp(THREE.MathUtils.euclideanModulo(yaw-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI,-dt*2.4,dt*2.4));
 if(b.brain)b.brain.mode='clear-jammer';
 const aim=device.pos.clone().sub(eye(b));b.pitch=Math.atan2(aim.y,Math.hypot(aim.x,aim.z));
 if(Math.abs(THREE.MathUtils.euclideanModulo(yaw-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI)>.01||b.stanceAmount<.95)return true;
 const hit=hammerContact(game,eye(b),face(b),hammerReach(b.stanceAmount,b.pitch),b.mesh);
 if(!hit||hit.device!==device||!canHammerContact(game,hit,b.team))return false;
 const charge=devices.find(c=>c.type==='charge'&&c.mesh.visible&&!c.active&&c.team===b.team&&c.pos.distanceToSquared(device.pos)<jammerRadius*jammerRadius)!;
 const escape=planBreachRetreat(game,b,charge);if(!escape){b.breachCooldown=.5;return false;}state.supportCharge=charge;state.supportEscape=escape;
 b.breachPanel=undefined;b.breachPoint=undefined;b.breachStart=b.pos.clone();b.hammerSwing=hammerSeconds;b.hammerHit=false;b.hammerTarget=hit.point;state.hammerObject=hit.object;
 return true;
}
export function considerPathBreach(game:Game,b:Bot,next:THREE.Vector3,dt:number){
 if(!game.authority||game.phase!=='action'||b.team!==0||(b.gadgetCharges??0)<=0||![0,2,3].includes(b.operator??-1)||(b.breachCooldown??0)>0||b.breachDevice?.mesh.visible||b.operator===3&&pendingCharge([...game.devices,...game.externalDevices],'bot:'+b.id))return false;
 const state=b.mesh.userData;state.breachSense=Math.max(0,(state.breachSense??0)-dt);if(state.breachSense>0)return false;state.breachSense=.15;
 const origin=eye(b),direction=next.clone().add(new THREE.Vector3(0,botPosture(b).eye,0)).sub(origin),hit=game.world.trace(origin,direction.clone().normalize(),Math.min(2.8,direction.length()+.03),true)[0],panel=hit?.object.userData.panel;
 return !!panel&&hit!.distance<=(b.operator===0?2.8:1.3)&&beginBotBreach(game,b,panel);
}
export function beginBotBreach(game:Game,b:Bot,panel:Panel){
 if(!game.authority||game.phase!=='action'||b.team!==0||b.hp<=0||(b.gadgetCharges??0)<=0||botBreaching(b)||(b.breachCooldown??0)>0||b.breachDevice?.mesh.visible||b.operator===3&&pendingCharge([...game.devices,...game.externalDevices],'bot:'+b.id))return false;
 const tool=b.operator===0?'ash':b.operator===2?'hammer':b.operator===3?'thermite':null;if(!tool||!game.world.canBreach(panel,tool))return false;
 const origin=eye(b),target=origin.clone().clamp(panel.min,panel.max),d=target.clone().sub(origin),yaw=Math.atan2(-d.x,-d.z),pitch=Math.atan2(d.y,Math.hypot(d.x,d.z)),range=tool==='hammer'?hammerReach(b.stanceAmount??0,pitch):tool==='thermite'?2.8:60;
 if(d.length()>range||d.length()<.02)return false;
 const delta=THREE.MathUtils.euclideanModulo(yaw-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI;turnBot(game,b,delta);if(Math.abs(THREE.MathUtils.euclideanModulo(yaw-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI)>.01)return false;
 b.pitch=pitch;b.breachPanel=panel;if(!checkedPanel(game,b,range)){b.breachPanel=undefined;return false;}
 b.breachPoint=target;b.breachStart=b.pos.clone();b.aiming=false;
 if(tool==='hammer'){const hit=hammerContact(game,origin,face(b),range,b.mesh);if(!hit||!canHammerContact(game,hit,b.team)){cancelBotBreach(b);return false;}b.hammerSwing=hammerSeconds;b.hammerHit=false;b.hammerTarget=hit.point;b.mesh.userData.hammerObject=hit.object;}
 if(tool==='ash'){b.launcherEquipped=true;b.launcherDraw=launcherDrawSeconds;b.launcherReload??=0;b.launcherShot??=0;}
 if(tool==='thermite'){b.chargeHold=2.5;game.emitSound('gadget',origin,.18);}
 return true;
}
export function updateBotBreaches(game:Game,dt:number){
 if(!game.authority)return;
 // Every committed action advances independently of the tactical decision cursor.
 for(const b of game.bots){
  b.breachCooldown=Math.max(0,(b.breachCooldown??0)-dt);let startedRetreat=false;
  if(b.hp<=0||b.team!==0||game.phase!=='action'||b.breachRetreat&&b.operator!==((b.mesh.userData.breachRetreat?.device.type==='round')?0:3)&&!(b.operator===2&&b.mesh.userData.supportCharge===b.mesh.userData.breachRetreat?.device)||(b.hammerSwing??0)>0&&b.operator!==2||b.launcherEquipped&&b.operator!==0||(b.chargeHold??0)>0&&b.operator!==3){cancelBotBreach(b);continue;}
  if(botBreaching(b)){
   const floor=game.world.ground(b.pos.x,b.pos.z,b.pos.y,.02)+.015;
   if(b.pos.y>floor+.06){const speed=(b.mesh.userData.fallSpeed??0)-9.8*dt;b.mesh.userData.fallSpeed=speed;const y=Math.max(floor,b.pos.y+speed*dt);if(!game.world.collide(b.pos.x,y,b.pos.z,.27,botPosture(b).height))b.pos.y=y;}else b.mesh.userData.fallSpeed=0;
   b.mesh.position.copy(b.pos);
  }
  if(b.breachStart&&b.pos.distanceTo(b.breachStart)>.15){cancelBotBreach(b);b.breachCooldown=.5;continue;}
  if((b.hammerSwing??0)>0){
   b.hammerSwing=Math.max(0,b.hammerSwing!-dt);
   if(!b.hammerHit&&b.hammerSwing<=hammerSeconds-hammerImpactSeconds){const hit=hammerContact(game,eye(b),face(b),hammerReach(b.stanceAmount??0,b.pitch??0),b.mesh);if(hit&&hit.object===b.mesh.userData.hammerObject&&(b.gadgetCharges??0)>0&&strikeHammerContact(game,hit,'bot:'+b.id,b.team)){b.hammerHit=true;b.hammerTarget=hit.point;b.gadgetCharges=Math.max(0,b.gadgetCharges!-hammerDurabilityCost(hit));}else{cancelBotBreach(b);b.breachCooldown=.5;}}
   if(b.hammerSwing===0){b.breachPanel=undefined;b.breachPoint=undefined;b.breachStart=undefined;if(b.brain)b.brain.decision=0;}
  }
  const supported=b.mesh.userData.supportCharge as Device|undefined;
  if(supported&&!supported.mesh.visible){delete b.mesh.userData.supportCharge;delete b.mesh.userData.supportEscape;}
  else if(supported?.active&&!b.breachRetreat&&!(b.hammerSwing!>0)){const escape=planBreachRetreat(game,b,supported)??b.mesh.userData.supportEscape;startBreachRetreat(b,supported,escape);b.breachStart=undefined;startedRetreat=true;}
  if(b.launcherEquipped){
   b.launcherDraw=Math.max(0,(b.launcherDraw??0)-dt);b.launcherReload=Math.max(0,(b.launcherReload??0)-dt);
   if(b.launcherDraw===0&&b.launcherReload===0&&(b.breachWait??0)===0){
    const p=b.breachPanel,hit=p?checkedPanel(game,b,60):null;if(!p||!hit||!game.world.canBreach(p,'ash')){cancelBotBreach(b);b.breachCooldown=.5;continue;}
    const actor={authority:game.authority,launcherEquipped:true,operator:0,hp:b.hp,downed:false,observing:false,launcherDraw:0,launcherReload:0,gadgetCount:b.gadgetCharges??0,phase:game.phase,team:b.team,face:()=>face(b),world:game.world,eye:()=>eye(b),yaw:b.mesh.rotation.y,pitch:b.pitch??0,lean:0,recoilPitch:0,recoilYaw:0,adsProgress:0,stanceAmount:b.stanceAmount??0,devices:game.devices,externalDevices:game.externalDevices,droneUnit:game.droneUnit,externalDrones:game.externalDrones,humans:game.humans,bots:game.bots,scouts:game.scouts,actorId:'bot:'+b.id,launcherShot:b.launcherShot??0,emitSound:game.emitSound.bind(game),tell:()=>{}};
    const impact=launcherTrajectory(actor).pos,escape=planBreachRetreat(game,b,{type:'round',pos:impact,mesh:p.mesh,time:breachingRoundFuseSeconds,active:false});if(!escape){cancelBotBreach(b);b.breachCooldown=.5;continue;}
    if(fireBreachingLauncher(actor)){const round=game.devices.at(-1)!;b.gadgetCharges=actor.gadgetCount;b.launcherReload=actor.launcherReload;b.launcherShot=actor.launcherShot;b.breachWait=Math.max(.2,round.time)+breachingRoundFuseSeconds;b.breachStart=undefined;startBreachRetreat(b,round,escape);startedRetreat=true;}
    else cancelBotBreach(b);
   }else if((b.breachWait??0)>0){b.breachWait=Math.max(0,b.breachWait!-dt);if(b.breachWait===0){b.launcherEquipped=false;b.breachPanel=undefined;b.breachPoint=undefined;b.breachStart=undefined;if(b.brain)b.brain.decision=0;}}
  }else if((b.launcherReload??0)>0)b.launcherReload=Math.max(0,b.launcherReload!-dt);
  if((b.chargeHold??0)>0){
   b.chargeHold=Math.max(0,b.chargeHold!-dt);const p=b.breachPanel;
   if(!p||!game.world.canBreach(p,'thermite')){cancelBotBreach(b);b.breachCooldown=.5;continue;}
   if(b.chargeHold===0){const hit=checkedPanel(game,b,2.8);if(!hit||(b.gadgetCharges??0)<=0||pendingCharge([...game.devices,...game.externalDevices],'bot:'+b.id)){cancelBotBreach(b);b.breachCooldown=.5;continue;}const pos=hit.point.clone(),mesh=deviceMesh('charge');mesh.position.copy(pos);mesh.lookAt(eye(b));game.world.scene.add(mesh);const device={type:'charge',pos,mesh,time:3,active:false,team:b.team,owner:'bot:'+b.id,panelId:game.world.panels.indexOf(p)};game.devices.push(device);b.breachDevice=device;b.gadgetCharges!--;game.emitSound('device-place',pos,.25);b.breachPanel=undefined;b.breachPoint=undefined;b.breachStart=undefined;}
  }
  const charge=b.breachDevice;
  let ignited=false;
  if(charge){if(!charge.mesh.visible){b.breachDevice=undefined;if(b.brain)b.brain.decision=0;}else if(!charge.active&&!game.jammed(charge.pos)&&game.world.canBreach(game.world.panels[charge.panelId!],'thermite')){
   b.mesh.userData.retreatDecision=Math.max(0,(b.mesh.userData.retreatDecision??0)-dt);
   if(b.mesh.userData.retreatDecision===0){b.mesh.userData.retreatDecision=.5;const path=planBreachRetreat(game,b,charge);if(path){charge.active=true;charge.time=3;startBreachRetreat(b,charge,path);game.emitSound('charge-ignite',charge.pos,.4);ignited=true;}}
  }}
  if(!ignited&&!startedRetreat)updateBreachRetreat(game,b,dt);
 }
}

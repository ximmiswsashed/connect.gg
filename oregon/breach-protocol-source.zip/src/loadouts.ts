// Deliberate custom loadout: Vigil carries SMG-12 as primary; all operators carry USP-style.
export const secondaryWeapon=5;
export const operatorWeapons=[[0],[1],[1],[3],[4,1],[2]];
export function eligible(op:number,weapon:number){return Number.isInteger(op)&&!!operatorWeapons[op]?.includes(weapon);}
export function validatedWeapon(op:number,weapon:number){return eligible(op,weapon)?weapon:operatorWeapons[op]?.[0]??0;}
export function isSecondaryOnly(op:number){return false;}

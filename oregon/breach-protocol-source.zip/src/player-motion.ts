import * as THREE from 'three';
import type {World} from './world';
import type {MovementState,Stance} from './movement';
// Shared receiver/body/camera coordinates. These dimensions retain prototype scale;
// they are not advertised as measured Y10S3 distances.
export const leanPose={distance:.48,eyeDrop:.10,cameraRoll:.20,bodyShift:.32,bodyRoll:.45,headCounterRoll:.25,headRadius:.18,response:14};
export const operatorSpeedTier=[3,2,1,2,1,3] as const;
// Relative tier tuning is provisional; absolute travel-time evidence is still required.
export const operatorMobility=(operator:number)=>[.90,1,1.05][(operatorSpeedTier[operator]??2)-1];
export function dampLean(value:number,velocity:number,target:number,dt:number){const w=leanPose.response,y=value-target,j=velocity+w*y,e=Math.exp(-w*dt);return {value:target+(y+j*dt)*e,velocity:(velocity-w*j*dt)*e};}
export function leanedEye(base:THREE.Vector3,yaw:number,lean:number,forward=0){return base.clone().add(new THREE.Vector3(Math.cos(yaw)*lean*leanPose.distance-Math.sin(yaw)*forward,-Math.abs(lean)*leanPose.eyeDrop,-Math.sin(yaw)*lean*leanPose.distance-Math.cos(yaw)*forward));}
export function limitLean(world:World,base:THREE.Vector3,yaw:number,value:number,forward=0){
 if(Math.abs(value)<1e-8)return 0;
 const center=leanedEye(base,yaw,0,forward),clear=(amount:number)=>{const end=leanedEye(base,yaw,amount,forward),delta=end.clone().sub(center),length=delta.length();return !world.collide(end.x,end.y-leanPose.headRadius,end.z,leanPose.headRadius,leanPose.headRadius*2)&&(!length||!world.sweepSphere(center,delta.normalize(),length,leanPose.headRadius));};
 if(clear(value))return value;let lo=0,hi=Math.abs(value);for(let i=0;i<10;i++){const m=(lo+hi)/2;if(clear(Math.sign(value)*m))lo=m;else hi=m;}return Math.sign(value)*lo;
}
export function movementState(a:{observing:boolean,vault:boolean,action:number,actionKind:string,gadget:number,reload:number,rappel:boolean,sprint:boolean,slow:boolean,stance:Stance,moving:boolean}):MovementState{
 if(a.observing)return 'observation';if(a.vault)return 'vault';if(a.action>0)return a.actionKind==='plant'?'plant':a.actionKind==='disable'?'disable':a.actionKind==='reinforce'||a.actionKind==='barricade'?'reinforce':'gadget';if(a.gadget>0)return 'gadget';if(a.reload>0)return 'reload';if(a.rappel)return 'rappel';if(a.sprint)return 'sprint';if(a.slow&&a.stance==='stand')return 'slow';return !a.moving&&a.stance==='stand'?'idle':a.stance;
}

import * as THREE from 'three';
import type {Game,Bot} from './game';
import {sites} from './data';

export const playstyles={
  roamer:{speed:2.6,patrolRadius:7,hold:2.5,coverChance:.35,aimLag:.18},
  anchor:{speed:1.65,patrolRadius:1.5,hold:7,coverChance:.9,aimLag:.25},
  support:{speed:2,patrolRadius:2.5,hold:3.5,coverChance:.75,aimLag:.23},
  breacher:{speed:2.2,patrolRadius:3,hold:3,coverChance:.55,aimLag:.2},
};
export function style(b:Bot){return playstyles[b.role??(b.team===1?'anchor':'breacher')];}

export function patrolGoal(game:Game,b:Bot){
 const objective=game.objectiveState;
 if(objective.planted){b.brain!.mode=b.team===1?'retake':'guard';return objective.position.clone();}
 if(objective.dropped&&b.team===0){b.brain!.mode='recover';return objective.dropped.clone();}
 const profile=style(b),site=sites[game.site];
 let center=game.world.point(b.id%2?site.a:site.b,site.floor);
 // Carrying the case overrides a support/roamer preference to follow teammates.
 if(b.team===0&&objective.carrier==='bot:'+b.id){b.brain!.mode='advance';return game.world.safeSpawn(center);}
 if(b.role==='support'){
  const mates=[...game.bots.filter(a=>a!==b&&a.team===b.team&&a.hp>0).map(a=>a.pos),...[game,...game.humans.map(h=>h.actor)].filter(a=>a.team===b.team&&a.hp>0).map(a=>a.pos)];
  const mate=mates.sort((a,c)=>a.distanceToSquared(b.pos)-c.distanceToSquared(b.pos))[0];
  if(mate)center=mate.clone();
  b.brain!.mode='support';
 }else b.brain!.mode=b.team===0?'advance':b.role==='roamer'?'patrol':'hold';
 // Anchors settle on a single home point instead of changing position every decision.
 if(b.role==='anchor'&&b.mesh.userData.aiHome)return (b.mesh.userData.aiHome as THREE.Vector3).clone();
 const angle=(b.id*.618+Math.random())*Math.PI*2,radius=profile.patrolRadius*(.4+Math.random()*.6);
 const goal=center.clone().add(new THREE.Vector3(Math.cos(angle)*radius,0,Math.sin(angle)*radius));game.world.safeSpawn(goal);
 if(b.role==='anchor')b.mesh.userData.aiHome=goal.clone();
 return goal;
}

export function trackAim(b:Bot,target:THREE.Vector3,dt:number,error:number,fresh:boolean){
 const data=b.mesh.userData;
 data.aimSampleTime=(data.aimSampleTime??0)-dt;
 if(fresh||data.aimSampleTime<=0){data.aimSample=target.clone();data.aimSampleTime=.12+Math.random()*.08;}
 data.aimErrorTime=(data.aimErrorTime??0)-dt;
 if(fresh||data.aimErrorTime<=0){const range=target.distanceTo(b.pos);data.aimError=new THREE.Vector3((Math.random()-.5)*error*range,(Math.random()-.5)*error*range,(Math.random()-.5)*error*range);data.aimErrorTime=.35+Math.random()*.25;}
 const desired=(data.aimSample as THREE.Vector3).clone().add(data.aimError as THREE.Vector3);
 // Start along the current barrel orientation: target switching cannot teleport the aim.
 if(!data.aiAim)data.aiAim=b.pos.clone().add(new THREE.Vector3(-Math.sin(b.mesh.rotation.y)*8,1.1,-Math.cos(b.mesh.rotation.y)*8));
 const aim=data.aiAim as THREE.Vector3;aim.lerp(desired,1-Math.exp(-dt/style(b).aimLag));return aim;
}

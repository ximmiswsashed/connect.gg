import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {canisterHand,canisterWrist} from './gadget-hands';
import {handModel,gripPose,wristPose} from './weapon-pose';
import {deviceMesh} from './devices';
import {breachingRoundSpeed,breachingRoundRange,breachingRoundRear,breachingRoundFront,breachingRoundRadius} from './breaching-round';
import {roundUtilityContact,type UtilityScene} from './round-utility-contact';
import type {Game} from './game';

export const launcherDrawSeconds=.35,launcherReloadSeconds=1.1;
export function launcherModel(){
 const root=new THREE.Group(),parts=new Map<number,THREE.BufferGeometry[]>();
 const add=(color:number,g:THREE.BufferGeometry,p:THREE.Vector3)=>{g.translate(p.x,p.y,p.z);const batch=parts.get(color)??[];batch.push(g);parts.set(color,batch);};
 const box=(c:number,w:number,h:number,d:number,x:number,y:number,z:number)=>add(c,new THREE.BoxGeometry(w,h,d),new THREE.Vector3(x,y,z));
 const black=0x293237,green=0x68715a,steel=0x849092;
 box(green,.075,.10,.18,0,0,-.025);box(black,.038,.09,.045,0,-.065,.013);box(black,.10,.025,.09,0,-.088,-.03);box(black,.10,.018,.24,0,-.025,.17);box(green,.09,.13,.045,0,-.045,.28);
 add(green,new THREE.CylinderGeometry(.049,.049,.33,12,1,true).rotateX(Math.PI/2),new THREE.Vector3(0,.018,-.265));
 add(black,new THREE.CylinderGeometry(.056,.056,.18,12).rotateX(Math.PI/2),new THREE.Vector3(0,.018,-.20));
 // Open muzzle, front blade and rear notch remain part of the model, not a HUD reticle.
 add(steel,new THREE.TorusGeometry(.041,.008,6,12),new THREE.Vector3(0,.018,-.435));
 box(black,.026,.025,.024,0,.0735,-.39);box(black,.026,.032,.024,0,.094,-.39);box(steel,.006,.017,.012,0,.112,-.39);box(black,.04,.042,.027,0,.069,.045);
 for(const side of [-1,1])box(black,.007,.028,.025,side*.014,.105,.045);box(black,.035,.007,.025,0,.088,.045);
 for(const [color,geometries] of parts){const geometry=mergeGeometries(geometries)!;geometries.forEach(g=>g.dispose());root.add(new THREE.Mesh(geometry,new THREE.MeshLambertMaterial({color})));}
 return root;
}
export function disposeLauncher(root:THREE.Group){root.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();for(const m of Array.isArray(o.material)?o.material:[o.material])m.dispose();}});root.removeFromParent();}
export const launcherGrip=(side:number)=>side<0?new THREE.Vector3(-.068,.018,-.20):new THREE.Vector3(...gripPose(5).right);
export const launcherWrist=(side:number)=>side<0?canisterWrist(-1).multiplyScalar(.5).applyAxisAngle(new THREE.Vector3(1,0,0),Math.PI/2):new THREE.Vector3(...wristPose(5).right).sub(new THREE.Vector3(...gripPose(5).right));
export function launcherHand(side:number,sleeve=true){
 const root=new THREE.Group(),model=side<0?canisterHand(-1,false):handModel(1,5);
 if(side<0){model.scale.setScalar(.5);model.rotation.x=Math.PI/2;}else if(!sleeve){const cloth=model.children[1];if(cloth){model.remove(cloth);cloth.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();(o.material as THREE.Material).dispose();}});}}
 root.add(model);if(side<0&&sleeve){const from=launcherWrist(side),to=from.clone().add(new THREE.Vector3(-.09,-.10,.18)),delta=to.clone().sub(from),g=new THREE.CapsuleGeometry(.03,delta.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()));g.translate(...from.add(to).multiplyScalar(.5).toArray());root.add(new THREE.Mesh(g,new THREE.MeshLambertMaterial({color:0x526048})));}return root;
}
export function launcherPose(ads:number,draw:number,reload:number,stance=0){
 const drawBlend=THREE.MathUtils.smoothstep(draw/launcherDrawSeconds,0,1),cycle=reload>0?1-reload/launcherReloadSeconds:0,open=reload>0?Math.sin(Math.PI*cycle):0,prone=THREE.MathUtils.clamp(stance-1,0,1);
 return {position:new THREE.Vector3(.16*(1-ads),THREE.MathUtils.lerp(-.14,-.112,ads)-.12*drawBlend*(1-.8*prone),THREE.MathUtils.lerp(-.34+.11*prone,-.20,ads)),rotation:new THREE.Euler(-.28*drawBlend,0,-.10*open),supportOffset:new THREE.Vector3(-.07*open,-.07*open*(1-.8*prone),.11*open)};
}
export function launcherWorldPose(game:Pick<Game,'eye'|'yaw'|'pitch'|'lean'|'recoilPitch'|'recoilYaw'|'adsProgress'|'launcherDraw'|'launcherReload'|'stanceAmount'>&Partial<Pick<Game,'rappel'|'rappelInverted'>>){
 const camera=new THREE.Quaternion().setFromEuler(new THREE.Euler(game.pitch+game.recoilPitch,game.yaw+game.recoilYaw,game.rappel&&game.rappelInverted?Math.PI:-game.lean*.2,'YXZ')),pose=launcherPose(game.adsProgress,game.launcherDraw,game.launcherReload,game.stanceAmount);return {position:pose.position.applyQuaternion(camera).add(game.eye()),quaternion:camera.multiply(new THREE.Quaternion().setFromEuler(pose.rotation))};
}
type LauncherActor=Pick<Game,'authority'|'launcherEquipped'|'operator'|'hp'|'downed'|'observing'|'launcherDraw'|'launcherReload'|'gadgetCount'|'phase'|'team'|'face'|'world'|'eye'|'yaw'|'pitch'|'lean'|'recoilPitch'|'recoilYaw'|'adsProgress'|'stanceAmount'|'devices'|'actorId'|'launcherShot'|'emitSound'|'tell'>&UtilityScene;
export function launcherTrajectory(game:LauncherActor){
 // Eye aim chooses a focus; the physical muzzle ray can hit a closer obstruction.
 const eye=game.eye(),direction=game.face(),surface=game.world.trace(eye,direction,60,true)[0];
 const eyeUtility=roundUtilityContact(game,undefined,eye,direction,surface?.distance??60,0);
 const focus=eyeUtility&&(!surface||eyeUtility.distance<surface.distance-1e-9)?eyeUtility.point:surface?.point??eye.clone().addScaledVector(direction,60);
 const pose=launcherWorldPose(game),muzzle=new THREE.Vector3(0,.018,-.445).applyQuaternion(pose.quaternion).add(pose.position),near=muzzle.clone().sub(eye),neckDirection=near.clone().normalize();
 const obstruction=game.world.trace(eye,neckDirection,near.length(),true)[0]??roundUtilityContact(game,undefined,eye,neckDirection,near.length(),0);
 const from=obstruction?eye:muzzle,aim=obstruction?neckDirection:focus.clone().sub(from).normalize();
 // Match the live capsule sweep, so retreat planning uses the first physical impact rather than a farther eye-ray wall.
 const start=from.clone().addScaledVector(aim,-breachingRoundRear),length=breachingRoundRange+breachingRoundRear+breachingRoundFront;
 const hit=game.world.sweepSphere(start,aim,length,breachingRoundRadius),utility=roundUtilityContact(game,undefined,start,aim,hit?.distance??length,breachingRoundRadius);
 const utilityFirst=utility&&(!hit||utility.distance<hit.distance-1e-9),pos=utilityFirst?utility.point.clone():hit?.point.clone()??from.clone().addScaledVector(aim,breachingRoundRange);
 return {from,aim,hit:utilityFirst?undefined:hit,pos};
}
export function fireBreachingLauncher(game:LauncherActor){
 if(!game.authority||!game.launcherEquipped||game.operator!==0||game.hp<=0||game.downed||game.observing||game.launcherDraw>0||game.launcherReload>0||game.gadgetCount<=0||game.phase==='prep'&&game.team===0||!['prep','action'].includes(game.phase))return false;
 const {from,aim,hit,pos}=launcherTrajectory(game),mesh=deviceMesh('round');mesh.position.copy(from);mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,-1),aim);game.world.scene.add(mesh);
 const panel=hit?.object.userData.panel;game.devices.push({type:'round',pos,mesh,time:Math.max(.12,from.distanceTo(pos)/breachingRoundSpeed),active:true,roundDirection:aim.clone(),roundRange:breachingRoundRange,team:game.team,owner:game.actorId,panelId:panel?game.world.panels.indexOf(panel):-1});game.gadgetCount--;game.launcherReload=game.gadgetCount>0?launcherReloadSeconds:0;game.launcherShot++;game.emitSound('launcher',from,.5);game.tell(game.gadgetCount?'BREACH ROUND FIRED · RELOADING':'BREACH ROUND FIRED · EMPTY');return true;
}

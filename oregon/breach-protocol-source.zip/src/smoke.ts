import * as THREE from 'three';
import type {World} from './world';
import type {Game,Bot,Device} from './game';
import {deviceMesh,deviceScale} from './devices';
import {refreshGasCloud} from './gas-cloud';
import {advanceThrowable,throwHit,type Throwable} from './throwable';
import {botPosture,turnBot} from './ai-posture';

export const smokeThrowDuration=.55;
export const smokeReleaseTime=.32;
export function pendingSmoke(devices:Device[],owner:string){return devices.find(d=>d.type==='gas'&&!d.active&&d.mesh.visible&&d.time>0&&d.owner===owner)??null;}
export function smokeReleasePosition(world:World,eye:THREE.Vector3,direction:THREE.Vector3){
 const pos=eye.clone().addScaledVector(direction,.45).add(new THREE.Vector3(0,-.22,0));
 if(throwHit(world,eye,pos)||world.collide(pos.x,pos.y-.18,pos.z,.18,.36))return null;
 return pos;
}
export function throwSmoke(world:World,devices:Device[],eye:THREE.Vector3,direction:THREE.Vector3,team:number,owner:string){
 if(pendingSmoke(devices,owner))return null;
 const pos=smokeReleasePosition(world,eye,direction);if(!pos)return null;
 const mesh=deviceMesh('gas');mesh.position.copy(pos);world.scene.add(mesh);
 const device:Device={type:'gas',pos,mesh,time:1000,active:false,team,owner,flightVelocity:direction.clone().multiplyScalar(9).add(new THREE.Vector3(0,2,0)),attached:false};
 devices.push(device);return device;
}
export function releaseSmoke(world:World,device:Device){
 if(device.type!=='gas'||device.active||!device.mesh.visible||device.time<=0)return false;
 device.flightVelocity=undefined;device.active=true;device.time=10;deviceScale(device.mesh,'gas',true);refreshGasCloud(world,device.mesh,device.pos,true);return true;
}
export function smokeThrowPlan(world:World,eye:THREE.Vector3,target:THREE.Vector3){
 const flat=target.clone().sub(eye).setY(0),distance=flat.length();if(distance<2||distance>12)return null;flat.normalize();
 let pitch=0,error=Infinity;
 // Solve the low arc for the existing launch velocity, including its upward bias.
 for(let a=-.8;a<=.55;a+=.01){const t=(distance-.45*Math.cos(a))/(9*Math.cos(a)),y=eye.y-.22+.45*Math.sin(a)+(9*Math.sin(a)+2)*t-4.9*t*t,e=Math.abs(y-(target.y+.18));if(e<error){error=e;pitch=a;}}
 if(error>.15)return null;
 const direction=flat.multiplyScalar(Math.cos(pitch)).setY(Math.sin(pitch)),pos=eye.clone().addScaledVector(direction,.45).add(new THREE.Vector3(0,-.22,0));
 if(throwHit(world,eye,pos)||world.collide(pos.x,pos.y-.18,pos.z,.18,.36))return null;
 const preview:Throwable={pos,mesh:new THREE.Object3D(),flightVelocity:direction.clone().multiplyScalar(9).add(new THREE.Vector3(0,2,0))};
 // Use the same swept-volume physics to reject ceiling/wall impacts far from the target.
 for(let t=0;t<2&&preview.flightVelocity&&preview.mesh.visible;t+=.05)advanceThrowable(world,preview,.05);
 const victim=target.clone().add(new THREE.Vector3(0,.4,0));
 return preview.attached&&preview.pos.distanceTo(victim)<2.5&&world.sight(preview.pos,victim)?{direction,landing:preview.pos}:null;
}
export function smokeSafeForTeam(game:Game,b:Bot,pos:THREE.Vector3){
  const friends=[...game.bots.filter(a=>a!==b&&a.team===b.team&&a.hp>0&&a.operator!==1).map(a=>a.pos),...[game,...game.humans.map(h=>h.actor)].filter(a=>a.team===b.team&&a.hp>0&&a.operator!==1).map(a=>a.pos)];
  return !friends.some(p=>p.distanceTo(pos)<4.5&&game.world.sight(pos,p.clone().add(new THREE.Vector3(0,.4,0))));
}

export function cancelBotSmokeThrow(b:Bot){b.smokeThrow=0;b.smokeReleased=false;delete b.mesh.userData.pendingSmokeDirection;delete b.mesh.userData.pendingSmokeLanding;}
export function updateBotSmokeThrows(game:Game,dt:number){
 // Held action clocks are independent of the expensive tactical decision cursor.
 for(const b of game.bots){
  if(b.operator!==1||b.hp<=0||game.phase!=='action'){if((b.smokeThrow??0)>0)cancelBotSmokeThrow(b);continue;}
  const state=b.mesh.userData;state.smokeHandling=Math.max(0,(state.smokeHandling??0)-dt);state.smokeDecision=Math.max(0,(state.smokeDecision??0)-dt);
  if((b.smokeThrow??0)<=0)continue;
  b.smokeThrow=Math.max(0,b.smokeThrow!-dt);
  if(!b.smokeReleased&&b.smokeThrow<=smokeThrowDuration-smokeReleaseTime){
   const direction=b.mesh.userData.pendingSmokeDirection as THREE.Vector3|undefined,landing=b.mesh.userData.pendingSmokeLanding as THREE.Vector3|undefined;
   if(!direction||!landing||(b.gadgetCharges??0)<=0||!smokeSafeForTeam(game,b,landing)){cancelBotSmokeThrow(b);continue;}
   const eye=b.pos.clone().add(new THREE.Vector3(0,botPosture(b).eye,0)),device=throwSmoke(game.world,game.devices,eye,direction,b.team,'bot:'+b.id);
   if(!device){cancelBotSmokeThrow(b);continue;}
   b.gadgetCharges!--;b.smokeReleased=true;game.emitSound('gadget',device.pos,.18);
  }
  if(b.smokeThrow===0){delete b.mesh.userData.pendingSmokeDirection;delete b.mesh.userData.pendingSmokeLanding;}
 }
}
type VisibleTarget={team:number,hp:number,pos:THREE.Vector3};
export function updateBotSmoke(game:Game,b:Bot,target:VisibleTarget|null,acquired:boolean,dt=.1,turnAllowance=dt*2.4){
 const state=b.mesh.userData;
 if(b.operator!==1||b.team!==1||b.hp<=0||game.phase!=='action')return false;
 if((b.smokeThrow??0)>0||state.smokeHandling>0)return true;
 if(!target||target.team===b.team||target.hp<=0||!acquired||state.smokeDecision>0)return false;
 state.smokeDecision=1;
 const safe=(pos:THREE.Vector3)=>smokeSafeForTeam(game,b,pos);
 const owner='bot:'+b.id,pending=pendingSmoke(game.devices,owner);
 if(pending){
  if(pending.pos.distanceTo(target.pos)<4&&safe(pending.pos)&&game.world.sight(pending.pos,target.pos.clone().add(new THREE.Vector3(0,.4,0)))&&releaseSmoke(game.world,pending)){
   game.emitSound('gas-release',pending.pos,.35);state.smokeDecision=10;state.smokeHandling=.35;return true;
  }return false;
 }
 if((b.gadgetCharges??0)<=0||game.devices.some(d=>d.type==='gas'&&d.active&&d.mesh.visible&&d.pos.distanceTo(target.pos)<5&&game.world.sight(d.pos,target.pos.clone().add(new THREE.Vector3(0,.4,0)))))return false;
 // Deploy only after visual acquisition, when defending the site or under pressure.
 if(target.pos.distanceTo(game.objective)>12&&b.hp>=60&&!game.objectiveState.planted)return false;
 const eye=b.pos.clone().add(new THREE.Vector3(0,botPosture(b).eye,0)),plan=smokeThrowPlan(game.world,eye,target.pos);
 if(!plan||!safe(plan.landing))return false;
 // The weapon aim may have already spent this cursor's turn budget. Utility
 // alignment must use the remainder and the same prone clearance sweep.
 const yaw=Math.atan2(-plan.direction.x,-plan.direction.z),diff=THREE.MathUtils.euclideanModulo(yaw-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI;
 turnBot(game,b,THREE.MathUtils.clamp(diff,-turnAllowance,turnAllowance));
 if(Math.abs(THREE.MathUtils.euclideanModulo(yaw-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI)>.01)return false;
 b.smokeThrow=smokeThrowDuration;b.smokeReleased=false;state.pendingSmokeDirection=plan.direction.clone();state.pendingSmokeLanding=plan.landing.clone();
 b.pitch=Math.asin(plan.direction.y);b.aiming=false;
 return true;
}

import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {gripPose} from './weapon-pose';

type Sleeve = {mesh:THREE.Mesh,elbow:THREE.Vector3,side:number,offset:number,upper:THREE.BufferGeometry};
// First-person cuffs follow the hand, while the other end stays toward the body.
// Baked remote sleeves still meet the separate third-person arm IK.
export class ViewmodelSleeves {
 private sleeves:Sleeve[]=[];
 private endpoint=new THREE.Vector3();
 private direction=new THREE.Vector3();
 private center=new THREE.Vector3();
 private vertex=new THREE.Vector3();
 private rotation=new THREE.Quaternion();
 private axis=new THREE.Vector3(0,1,0);
 install(left:THREE.Group,right:THREE.Group,weapon:number){
  for(const sleeve of this.sleeves)sleeve.upper.dispose();
  this.sleeves=[];
  const grip=gripPose(weapon);
  const elbows=[{left:[-.151,-.117,.110],right:[.127,-.160,.326]},{left:[-.15,-.18,.03],right:[.15,-.20,.50]},{left:[-.15,-.155,.143],right:[.12,-.19,.288]},{left:[-.15,-.17,.02],right:[.12,-.19,.32]},{left:[-.15,-.19,.13],right:[.12,-.19,.32]},{left:[-.159,-.172,.251],right:[.104,-.145,.255]}][weapon];
  for(const [hand,side,key] of [[left,-1,'left'],[right,1,'right']] as const){
   const model=hand.children[0],mesh=model.children[1] as THREE.Mesh;
   const forearm=mesh.geometry,upper=new THREE.CylinderGeometry(.037,.030,1,8,8,false).toNonIndexed(),offset=forearm.attributes.position.count;
   if(forearm.getAttribute('color'))upper.setAttribute('color',new THREE.Float32BufferAttribute(new Float32Array(upper.attributes.position.count*3).fill(.9),3));const combined=mergeGeometries([forearm,upper]);if(!combined)throw Error('Sleeve vertex attributes do not match');mesh.geometry=combined;forearm.dispose();
   mesh.frustumCulled=false;
   mesh.userData.bodyCapVertices=Array.from({length:upper.attributes.position.count},(_,i)=>i).filter(i=>Math.abs(upper.attributes.position.getY(i)-.5)<1e-5).map(i=>i+offset);
   mesh.name='body-connected-sleeve';
   this.sleeves.push({mesh,side,offset,upper,elbow:new THREE.Vector3(...elbows[key]).sub(new THREE.Vector3(...grip[key]))});
  }
 }
 update(camera:THREE.Object3D){
  for(const sleeve of this.sleeves){
   const model=sleeve.mesh.parent!;
   // The shoulder-side cap remains behind the camera, even in inspection.
   this.endpoint.set(sleeve.side*.25,-.30,.10);
   camera.localToWorld(this.endpoint);model.worldToLocal(this.endpoint);
   this.direction.copy(this.endpoint).sub(sleeve.elbow);
   const length=this.direction.length();
   this.center.copy(sleeve.elbow).add(this.endpoint).multiplyScalar(.5);
   this.rotation.setFromUnitVectors(this.axis,this.direction.normalize());
   const source=sleeve.upper.attributes.position,sourceNormals=sleeve.upper.attributes.normal,positions=sleeve.mesh.geometry.attributes.position,normals=sleeve.mesh.geometry.attributes.normal;
   for(let i=0;i<source.count;i++){
    this.vertex.fromBufferAttribute(source,i);this.vertex.y*=length;this.vertex.applyQuaternion(this.rotation).add(this.center);positions.setXYZ(sleeve.offset+i,this.vertex.x,this.vertex.y,this.vertex.z);
    this.vertex.fromBufferAttribute(sourceNormals,i).applyQuaternion(this.rotation);normals.setXYZ(sleeve.offset+i,this.vertex.x,this.vertex.y,this.vertex.z);
   }
   positions.needsUpdate=normals.needsUpdate=true;
  }
 }
 dispose(){for(const sleeve of this.sleeves)sleeve.upper.dispose();this.sleeves=[];}
}

import {blendFov} from './aiming-profile';
import {leanPose} from './player-motion';
import * as THREE from 'three';
import type {Game} from './game';
import type {Panel} from './world';
import type {RecordedActor,RecordedPanel,ReplayClip} from './replay';
import {CharacterRig} from './characters';
import {WeaponView,adsFov,viewmodelFov,type Optic} from './optics';
import {deviceMesh,deviceScale,disposeDevice} from './devices';

type PoseModel=Parameters<CharacterRig['update']>[0]&{actualVelocity:THREE.Vector3,stanceAmount:number,pitch:number,gaitCycle:number,vaultProgress:number,vaultFrom:THREE.Vector3|null};
type Variant={rig:CharacterRig,model:PoseModel,vaultOrigin:THREE.Vector3,hammerPoint:THREE.Vector3,actionPoint:THREE.Vector3};
type PreparedSurface={geometry:THREE.BufferGeometry,material:THREE.Material|THREE.Material[],holes:{point:THREE.Vector3,radius:number}[],visible:boolean,health?:Uint8Array,removed:number,revision:number};
const emptyClip=():ReplayClip=>({id:'',duration:3.5,killer:'',victim:'',reason:'',winner:0,padded:0,frames:[]});
const weaponId=(pose:RecordedActor)=>pose.slot?(pose.secondary??5):pose.weapon;
const loadoutKey=(pose:RecordedActor)=>[weaponId(pose),pose.optic,pose.skin,pose.attachment].join(':');
const actorKey=(pose:RecordedActor)=>[pose.id,pose.op,loadoutKey(pose)].join(':');
const mix=THREE.MathUtils.lerp;
const angle=(a:number,b:number,t:number)=>a+(THREE.MathUtils.euclideanModulo(b-a+Math.PI,Math.PI*2)-Math.PI)*t;

/** One reusable playback scene. Static geometry/materials are borrowed; poses and cuts are owned. */
export class ReplayView{
 scene=new THREE.Scene();camera:THREE.PerspectiveCamera;weapon:WeaponView;clip:ReplayClip;
 rigs=new Map<string,CharacterRig>();panels=new Map<number,Panel>();devices=new Map<string,THREE.Mesh>();cursor=0;played=new Set<string>();proxy:Game;lastTime=-1;
 diagnostics={sceneBuilds:1,rigBuilds:0,weaponBuilds:0,deviceBuilds:0,maskUpdates:0,preparedSurfaces:0,prepareMs:0,warmMs:0,lastUpdateMs:0,cleanupMs:0};
 private viewmodelProjection=new THREE.Group();
 private variants=new Map<string,Variant>();private weaponViews=new Map<string,WeaponView>();
 private surfaces=new Map<RecordedPanel,PreparedSurface>();private applied=new Map<number,RecordedPanel>();private ownedGeometries=new Set<THREE.BufferGeometry>();
 private originals=new Map<number,THREE.BufferGeometry>();private staticCopies:{source:THREE.Mesh,copy:THREE.Mesh}[]=[];
 private warmTarget=new THREE.WebGLRenderTarget(1,1);private maskActive=false;private surfaceDirty=true;private audioPoint=new THREE.Vector3();private actorIds=new Set<string>();private disposed=false;
 effects=true;brightness=.8;reticleColor='#ff4234';reticleOpacity=1;
 constructor(public game:Game,clip?:ReplayClip){
  this.clip=emptyClip();this.scene.background=game.world.scene.background;this.scene.fog=game.world.scene.fog?.clone()??null;this.camera=new THREE.PerspectiveCamera(78,game.camera.aspect,.05,180);this.scene.add(this.camera);this.camera.add(this.viewmodelProjection);this.weapon=new WeaponView(this.camera);
  const actors=new Set([...game.humans.map(h=>h.mesh),...game.bots.map(b=>b.mesh),game.droneUnit.mesh,...game.externalDrones.map(d=>d.mesh),...game.devices.map(d=>d.mesh),...game.externalDevices.map(d=>d.mesh),game.camera]);
  game.world.scene.updateMatrixWorld(true);const panelIds=new Map(game.world.panels.map((p,id)=>[p,id]));
  game.world.scene.traverse(o=>{
   let parent:THREE.Object3D|null=o,visible=true;while(parent){if(actors.has(parent as THREE.Group))return;visible&&=parent.visible;parent=parent.parent;}
   if(o instanceof THREE.Light){this.scene.add(o.clone());return;}if(o.userData.cameraLens||!(o instanceof THREE.Mesh)||o instanceof THREE.SkinnedMesh)return;
   const panel=o.userData.panel as Panel|undefined,mutable=panel&&(panel.kind!=='solid'||o.userData.securityId!==undefined);
   if(o.userData.importedCollider)return;
   let copy:THREE.Mesh;
   if(o instanceof THREE.InstancedMesh){
    if(!o.userData.sourceMapBatch)return;
    // Object3D.clone JSON-serializes userData. Quality metadata contains entire
    // materials/textures, so copying a map batch that way serialized its atlas.
    const instance=new THREE.InstancedMesh(o.geometry,o.material,o.count);instance.instanceMatrix.array.set(o.instanceMatrix.array);instance.instanceMatrix.setUsage(o.instanceMatrix.usage);instance.instanceMatrix.needsUpdate=true;instance.instanceColor=o.instanceColor?new THREE.InstancedBufferAttribute(o.instanceColor.array.slice(),o.instanceColor.itemSize,o.instanceColor.normalized,o.instanceColor.meshPerAttribute):null;instance.morphTexture=o.morphTexture?.clone()??null;instance.boundingBox=o.boundingBox?.clone()??null;instance.boundingSphere=o.boundingSphere?.clone()??null;instance.userData.sourceMapBatch=true;instance.userData.replaySource=o.uuid;copy=instance;
   }
   else copy=new THREE.Mesh(mutable?(o.userData.originalGeometry as THREE.BufferGeometry).clone():o.geometry,o.material);
   copy.matrix.copy(o.matrixWorld);copy.matrix.decompose(copy.position,copy.quaternion,copy.scale);copy.matrixAutoUpdate=false;copy.visible=visible;copy.castShadow=o.castShadow;copy.receiveShadow=o.receiveShadow;copy.layers.mask=o.layers.mask;copy.renderOrder=o.renderOrder;copy.customDepthMaterial=o.customDepthMaterial;copy.customDistanceMaterial=o.customDistanceMaterial;copy.userData.nativeSurface=o.userData.nativeSurface;this.scene.add(copy);
   if(mutable){const id=panelIds.get(panel)!;const owned={...panel,mesh:copy,min:panel.min.clone(),max:panel.max.clone(),holes:[],grid:panel.grid?.clone()} as Panel;copy.userData.originalGeometry=copy.geometry;copy.userData.originalMaterial=o.userData.originalMaterial;this.originals.set(id,copy.geometry);this.panels.set(id,owned);}
   else this.staticCopies.push({source:o,copy});
  });
  const world=Object.create(game.world);world.trace=()=>[];this.proxy=Object.create(game);Object.defineProperty(this.proxy,'state',{value:'stand',writable:true,enumerable:true});
  Object.assign(this.proxy,{world,pos:new THREE.Vector3(),actualVelocity:new THREE.Vector3(),velocity:new THREE.Vector3(),camera:this.camera,observing:false,vaultFrom:null,action:0,gadgetTime:0,inspect:0,ammo:[0,0],reserve:[0,0],launcherEquipped:false,launcherDraw:0,launcherReload:0,launcherShot:0,hammerSwing:0,hammerTarget:null,smokeThrow:0,smokeReleased:false,landingBlend:0});
  if(clip)this.prepare(clip);
 }
 syncStatic(){this.game.world.scene.updateMatrixWorld(true);for(const {source,copy} of this.staticCopies){copy.material=source.material;copy.matrix.copy(source.matrixWorld);copy.matrix.decompose(copy.position,copy.quaternion,copy.scale);let visible=true;for(let p:THREE.Object3D|null=source;p;p=p.parent)visible&&=p.visible;copy.visible=visible;copy.castShadow=source.castShadow;copy.receiveShadow=source.receiveShadow;}this.scene.background=this.game.world.scene.background;}
 private variant(pose:RecordedActor){
  const key=actorKey(pose);let entry=this.variants.get(key);
  if(!entry){
   const rig=new CharacterRig(pose.op),id=weaponId(pose),model:PoseModel={pos:new THREE.Vector3(),yaw:0,stance:'stand',stanceAmount:0,lean:0,adsProgress:0,state:'stand',reload:0,hp:100,weapon:id,slot:pose.slot,secondary:pose.secondary??5,action:0,pitch:0,gaitCycle:0,vaultProgress:0,vaultFrom:null,actualVelocity:new THREE.Vector3(),weaponSkins:{[id]:pose.skin},attachmentSkins:{[id]:pose.attachment},optics:{[id]:pose.optic as Optic}};
   entry={rig,model,vaultOrigin:new THREE.Vector3(),hammerPoint:new THREE.Vector3(),actionPoint:new THREE.Vector3()};this.variants.set(key,entry);this.scene.add(rig.root);rig.update(this.pose(entry,pose,pose,0),0,model.pos);rig.root.visible=false;rig.root.removeFromParent();this.diagnostics.rigBuilds++;
  }
  return entry;
 }
 private view(pose:RecordedActor){const key=loadoutKey(pose);let view=this.weaponViews.get(key);if(!view){view=this.weaponViews.size===0?this.weapon:new WeaponView(this.camera);view.build(weaponId(pose),pose.optic as Optic,pose.skin,pose.attachment);view.rig.visible=false;view.rig.removeFromParent();this.weaponViews.set(key,view);this.diagnostics.weaponBuilds++;}return view;}
 private pose(entry:Variant,a:RecordedActor,b:RecordedActor,t:number){
  const m=entry.model;m.pos.set(mix(a.p[0],b.p[0],t),mix(a.p[1],b.p[1],t),mix(a.p[2],b.p[2],t));m.yaw=angle(a.yaw,b.yaw,t);m.pitch=mix(a.pitch,b.pitch,t);m.stance=a.stance;m.stanceAmount=mix(a.amount,b.amount,t);m.lean=mix(a.lean,b.lean,t);m.adsProgress=mix(a.ads,b.ads,t);m.state=a.state;m.rappelInverted=a.inverted;m.reload=a.reload;m.inspect=a.inspect;m.hp=a.hp;m.shotSerial=a.shot;m.action=a.action;m.actionKind=a.actionKind;m.actionTotal=a.actionTotal;m.vaultPlan=a.vault;m.vaultFrom=a.vault?entry.vaultOrigin.fromArray(a.vault.points[0]):null;m.vaultProgress=mix(a.vaultProgress,b.vaultProgress,t);m.gaitCycle=mix(a.gait,b.gait,t);m.actualVelocity.fromArray(a.velocity);
  const e=a.equipment;m.launcherEquipped=e?.launcher??false;m.launcherDraw=e?.draw??0;m.launcherReload=e?.launcherReload??0;m.launcherShot=e?.launcherShot??0;m.hammerSwing=e?.hammer??0;m.hammerHit=e?.hammerHit??false;m.hammerTarget=e?.hasHammerTarget?entry.hammerPoint.fromArray(e.hammerTarget):null;m.smokeThrow=e?.smoke??0;m.smokeReleased=e?.released??false;m.jammerYaw=e?.jammerYaw??a.yaw;m.actionPosition=entry.actionPoint.fromArray(e?.actionPosition??a.p);m.reloadTotal=e?.reloadTotal??0;m.reloadEmpty=e?.reloadEmpty??false;m.rappel=e?.rappel??a.state==='rappel';return m;
 }
 preloadRoster(){
  const poses=this.game.history.roster(this.game),wantedActors=new Set<string>(),wantedViews=new Set<string>();
  for(const pose of poses){
   const actor=pose.id===this.game.actorId?this.game:this.game.humans.find(h=>h.id===pose.id)?.actor;
   const variants=actor?[{...pose,slot:0,optic:actor.optics[pose.weapon]??'iron',skin:actor.weaponSkins[pose.weapon]??'Factory',attachment:actor.attachmentSkins[pose.weapon]??'Factory'},{...pose,slot:1,optic:actor.optics[actor.secondary]??'holo',skin:actor.weaponSkins[actor.secondary]??'Factory',attachment:actor.attachmentSkins[actor.secondary]??'Factory'}]:[pose];
   for(const p of variants){this.variant(p).rig.root.visible=false;this.view(p);wantedActors.add(actorKey(p));wantedViews.add(loadoutKey(p));}
  }
  for(const [key,entry] of this.variants)if(!wantedActors.has(key)){entry.rig.dispose();this.variants.delete(key);}
  for(const [key,view] of this.weaponViews)if(!wantedViews.has(key)){view.dispose();this.weaponViews.delete(key);}
  if(![...this.weaponViews.values()].includes(this.weapon)&&this.weaponViews.size)this.weapon=this.weaponViews.values().next().value!;
  this.rigs.clear();this.syncStatic();
 }
 private prepareSurface(state:RecordedPanel){
  const panel=this.panels.get(state.id);if(!panel)return;
  const original=this.originals.get(state.id)!;panel.mesh.geometry=original;delete panel.mesh.userData.holeKey;delete panel.mesh.userData.gridGeometryRevision;
  if(panel.grid&&state.grid)panel.grid.restore(state.grid);
  panel.broken=state.broken;panel.hp=state.hp;panel.reinforced=state.reinforced;panel.holes=state.holes.map(h=>({point:new THREE.Vector3().fromArray(h),radius:h[3]}));
  if(panel.grid&&panel.mesh.userData.nativeSurface&&!state.reinforced){panel.mesh.material=panel.mesh.userData.originalMaterial;panel.mesh.visible=false;}
  else{panel.mesh.visible=!state.broken;this.game.world.updateBarricadeGeometry(panel);this.game.world.updateDamage(panel);}
  const geometry=panel.mesh.geometry;if(geometry!==original)this.ownedGeometries.add(geometry);
  this.surfaces.set(state,{geometry,material:panel.mesh.material,visible:panel.mesh.visible,holes:panel.holes,health:panel.grid?.health.slice(),removed:panel.grid?.removed??0,revision:panel.grid?.revision??0});this.diagnostics.preparedSurfaces++;
 }
 prepare(clip:ReplayClip){
  const start=performance.now();this.endClip();this.clip=clip;this.syncStatic();
  for(const entry of this.variants.values()){entry.rig.initialized=false;entry.rig.lastShot=-1;entry.rig.pumpLife=0;entry.rig.motion.set(0,0,0);entry.rig.root.visible=false;}
  for(const view of this.weaponViews.values()){view.shot=-1;view.pumpLife=0;view.flashLife=0;view.clock=0;view.motion.set(0,0,0);view.rig.visible=false;}
  for(const frame of clip.frames){
   for(const actor of frame.actors){this.variant(actor);if(actor.id===clip.killer)this.view(actor);}
   for(const state of frame.panels)this.prepareSurface(state);
   for(const d of frame.devices)if(!this.devices.has(d.id)){const mesh=deviceMesh(d.type);mesh.visible=false;this.devices.set(d.id,mesh);this.scene.add(mesh);this.diagnostics.deviceBuilds++;}
  }
  for(const entry of this.variants.values()){entry.rig.initialized=false;entry.rig.lastShot=-1;entry.rig.pumpLife=0;}
  this.update(0,0,true,false);this.cursor=0;this.lastTime=-1;this.played.clear();this.surfaceDirty=true;this.maskActive=false;this.diagnostics.prepareMs=performance.now()-start;
 }
 /** Upload buffers and compile materials into a private 1px target before playback. */
 warm(renderer:THREE.WebGLRenderer){
  const start=performance.now(),saved:{object:THREE.Object3D,visible:boolean,culled:boolean}[]=[],target=renderer.getRenderTarget(),attached:THREE.Object3D[]=[];
  for(const entry of this.variants.values())if(!entry.rig.root.parent){this.scene.add(entry.rig.root);attached.push(entry.rig.root);}
  for(const view of this.weaponViews.values())if(!view.rig.parent){this.viewmodelProjection.add(view.rig);attached.push(view.rig);}
  this.scene.traverse(object=>{saved.push({object,visible:object.visible,culled:object.frustumCulled});if(!object.userData.hitbox)object.visible=true;object.frustumCulled=false;});
  try{renderer.setRenderTarget(this.warmTarget);renderer.render(this.scene,this.camera);}finally{renderer.setRenderTarget(target);for(const s of saved){s.object.visible=s.visible;s.object.frustumCulled=s.culled;}for(const object of attached)object.removeFromParent();}
  this.diagnostics.warmMs=performance.now()-start;
 }
 update(time:number,dt:number,silent=false,syncMask=true){
  const started=performance.now(),frames=this.clip.frames;if(!frames.length)return;
  const timeSafe=Math.min(3.5,Math.max(0,time));if(timeSafe<this.lastTime){this.cursor=0;this.applied.clear();this.surfaceDirty=true;}
  while(this.cursor<frames.length&&frames[this.cursor].t<=timeSafe){const frame=frames[this.cursor++];
   for(const state of frame.panels){if(this.applied.get(state.id)===state)continue;const panel=this.panels.get(state.id),prepared=this.surfaces.get(state);if(!panel||!prepared)continue;panel.hp=state.hp;panel.broken=state.broken;panel.reinforced=state.reinforced;panel.holes=prepared.holes;panel.mesh.geometry=prepared.geometry;panel.mesh.material=prepared.material;panel.mesh.visible=prepared.visible;if(panel.grid&&prepared.health){panel.grid.health.set(prepared.health);panel.grid.revision=prepared.revision;panel.grid.removed=prepared.removed;}this.applied.set(state.id,state);this.surfaceDirty=true;}
   for(const d of frame.devices){const mesh=this.devices.get(d.id);if(!mesh)continue;mesh.position.fromArray(d.p);if(d.q)mesh.quaternion.fromArray(d.q);mesh.visible=d.visible;deviceScale(mesh,d.type,d.active);}
   if(!silent)for(const event of frame.sounds)if(!this.played.has(event.id)){this.played.add(event.id);this.game.audio.play(event.kind,this.audioPoint.fromArray(event.pos),event.gain,'replay:'+this.clip.id+event.id);}
  }
  const a=frames[Math.max(0,this.cursor-1)],b=frames[Math.min(frames.length-1,this.cursor)],fraction=THREE.MathUtils.clamp((timeSafe-a.t)/Math.max(.0001,b.t-a.t),0,1),team=a.actors.find(x=>x.id===this.clip.killer)?.team;
  this.actorIds.clear();
  for(const pose of a.actors){
   const next=b.actors.find(x=>x.id===pose.id)??pose,entry=this.variants.get(actorKey(pose));if(!entry)continue;const model=this.pose(entry,pose,next,fraction),rig=entry.rig,old=this.rigs.get(pose.id);if(old&&old!==rig)old.root.removeFromParent();this.rigs.set(pose.id,rig);this.actorIds.add(pose.id);rig.setTeam(pose.team===team);rig.root.visible=pose.id!==this.clip.killer;if(rig.root.visible&&!rig.root.parent)this.scene.add(rig.root);else if(!rig.root.visible)rig.root.removeFromParent();rig.update(model,dt,model.pos);
   if(pose.id===this.clip.killer){
    const g=this.proxy;Object.assign(g,model,{operator:pose.op,team:pose.team,weapon:pose.weapon,slot:pose.slot,gadgetTime:pose.gadget,visualY:model.pos.y,cameraHeight:mix(pose.height,next.height,fraction),cameraForward:pose.forward,recoilPitch:mix(pose.recoil[0],next.recoil[0],fraction),recoilYaw:mix(pose.recoil[1],next.recoil[1],fraction),shake:pose.recoil[2],shotAge:(pose.shotAge??10)+Math.max(0,timeSafe-a.t),switchRemaining:Math.max(0,(pose.switchRemaining??0)-Math.max(0,timeSafe-a.t)),switchTotal:pose.switchTotal??0,rappel:pose.state==='rappel'||pose.inverted});
    for(let i=0;i<2;i++){g.ammo[i]=pose.ammo[i];g.reserve[i]=pose.reserve[i];}
    const view=this.weaponViews.get(loadoutKey(pose));if(view){if(this.weapon!==view){this.weapon.rig.visible=false;this.weapon.rig.removeFromParent();}this.weapon=view;if(view.rig.parent!==this.viewmodelProjection)this.viewmodelProjection.add(view.rig);}
    this.camera.position.copy(g.eye());this.camera.rotation.set(g.pitch+g.recoilPitch,g.yaw+g.recoilYaw,pose.inverted?Math.PI:-g.lean*leanPose.cameraRoll,'YXZ');this.camera.fov=blendFov(g.baseFov,adsFov(g.optic,g.baseFov),g.adsProgress);this.camera.aspect=this.game.camera.aspect;this.camera.updateProjectionMatrix();this.viewmodelProjection.scale.set(1,1,1);this.weapon.update(g,dt,this.brightness,this.effects,this.reticleColor,this.reticleOpacity);const vmFov=viewmodelFov(g.optic,g.adsProgress,g.slot===1?g.secondary:g.weapon),projectionScale=Math.tan(this.camera.fov*Math.PI/360)/Math.tan(vmFov*Math.PI/360);this.viewmodelProjection.scale.set(projectionScale,projectionScale,1);if(this.weapon.reticle)this.weapon.reticle.material.uniforms.angularSize.value.multiplyScalar(projectionScale);
   }
  }
  for(const [id,rig] of this.rigs)if(!this.actorIds.has(id)){rig.root.removeFromParent();this.rigs.delete(id);}
  if(syncMask&&(this.surfaceDirty||!this.maskActive)){this.game.world.imported?.syncDestruction(this.panels);this.surfaceDirty=false;this.maskActive=true;this.diagnostics.maskUpdates++;}
  this.lastTime=timeSafe;this.diagnostics.lastUpdateMs=performance.now()-started;
 }
 endClip(){
  const start=performance.now();if(this.maskActive)this.game.world.imported?.syncDestruction();this.maskActive=false;this.surfaceDirty=true;
  for(const [id,panel] of this.panels){panel.mesh.geometry=this.originals.get(id)!;panel.mesh.visible=false;}
  for(const geometry of this.ownedGeometries)geometry.dispose();this.ownedGeometries.clear();this.surfaces.clear();this.applied.clear();
  for(const mesh of this.devices.values())disposeDevice(mesh);this.devices.clear();for(const entry of this.variants.values()){entry.rig.root.visible=false;entry.rig.root.removeFromParent();}for(const view of this.weaponViews.values()){view.rig.visible=false;view.rig.removeFromParent();}
  this.rigs.clear();this.clip=emptyClip();this.cursor=0;this.played.clear();this.lastTime=-1;this.diagnostics.cleanupMs=performance.now()-start;
 }
 get storage(){return {rigVariants:this.variants.size,weaponVariants:this.weaponViews.size,preparedSurfaces:this.surfaces.size,temporaryGeometries:this.ownedGeometries.size,devices:this.devices.size,staticCopies:this.staticCopies.length};}
 dispose(){if(this.disposed)return;this.disposed=true;this.endClip();for(const geometry of this.originals.values())geometry.dispose();for(const entry of this.variants.values())entry.rig.dispose();const views=new Set(this.weaponViews.values());views.add(this.weapon);for(const view of views)view.dispose();this.variants.clear();this.weaponViews.clear();this.warmTarget.dispose();this.scene.traverse(o=>{if(o instanceof THREE.InstancedMesh)o.dispose();if(o instanceof THREE.DirectionalLight||o instanceof THREE.SpotLight||o instanceof THREE.PointLight)o.shadow.dispose();});this.scene.clear();}
}

import * as THREE from 'three';
import type {Game,Device} from './game';
import {posture} from './pose';

// Ash: Ubisoft Y5S4 damage (50 HP), Y5S4.3 range (2 m). Curves/Thermite radius remain prototype tuning.
// Thermite's documented pre-Y11S3.1 damage is 200; radius/falloff and earlier continuity remain inferred.
export const breachingBlast={round:{radius:2,fullDamageRadius:1,damage:50},charge:{radius:4,fullDamageRadius:1,damage:200}};
const spent=new WeakSet<Device>();
export function detonateBreachingDevice(game:Game,device:Device){
 if(!game.authority||!['round','charge'].includes(device.type)||!device.active||!device.mesh.visible||spent.has(device))return;
 spent.add(device);device.active=false;device.mesh.visible=false;
 if(device.type==='round'&&!device.roundImpact)return; // A range-expired miss has no explosive impact.
 const kind=device.type==='charge'?'charge':'round',tuning=breachingBlast[kind],panel=game.world.panels[device.panelId??-1];
 if(panel&&game.world.canBreach(panel,kind==='charge'?'thermite':'ash'))game.world.breach(panel,kind==='charge'?'thermite':'ash',device.pos);
 // Offset toward the approach side so an intact impact surface does not occlude its own front-side blast.
 const normal=device.blastNormal?.clone()??new THREE.Vector3(0,0,1).applyQuaternion(device.mesh.quaternion);
 const origin=device.pos.clone().addScaledVector(normal.normalize(),.04),owner=device.owner??'explosion',team=device.team??0;
 const visible=(target:THREE.Vector3)=>target.distanceTo(origin)<tuning.radius&&game.world.sight(origin,target);
 const damage=(feet:THREE.Vector3,amount:number)=>{
  const p=posture(amount),points=[p.bodyY,p.height*.75,.22].map(y=>feet.clone().add(new THREE.Vector3(0,y,0))).filter(visible);
  if(!points.length)return 0;const distance=Math.min(...points.map(v=>v.distanceTo(origin)));
  return Math.ceil(tuning.damage*THREE.MathUtils.clamp((tuning.radius-distance)/(tuning.radius-tuning.fullDamageRadius),0,1));
 };
 const humans=new Set([game,...game.humans.map(h=>h.actor)]);
 for(const actor of humans)if(actor.hp>0){const n=damage(actor.pos,actor.stanceAmount);if(n)actor.takeDamage(n,owner,team);}
 for(const bot of game.bots)if(bot.hp>0){const n=damage(bot.pos,bot.stanceAmount??0);if(n)game.damageBot(bot,n,owner,team);}
 for(const other of new Set([...game.devices,...game.externalDevices])){
  if(other===device||!other.mesh.visible||other.type==='gas'&&other.active||!visible(other.mesh.position))continue;
  other.mesh.visible=false;other.active=false;other.type='destroyed';other.flightVelocity=undefined;
 }
 const drones=new Set([game.droneUnit,...game.humans.map(h=>h.actor.droneUnit),...game.externalDrones,...game.bots.flatMap(b=>b.drone?[b.drone]:[])]);
 for(const drone of drones)if(drone.alive&&drone.deployed&&visible(drone.pos.clone().add(new THREE.Vector3(0,.1,0))))drone.destroy();
 for(const scout of game.scouts)if(scout.mesh.visible&&visible(scout.pos.clone().add(new THREE.Vector3(0,.1,0))))scout.mesh.visible=false;
 for(const camera of game.world.panels)if(camera.mesh.userData.securityId!==undefined&&!camera.broken&&visible(origin.clone().clamp(camera.min,camera.max))){
  camera.broken=true;camera.hp=0;camera.mesh.visible=false;
 }
 game.emitSound('breach',device.pos,.85);
}

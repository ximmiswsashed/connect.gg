import * as T from 'three';import type {World} from './world';
export const spawnSeparation=1.10;
/** Reserve actual resolved positions, so collision recovery cannot collapse a team onto one point. */
export function reserveSpawn(world:World,preferred:T.Vector3,occupied:readonly T.Vector3[],height=1.7){
 const base=preferred.clone();world.safeSpawn(base,height);
 const valid=(p:T.Vector3)=>Number.isFinite(p.y)&&p.y>-24&&Math.abs(p.y-base.y)<.45&&!world.collide(p.x,p.y+.02,p.z,.28,height)&&occupied.every(other=>Math.abs(other.y-p.y)>height||Math.hypot(other.x-p.x,other.z-p.z)>=spawnSeparation-1e-6);
 if(valid(base))return base;
 for(let ring=1;ring<=16;ring++){const radius=ring*spawnSeparation,count=Math.max(12,Math.ceil(radius*Math.PI*2/spawnSeparation));for(let i=0;i<count;i++){const a=i*Math.PI*2/count,x=base.x+Math.cos(a)*radius,z=base.z+Math.sin(a)*radius,y=world.ground(x,z,base.y);const p=new T.Vector3(x,y+.015,z);if(valid(p))return p;}}
 throw new Error('No clear, separated spawn position near the selected location');
}

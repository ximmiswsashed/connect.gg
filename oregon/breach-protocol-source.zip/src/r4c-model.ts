import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {paintUV} from './cosmetics';

// Original, receiver-space mesh. Dimensions follow the project's measured R4-C
// silhouette; no imported firearm geometry or copied texture is used here.
const black=new THREE.MeshLambertMaterial({color:0x28312e});
const steel=new THREE.MeshLambertMaterial({color:0x586263});
black.userData.shared=steel.userData.shared=true;
const paints=new Map<string,THREE.MeshLambertMaterial>();
export function skinPaint(finish:unknown){
 const key=String(finish);let material=paints.get(key);if(material)return material;
 const canvas=document.createElement('canvas');canvas.width=canvas.height=128;
 const ctx=canvas.getContext('2d')!;
 const palettes:Record<string,[string,string,string]>={
  'R4C Tiger':['#ad8144','#292d25','#ccaa65'],'R4C Zebra':['#abb0ad','#303635','#d7dad4'],
  'R4C Elephant':['#727d79','#46524e','#a2aaa0'],'R4C Leopard':['#b69960','#323a30','#706647'],
  'R4C Snake':['#788366','#354537','#acaf83'],'R4C Gold':['#b59b49','#746332','#d8c67a'],
  'R4C Platinum':['#9ca9ae','#5a6b75','#d8dfe0'],'R4C Diamond':['#98b5c2','#566d87','#d3e4df'],
  'R4C Spartian Authority':['#61633d','#242e2e','#c29b55'],
  'R4C Black Ice':['#173840','#091d28','#76abb3'],'R4C Glacier':['#748e97','#455a6c','#b6cdd0']};
 const colors=palettes[key]??['#46534b','#2a342e','#758075'];ctx.fillStyle=colors[0];ctx.fillRect(0,0,128,128);
 // Deterministic small painted patterns preserve the existing skin choices.
 let seed=17;for(let i=0;i<key.length;i++)seed=(seed*31+key.charCodeAt(i))>>>0;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 for(let i=0;i<32;i++){const x=random()*128,y=random()*128;ctx.fillStyle=colors[1+i%2];ctx.beginPath();
  if(key.includes('Tiger')||key.includes('Zebra')){ctx.moveTo(x,y);ctx.lineTo(x+8,y-7);ctx.lineTo(x+28,y+22);ctx.lineTo(x+17,y+18);}
  else if(key.includes('Gold')||key.includes('Platinum')){ctx.rect(x,y,1,25);}
  else if(key.includes('Diamond')||key.includes('Ice')||key.includes('Glacier')){ctx.moveTo(x,y);ctx.lineTo(x+random()*27,y-19);ctx.lineTo(x+32,y+24);}
  else{ctx.ellipse(x,y,4+random()*8,3+random()*6,random()*3,0,Math.PI*2);}ctx.fill();}
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.userData.shared=true;
 material=new THREE.MeshLambertMaterial({map:texture});material.userData={shared:true,finish:key,originalPattern:true};paints.set(key,material);return material;
}
export function r4cModel(finish:unknown){
 const root=new THREE.Group(),body=new Map<THREE.Material,THREE.BufferGeometry[]>(),mag=new Map<THREE.Material,THREE.BufferGeometry[]>(),coat=skinPaint(finish);let magazine=false;
 const add=(g:THREE.BufferGeometry,m:THREE.Material=coat)=>{if(g.index){const old=g;g=g.toNonIndexed();old.dispose();}const target=magazine?mag:body,list=target.get(m)??[];list.push(g);target.set(m,list);};
 const box=(x:number,y:number,z:number,w:number,h:number,d:number,m:THREE.Material=coat)=>add(new THREE.BoxGeometry(w,h,d).translate(x,y,z),m);
 const tube=(x:number,y:number,z:number,r:number,d:number,m:THREE.Material=steel)=>add(new THREE.CylinderGeometry(r,r,d,10).rotateX(Math.PI/2).translate(x,y,z),m);
 const profile=(points:number[][],w:number,m:THREE.Material=coat)=>{const s=new THREE.Shape();points.forEach(([z,y],i)=>i?s.lineTo(z,y):s.moveTo(z,y));s.closePath();add(new THREE.ExtrudeGeometry(s,{depth:w,bevelEnabled:true,bevelThickness:.0008,bevelSize:.0008,bevelSegments:1,steps:1}).rotateY(-Math.PI/2).translate(w/2,0,0),m);};
 // Upper/lower receiver, forward assist, charging handle, bolt/ejection cover.
 profile([[-.119,.022],[-.114,.054],[-.090,.061],[.064,.061],[.078,.047],[.075,.019]],.033);
 profile([[-.105,.019],[.069,.019],[.070,-.002],[.010,-.002],[-.014,-.002],[-.030,-.028],[-.087,-.028],[-.103,-.011]],.031);
 box(.0175,.038,-.028,.0025,.016,.054,steel);box(.019,.030,-.049,.003,.003,.052,black);
 tube(-.017,.044,.065,.005,.012);box(0,.056,.081,.055,.006,.007,black);
 for(const x of [-.017,.017]){box(x,.005,-.018,.002,.008,.008,steel);box(x,.006,.038,.002,.004,.014,black);}
 // Sloping firing grip and open trigger guard; anchors match the glove profiles.
 profile([[.014,-.009],[.047,-.011],[.072,-.063],[.043,-.069],[.021,-.027]],.029,black);
 for(const x of [-.0155,.0155])for(let i=0;i<4;i++)box(x,-.030-i*.007,.046+i*.004,.001,.003,.021,steel);
 box(0,-.011,.005,.005,.017,.005,black);box(0,-.024,.012,.024,.004,.039,steel);box(0,-.014,-.006,.024,.019,.003,steel);
 // Faceted handguard with open longitudinal ventilation and separate rail teeth.
 box(0,.043,-.178,.042,.024,.136);box(0,.056,-.178,.036,.006,.136,black);
 box(0,.003,-.178,.034,.004,.136,black);
 for(const z of [-.108,-.247])box(0,.029,z,.036,.052,.005,black);
 for(const x of [-.0215,.0215]){box(x,.046,-.178,.004,.006,.136);box(x,.032,-.178,.004,.004,.136);for(let i=0;i<8;i++)box(x,.043,-.237+i*.017,.004,.022,.007);}
 // Barrel / collar / flash hider end at the shared ballistic muzzle point.
 tube(0,.046,-.258,.006,.026);tube(0,.046,-.273,.007,.008,black);tube(0,.046,-.281,.0068,.013,black);
 for(const x of [-.0068,.0068])box(x,.046,-.283,.002,.010,.009,steel);
 // Continuous mounting contact plane with Picatinny grooves recessed below it.
 box(0,.064,-.080,.020,.008,.306,black);
 for(let i=0;i<28;i++)box(0,.0692,-.229+i*.011,.026,.0024,.007,steel);
 // Buffer tube, adjustable skeletal stock, cheek rest and rubber butt plate.
 tube(0,.040,.150,.010,.145,black);
 profile([[.095,.030],[.214,.049],[.290,.041],[.292,-.047],[.274,-.053],[.249,-.010],[.115,.011]],.031);
 box(0,.050,.214,.035,.010,.131,black);box(0,-.006,.289,.037,.089,.013,black);
 box(0,.015,.185,.018,.009,.035,steel);
 // Curved magazine remains a separately animated part with the existing pivot.
 magazine=true;profile([[-.029,.017],[-.081,.017],[-.087,-.034],[-.101,-.085],[-.094,-.097],[-.054,-.097],[-.036,-.047]],.017,black);
 for(const x of [-.0095,.0095])for(let i=0;i<3;i++)profile([[-.043-i*.013,-.018],[-.052-i*.013,-.079],[-.055-i*.013,-.083],[-.045-i*.013,-.018]],.001,steel);
 box(0,-.097,-.075,.023,.004,.047,steel);magazine=false;
 const bounds=new THREE.Box3(new THREE.Vector3(-.03,-.10,-.29),new THREE.Vector3(.03,.071,.30));
 const assemble=(parts:Map<THREE.Material,THREE.BufferGeometry[]>,group:THREE.Group,offset=new THREE.Vector3())=>{for(const [m,geometries]of parts){const g=mergeGeometries(geometries)!;geometries.forEach(p=>p.dispose());if(m===coat)paintUV(g,bounds);g.translate(-offset.x,-offset.y,-offset.z);const mesh=new THREE.Mesh(g,m);mesh.userData.dynamic=true;group.add(mesh);}};
 assemble(body,root);const pivot=new THREE.Group();pivot.name='r4c-magazine';pivot.position.set(0,-.03,-.065);assemble(mag,pivot,pivot.position);root.add(pivot);
 root.userData={weapon:0,finish,ready:true,originalModel:true,magazine:pivot};return root;
}

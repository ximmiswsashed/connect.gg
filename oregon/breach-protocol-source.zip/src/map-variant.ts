// Keep visual, collision, navigation and lobby compatibility selection consistent.
const query=new URLSearchParams(location.search);
declare const __MAP_COMPARISON__:boolean;
export const mapGeometry=(__MAP_COMPARISON__?query.get('geometry'):null)??'scratch';
export const mapCollision=(__MAP_COMPARISON__?query.get('collision'):null)??'scratch';
export const mapNavigation=(__MAP_COMPARISON__?query.get('navigation'):null)??(mapCollision==='scratch'?'scratch-candidate':mapCollision==='browser'?'browser':'reference');
export const browserNavigation=mapNavigation==='browser';
export const navigationCandidate=mapNavigation==='scratch-candidate';
export const sourceMapCompatibility=`oregon-y9s4-sectional-v19-${mapCollision}-${browserNavigation?'browser':'reference'}${mapGeometry==='scratch'?'-scratch-preview-shapes-v2':''}${navigationCandidate?'-navigation-candidate-v3':''}`;

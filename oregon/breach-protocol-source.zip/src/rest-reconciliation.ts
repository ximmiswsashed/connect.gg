import * as THREE from 'three';
import type {Game} from './game';
import {posture,stanceValue} from './pose';

/** Smooth an acknowledged idle error using the ordinary collision/step solver. */
export function reconcileRestingStep(actor:Game,target:THREE.Vector3,dt:number){
 if(!Number.isFinite(dt)||dt<=0)return false;
 const delta=target.clone().sub(actor.pos);delta.y=0;const error=delta.length();if(error<.002)return false;
 delta.multiplyScalar(1-Math.exp(-12*Math.min(dt,.25)));delta.clampLength(0,1.2*Math.min(dt,.25));
 const count=Math.max(1,Math.ceil(delta.length()/.04)),dx=delta.x/count,dz=delta.z/count,pose=stanceValue(actor.stance),height=Math.max(posture(actor.stanceAmount).height,posture(pose).height),origin=actor.pos.clone();
 for(let i=0;i<count;i++){
  const before=actor.pos.clone();actor.move(actor.pos,dx,dz,height);
  if(actor.postureBlocked(actor.pos,actor.stanceAmount)||actor.postureBlocked(actor.pos,pose)){actor.pos.copy(before);break;}
  if(actor.pos.distanceToSquared(before)<1e-16)break;
 }
 const moved=actor.pos.distanceToSquared(origin)>1e-16;if(moved)actor.camera.position.copy(actor.eye());return moved;
}

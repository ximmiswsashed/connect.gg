import type * as THREE from 'three';
import type {World} from './world';

/** Resolution changes must not rewalk every map/actor material or reallocate an unchanged canvas. */
export function displayUpdater(renderer:THREE.WebGLRenderer,world:World,camera:THREE.PerspectiveCamera){
 let quality:string|undefined;
 return (width:number,height:number,scale:number,nextQuality:string,selectedAspect?:number)=>{
  const w=Math.max(1,Math.round(width*scale)),h=Math.max(1,Math.round(height*scale));
  if(renderer.domElement.width!==w||renderer.domElement.height!==h)renderer.setSize(w,h,false);
  const aspect=selectedAspect??width/height;
  if(camera.aspect!==aspect){camera.aspect=aspect;camera.updateProjectionMatrix();}
  if(quality!==nextQuality){world.setQuality(nextQuality);quality=nextQuality;}
 };
}

import * as THREE from 'three';
import type {Game,Human,Bot} from './game';
import {sweepSphereTriangle} from './swept-sphere';
export type RoundActorContact={distance:number,point:THREE.Vector3,human?:Human,bot?:Bot};
export function roundActorContact(game:Game,owner:string,from:THREE.Vector3,dir:THREE.Vector3,length:number,radius:number):RoundActorContact|null{
 let best:RoundActorContact|null=null;
 const box=new THREE.Box3().setFromPoints([from,from.clone().addScaledVector(dir,length)]).expandByScalar(radius);
 const actors:[THREE.Object3D,Human|null,Bot|null][]=[...game.humans.filter(h=>h.actor.hp>0&&h.id!==owner).map(h=>[h.mesh,h,null] as [THREE.Object3D,Human,null]),...game.bots.filter(b=>b.hp>0&&'bot:'+b.id!==owner).map(b=>[b.mesh,null,b] as [THREE.Object3D,null,Bot])];
 for(const [root,human,bot] of actors){root.updateWorldMatrix(true,true);root.traverse(o=>{
  const mesh=o as THREE.Mesh;if(!mesh.isMesh||!mesh.userData.hitbox)return;
  const geometry=mesh.geometry;if(!geometry.boundingBox)geometry.computeBoundingBox();
  if(!geometry.boundingBox||!geometry.boundingBox.clone().applyMatrix4(mesh.matrixWorld).intersectsBox(box))return;
  const positions=geometry.getAttribute('position'),index=geometry.index;
  const vertex=(i:number)=>new THREE.Vector3().fromBufferAttribute(positions,index?index.getX(i):i).applyMatrix4(mesh.matrixWorld);
  for(let i=0;i<(index?.count??positions.count);i+=3){
   const hit=sweepSphereTriangle(from,dir,best?.distance??length,radius,new THREE.Triangle(vertex(i),vertex(i+1),vertex(i+2)));
   if(hit)best={distance:hit.distance,point:hit.point,human:human??undefined,bot:bot??undefined};
  }
 });}
 return best;
}

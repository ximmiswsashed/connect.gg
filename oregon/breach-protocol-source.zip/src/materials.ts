import * as THREE from 'three';
export function surfaceTexture(type:string){
 const canvas=document.createElement('canvas');canvas.width=canvas.height=256;const c=canvas.getContext('2d')!;
 let seed=83;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 c.fillStyle='#d8d5cb';c.fillRect(0,0,256,256);
 const image=c.getImageData(0,0,256,256);for(let i=0;i<image.data.length;i+=4){const n=185+random()*45;image.data[i]=n;image.data[i+1]=n;image.data[i+2]=n;image.data[i+3]=255;}c.putImageData(image,0,0);
 if(['wood','siding','soft','laminate'].includes(type)){for(let i=0;i<150;i++){c.strokeStyle=`rgba(55,43,25,${random()*.2})`;c.lineWidth=.3+random();c.beginPath();const y=random()*256;c.moveTo(0,y);for(let x=0;x<=256;x+=16)c.lineTo(x,y+Math.sin(x*.04+i)*random()*3);c.stroke();}for(let y=0;y<256;y+=type==='siding'?32:64){c.fillStyle='#38352688';c.fillRect(0,y,256,2);c.fillStyle='#ffffff33';c.fillRect(0,y+2,256,1);}}
 if(type==='brick'){c.fillStyle='#92867b';c.fillRect(0,0,256,256);for(let r=0;r<8;r++)for(let col=-1;col<5;col++){c.fillStyle=`rgb(${140+random()*40},${115+random()*35},${98+random()*30})`;c.fillRect(col*64+(r%2)*32+2,r*32+2,60,28);c.fillStyle='#ffffff13';c.fillRect(col*64+(r%2)*32+3,r*32+3,58,2);}}
 if(type==='metal'){for(let y=0;y<256;y+=2){c.fillStyle=`rgba(255,255,255,${random()*.09})`;c.fillRect(0,y,256,1);}for(const x of [8,248])for(const y of [8,248]){c.fillStyle='#494f52';c.beginPath();c.arc(x,y,2,0,Math.PI*2);c.fill();}}
 if(type==='floor'){c.strokeStyle='#5a5b5660';c.lineWidth=2;for(let x=0;x<256;x+=64){c.beginPath();c.moveTo(x,0);c.lineTo(x,256);c.stroke();c.beginPath();c.moveTo(0,x);c.lineTo(256,x);c.stroke();}}
 if(type==='terrain'){for(let i=0;i<2200;i++){c.fillStyle=random()>.5?'#54623a55':'#b3a68655';c.fillRect(random()*256,random()*256,1+random()*3,1+random()*5);}}
 if(type==='concrete'||type==='drywall'){for(let i=0;i<800;i++){c.fillStyle=random()>.5?'#ffffff20':'#363b381c';c.fillRect(random()*256,random()*256,random()*3,random()*3);}}
 if(type==='checkered'){for(let y=0;y<8;y++)for(let x=0;x<8;x++){c.fillStyle=(x+y)%2?'#363a37':'#e6ddbd';c.fillRect(x*32,y*32,32,32);c.strokeStyle='#2c302b55';c.lineWidth=.7;c.strokeRect(x*32+.5,y*32+.5,31,31);}}
 if(type==='redcabinet'){c.fillStyle='#9b3029';c.fillRect(0,0,256,256);for(let i=0;i<350;i++){c.fillStyle='#4a21120b';c.fillRect(random()*256,random()*256,2,2);}}
 if(type==='fabric'||type==='sandbag'){c.fillStyle=type==='fabric'?'#708073':'#ad9d74';c.fillRect(0,0,256,256);for(let y=0;y<256;y+=4){c.strokeStyle='#fff2';c.beginPath();c.moveTo(0,y);c.lineTo(256,y);c.stroke();}for(let x=0;x<256;x+=4){c.strokeStyle='#17211722';c.beginPath();c.moveTo(x,0);c.lineTo(x,256);c.stroke();}}
 if(type==='plaster'){c.fillStyle='#d8cdb0';c.fillRect(0,0,256,256);for(let i=0;i<1700;i++){c.fillStyle=random()>.5?'#fff3dc18':'#7c756018';c.fillRect(random()*256,random()*256,1+random()*4,1+random()*3);}}
 if(type==='ceiling'){c.fillStyle='#deded1';c.fillRect(0,0,256,256);for(let i=0;i<1600;i++){c.fillStyle='#888d7918';c.fillRect(random()*256,random()*256,1,1);}c.strokeStyle='#9a9e91';c.lineWidth=2;for(let y=0;y<256;y+=64)for(let x=0;x<256;x+=64)c.strokeRect(x,y,64,64);}
 if(type==='corrugated'){for(let x=0;x<256;x+=16){c.fillStyle='#a3a599';c.fillRect(x,0,4,256);c.fillStyle='#deded4';c.fillRect(x+4,0,3,256);}}
 if(type==='dirt'||type==='gravel'){for(let i=0;i<2300;i++){c.fillStyle=random()>.5?'#fff4db28':'#47463933';c.beginPath();c.ellipse(random()*256,random()*256,type==='gravel'?1+random()*3:1,1+random()*2,random()*Math.PI,0,Math.PI*2);c.fill();}}
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.anisotropy=2;return texture;
}
export function bakeGeometry(geo:THREE.BufferGeometry,tile=2,offset=new THREE.Vector3()){
 const p=geo.getAttribute('position'),normal=geo.getAttribute('normal'),uv=geo.getAttribute('uv'),colors=new Float32Array(p.count*3);for(let i=0;i<p.count;i++){const x=p.getX(i)+offset.x,y=p.getY(i)+offset.y,z=p.getZ(i)+offset.z,nx=normal.getX(i),ny=normal.getY(i);if(uv){if(Math.abs(ny)>.5)uv.setXY(i,x/tile,z/tile);else if(Math.abs(nx)>.5)uv.setXY(i,z/tile,y/tile);else uv.setXY(i,x/tile,y/tile);}const light=.74+Math.max(0,ny)*.22+(nx<0?.06:0);colors[i*3]=colors[i*3+1]=colors[i*3+2]=light;}geo.setAttribute('color',new THREE.BufferAttribute(colors,3));return geo;
}

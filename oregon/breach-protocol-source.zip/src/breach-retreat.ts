import * as THREE from 'three';
import type {Game,Bot,Device} from './game';
import {botPosture,turnBot} from './ai-posture';
import {movementConfig} from './movement';
import {breachingBlast} from './breaching-blast';
import {breachingRoundFuseSeconds} from './breaching-round';

type Retreat={device:Device,path:THREE.Vector3[]};
const speed=(b:Bot)=>movementConfig[b.stance??'stand'].speed;
function segment(game:Game,b:Bot,from:THREE.Vector3,to:THREE.Vector3){
 const distance=from.distanceTo(to),n=Math.max(1,Math.ceil(distance/.12));let prior=from;
 for(let i=1;i<=n;i++){
  const p=from.clone().lerp(to,i/n),floor=game.world.ground(p.x,p.z,prior.y,.02)+.015;
  if(Math.abs(floor-prior.y)>.25)return false;p.y=floor;
  if(game.postureBlocked(p,b.stanceAmount??0,b.mesh.rotation.y))return false;
  if(game.bots.some(other=>other!==b&&other.hp>0&&Math.abs(other.pos.y-p.y)<1.8&&Math.hypot(other.pos.x-p.x,other.pos.z-p.z)<.56)||[game,...game.humans.map(h=>h.actor)].some(a=>a.hp>0&&Math.abs(a.pos.y-p.y)<1.8&&Math.hypot(a.pos.x-p.x,a.pos.z-p.z)<.56))return false;
  prior=p;
 }
 to.y=prior.y;return true;
}
export function planBreachRetreat(game:Game,b:Bot,device:Device){
 const kind=device.type==='round'?'round':'charge',radius=breachingBlast[kind].radius+.45,away=b.pos.clone().sub(device.pos).setY(0);if(away.length()>=radius)return [];
 if(away.lengthSq()<.001)away.set(0,0,1);away.normalize();
 const candidates:THREE.Vector3[][]=[];
 for(const angle of [0,.4,-.4,.8,-.8,1.2,-1.2,Math.PI/2,-Math.PI/2,Math.PI]){
  const direction=away.clone().applyAxisAngle(new THREE.Vector3(0,1,0),angle),goal=device.pos.clone().addScaledVector(direction,radius);goal.y=b.pos.y;
  const paths=[[goal],...[-1,1].map(side=>[b.pos.clone().addScaledVector(new THREE.Vector3(away.z,0,-away.x),side*.9),goal.clone()])];
  for(const path of paths){let previous=b.pos,length=0,clear=true;for(const point of path){length+=previous.distanceTo(point);if(!segment(game,b,previous,point)){clear=false;break;}previous=point;}const fullBudget=kind==='round'?breachingRoundFuseSeconds-.2:2.6,budget=device.active?Math.max(0,Math.min(fullBudget,device.time-.2)):fullBudget;if(clear&&length/speed(b)<budget){if(angle===0&&path.length===1)return path;candidates.push(path);}}
 }
 candidates.sort((a,c)=>length(b.pos,a)-length(b.pos,c));return candidates[0]??null;
}
function length(from:THREE.Vector3,path:THREE.Vector3[]){let distance=0;for(const point of path){distance+=from.distanceTo(point);from=point;}return distance;}
export function startBreachRetreat(b:Bot,device:Device,path:THREE.Vector3[]){b.breachRetreat=true;b.mesh.userData.retreatBlocked=false;b.mesh.userData.retreatRetry=0;b.mesh.userData.breachRetreat={device,path} satisfies Retreat;}
export function updateBreachRetreat(game:Game,b:Bot,dt:number){
 const plan=b.mesh.userData.breachRetreat as Retreat|undefined;if(!plan)return;
 if(!plan.device.mesh.visible||!plan.device.active){b.breachRetreat=false;delete b.mesh.userData.breachRetreat;if(b.brain)b.brain.decision=0;return;}
 b.aiming=false;const height=botPosture(b).height;
 if(plan.device.type==='round'&&plan.device.attached){const goal=plan.path.at(-1)??b.pos;if(Math.hypot(goal.x-plan.device.pos.x,goal.z-plan.device.pos.z)<breachingBlast.round.radius+.25)b.mesh.userData.retreatBlocked=true;}
 for(let elapsed=0;elapsed<dt;elapsed+=.034){
  const target=plan.path[0];if(!target||b.mesh.userData.retreatBlocked)break;const direction=target.clone().sub(b.pos).setY(0),distance=direction.length();if(distance<.06){plan.path.shift();continue;}
  direction.normalize();const travel=Math.min(distance,speed(b)*Math.min(.034,dt-elapsed)),next=b.pos.clone().addScaledVector(direction,travel);
  if(!segment(game,b,b.pos,next)){b.mesh.userData.retreatBlocked=true;break;}
  const before=b.pos.clone();game.move(b.pos,direction.x*travel,direction.z*travel,height);
  if(game.postureBlocked(b.pos,b.stanceAmount??0,b.mesh.rotation.y))b.pos.copy(before);
  const yaw=Math.atan2(-direction.x,-direction.z),diff=THREE.MathUtils.euclideanModulo(yaw-b.mesh.rotation.y+Math.PI,Math.PI*2)-Math.PI;turnBot(game,b,THREE.MathUtils.clamp(diff,-.1,.1));
  const moved=before.distanceTo(b.pos);b.mesh.userData.foot=(b.mesh.userData.foot??0)+moved;if(b.mesh.userData.foot>1.8){b.mesh.userData.foot=0;game.emitSound('footstep',b.pos.clone().add(new THREE.Vector3(0,.08,0)),.25);game.noises.push({pos:b.pos.clone(),team:b.team,time:1.5,radius:6});}
 }
 b.mesh.position.copy(b.pos);
 // A late obstacle invalidates only the remaining path, never collision or the live fuse.
 if(b.mesh.userData.retreatBlocked){b.mesh.userData.retreatRetry=Math.max(0,(b.mesh.userData.retreatRetry??0)-dt);if(b.mesh.userData.retreatRetry===0){b.mesh.userData.retreatRetry=.25;const path=planBreachRetreat(game,b,plan.device);if(path){plan.path=path;b.mesh.userData.retreatBlocked=false;}}}
}

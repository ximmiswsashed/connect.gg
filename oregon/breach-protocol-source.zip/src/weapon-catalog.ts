// Legal choices checked against Ubisoft operator pages on 2026-10-21.
export type WeaponSpec={name:string,damage:number,rpm:number,mag:number,reload:number,ads:number,spread:number,recoil:number,reserve:number,model:number,pellets:number,automatic:boolean};
const gun=(name:string,damage:number,rpm:number,mag:number,reload:number,model:number,pellets=1,automatic=true):WeaponSpec=>({name,damage,rpm,mag,reload,ads:model===5?.16:model===1?.25:.22,spread:pellets>1?.09:.06,recoil:0,reserve:mag*5,model,pellets,automatic});
export const weaponCatalog=[
gun('R4-C',39,860,30,2.5,0),gun('M590A1',18,85,7,3.1,1,8,false),gun('SMG-12',28,1270,32,2.7,2),gun('556XI',46,690,30,2.8,3),gun('MP5K',30,800,30,2.3,4),gun('P226 Mk 25',50,450,15,1.8,5,1,false),
gun('G36C',38,780,30,2.4,0),gun('FMG-9',34,800,30,2.3,4),gun('L85A2',47,670,30,2.7,3),gun('M1014',20,200,8,3.2,1,8,false),gun('K1A',36,720,30,2.4,3),gun('BOSG.12.2',125,120,2,2.5,1,1,false),gun('M45 MEUSOC',58,450,7,1.7,5,1,false),gun('5.7 USG',42,450,20,1.8,5,1,false),gun('SMG-11',35,1270,16,2.1,2),gun('C75 Auto',35,1000,26,2.1,5),gun('Reaper MK2',33,1000,25,2.2,2),gun('ITA12S',22,85,5,3.0,1,8,false)
];
export const weaponModel=(id:number)=>weaponCatalog[id]?.model??0;
export const weaponRail=(id:number)=>({mountY:id===6?.109:id>=6?(weaponModel(id)===5?.040:.058):[.0704,.0535,.046,.0575,.063,.029][id]??.0704,rearZ:id>=6?(weaponModel(id)===5?.045:.04):[ -.08,.105,.06,.09,.05,.045][id]??-.08});
export const weaponPoint=(id:number):[number,number,number]=>id>=6?[0,weaponModel(id)===5?.012:.018,weaponModel(id)===5?-.14:weaponModel(id)===2?-.25:weaponModel(id)===1?(id===17?-.31:-.53):-.45]:[[0,.046,-.28785],[0,.025,-.580],[0,.010,-.250],[0,.012,-.500],[0,.018,-.240],[0,.014,-.126]][id] as [number,number,number];

import type {Game} from './game';
import type {ReplayClip} from './replay';
import {damageTotals,type HitRegion} from './replay-damage';
import {operators,weapons} from './data';
import './round-presentation.css';
const escape=(text:string)=>text.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));

/** Persistent interface nodes avoid rebuilding the replay HUD on every frame. */
export class RoundPresentation{
 result=document.createElement('section');replay=document.createElement('aside');lastResult='';lastClip='';
 private title:HTMLElement;private reason:HTMLElement;private score:HTMLElement;private next:HTMLElement;
 private remaining:HTMLElement|null=null;
 constructor(){
  this.result.id='round-outcome';this.result.className='round-outcome';this.result.hidden=true;this.result.setAttribute('role','status');this.result.setAttribute('aria-live','polite');
  this.result.innerHTML='<div class="round-outcome-content"><h1></h1><p class="round-reason"></p><div class="round-score"></div><p class="round-next"></p></div>';
  this.title=this.result.querySelector('h1')!;this.reason=this.result.querySelector('.round-reason')!;this.score=this.result.querySelector('.round-score')!;this.next=this.result.querySelector('.round-next')!;
  this.replay.id='replay-summary';this.replay.className='replay-summary';this.replay.hidden=true;this.replay.setAttribute('aria-label','Final kill replay');
  document.body.append(this.result,this.replay);
 }
 hide(){this.result.hidden=true;this.replay.hidden=true;}
 prepareReplay(clip:ReplayClip){const resultHidden=this.result.hidden,replayHidden=this.replay.hidden;this.showReplay(clip,0);this.result.hidden=resultHidden;this.replay.hidden=replayHidden;}
 showResult(game:Game){
  const r=game.roundSequence.result;if(!r||r.round!==game.round||game.phase!=='result'){this.hide();return;}
  const fresh=this.lastResult!==r.id,won=r.winner===game.team;
  this.replay.hidden=true;this.result.hidden=false;
  if(fresh){
   this.lastResult=r.id;this.result.className='round-outcome '+(won?'round-won':'round-lost');
   this.title.textContent=won?'ROUND WON':'ROUND LOST';this.reason.textContent=r.reason;
   this.score.innerHTML=`<span>Attack <strong>${r.score[0]}</strong></span><span>Defense <strong>${r.score[1]}</strong></span>`;
   game.audio.play(won?'round-win':'round-loss',undefined,.45,'round-result:'+r.id);
  }
  const after=game.roundSequence.stage==='hold'||game.roundSequence.stage==='done';
  this.next.textContent=after?'Preparing the next round':r.replayId?'Final kill replay follows':'Objective result · No final kill replay';
  this.result.classList.toggle('round-hold',after);
  game.roundSequence.shown(performance.now());
 }
 showReplay(clip:ReplayClip|null,elapsed:number){
  this.result.hidden=true;this.replay.hidden=false;
  if(!clip){if(this.lastClip!=='missing'){this.replay.innerHTML='<h2>Final kill replay</h2><p>Recording has not arrived.</p>';this.lastClip='missing';this.remaining=null;}return;}
  if(this.lastClip!==clip.id){
   this.lastClip=clip.id;
   const killer=clip.frames.at(-1)?.actors.find(a=>a.id===clip.killer),victim=clip.frames.at(-1)?.actors.find(a=>a.id===clip.victim);
   const hits=clip.damage??[],totals=damageTotals(hits),lastHit=[...hits].reverse().find(e=>e.attacker===clip.killer),weapon=lastHit?.weapon??(killer?.slot?5:killer?.weapon);
   const active=(region:HitRegion)=>totals[region]>0?' class="damage-hit"':'',amount=(n:number)=>Number.isInteger(n)?String(n):n.toFixed(1);
   const silhouette=`<svg class="damage-silhouette" viewBox="0 0 100 200" role="img" aria-label="Recorded victim hit regions"><circle cx="50" cy="21" r="15"${active('head')}/><path d="M32 42 H68 L64 108 H36 Z"${active('torso')}/><g${active('arms')}><path d="M26 45 L15 48 L7 105 L18 108 L30 65 Z"/><path d="M74 45 L85 48 L93 105 L82 108 L70 65 Z"/></g><g${active('legs')}><path d="M36 114 H48 L45 190 H30 Z"/><path d="M52 114 H64 L70 190 H55 Z"/></g></svg>`;
   const rows=(['head','torso','arms','legs'] as HitRegion[]).filter(region=>totals[region]>0).map(region=>`<div><dt>${region[0].toUpperCase()+region.slice(1)}</dt><dd>${amount(totals[region])}</dd></div>`).join('');
   this.replay.innerHTML=`<header><h2>FINAL KILL</h2><time></time></header><p class="replay-player">${escape(killer?.name??clip.killer)}</p><p>${escape(operators[killer?.op??-1]?.name??'Unknown operator')} · ${escape(weapons[weapon??-1]?.name??'Weapon not recorded')}</p><p class="replay-victim">Eliminated ${escape(victim?.name??clip.victim)}</p><div class="replay-damage">${silhouette}<section aria-label="Victim damage totals"><h3>Encounter damage</h3>${rows?`<dl>${rows}</dl>`:'<p>No localized damage recorded.</p>'}${totals.unlocalized?`<p>Unlocalized: ${amount(totals.unlocalized)}</p>`:''}${totals.penetrated?`<p>Through surfaces: ${amount(totals.penetrated)}</p>`:''}${clip.damageComplete===false?'<p>Recording limit reached; totals may be partial.</p>':''}</section></div>`;
   this.remaining=this.replay.querySelector('time');
  }
  if(this.remaining)this.remaining.textContent=Math.max(0,3.5-elapsed).toFixed(1)+'s';
 }
}

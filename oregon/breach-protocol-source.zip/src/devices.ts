import {gasCloudMaterial} from './gas-cloud';
import {jammerRadius} from './gadget-effects';
import type {Device} from './game';
import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';

export function deviceRoot(object:THREE.Object3D):THREE.Mesh|undefined{return object.userData.deviceRoot;}
export function deviceMesh(type:string){
 const mesh=new THREE.Mesh(type==='charge'?new RoundedBoxGeometry(.32,.44,.075,1,.01):type==='jammer'?new RoundedBoxGeometry(.28,.25,.20,1,.015):type==='round'?new THREE.CylinderGeometry(.045,.045,.20,8).rotateX(Math.PI/2):new THREE.CylinderGeometry(.105,.115,.30,8),new THREE.MeshLambertMaterial({color:type==='gas'?0x667445:type==='charge'?0xc69d5a:type==='round'?0x606970:0x39434a,transparent:type==='gas',opacity:1,depthWrite:true}));
 mesh.userData.deviceGeometry=mesh.geometry;mesh.userData.deviceMaterial=mesh.material;
 const batches=new Map<number,THREE.BufferGeometry[]>();
 const part=(color:number,geometry:THREE.BufferGeometry,x:number,y:number,z:number)=>{geometry.translate(x,y,z);if(!batches.has(color))batches.set(color,[]);batches.get(color)!.push(geometry);};
 const box=(c:number,w:number,h:number,d:number,x:number,y:number,z:number)=>part(c,new THREE.BoxGeometry(w,h,d),x,y,z);
 const cylinder=(c:number,r:number,h:number,x:number,y:number,z:number)=>part(c,new THREE.CylinderGeometry(r,r,h,8),x,y,z);
 const black=0x20272b,steel=0x899497,signal=0x77d38a;
 if(type==='jammer'){
  for(const x of [-.105,.105])for(const z of [-.07,.07]){cylinder(black,.007,.27,x,.25,z);cylinder(steel,.014,.022,x,.126,z);box(black,.055,.025,.04,x,-.135,z);}
  box(black,.12,.055,.012,0,.035,.105);box(signal,.08,.024,.005,0,.035,.113);
  for(const x of [-.08,.08])box(steel,.018,.025,.012,x,-.06,.108);
  for(const x of [-.055,0,.055])box(black,.026,.025,.012,x,.135,0);
 }else if(type==='gas'){
  cylinder(black,.107,.025,0,-.13,0);cylinder(steel,.098,.025,0,.15,0);
  box(black,.055,.033,.06,0,.18,0);box(steel,.065,.009,.014,0,.16,-.074);
  box(black,.065,.058,.009,0,.05,-.105);box(signal,.014,.012,.005,.02,.065,-.112);
  for(const y of [-.07,.095])cylinder(black,.116,.018,0,y,0);
  mesh.userData.cloudGeometry=new THREE.SphereGeometry(.18,8,6);mesh.userData.cloudMaterial=gasCloudMaterial();
 }else if(type==='charge'){
  for(const x of [-.11,.11]){box(black,.035,.38,.018,x,0,.046);for(const y of [-.17,.17])box(steel,.055,.023,.025,x,y,.06);}
  box(black,.14,.08,.033,0,.14,.057);box(signal,.052,.02,.005,-.026,.14,.077);
  box(black,.022,.22,.018,.025,-.015,.056);box(black,.12,.018,.018,-.025,-.12,.056);
  for(const y of [-.075,0,.075])box(steel,.15,.018,.012,-.025,y,.046);
 }else if(type==='round'){
  part(black,new THREE.ConeGeometry(.045,.06,8).rotateX(-Math.PI/2),0,0,-.13);
  for(const angle of [0,Math.PI/2]){const fin=new THREE.BoxGeometry(.13,.008,.065);fin.rotateZ(angle);part(steel,fin,0,0,.06);}
 }
 for(const [color,geometries] of batches){const geometry=mergeGeometries(geometries,false)!;for(const source of geometries)source.dispose();const material=new THREE.MeshLambertMaterial({color});if(type==='charge'&&color===signal)mesh.userData.signalMaterial=material;mesh.add(new THREE.Mesh(geometry,material));}
 mesh.traverse(o=>{o.userData.deviceRoot=mesh;o.userData.bulletMaterial='metal';});return mesh;
}
export type ChargeStatus='ready'|'jammed'|'burning';
export function chargeStatus(device:Device,devices:readonly Device[]):ChargeStatus{
 if(device.active)return 'burning';
 return devices.some(d=>d.type==='jammer'&&d.mesh.visible&&d.pos.distanceToSquared(device.pos)<jammerRadius*jammerRadius)?'jammed':'ready';
}
// Reuse the existing status-light batch: no extra mesh, texture or replicated field.
export function updateChargeFeedback(devices:readonly Device[]){
 for(const d of devices){if(d.type!=='charge'||!d.mesh.visible)continue;const state=chargeStatus(d,devices);if(d.mesh.userData.chargeStatus===state)continue;
  d.mesh.userData.chargeStatus=state;const material=d.mesh.userData.signalMaterial as THREE.MeshLambertMaterial|undefined;
  if(material)material.color.setHex(state==='jammed'?0xee6255:state==='burning'?0xffa143:0x77d38a);
 }
}
export function ownedChargeSummary(devices:readonly Device[],owner:string){
 const counts={ready:0,jammed:0,burning:0};for(const d of devices)if(d.type==='charge'&&d.mesh.visible&&d.owner===owner)counts[chargeStatus(d,devices)]++;
 return (Object.keys(counts) as ChargeStatus[]).filter(state=>counts[state]>0).map(state=>counts[state]+' '+state.toUpperCase()).join(' · ');
}
export function deviceScale(mesh:THREE.Mesh,type:string,active:boolean){
 if(type==='gas'){mesh.geometry=active?mesh.userData.occludedCloudGeometry??mesh.userData.cloudGeometry:mesh.userData.deviceGeometry;mesh.material=active?mesh.userData.cloudMaterial:mesh.userData.deviceMaterial;for(const child of mesh.children)child.visible=!active;}
 mesh.scale.setScalar(type==='gas'&&active?4/.18:1);
}
export function disposeDevice(mesh:THREE.Mesh){
 const geometries=new Set<THREE.BufferGeometry>(),materials=new Set<THREE.Material>();
 mesh.traverse(o=>{if(o instanceof THREE.Mesh){geometries.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:[o.material])materials.add(m);}});
 for(const geo of [mesh.userData.deviceGeometry,mesh.userData.cloudGeometry,mesh.userData.occludedCloudGeometry])if(geo)geometries.add(geo);
 for(const material of [mesh.userData.deviceMaterial,mesh.userData.cloudMaterial])if(material)materials.add(material);for(const geo of geometries)geo.dispose();for(const material of materials)material.dispose();mesh.removeFromParent();
}

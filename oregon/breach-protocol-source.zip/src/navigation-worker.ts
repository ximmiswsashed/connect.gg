type Init={kind:'init',positions:Float32Array,offsets:Uint32Array,links:Uint32Array};
type Query={kind:'route',id:number,start:number,goal:number,extra:[number,number][],blocked?:number[],blockedLinks?:[number,number][]};
const context=globalThis as unknown as {onmessage:(e:MessageEvent<Init|Query>)=>void,postMessage:(data:unknown)=>void};
let positions:Float32Array,offsets:Uint32Array,links:Uint32Array;
context.onmessage=e=>{const m=e.data;if(m.kind==='init'){positions=m.positions;offsets=m.offsets;links=m.links;return;}const count=positions.length/3,blocked=new Set(m.blocked??[]),blockedLinks=new Set((m.blockedLinks??[]).map(([i,j])=>i*count+j)),prev=new Int32Array(count).fill(-1),cost=new Float32Array(count).fill(Infinity),closed=new Uint8Array(count),heap:[number,number][]=[];
 const distance=(a:number,b:number)=>Math.hypot(positions[a*3]-positions[b*3],positions[a*3+1]-positions[b*3+1],positions[a*3+2]-positions[b*3+2]);const extra=new Map<number,number[]>();for(const [i,j] of m.extra){const list=extra.get(i)??[];list.push(j);extra.set(i,list);}
 const push=(id:number,f:number)=>{let i=heap.length;heap.push([id,f]);while(i){const parent=(i-1)>>1;if(heap[parent][1]<=f)break;heap[i]=heap[parent];i=parent;}heap[i]=[id,f];};
 const pop=()=>{const first=heap[0],last=heap.pop()!;if(heap.length){let i=0;while(i*2+1<heap.length){let j=i*2+1;if(j+1<heap.length&&heap[j+1][1]<heap[j][1])j++;if(heap[j][1]>=last[1])break;heap[i]=heap[j];i=j;}heap[i]=last;}return first[0];};cost[m.start]=0;prev[m.start]=m.start;push(m.start,0);
 while(heap.length){const i=pop();if(closed[i])continue;closed[i]=1;if(i===m.goal)break;const visit=(j:number)=>{if(closed[j]||blocked.has(j)||blockedLinks.has(i*count+j))return;const c=cost[i]+distance(i,j);if(c<cost[j]){cost[j]=c;prev[j]=i;push(j,c+distance(j,m.goal));}};for(let k=offsets[i];k<offsets[i+1];k++)visit(links[k]);for(const j of extra.get(i)??[])visit(j);}
 const ids:number[]=[];if(closed[m.goal]){ids.push(m.goal);while(ids.at(-1)!==m.start)ids.push(prev[ids.at(-1)!]);ids.reverse();}context.postMessage({id:m.id,ids});
};

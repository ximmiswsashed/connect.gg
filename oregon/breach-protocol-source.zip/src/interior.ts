import type {World} from './world';import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';import {bakeGeometry} from './materials';
import {rooms,planX,planZ} from './map-plan';
// Authored from the supplied February 2020 tour; individual 2025 continuity remains in the reference checklist.
// Decorative surfaces never acquire destruction flags. Every piece of cover is registered at every quality.
export function buildInterior(w:World){
 const b=(room:string,x:number,y:number,z:number,W:number,H:number,D:number,mat:string,solid=true)=>{const r=rooms.find(r=>r.id===room)!;const m=w.box(planX(x),r.f*4+y,planZ(z),W,H,D,mat,solid);if(['redcabinet','fabric','sandbag','wood','white'].includes(mat)&&Math.min(W,H,D)>.1){const old=m.geometry;m.geometry=bakeGeometry(new RoundedBoxGeometry(W,H,D,1,Math.min(.025,Math.min(W,H,D)*.15)));m.userData.originalGeometry=m.geometry;old.dispose();}m.userData.propId=room+'-visual-'+x+'-'+z;m.userData.reference='fQCcwDttF4E · reference board';if(solid){m.userData.bulletMaterial=['wood','redcabinet'].includes(mat)?'wood':mat==='metal'?'metal':'stone';m.userData.penetration=mat==='wood'&&H<1.2&&Math.min(W,D)<.3;}return m;};
 const shelf=(room:string,x:number,z:number,width:number,depth:number,height:number,mat='white')=>{if(room==='supply'){for(const dx of [-width/2,width/2])for(const dz of [-depth/2,depth/2])b(room,x+dx/.075,height/2,z+dz/.075,.055,height,.055,mat);}else{b(room,x,height/2,z,width,height,.06,mat);for(const dx of [-width/2,width/2])b(room,x+dx/.075,height/2,z,.055,height,depth,mat);}for(const y of [.15,.65,1.15,1.65].filter(y=>y<height)){b(room,x,y,z,width,.055,depth,mat);for(let i=0;i<3;i++)b(room,x+(i-1)*width/4/.075,y+.075,z,.22,.12,.26,i%2?'green':'fabric',false);}};
 // Kitchen: red wall-mounted cabinets, cream bases, stainless worktops, and full-height refrigerator cover.
 for(const x of [327,350,373,396]){b('kitchen',x,.46,344,1.62,.92,.62,'white');b('kitchen',x,.95,344,1.68,.07,.68,'metal');b('kitchen',x,2.28,348,1.62,.62,.42,'redcabinet');for(const dx of [-.35,.35])b('kitchen',x+dx/.075,2.25,344.8,.025,.18,.03,'metal',false);}
 b('kitchen',371,1.03,298,1.1,2.06,.82,'white');b('kitchen',371,1.1,292.3,.93,1.7,.025,'metal',false);b('kitchen',376,1.10,292,.035,.34,.035,'metal',false);
 for(const z of [270,292,314]){b('kitchen',459,.45,z,.62,.9,1.56,'white');b('kitchen',459,.94,z,.7,.08,1.62,'metal');}
 b('kitchen',457,2.15,307,.8,.25,1.6,'metal');b('kitchen',460,2.7,307,.34,.9,.48,'metal',false);
 // Classroom is improvised fortified cover, not a school desk grid (tour 5:31).
 for(const [x,z] of [[486,437],[502,448]])for(let row=0;row<3;row++)for(let i=0;i<4;i++)b('classroom',x+(i-1.5)*5+(row%2?2:0),.15+row*.25,z,.4,.28,.55,'sandbag');
 // Meeting: couches, piano, table and string-lit exposed structural beams (6:27 and reverse 6:57).
 const sofa=(x:number,z:number,axis='z')=>{b('meeting',x,.27,z,axis==='z'?2:.75,.4,axis==='z'?.75:2,'fabric');b('meeting',x,.66,z+(axis==='z'?4:0),axis==='z'?2:.2,.6,axis==='z'?.2:2,'fabric');for(const side of [-1,1])b('meeting',x+(axis==='z'?side*12:0),.55,z+(axis==='z'?0:side*12),axis==='z'?.18:.75,.65,axis==='z'?.75:.18,'fabric');};
 sofa(495,217);sofa(479,280,'x');b('meeting',586,.52,326,1.85,1.04,.65,'wood');b('meeting',586,.82,321.3,1.55,.055,.38,'white',false);b('meeting',586,.63,329,.16,.2,.08,'metal',false);
 for(const x of [490,563]){b('meeting',x,1.95,300,.22,3.9,.22,'wood');b('meeting',x,3.70,269,.24,.25,12.5,'wood',false);}
 for(let i=0;i<13;i++)b('meeting',482+i*9,3.25+Math.sin(i/12*Math.PI)*-.25,320,.04,.055,.04,'white',false);
 // Trophy display case and original stylized taxidermy silhouettes (8:10); no imported game assets.
 b('trophy',467,.55,338,1.9,1.1,.8,'wood');b('trophy',467,1.13,338,1.96,.1,.86,'wood');for(const dx of [-.93,.93])b('trophy',467+dx/.075,1.6,338,.08,.95,.8,'wood');b('trophy',467,2.08,338,1.96,.08,.8,'wood');b('trophy',467,1.55,338,.65,.25,.23,'sandbag',false);b('trophy',473,1.78,338,.16,.3,.18,'sandbag',false);b('trophy',572,1.95,337,.38,.44,.29,'sandbag',false);
 shelf('dorms',317,410,1.25,.4,2.05);shelf('dorms',318,370,1.3,.4,1.95);
 // Kids room red center divider/bunk and dresser; cover coordinates are traced from the historical plan.
 b('kids',374,1.12,333,1.30,2.24,.09,'redcabinet');b('kids',423,.55,274,1.25,1.1,.55,'white');for(let i=0;i<3;i++)b('kids',423,.25+i*.32,278,.75,.04,.025,'metal',false);
 // Supply continuity cross-checked in the 2025 guide at 10:49: metal shelving and yellow low cart.
 shelf('supply',514,238,1.7,.52,2.1,'green');shelf('supply',575,235,1.65,.5,2.05,'green');
 b('supply',554,.52,266,1.2,.09,.75,'yellow');for(const x of [547,561])for(const z of [262,270]){b('supply',x,.27,z,.05,.48,.05,'metal');b('supply',x,.08,z,.13,.16,.10,'metal');}b('supply',554,.67,266,.48,.25,.38,'wood');
 for(const x of [493,504,515])for(let row=0;row<3;row++)b('meeting',x+(row%2?2:0),.15+row*.25,332,.45,.28,.57,'sandbag');
 shelf('small',149,363,2.2,.48,2.1,'metal');b('small',122,.45,365,1.0,.9,1.3,'metal');
 // Wall trim, exposed plaster/brick bands and roof beams follow each room's authored boundaries.
 for(const r of rooms){if(r.f<0)continue;const x=(r.x0+r.x1)/2,z=(r.z0+r.z1)/2;for(const [xx,zz,W,D] of [[x,r.z0+.1,r.x1-r.x0,.06],[x,r.z1-.1,r.x1-r.x0,.06],[r.x0+.1,z,.06,r.z1-r.z0],[r.x1-.1,z,.06,r.z1-r.z0]]){const m=w.box(xx,r.f*4+.12,zz,W,.16,D,'wood',false);m.userData.trim=true;}}
}

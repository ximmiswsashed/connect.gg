import * as THREE from 'three';

// Texture extents include transparent padding. Each pattern needs its own size.
export const reticleImageWidths:Record<string,number>={holo:.0055,reddot:.0006,reflex:.0015,acog:.005};

// A collimated image is sampled only by fragments of the authored rear lens.
// Camera-forward is also the central ballistic aim ray. Housing depth occludes
// the image, and no geometry exists outside the lens aperture.
export function opticalReticle(texture:THREE.Texture,optic:string,anchorOverride?:THREE.Vector2){
 const anchor=anchorOverride??(optic==='reflex'||optic==='nomreflex'?new THREE.Vector2(.5,.546875):optic==='acog'?new THREE.Vector2(.4990234375,.9697265625):new THREE.Vector2(.5,.5));
 const material=new THREE.ShaderMaterial({transparent:true,depthTest:true,depthWrite:false,side:THREE.FrontSide,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1,toneMapped:false,
  uniforms:{reticleMap:{value:texture},brightness:{value:.8},opacity:{value:1},angularSize:{value:new THREE.Vector2(.07,.07)},aimAnchor:{value:anchor},tint:{value:new THREE.Color(optic==='reflex'||optic==='nomreflex'?0x63ff47:0xff4234)}},
  vertexShader:`varying vec3 vView; varying vec2 vRight; varying vec2 vUp;
  void main(){vec4 p=modelViewMatrix*vec4(position,1.0);vView=p.xyz;vRight=normalize(modelViewMatrix[0].xy);vUp=normalize(modelViewMatrix[1].xy);gl_Position=projectionMatrix*p;}`,
  fragmentShader:`uniform sampler2D reticleMap;uniform float brightness;uniform float opacity;uniform vec2 angularSize;uniform vec2 aimAnchor;uniform vec3 tint;varying vec3 vView;varying vec2 vRight;varying vec2 vUp;
  void main(){vec2 ray=vView.xy/max(.001,-vView.z);vec2 uv=aimAnchor+vec2(dot(ray,vRight),dot(ray,vUp))/angularSize;if(any(lessThan(uv,vec2(0.0)))||any(greaterThan(uv,vec2(1.0))))discard;vec4 image=texture2D(reticleMap,uv);if(image.a<.015)discard;gl_FragColor=vec4(tint,smoothstep(.03,.45,image.a)*brightness*opacity);}`
 });
 const mesh=new THREE.Mesh(new THREE.BufferGeometry(),material);mesh.name='Optical reticle';mesh.frustumCulled=false;mesh.renderOrder=12;mesh.userData.aimAnchor=anchor.toArray();return mesh;
}

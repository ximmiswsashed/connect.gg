import * as THREE from 'three';
import type {Game,Device} from './game';
import {sweepSphereTriangle} from './swept-sphere';

export type RoundUtilityContact={distance:number,point:THREE.Vector3,normal:THREE.Vector3,root:THREE.Object3D};
export type UtilityScene=Pick<Game,'devices'|'externalDevices'|'droneUnit'|'externalDrones'|'humans'|'bots'|'scouts'>;
export function roundUtilityRoots(game:UtilityScene,round?:Device):THREE.Object3D[]{
 const devices=[...new Set([...game.devices,...game.externalDevices])].filter(d=>d!==round&&d.mesh.visible&&d.type!=='destroyed'&&!(d.type==='gas'&&d.active));
 const drones=[...new Set([game.droneUnit,...game.externalDrones,...game.humans.map(h=>h.actor.droneUnit),...game.bots.flatMap(b=>b.drone?[b.drone]:[])])].filter(d=>d.alive&&d.deployed);
 return [...devices.map(d=>d.mesh),...drones.map(d=>d.mesh),...game.scouts.filter(s=>s.mesh.visible).map(s=>s.mesh)];
}
export function roundUtilityContact(game:UtilityScene,round:Device|undefined,from:THREE.Vector3,dir:THREE.Vector3,length:number,radius:number):RoundUtilityContact|null{
 const roots=roundUtilityRoots(game,round);
 const box=new THREE.Box3().setFromPoints([from,from.clone().addScaledVector(dir,length)]).expandByScalar(radius);
 let best:RoundUtilityContact|null=null;
 for(const root of roots){root.updateWorldMatrix(true,true);root.traverseVisible(o=>{
  const mesh=o as THREE.Mesh;if(!mesh.isMesh)return;
  const geometry=mesh.geometry;if(!geometry.boundingBox)geometry.computeBoundingBox();
  if(!geometry.boundingBox||!geometry.boundingBox.clone().applyMatrix4(mesh.matrixWorld).intersectsBox(box))return;
  const positions=geometry.getAttribute('position'),index=geometry.index;
  const vertex=(i:number)=>new THREE.Vector3().fromBufferAttribute(positions,index?index.getX(i):i).applyMatrix4(mesh.matrixWorld);
  for(let i=0;i<(index?.count??positions.count);i+=3){
   const triangle=new THREE.Triangle(vertex(i),vertex(i+1),vertex(i+2));
   const hit=sweepSphereTriangle(from,dir,best?.distance??length,radius,triangle);
   if(hit)best={distance:hit.distance,point:hit.point,normal:hit.normal,root};
  }
 });}
 return best;
}

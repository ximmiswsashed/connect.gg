import * as THREE from 'three';
export type SphereSweepHit={distance:number,point:THREE.Vector3,normal:THREE.Vector3};
// Continuous sphere/triangle contact: face slab, finite edge cylinders and vertices.
// Direction must be normalized. Geometry and distances are world-space metres.
export function sweepSphereTriangle(from:THREE.Vector3,dir:THREE.Vector3,length:number,radius:number,triangle:THREE.Triangle):SphereSweepHit|null{
 let best:SphereSweepHit|null=null;
 const normal=triangle.getNormal(new THREE.Vector3());
 const accept=(distance:number,point:THREE.Vector3)=>{
  if(distance< -1e-9||distance>length+1e-9||best&&distance>=best.distance)return;
  distance=Math.max(0,Math.min(length,distance));
  const n=from.clone().addScaledVector(dir,distance).sub(point);
  if(n.lengthSq()<1e-18){n.copy(normal);if(n.dot(dir)>0)n.negate();}else n.normalize();
  best={distance,point:point.clone(),normal:n};
 };
 const closest=triangle.closestPointToPoint(from,new THREE.Vector3());
 if(closest.distanceToSquared(from)<=radius*radius+1e-12)accept(0,closest);
 const roots=(a:number,b:number,c:number)=>{
  if(a<1e-16)return [];
  const discriminant=b*b-4*a*c;if(discriminant< -1e-12)return [];
  const root=Math.sqrt(Math.max(0,discriminant));return [(-b-root)/(2*a),(-b+root)/(2*a)];
 };
 const signed=normal.dot(from.clone().sub(triangle.a)),velocity=normal.dot(dir);
 if(Math.abs(velocity)>1e-12)for(const side of [-1,1]){
  const t=(side*radius-signed)/velocity;
  if(t<0||t>length)continue;
  const contact=from.clone().addScaledVector(dir,t).addScaledVector(normal,-side*radius);
  if(triangle.containsPoint(contact))accept(t,contact);
 }
 for(const [a,b] of [[triangle.a,triangle.b],[triangle.b,triangle.c],[triangle.c,triangle.a]]){
  const edge=b.clone().sub(a),edgeLength=edge.length();if(edgeLength<1e-12)continue;edge.divideScalar(edgeLength);
  const offset=from.clone().sub(a),along=offset.dot(edge),speed=dir.dot(edge);
  const perpendicular=offset.clone().addScaledVector(edge,-along),direction=dir.clone().addScaledVector(edge,-speed);
  for(const t of roots(direction.lengthSq(),2*perpendicular.dot(direction),perpendicular.lengthSq()-radius*radius)){
   const coordinate=along+speed*t;if(coordinate>=0&&coordinate<=edgeLength)accept(t,a.clone().addScaledVector(edge,coordinate));
  }
 }
 for(const vertex of [triangle.a,triangle.b,triangle.c]){
  const offset=from.clone().sub(vertex);
  for(const t of roots(1,2*offset.dot(dir),offset.lengthSq()-radius*radius))accept(t,vertex);
 }
 return best;
}
export function boxTriangles(min:THREE.Vector3,max:THREE.Vector3){
 const corners=Array.from({length:8},(_,i)=>new THREE.Vector3(i&1?max.x:min.x,i&2?max.y:min.y,i&4?max.z:min.z));
 return [[0,2,3],[0,3,1],[4,5,7],[4,7,6],[0,1,5],[0,5,4],[2,6,7],[2,7,3],[0,4,6],[0,6,2],[1,3,7],[1,7,5]].map(([a,b,c])=>new THREE.Triangle(corners[a],corners[b],corners[c]));
}

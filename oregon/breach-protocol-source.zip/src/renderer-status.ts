/** A context can exist while WebGL is rasterized on the CPU. */
export function rendererStatus(name:string){
 const software=/swiftshader|llvmpipe|softpipe|software|\bwarp\b|microsoft basic render/i.test(name);
 const unknown=!name||/^(WebKit WebGL|WebGL|ANGLE)$/i.test(name);
 return {name,software,kind:software?'software':unknown?'unknown':'hardware'} as const;
}

export function rendererStatusHTML(name:string){
 const status=rendererStatus(name),safe=name.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
 const message=status.software
  ? 'Software rendering detected: WebGL is running on the CPU. On Windows with Brave, download and run the website GPU launcher below. It opens this website using the dedicated D3D11 profile used by the local game. You may need to sign in again in that profile. Alternatively, enable graphics acceleration in Brave Settings / System and relaunch. Check brave://gpu for a fallback reason and choose Default or D3D11 in the ANGLE backend setting, rather than D3D11 WARP. A webpage cannot change the browser graphics backend.'
  :status.kind==='unknown'?'The browser hides the graphics adapter. Hardware acceleration could not be verified.':'Hardware graphics adapter detected.';
 return `<p role="status">${message}</p><dl><dt>WebGL renderer</dt><dd style="overflow-wrap:anywhere">${safe||'Not disclosed by browser'}</dd></dl><p><a href="./Play%20Website%20-%20GPU.cmd" download="Play Website - GPU.cmd">Download website GPU launcher · Windows / Brave</a></p><p>The game supports a 240 FPS limit. Your monitor refresh rate and browser scheduling can impose a lower ceiling. A steady 60 FPS cap can also come from display settings or browser energy saving. Open Settings to choose 240 FPS; use F8 during a match to record actual rendering performance.</p>`;
}

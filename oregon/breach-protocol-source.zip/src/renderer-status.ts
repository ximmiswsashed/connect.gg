/** A context can exist while WebGL is rasterized on the CPU. */
export function rendererStatus(name:string){
 const software=/swiftshader|llvmpipe|softpipe|software|\bwarp\b|microsoft basic render/i.test(name);
 const unknown=!name||/^(WebKit WebGL|WebGL|ANGLE)$/i.test(name);
 return {name,software,kind:software?'software':unknown?'unknown':'hardware'} as const;
}

export function rendererStatusHTML(name:string){
 const status=rendererStatus(name),safe=name.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
 const message=status.software
  ? 'Software rendering detected: WebGL is running on the CPU. For the downloaded game, close this game tab and open Start Game.cmd to use its dedicated D3D11 browser profile. Otherwise, enable graphics acceleration in Brave Settings / System and relaunch. If already enabled, check brave://gpu for the fallback reason. In brave://flags, Choose ANGLE graphics backend should be Default or D3D11, never D3D11 WARP. A webpage cannot change browser GPU routing.'
  :status.kind==='unknown'?'The browser hides the graphics adapter. Hardware acceleration could not be verified.':'Hardware graphics adapter detected.';
 return `<p role="status">${message}</p><dl><dt>WebGL renderer</dt><dd style="overflow-wrap:anywhere">${safe||'Not disclosed by browser'}</dd></dl>`;
}

import type {Device} from './game';
// Historical operator tuning used by this Y9S4 map build.
export const jammerRadius=2.25;
// Y6S3 made both zones spherical: warning precedes control disruption.
export const jammerWarningRadius=4.75;
export function pendingCharge(devices:Device[],owner:string){return devices.find(d=>d.type==='charge'&&!d.active&&d.mesh.visible&&d.time>0&&d.owner===owner)??null;}
export const gasInterval=.66;
export const gasTickDamage=15;

// Each victim has its own exposure clock; leaving the cloud resets exposure.
const gasClocks=new WeakMap<object,WeakMap<object,number>>();
export function gasDamage(device:object,target:object,dt:number,exposed:boolean){
 let clocks=gasClocks.get(device);
 if(!clocks){clocks=new WeakMap();gasClocks.set(device,clocks);}
 if(!exposed){clocks.delete(target);return 0;}
 const remaining=(clocks.get(target)??0)-dt;
 const ticks=remaining<=0?Math.floor((-remaining+1e-9)/gasInterval)+1:0;
 clocks.set(target,remaining+ticks*gasInterval);
 return ticks*gasTickDamage;
}

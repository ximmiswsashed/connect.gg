import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';

// Stylized backpack electronics. Keep its rear depth inside the original backpack
// profile so the prone silhouette does not grow beyond the existing body envelope.
export function ercPack(){
 const root=new THREE.Group(),caseParts:THREE.BufferGeometry[]=[],hardware:THREE.BufferGeometry[]=[];
 root.name='ERC-7 backpack';root.userData.skinAttachment=true;
 const box=(parts:THREE.BufferGeometry[],w:number,h:number,d:number,x:number,y:number,z:number,rounded=false)=>parts.push((rounded?new RoundedBoxGeometry(w,h,d,1,.01):new THREE.BoxGeometry(w,h,d)).translate(x,y,z));
 box(caseParts,.31,.40,.04,0,.03,.14,true);box(caseParts,.28,.36,.10,0,.03,.20,true);
 for(const side of [-1,1]){
  box(hardware,.025,.27,.035,side*.15,.03,.20);
  for(const y of [-.11,-.065,-.02,.025,.07,.115])box(hardware,.025,.012,.075,side*.15,y,.20);
  caseParts.push(new THREE.CylinderGeometry(.009,.009,.09,8).translate(side*.09,.25,.18));
  hardware.push(new THREE.CylinderGeometry(.014,.014,.023,8).translate(side*.09,.209,.18));
  box(hardware,.035,.035,.011,side*.09,-.07,.255);
  box(caseParts,.03,.34,.014,side*.115,.02,.121);
 }
 for(const y of [-.018,.012,.042,.072,.102])box(hardware,.16,.008,.010,0,y,.253);
 box(hardware,.064,.039,.010,0,-.094,.253);
 for(const [parts,color] of [[caseParts,0x30393c],[hardware,0x596765]] as const){const flat=parts.map(g=>g.index?g.toNonIndexed():g),geometry=mergeGeometries(flat)!;for(const g of new Set([...parts,...flat]))g.dispose();const mesh=new THREE.Mesh(geometry,new THREE.MeshLambertMaterial({color}));mesh.userData.cosmetic=true;mesh.userData.ownedSkinMaterial=true;root.add(mesh);}
 root.userData.modelBounds=new THREE.Box3().setFromObject(root);
 return root;
}
export function disposeErcPack(root:THREE.Group){root.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();for(const m of Array.isArray(o.material)?o.material:[o.material])m.dispose();}});root.removeFromParent();}

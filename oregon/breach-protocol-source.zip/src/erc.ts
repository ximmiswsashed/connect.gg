export const ercCapacity=12;
export const ercRechargeRate=2;
export const ercActivationRatio=.2;
export type CloakedActor={team:number,hp:number,interference?:number,ercGlitch?:number};
export function observationHidden(viewer:{team:number,observing:boolean},actor:CloakedActor){
 return viewer.observing&&viewer.team!==actor.team&&actor.hp>0&&(actor.interference??0)>0&&(actor.ercGlitch??0)<=0;
}

import * as THREE from 'three';
import {magazineReloadMotion} from './weapon-geometry';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
type V3=[number,number,number];
// Keep the dropped support hand clear of the floor until it returns to the grip.
export const proneReloadLift=(p:number)=>.30*THREE.MathUtils.smoothstep(p,0,.06)*(1-THREE.MathUtils.smoothstep(p,.97,1));
// Receiver-relative contact points, in meters. Shared by viewmodel and remote arm IK.
export const gripPose=(weapon:number):{right:V3,left:V3}=>[
 {right:[.022,-.037,.061],left:[-.010,.022,-.195]},
 {right:[.025,-.043,.190],left:[-.018,-.054,-.275]},
 {right:[.024,-.091,.025],left:[-.016,-.029,-.162]},
 {right:[.024,-.091,.057],left:[-.018,-.044,-.285]},
 {right:[.024,-.091,.057],left:[-.024,-.089,-.192]},
 {right:[.025,-.050,.029],left:[-.043,-.055,.015]},
][weapon] as {right:V3,left:V3};
// Sleeve junctions in receiver space; remote forearm IK meets the actual glove wrist.
export const wristPose=(weapon:number):{right:V3,left:V3}=>[
 {right:[.052,-.078,.143],left:[-.054,-.012,-.104]},
 {right:[.070,-.090,.320],left:[-.050,-.085,-.170]},
 {right:[.045,-.125,.098],left:[-.050,-.060,-.057]},
 {right:[.045,-.125,.130],left:[-.050,-.075,-.180]},
 {right:[.045,-.125,.130],left:[-.055,-.129,-.125]},
 {right:[.045,-.084,.104],left:[-.058,-.090,.073]},
][weapon] as {right:V3,left:V3};
export function magazineHandPose(weapon:number,p:number,empty=false){
 const motion=magazineReloadMotion(weapon,p);
 const centers:V3[]=[[-.035,-.110,-.075],[0,0,0],[-.030,-.177,.025],[-.039,-.126,-.094],[-.035,-.112,-.086],[-.033,-.089,.029]];
 const pivot=weapon===0?new THREE.Vector3(0,-.03,-.065):new THREE.Vector3(0,-.12,0),target=new THREE.Vector3(...centers[weapon]);
 target.sub(pivot).applyAxisAngle(new THREE.Vector3(0,0,1),motion.angle).add(pivot);target.x-=motion.left;target.y-=motion.down;
 const idle=new THREE.Vector3(...gripPose(weapon).left),lowIdle=idle.clone().add(new THREE.Vector3(0,-.22,0)),lowTarget=target.clone().add(new THREE.Vector3(0,-.22,0).applyAxisAngle(new THREE.Vector3(0,0,1),motion.angle)).add(new THREE.Vector3(0,0,[3,4].includes(weapon)?-.05:0));
 const controls:V3[]=[[-.039,.050,.040],[0,0,0],[-.041,.028,-.010],[-.040,.019,-.026],[-.040,.030,-.140],[-.034,.025,.040]];
 const control=new THREE.Vector3(...controls[weapon]);control.x-=.052;control.y-=.020;control.z+=Math.sin(Math.PI*THREE.MathUtils.clamp((p-.85)/.09,0,1))*.025;
 const lowControl=control.clone().add(new THREE.Vector3(0,-.22,0)),between=(from:THREE.Vector3,to:THREE.Vector3,start:number,end:number)=>from.clone().lerp(to,THREE.MathUtils.smoothstep(p,start,end));
 let position=idle.clone(),magazineBlend=0,controlBlend=0,rotationZ=0;
 if(p<.06)position=between(idle,lowIdle,0,.06);
 else if(p<.12){const t=THREE.MathUtils.smoothstep(p,.06,.12);position=lowIdle.clone().lerp(lowTarget,t);magazineBlend=t;rotationZ=motion.angle*t;}
 else if(p<.22){position=between(lowTarget,target,.12,.22);magazineBlend=1;rotationZ=motion.angle;}
 else if(p<.78){position=target;magazineBlend=1;rotationZ=motion.angle;}
 else if(!empty){if(p<.84){position=between(target,lowTarget,.78,.84);magazineBlend=1;rotationZ=motion.angle;}else if(p<.92){const t=THREE.MathUtils.smoothstep(p,.84,.92);position=lowTarget.clone().lerp(lowIdle,t);magazineBlend=1-t;}else position=between(lowIdle,idle,.92,1);}
 else if(p<.82){position=between(target,lowTarget,.78,.82);magazineBlend=1;rotationZ=motion.angle;}
 else if(p<.85){const t=THREE.MathUtils.smoothstep(p,.82,.85);position=lowTarget.clone().lerp(lowControl,t);magazineBlend=1-t;controlBlend=t;}
 else if(p<.89){position=between(lowControl,control,.85,.89);controlBlend=1;}
 else if(p<.91){position=control;controlBlend=1;}
 else if(p<.94){position=between(control,lowControl,.91,.94);controlBlend=1;}
 else if(p<.97){const t=THREE.MathUtils.smoothstep(p,.94,.97);position=lowControl.clone().lerp(lowIdle,t);controlBlend=1-t;}
 else position=between(lowIdle,idle,.97,1);
 return {position,rotationZ,magazineBlend,controlBlend};
}
export function shotgunReloadPose(p:number,capacity:number){
 const cycle=(THREE.MathUtils.clamp((p-.06)/.86,0,.999999)*capacity)%1,feed=THREE.MathUtils.smoothstep(cycle,0,.60),shell=new THREE.Vector3(-.080*(1-feed),-.130+.100*feed,.045-.032*feed),idle=new THREE.Vector3(...gripPose(1).left),holding=shell.clone().add(new THREE.Vector3(-.035,-.020,.024));
 // After insertion the shell is hidden. Withdraw along the same clear path to
 // the next pickup so the support hand does not teleport at the cycle wrap.
 if(cycle>=.68)holding.lerp(new THREE.Vector3(-.115,-.150,.069),THREE.MathUtils.smoothstep(cycle,.68,1));
 let hand=holding.clone(),gripBlend=1;const lowIdleStart=idle.clone().add(new THREE.Vector3(0,-.10,0)),lowHolding=holding.clone().add(new THREE.Vector3(0,-.10,0));if(p<.02){hand=idle.clone().lerp(lowIdleStart,THREE.MathUtils.smoothstep(p,0,.02));gripBlend=0;}else if(p<.04){const t=THREE.MathUtils.smoothstep(p,.02,.04);hand=lowIdleStart.lerp(lowHolding,t);gripBlend=t;}else if(p<.06)hand=lowHolding.lerp(holding,THREE.MathUtils.smoothstep(p,.04,.06));
 if(p>=.92){const low=holding.clone().add(new THREE.Vector3(0,-.10,0)),lowIdle=idle.clone().add(new THREE.Vector3(0,-.10,0));if(p<.95)hand=holding.clone().lerp(low,THREE.MathUtils.smoothstep(p,.92,.95));else if(p<.98){const t=THREE.MathUtils.smoothstep(p,.95,.98);hand=low.lerp(lowIdle,t);gripBlend=1-t;}else{hand=lowIdle.lerp(idle,THREE.MathUtils.smoothstep(p,.98,1));gripBlend=0;}}
 return {shell,visible:p>=.06&&p<.92&&cycle<.68,gripBlend,hand};
}
function pistolHand(side:number){
 const root=new THREE.Group(),parts:THREE.BufferGeometry[]=[],sleeves:THREE.BufferGeometry[]=[],origin=new THREE.Vector3(...(side===1?gripPose(5).right:gripPose(5).left));
 const glove=new THREE.MeshLambertMaterial({color:0x30392f}),cloth=new THREE.MeshLambertMaterial({color:0x526048});
 const link=(a:V3,b:V3,r:number,target=parts)=>{const p=new THREE.Vector3(...a),q=new THREE.Vector3(...b),direction=q.clone().sub(p),g=new THREE.CapsuleGeometry(r,direction.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),direction.normalize()));g.translate(...p.add(q).multiplyScalar(.5).sub(origin).toArray());target.push(g.toNonIndexed());g.dispose();};
 const palm=new THREE.SphereGeometry(1,10,8);palm.scale(side===1?.010:.011,.031,.025);parts.push(palm.toNonIndexed());palm.dispose();
 if(side===1){
  // Three grip fingers wrap around the front strap. Index reaches into the open guard.
  for(let i=0;i<3;i++){const y=-.041-i*.017;link([.025,y,.020],[.025,y,-.009],.0065);link([.025,y,-.009],[-.018,y,-.016],.006);link([-.018,y,-.016],[-.022,y,.006],.0055);}
  link([.026,-.023,.020],[.024,-.028,-.031],.006);link([.024,-.028,-.031],[.008,-.030,-.029],.0055);
  // Thumb crosses behind the backstrap, then lies along the opposite side below the slide.
  link([.025,-.026,.049],[.025,-.016,.075],.008);link([.025,-.016,.075],[-.024,-.015,.075],.0075);link([-.024,-.015,.075],[-.024,-.019,.041],.0065);
  link([.038,-.064,.068],[.045,-.084,.104],.018);
  link([.045,-.084,.104],[.104,-.145,.255],.029,sleeves);
 }else{
  // Support palm fills the exposed left side, fingers outside the firing-hand knuckles.
  for(let i=0;i<4;i++){const y=-.033-i*.016;link([-.043,y,.006],[-.031,y,-.025],.0065);link([-.031,y,-.025],[.012,y,-.031],.006);link([.012,y,-.031],[.027,y,-.020],.0055);}
  link([-.040,-.029,.029],[-.031,-.025,-.007],.008);link([-.031,-.025,-.007],[-.029,-.017,-.040],.0065);
  link([-.043,-.074,.033],[-.058,-.090,.073],.019);
  link([-.058,-.090,.073],[-.159,-.172,.251],.029,sleeves);
 }
 for(const [geos,material] of [[parts,glove],[sleeves,cloth]] as const){const geometry=mergeGeometries(geos);geos.forEach(g=>g.dispose());if(geometry)root.add(new THREE.Mesh(geometry,material));}
 root.userData.pose=side===1?'pistol-grip':'pistol-support';return root;
}
function verticalGripHand(side:number,weapon=4){
 const root=new THREE.Group(),parts:THREE.BufferGeometry[]=[],sleeves:THREE.BufferGeometry[]=[],origin=new THREE.Vector3(...(side===1?gripPose(weapon).right:gripPose(weapon).left));
 const glove=new THREE.MeshLambertMaterial({color:0x30392f}),cloth=new THREE.MeshLambertMaterial({color:0x526048});
 const link=(a:V3,b:V3,r:number,target=parts)=>{const shift=weapon===2?new THREE.Vector3(0,0,-.032):new THREE.Vector3(),p=new THREE.Vector3(...a).add(shift),q=new THREE.Vector3(...b).add(shift),d=q.clone().sub(p),g=new THREE.CapsuleGeometry(r,d.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize()));g.translate(...p.add(q).multiplyScalar(.5).sub(origin).toArray());target.push(g.toNonIndexed());g.dispose();};
 const palm=new THREE.SphereGeometry(1,10,8);palm.scale(.009,.031,.023);parts.push(palm.toNonIndexed());palm.dispose();
 if(side===1){
  for(let i=0;i<3;i++){const y=-.079-i*.017,z=.028+i*.001;link([.024,y,.051],[.024,y,z],.0065);link([.024,y,z],[-.023,y,z],.006);link([-.023,y,z],[-.023,y,.050],.0055);}
  link([.024,-.060,.052],[.024,-.043,.027],.006);link([.024,-.043,.027],[.005,-.043,weapon===2?.023:.036],.0055);
  link([.024,-.062,.075],[.025,-.043,.101],.008);link([.025,-.043,.101],[-.024,-.043,.101],.0075);link([-.024,-.043,.101],[-.024,-.048,.067],.0065);
  link([.038,-.111,.088],[.045,-.125,.130],.018);link([.045,-.125,.130],[.12,-.19,.32],.030,sleeves);
 }else{
  for(let i=0;i<4;i++){const y=-.063-i*.016;link([-.024,y,-.192],[-.024,y,-.163],.0065);link([-.024,y,-.163],[.023,y,-.163],.006);link([.023,y,-.163],[.023,y,-.194],.0055);}
  link([-.024,-.061,-.207],[-.024,-.047,-.226],.008);link([-.024,-.047,-.226],[.022,-.047,-.226],.0075);link([.022,-.047,-.226],[.022,-.053,-.197],.0065);
  link([-.034,-.106,-.174],[-.055,-.129,-.125],.018);link([-.055,-.129,-.125],[-.15,-.19,.13],.030,sleeves);
 }
 for(const [geos,material] of [[parts,glove],[sleeves,cloth]] as const){const geometry=mergeGeometries(geos);geos.forEach(g=>g.dispose());if(geometry)root.add(new THREE.Mesh(geometry,material));}
 root.userData.pose=side===1?(weapon===3?'556xi-grip':weapon===2?'smg12-grip':'mp5k-grip'):'mp5k-foregrip';return root;
}
function shotgunHand(side:number,weapon=1){
 const root=new THREE.Group(),parts:THREE.BufferGeometry[]=[],sleeves:THREE.BufferGeometry[]=[],origin=new THREE.Vector3(...(side===1?gripPose(weapon).right:gripPose(weapon).left));
 const glove=new THREE.MeshLambertMaterial({color:0x30392f}),cloth=new THREE.MeshLambertMaterial({color:0x526048});
 const link=(a:V3,b:V3,r:number,target=parts)=>{const shift=weapon===3?new THREE.Vector3(0,.010,-.010):weapon===2?new THREE.Vector3(0,.025,.113):new THREE.Vector3(),p=new THREE.Vector3(...a).add(shift),q=new THREE.Vector3(...b).add(shift),d=q.clone().sub(p),g=new THREE.CapsuleGeometry(r,d.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize()));g.translate(...p.add(q).multiplyScalar(.5).sub(origin).toArray());target.push(g.toNonIndexed());g.dispose();};
 const palm=new THREE.SphereGeometry(1,10,8);palm.scale(side===1?.008:.023,side===1?.027:.008,.033);parts.push(palm.toNonIndexed());palm.dispose();
 if(side===1){
  for(let i=0;i<3;i++){const z=.170+i*.018;link([.025,-.042,z],[.026,-.073,z],.0065);link([.026,-.073,z],[-.025,-.073,z],.006);link([-.025,-.073,z],[-.025,-.044,z],.0055);}
  link([.025,-.028,.166],[.025,-.049,.136],.006);link([.025,-.049,.136],[.007,-.052,.133],.0055);
  link([.025,-.028,.185],[.026,.014,.180],.008);link([.026,.014,.180],[-.025,.014,.180],.0075);link([-.025,.014,.180],[-.026,-.019,.171],.0065);
  link([.043,-.063,.230],[.070,-.090,.320],.018);link([.070,-.090,.320],[.15,-.20,.50],.030,sleeves);
 }else{
  for(let i=0;i<4;i++){const z=-.307+i*.018;link([-.034,-.027,z],[-.033,-.058,z],.0065);link([-.033,-.058,z],[.026,-.058,z],.006);link([.026,-.058,z],[.033,-.028,z],.0055);}
  link([-.035,-.039,-.255],[-.036,-.005,-.252],.008);link([-.036,-.005,-.252],[-.032,.013,-.270],.0065);
  link([-.027,-.064,-.250],[-.050,-.085,-.170],.018);link([-.050,-.085,-.170],[-.15,-.18,.03],.030,sleeves);
 }
 for(const [geos,material] of [[parts,glove],[sleeves,cloth]] as const){const geometry=mergeGeometries(geos);geos.forEach(g=>g.dispose());if(geometry)root.add(new THREE.Mesh(geometry,material));}
 root.userData.pose=side===1?'shotgun-stock-grip':weapon===3?'556xi-handguard':weapon===2?'smg12-shroud':'shotgun-pump';return root;
}
function sourceRifleHand(side:number){
 const root=new THREE.Group(),parts:THREE.BufferGeometry[]=[],sleeves:THREE.BufferGeometry[]=[],origin=new THREE.Vector3(...(side===1?gripPose(0).right:gripPose(0).left));
 const glove=new THREE.MeshLambertMaterial({color:0x30392f}),cloth=new THREE.MeshLambertMaterial({color:0x526048});
 const link=(a:V3,b:V3,r:number,target=parts)=>{const p=new THREE.Vector3(...a),q=new THREE.Vector3(...b),d=q.clone().sub(p),g=new THREE.CapsuleGeometry(r,d.length(),2,8);g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize()));g.translate(...p.add(q).multiplyScalar(.5).sub(origin).toArray());target.push(g.toNonIndexed());g.dispose();};
 const palm=new THREE.SphereGeometry(1,10,8);palm.scale(side===1?.008:.022,side===1?.023:.008,side===1?.022:.034);parts.push(palm.toNonIndexed());palm.dispose();
 if(side===1){
  // Finger fronts follow the supplied sloping grip, measured at each finger height.
  for(const [y,z] of [[-.026,.023],[-.043,.031],[-.058,.040]]){link([.022,y,.063],[.021,y,z],.0065);link([.021,y,z],[-.020,y,z],.006);link([-.020,y,z],[-.020,y,z+.022],.0055);}
  link([.022,-.013,.045],[.022,-.013,.017],.006);link([.022,-.013,.017],[.006,-.012,.001],.0055);
  link([.022,-.018,.074],[.023,-.006,.082],.008);link([.023,-.006,.082],[-.022,-.006,.083],.007);link([-.022,-.006,.083],[-.022,-.013,.051],.0065);
  link([.035,-.052,.092],[.052,-.078,.143],.018);link([.052,-.078,.143],[.127,-.160,.326],.030,sleeves);
 }else{
  for(let i=0;i<4;i++){const z=-.223+i*.018;link([-.029,.050,z],[-.028,.023,z],.0065);link([-.028,.023,z],[.023,.023,z],.006);link([.023,.023,z],[.028,.051,z],.0055);}
  link([-.027,.040,-.170],[-.031,.054,-.171],.008);link([-.031,.054,-.171],[-.031,.057,-.185],.0065);
  link([-.026,.009,-.170],[-.054,-.012,-.104],.018);link([-.054,-.012,-.104],[-.151,-.117,.110],.030,sleeves);
 }
 for(const [geos,material] of [[parts,glove],[sleeves,cloth]] as const){const geometry=mergeGeometries(geos);geos.forEach(g=>g.dispose());if(geometry)root.add(new THREE.Mesh(geometry,material));}
 root.userData.pose=side===1?'r4c-grip':'r4c-handguard';return root;
}
// The same vertex topology curls the support fingers around a magazine or
// extends the index toward a control. Wrist/sleeve vertices retain their junction.
function addReloadMorphs(model:THREE.Group,weapon:number){
 const mesh=model.children[0] as THREE.Mesh,base=mesh.geometry.getAttribute('position');
 const variants:THREE.BufferAttribute[]=[],normalVariants:THREE.BufferAttribute[]=[];
 for(const control of [false,true]){
  const parts:THREE.BufferGeometry[]=[],palm=new THREE.SphereGeometry(1,10,8);palm.scale(.009,weapon===1?.017:.031,weapon===1?.025:.022);parts.push(palm.toNonIndexed());palm.dispose();
  const link=(a:V3,b:V3,r:number)=>{const p=new THREE.Vector3(...a),q=new THREE.Vector3(...b),d=q.clone().sub(p),geo=new THREE.CapsuleGeometry(r,d.length(),2,8);geo.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize()));geo.translate(...p.add(q).multiplyScalar(.5).toArray());parts.push(geo.toNonIndexed());geo.dispose();};
  const halfWidth=[.014,.014,.010,.015,.014,.016][weapon],halfDepth=[.027,.027,.019,.038,.029,.024][weapon],right=2*halfWidth+.032;
  for(let i=0;i<4;i++){
   const y=.025-i*.017;
   if(weapon===1){const z=-.044+i*.014;link([0,0,z],[.010,-.020,z],.0065);link([.010,-.020,z],[.026,-.020,z],.006);link([.026,-.020,z],[.043,.012,z],.0055);}
   else if(control){const end=i===0?.052:.020;link([0,y,.002],[.015,y,-.016],.0065);link([.015,y,-.016],[end,y,-.013],.006);link([end,y,-.013],[end,y,0],.0055);}
   else {link([0,y,.004],[0,y,-halfDepth-.008],.0065);link([0,y,-halfDepth-.008],[right,y,-halfDepth-.008],.006);link([right,y,-halfDepth-.008],[right,y,.006],.0055);}
  }
  if(weapon===1){link([0,0,.020],[.010,-.040,-.023],.008);link([.010,-.040,-.023],[.038,.014,-.025],.0065);}
  else {link([0,.016,.019],[.005,.029,halfDepth+.008],.008);
  if(weapon===4){link([.005,.029,halfDepth+.008],[control?.021:right,.029,halfDepth+.008],.0075);link([control?.021:right,.029,halfDepth+.008],[control?.021:right,.024,.012],.0065);}
  else link([.005,.029,halfDepth+.008],[control?.021:right,.029,halfDepth+.008],.0065);}
  const merged=mergeGeometries(parts)!;parts.forEach(g=>g.dispose());const changed=merged.getAttribute('position'),positions=new Float32Array(base.array as ArrayLike<number>);positions.set(changed.array as ArrayLike<number>);variants.push(new THREE.BufferAttribute(positions,3));const normals=new Float32Array(mesh.geometry.getAttribute('normal').array as ArrayLike<number>);normals.set(merged.getAttribute('normal').array as ArrayLike<number>);normalVariants.push(new THREE.BufferAttribute(normals,3));merged.dispose();
 }
 mesh.geometry.morphAttributes.position=variants;mesh.geometry.morphAttributes.normal=normalVariants;mesh.updateMorphTargets();mesh.geometry.computeBoundingSphere();
}
export function supportHandMorph(hand:THREE.Group,magazine=0,control=0){const mesh=hand.children[0]?.children[0] as THREE.Mesh|undefined;if(mesh?.morphTargetInfluences){mesh.morphTargetInfluences[0]=magazine;mesh.morphTargetInfluences[1]=control;}}
export function handModel(side:number,weapon=0){
 const model=weapon===0?sourceRifleHand(side):weapon===2?(side===1?verticalGripHand(side,2):shotgunHand(side,2)):weapon===3?(side===1?verticalGripHand(side,3):shotgunHand(side,3)):weapon===1?shotgunHand(side):weapon===4?verticalGripHand(side):pistolHand(side);
 model.traverse(o=>{if(!(o instanceof THREE.Mesh)||!o.geometry.getAttribute('normal'))return;const normal=o.geometry.getAttribute('normal'),position=o.geometry.getAttribute('position'),colors=new Float32Array(position.count*3);for(let i=0;i<position.count;i++){const facing=Math.abs(normal.getX(i)),light=.80+.18*Math.max(0,normal.getY(i))+.04*facing;colors.set([light,light,light*.97],i*3);}o.geometry.setAttribute('color',new THREE.BufferAttribute(colors,3));(o.material as THREE.MeshLambertMaterial).vertexColors=true;});model.userData.handScale='receiver-space meters';if(side===-1)addReloadMorphs(model,weapon);return model;
}
const smooth=(t:number)=>{t=THREE.MathUtils.clamp(t,0,1);return t*t*(3-2*t);};
export function inspectionPose(weapon:number,remaining:number):{position:V3,rotation:V3}{
 if(remaining<=0)return {position:[0,0,0],rotation:[0,0,0]};
 const t=THREE.MathUtils.clamp(1-remaining/3.2,0,1),envelope=smooth(t/.12)*smooth((1-t)/.13);
 // Raise, hold left, pass across, hold right, then settle. No full spins.
 const yaw=t<.32?.82*smooth(t/.16):t<.68?THREE.MathUtils.lerp(.82,-.82,smooth((t-.32)/.36)):-.82;
 const pistol=weapon===5,depth=weapon===1?-.40:pistol?-.14:-.34;
 return {position:[(pistol?-.15:-.19)*envelope,.070*envelope,depth*envelope],rotation:[-.12*envelope,yaw*envelope,(pistol?.20:.14)*envelope]};
}

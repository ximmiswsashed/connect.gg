import * as THREE from 'three';
import {movementConfig as motion,type Stance} from './movement';
export const stanceValue=(s:Stance)=>s==='stand'?0:s==='crouch'?1:2;
export function posture(value:number){const crouch=Math.min(1,value),prone=Math.max(0,value-1),bodyY=THREE.MathUtils.lerp(1.08,.51,crouch)*(1-prone)+.30*prone,bodyScaleY=THREE.MathUtils.lerp(1,.78,crouch)*(1-prone)+prone,tilt=-prone*Math.PI/2;const height=Math.max(THREE.MathUtils.lerp(motion.stand.height,motion.crouch.height,crouch)*(1-prone)+motion.prone.height*prone,bodyY+Math.cos(tilt)*bodyScaleY*.705+Math.abs(Math.sin(tilt))*.27+.03);return {crouch,prone,bodyY,bodyScaleY,tilt,height,eye:THREE.MathUtils.lerp(motion.stand.eye,motion.crouch.eye,crouch)*(1-prone)+motion.prone.eye*prone};}
export function stride(state:string,stance:Stance){return stance==='prone'?.4:stance==='crouch'?.45:state==='slow'?.5:state==='sprint'?1.10:.85;}
// Contact phase and audible steps share actual traveled meters, never input-held time.
export function gaitPhase(distance:number,state:string,stance:Stance){return distance/stride(state,stance)*Math.PI;}

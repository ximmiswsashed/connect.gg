// Pixel coordinates traced from the three dated March 2020 plans in REFERENCE_CHECKLIST.md.
// Absolute scale and retained 4 m floor spacing are explicitly UNVERIFIED.
export const planScale=.075;
export const planX=(x:number)=>(x-420)*planScale;
export const planZ=(z:number)=>(z-300)*planScale;
export type Room={id:string,name:string,f:number,x0:number,x1:number,z0:number,z1:number,mat:string,y?:number};
const r=(id:string,name:string,f:number,a:number,b:number,c:number,d:number,mat='floor'):Room=>({id,name,f,x0:planX(a),z0:planZ(b),x1:planX(c),z1:planZ(d),mat});
export const rooms:Room[]=[
 r('small','Small Tower',0,34,289,159,454,'wood'),r('dining','Dining Hall',0,159,239,299,354,'wood'),r('showers','Showers',0,159,354,269,447,'concrete'),r('showerhall','Shower Corridor',0,269,354,299,447),r('showerhall','Shower Corridor',0,159,447,299,486,'wood'),
 r('kitchen','Kitchen',0,299,254,466,354),r('security','Security',0,299,354,433,403),r('hall','Main Hall',0,299,403,466,442,'wood'),r('white','White Stairs',0,299,442,423,486,'wood'),r('mainstairs','Main Stairs',0,602,393,615,508,'wood'),
 r('classroom','Classroom',0,466,393,522,508,'wood'),r('lobby','Lobby',0,522,393,615,508,'wood'),r('lobby','Lobby',0,466,354,615,393,'wood'),r('garage','Garage',0,615,349,703,473,'concrete'),
 r('meeting','Meeting Hall',0,466,184,615,354,'wood'),r('corridor','Kitchen Corridor',0,424,134,466,254),r('corridor','Kitchen Corridor',0,424,134,512,184),r('tower','Big Tower',0,424,89,620,134,'wood'),r('tower','Big Tower',0,512,34,620,89,'wood'),
 r('freezer','Freezer',-1,294,333,448,396,'concrete'),r('freezer','Freezer',-1,294,396,371,464,'concrete'),r('freezerstair','Freezer Stairs',-1,406,244,448,333,'concrete'),
 r('laundry','Laundry',-1,448,332,600,408,'concrete'),r('supply','Supply',-1,495,202,592,290,'concrete'),r('supply','Supply',-1,547,290,592,332,'concrete'),r('supplycloset','Supply Closet',-1,495,290,547,332,'concrete'),
 r('pillar','Basement Hall',-1,447,202,495,332,'concrete'),r('boiler','Boiler',-1,447,110,534,202,'metal'),r('boiler','Boiler',-1,534,110,592,160,'concrete'),r('electrical','Electrical Room',-1,534,160,592,202,'concrete'),r('blue','Blue Bunker',-1,592,110,674,202,'concrete'),r('bunker','Bunker',-1,592,202,664,300,'concrete'),r('back','Back Stairs',-1,491,27,549,110,'concrete'),r('laundrystairb','Laundry Stairs',-1,499,408,559,488,'concrete'),r('laundrylanding','Laundry Landing',-1,559,408,592,488,'concrete'),
 r('smallup','Small Tower',1,38,293,160,406,'wood'),r('smallup','Small Tower',1,160,293,231,406,'wood'),r('kids','Kids Dorms',1,309,257,455,352,'wood'),r('dorms','Dorm Main Hall',1,309,352,432,450,'wood'),r('whiteup','White Stairs',1,309,450,432,493,'wood'),
 r('trophy','Trophy',1,455,314,529,359,'wood'),r('dorms','Dorm Main Hall',1,432,359,529,389,'wood'),r('games','Game Room',1,432,389,529,450,'wood'),r('closet','Walk-in',1,480,450,529,493,'wood'),r('master','Master Bedroom',1,529,389,602,493,'wood'),r('master','Master Bedroom',1,529,359,602,389,'wood'),
 r('armoryhall','Armory Corridor',1,602,314,633,499,'wood'),r('armory','Armory',1,633,353,720,457,'wood'),r('attic','Attic',1,455,257,584,314,'wood'),r('atticnorth','Attic Connector',1,535,132,584,257,'wood'),r('towerup','Big Tower',1,469,89,640,132,'wood'),r('towerup','Big Tower',1,529,31,640,89,'wood'),r('towerthird','Big Tower · Third Floor',2,529,34,620,134,'wood')
];
export type Door={f:number,axis:'x'|'z',at:number,c:number,width:number,exterior?:boolean,window?:boolean,id:string,verified:string,y?:number};
const d=(id:string,f:number,axis:'x'|'z',at:number,c:number,width:number,exterior=false,window=false):Door=>({id,f,axis,at:axis==='x'?planX(at):planZ(at),c:axis==='x'?planZ(c):planX(c),width:width*planScale,exterior,window,verified:'2020 plan opening; height unverified'});
export const doors:Door[]=[
 d('small-dining',0,'x',159,312,18),d('small-ext',0,'x',34,417,20,true),d('dining-kitchen',0,'x',299,287,25),d('showers-white',0,'x',269,423,20),d('showers-small',0,'x',159,424,20),d('white-hall',0,'x',299,429,18),d('hall-showerhall',0,'x',299,474,18),d('white-showerhall',0,'z',447,284,18),d('showerhall-showers',0,'z',447,202,18),d('showerhall-small',0,'x',159,460,18),d('security-hall',0,'z',403,358,20),d('hall-lobby',0,'x',466,419,20),d('lobby-meeting',0,'z',354,546,20),d('lobby-classroom',0,'x',522,471,20),d('classroom-lobby',0,'z',393,492,20),d('entrance-ext',0,'z',508,563,22,true),d('garage-ext',0,'x',703,421,20,true),d('garage-lobby',0,'x',615,378,18),d('classroom-ext',0,'z',508,495,22,true,true),d('kitchen-corridor',0,'z',254,444,20),d('corridor-tower',0,'z',134,446,20),d('corridor-meeting',0,'x',466,198,20),d('tower-ext',0,'x',620,72,20,true),d('white-hall-stairs',0,'z',442,320,18),
 d('freezer-stairs',-1,'z',333,430,20),d('freezer-laundry',-1,'x',448,367,20),d('laundry-pillar',-1,'z',332,470,20),d('laundry-electrical',-1,'z',332,527,18),d('laundry-supply',-1,'z',332,570,20),d('laundry-stairs',-1,'z',408,529,20),d('supply-pillar',-1,'x',495,257,20),d('pillar-boiler',-1,'z',202,459,18),d('boiler-back',-1,'z',110,520,20),d('boiler-electrical',-1,'x',534,188,18),d('blue-construction',-1,'x',592,128,18),d('blue-bunker',-1,'z',202,618,20),d('blue-ext',-1,'x',674,154,22,true),d('electrical-supply',-1,'x',547,315,18),
 d('kids-dorms',1,'z',352,405,20),d('kids-ext',1,'z',257,410,20,true,true),d('dorms-game',1,'x',432,397,18),d('dorms-white',1,'z',450,389,20),d('hall-trophy',1,'z',359,496,18),d('games-south-window',1,'z',450,455,20,true,true),d('game-closet',1,'z',450,506,18),d('game-master',1,'x',529,420,20),d('master-closet',1,'x',529,476,18),d('master-ext',1,'z',493,565,20,true,true),d('attic-trophy',1,'z',314,509,18),d('armoryhall-armory',1,'x',633,400,20),d('armory-ext',1,'x',720,407,20,true,true),d('attic-connector',1,'z',257,560,20),d('attic-tower',1,'z',132,560,24),d('towerup-ext',1,'x',640,82,20,true,true),d('smallup-ext',1,'x',38,384,20,true,true),
 d('small-south-window',0,'z',454,80,20,true,true),d('showerhall-window',0,'z',486,230,22,true,true),d('kitchen-hall',0,'z',354,444,20),d('lobby-hall',0,'x',466,379,20),d('security-white',0,'x',299,375,18),d('classroom-entrance',0,'x',522,465,20),d('classroom-mainstairs',0,'x',602,470,18),
 d('corridor-ext',0,'x',424,225,18,true),d('tower-west-ext',0,'z',89,471,20,true),d('garage-north-window',0,'z',349,665,22,true,true),d('classroom-garage',0,'x',615,421,18),
 d('dorm-big-window',1,'x',309,387,24,true,true),d('white-stairs-south-window',1,'z',493,382,20,true,true),d('master-south-window',1,'z',493,540,18,true,true),d('armoryhall-south-window',1,'z',499,617,18,true,true),d('smallup-east-window',1,'x',231,350,18,true,true),d('towerup-north-window',1,'z',31,613,18,true,true),
 d('third-west-window',2,'x',529,64,18,true,true),d('third-east-window',2,'x',620,104,18,true,true)
];
export const stairs=[
 {x0:planX(406),x1:planX(448),z0:planZ(244),z1:planZ(333),lower:-1,axis:'z',reverse:true,name:'Freezer Stairs'},
 {x0:planX(499),x1:planX(559),z0:planZ(408),z1:planZ(488),lower:-1,axis:'z',reverse:false,name:'Laundry Stairs'},
 {x0:planX(491),x1:planX(549),z0:planZ(27),z1:planZ(110),lower:-1,axis:'z',reverse:true,name:'Back Stairs'},
 // White stair flight width is provisional; leave the plan's circulation strip clear.
 {x0:planX(330),x1:planX(410),z0:planZ(455),z1:planZ(480),lower:0,axis:'x',reverse:true,name:'White Stairs'},
 {x0:planX(535),x1:planX(570),z0:planZ(34),z1:planZ(134),lower:0,axis:'z',reverse:true,name:'Tower Stairs'},
 {x0:planX(602),x1:planX(615),z0:planZ(393),z1:planZ(499),lower:0,axis:'z',reverse:true,name:'Main Stairs'},
 {x0:planX(580),x1:planX(610),z0:planZ(34),z1:planZ(134),lower:1,axis:'z',reverse:false,name:'Tower Upper Stairs'},
 {x0:planX(65),x1:planX(104),z0:planZ(315),z1:planZ(454),lower:0,axis:'z',reverse:true,name:'Small Tower Stairs'}
];
const soft=(id:string,f:number,axis:'x'|'z',at:number,lo:number,hi:number)=>({id,f,axis,at:axis==='x'?planX(at):planZ(at),lo:axis==='x'?planZ(lo):planX(lo),hi:axis==='x'?planZ(hi):planX(hi),reinforce:true,reference:'yellow wall mark in dated 2020 plan; meter height and reinforcement slots unverified'});
export const softSurfaces=[soft('freezer-laundry',-1,'x',448,340,395),soft('pillar-boiler',-1,'z',202,463,491),soft('supply-boiler',-1,'z',202,500,584),soft('supply-bunker',-1,'x',592,253,287),soft('laundry-electrical',-1,'z',332,500,538),soft('laundry-supply',-1,'z',332,551,585),soft('construction-blue',-1,'x',592,164,197),soft('dining-small',0,'x',159,301,347),soft('kitchen-dining',0,'x',299,293,348),soft('kitchen-security',0,'z',354,310,426),soft('kitchen-meeting',0,'x',466,302,344),soft('showers-white',0,'x',269,363,411),soft('showers-small',0,'x',159,363,412),soft('lobby-meeting',0,'z',354,581,611),soft('entrance-classroom',0,'x',522,400,458),soft('garage-lobby',0,'z',473,622,694),soft('tower-corridor',0,'z',134,518,548),soft('kids-attic',1,'x',455,267,306),soft('attic-tower',1,'z',132,540,580),soft('trophy-attic',1,'z',314,513,580),soft('master-armory',1,'x',633,365,406),soft('walkin-game',1,'z',450,483,519),soft('dorms-game',1,'x',432,418,446)];
export const hatches=[{id:'security-freezer',f:0,x:planX(411),z:planZ(386)},{id:'meeting-electrical',f:0,x:planX(562),z:planZ(194)},{id:'lobby-storage',f:0,x:planX(559),z:planZ(435)},{id:'kids-kitchen',f:1,x:planX(325),z:planZ(309)},{id:'armory-garage',f:1,x:planX(686),z:planZ(430)}];
export const attackerSpawns=[{name:'Street',x:planX(440),z:planZ(645)},{name:'Junkyard',x:planX(-130),z:planZ(430)},{name:'Construction Site',x:planX(850),z:planZ(100)}];

// Room identity and world position are shared by chassis, markers, spotting and zones.
// Positions inferred from contemporary cutaways; metric calibration remains unverified.
export const bombLocations={
 laundry:{room:'laundry',floor:-1,x:planX(465),z:planZ(357),yaw:0},
 supply:{room:'supply',floor:-1,x:planX(560),z:planZ(250),yaw:Math.PI/2},
 kitchen:{room:'kitchen',floor:0,x:planX(375),z:planZ(323),yaw:0},
 dining:{room:'dining',floor:0,x:planX(252),z:planZ(316),yaw:Math.PI/2},
 meeting:{room:'meeting',floor:0,x:planX(558),z:planZ(274),yaw:0},
 kids:{room:'kids',floor:1,x:planX(371),z:planZ(301),yaw:0},
 dorms:{room:'games',floor:1,x:planX(454),z:planZ(438),yaw:Math.PI/2,zoneRooms:['dorms','games']}
};
// Eight evidenced locations. Exact mount height/orientation/FOV remains provisional.
export const securityCameras=[
 {name:'Armory Corridor',x:planX(619),y:7.45,z:planZ(326),yaw:Math.PI,pitch:-.25},
 {name:'Lobby',x:planX(599),y:3.45,z:planZ(364),yaw:Math.PI/2,pitch:-.25},
 {name:'Shower Corridor',x:planX(286),y:3.45,z:planZ(475),yaw:Math.PI/2,pitch:-.25},
 {name:'Meeting Rear',x:planX(474),y:3.45,z:planZ(190),yaw:Math.PI,pitch:-.25},
 {name:'Freezer',x:planX(300),y:-.55,z:planZ(347),yaw:-Math.PI/2,pitch:-.25},
 {name:'Junkyard',x:planX(148),y:3,z:planZ(502),yaw:0,pitch:-.25},
 {name:'Parking',x:planX(631),y:3,z:planZ(531),yaw:0,pitch:-.25},
 {name:'Construction Site',x:planX(751),y:3,z:planZ(73),yaw:Math.PI/2,pitch:-.25}
];

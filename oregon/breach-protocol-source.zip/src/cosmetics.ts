import {weaponCatalog} from './weapon-catalog';
import * as THREE from 'three';
import {sourceSkins} from './equipment';
import {skinPaint} from './r4c-model';
export const finishes=['Factory',...sourceSkins] as const;
export type Finish=typeof finishes[number];
export const availableSkins=(_weapon:number)=>['Factory',...sourceSkins];
export const validFinish=(v:unknown):Finish=>finishes.includes(v as Finish)?v as Finish:'Factory';
export function validateSkins(v:unknown){const out:Record<number,string>={};for(let i=0;i<weaponCatalog.length;i++){const value=v&&typeof v==='object'?(v as Record<number,unknown>)[i]:null;out[i]=availableSkins(i).includes(String(value))?String(value):i===0?sourceSkins[0]:'Factory';}return out;}
export function setCosmeticQuality(_q:string){}
const materials=new Map<string,THREE.Material>();
export function finishMaterial(_value:unknown,part:'weapon'|'attachment'|'accent'='weapon',_q='Medium'){if(validFinish(_value)!=='Factory')return skinPaint(_value);let m=materials.get(part);if(!m){m=new THREE.MeshLambertMaterial({color:part==='accent'?0x687073:0x354047});m.userData={shared:true,finish:'Factory',cosmeticPart:part};materials.set(part,m);}return m;}
export const firearmLengths=[.303,.88,.43,.76,.46,.24];
// One stable paint coordinate system per modeled object, rather than repeating box UVs.
export function paintUV(geometry:THREE.BufferGeometry,bounds?:THREE.Box3,offset=new THREE.Vector3()){
 geometry.computeBoundingBox();const box=bounds??geometry.boundingBox!,p=geometry.getAttribute('position'),uv=new Float32Array(p.count*2),width=Math.max(.01,box.max.z-box.min.z),height=Math.max(.01,box.max.y-box.min.y);
 for(let i=0;i<p.count;i++){uv[i*2]=(box.max.z-p.getZ(i)-offset.z)/width;uv[i*2+1]=(p.getY(i)+offset.y-box.min.y)/height;}geometry.setAttribute('uv',new THREE.BufferAttribute(uv,2));
}

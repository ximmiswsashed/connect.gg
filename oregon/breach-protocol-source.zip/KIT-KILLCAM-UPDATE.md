# Kit, personal killcam and action circle update

Implemented in the existing game sidebar. All six existing operators have their Ubisoft-listed primary, secondary and secondary-gadget choices. Added 12 guns (18 total), original procedural models and shared optic sockets. Existing zero-recoil policy retained. Weapon balance/model detail is prototype implementation, not a precise reproduction of every Siege statistic or animation.

Reload/plant/defuse/reinforce/barricade/revive actions use small SVG progress circles. Fully eliminated players receive a private recorded killer view, then live first-person teammate spectating. Personal playback does not stop the match. Press 2 to skip/cycle; V for cameras; 4 to deploy secondary gadget; 5 for charge detonation or camera EMP; F recovers eligible own gadgets. Primary gadgets remain on G.

Gadgets: breach charge, claymore, barbed wire, proximity alarm, deployable shield, frag, stun, impact EMP, smoke, bulletproof camera, nitro, impact grenade. Authoritative inventory/placement, walls/collision, blasts, LOS smoke, flash, enemy triggers, EMP disable, live cameras, recovery and melee are implemented and networked.

Validation: TypeScript and production build passed. Gameplay checks: 140 passing assertions including all 18 models, all 38 legal optic sockets, secondary fire/reload, each utility type, wire clock damage/melee, shield ray/collision/recovery, EMP and private replay. Three-client real relay check: 11 passing assertions, private victim-only replay, uninterrupted match/movement, real teammate jammer placement and nitro replication. Full imported map presentation: 8 assertions, 195 batches and 41,470 nav nodes retained; reload ring, automatic replay and live placement animation rendered without browser errors. Round selection/readiness/round-ending replay regressions retained; reports included alongside this file.

References (current Ubisoft operator listings):
- https://www.ubisoft.com/en-us/game/rainbow-six/siege/game-info/operators/ash
- https://www.ubisoft.com/en-us/game/rainbow-six/siege/game-info/operators/smoke
- https://www.ubisoft.com/en-us/game/rainbow-six/siege/game-info/operators/sledge
- https://www.ubisoft.com/en-us/game/rainbow-six/siege/game-info/operators/thermite
- https://www.ubisoft.com/en-us/game/rainbow-six/siege/game-info/operators/mute
- https://www.ubisoft.com/en-us/game/rainbow-six/siege/game-info/operators/vigil
- Reaper MK2: https://news.ubisoft.com/en-us/article/7argvNYn3AvUMW23nqkY1B/rainbow-six-siege-x-operation-high-stakes-operator-and-gadget-guide
- EMP 1.8m / 9 seconds: https://www.ubisoft.com/en-gb/game/rainbow-six/siege/news-updates/2vKaDckg5VPV1ViA4p8KM/y7s3-preseason-designers-notes
- Moving wire 5 HP/s: https://www.ubisoft.com/en-ca/game/rainbow-six/siege/news-updates/seasons/newblood
- Impact 40 damage / 2m: https://www.ubisoft.com/en-us/game/rainbow-six/siege/news-updates/2D4HsYOBEEg0wEW5dim34o/y9s13-designers-notes

Existing asset packs and optimized loading are reused unchanged. Website release uses equipment-v10 protocol; both players must refresh. No home relay restart, browser GPU flag changes, map pack or root website rewrite required.

# Breach Protocol — movement and aiming overhaul

Working code in the existing game, with zero aiming recoil and original visual weapon kick. Map geometry/assets, menu content, legal kit choices, four-letter lobbies and custom destruction rules are preserved. This is a verified consistency and presentation overhaul with a pinned reference; it is **not a measured perfect Siege replica**.

## Reference and evidence boundaries

The single footage target is **Siege X Y10S3.0 preview build 93555560**, Operation High Stakes, from [Beaulo’s creator recording](https://www.youtube.com/watch?v=4ONx3X6DgwE), published 17 August 2025. His description declares 1920×1080 output, **85° vertical FOV / 5:4 aspect**. The recording thanks Ubisoft for early access. Its preview status matters: this report makes no claim about the latest release build. Captured frames are at **854.322 and 859.322 seconds**. The comparison lab uses the same vertical FOV/aspect and stretches the 5:4 camera into 16:9 output to match the encoded video. Settings are creator-declared, not visible on a settings screen in these frames.

The usable pose is Reaper MK2 with a non-magnifying holographic sight. Housing and reticle designs differ from the game’s original NATO model. A manual estimate of the reference lens height is about **8% of image height, uncertainty ±1.5 percentage points**; it guides approximate framing, not an exact model calibration. Unknown-version historical screenshots are excluded. No controlled known-distance travel sequence, complete stance sequence, firing-rate sequence or matching screenshot for every gun/optic exists in this evidence set. Consequently, all timings/distances below are **measured old implementation versus candidate**, not measurements of Siege.

Published inherited rules inform the implementation: [Y9S1 ADS classes and precision behavior](https://www.ubisoft.com/en-us/game/rainbow-six/siege/news-updates/3jBlCdtRBQx2sCjmY2umNu/y9s1-designers-notes), [Y7S4 ADS movement and stance precision](https://www.ubisoft.com/en-us/game/rainbow-six/siege/news-updates/1ijmpKD6RrqMiD5VrEqt1i), and [Ubisoft’s FOV/sensitivity explanation](https://www.ubisoft.com/en-gb/game/rainbow-six/siege/news-updates/3IMlDGlaRFgdvQNq3BOSFv/guide-to-ads-sensitivity-in-y5s3). These older official rules are distinguished from measurements of the chosen preview recording. [Y10S3 notes](https://www.ubisoft.com/en-gb/game/rainbow-six/siege/news-updates/4czc3hlHtXrd27crELGDcc/y10s3-designers-notes) identify the seasonal context.

## Implemented corrections

- **Movement:** analytic acceleration/braking preserves momentum briefly on reversal instead of resetting velocity to zero. Diagonal movement stays normalized. Explicit state priority covers observation, vault, action, gadget, reload, rappel, sprint, slow walk and stance. Shared posture dimensions drive collision and camera height. Standing ADS uses a 2.34 m/s cap; hip movement uses provisional relative operator tiers. Interrupted actions clear their modifiers. Simulation updates are bounded to 1/120 s; higher render rates retain their smaller deltas.
- **Lean:** critically damped Q/E toggle response reverses continuously. A swept head volume prevents wall clipping while keeping the requested lean direction, so leaving a wall resumes the lean. Camera, body roll, head target and hitbox presentation share coordinates. Prone/ADS/stance transitions remain usable. Weapon rotation pivots around the optic line rather than shifting the lens off the aim ray. No artificial strafe impulse is added.
- **ADS:** world FOV, viewmodel FOV, receiver pose, angular optic magnification and mouse sensitivity are separate. Every legal pair has a profile record; most are mechanically derived from the original model, not individually reference-calibrated. The old 18° holographic viewmodel FOV made the housing enormous. The candidate uses a 64° viewmodel FOV and approximately 0.27 m eye relief for the original non-magnifying housing. Sights sit on rail sockets; G36C mounting height clears its modeled carry handle. Nominal 1× means no extra optical magnification; a separate 0.9 world-camera FOV factor supplies approximate ADS camera zoom. The 0.9 factor is an inherited tuning assumption, not newly established by these Y10S3 frames.
- **Optical math:** after that camera ADS zoom, magnifying optics use `2 atan(tan(verticalFOV/2)/2.5)`. A fixed target measures exactly 2.5× the projected height relative to 1× ADS. At base 85°, the world FOVs are 76.5° and 35.00373°. Reticles remain sampled only through the authored rear lens and use the camera-forward aiming ray. ADS sensitivity blends continuously from hip sensitivity rather than jumping when the input button changes.
- **Firing:** preserve cooldown remainder across updates; retain complete short trigger edges across network snapshots, ordered and deduplicated. Semi-auto stays semi-auto. Actual travel controls movement spread; ADS precision blends by class, with distinct shotgun pellets. Fully ADS non-pellet guns retain the requested exact zero aim recoil/spread. Visual shot kick moves the weapon and mounted optic together; camera pitch/yaw and ballistics stay unchanged. Muzzle obstruction uses the same physical barrel location as the rendered firearm. Flash visibility follows actual shot age, preventing a false flash at initial equip.
- **Animation/presentation:** one priority order prevents inspection or decorative sway from overriding reload, handling, ADS, vault and device actions. Switching has a separate timer and reversible ADS transition. Original sleeves/hands retain grip targets; the L85 reload hand now meets its rear bullpup magazine. Stale parent matrices no longer cause remote hand/head jitter. Lean, ADS, eye height and stance interpolate together over the existing network snapshots. Recorded shot age and switch state reproduce kick/handling in replay. Replay projection now agrees with the separate live viewmodel camera.

## Timed travel and stopping: saved original versus candidate

10 m horizontal distance on the same flat calibration range, from rest, held inputs; operator Ash. Stop distance is measured after releasing input for one second. Four actual simulation deltas: 30 / 60 / 144 / 240 Hz. These are controlled update rates, **not hardware FPS measurements**. The before column uses 30 Hz; the after column spans all four rates. Hip changes largely reflect the provisional operator tier, not a claim of reference-measured speed.

| Mode | Before 10 m (s) | After 10 m range (s) | Before stopping (m) | After stopping range (m) |
|---|---:|---:|---:|---:|
| walk | 2.9578 | 2.8178–2.8178 | 0.0340 | 0.0357–0.0357 |
| sprint | 1.7711 | 1.6875–1.6875 | 0.0570 | 0.0598–0.0599 |
| slow | 7.4241 | 7.0713–7.0713 | 0.0135 | 0.0142–0.0142 |
| crouch | 5.4221 | 5.1647–5.1647 | 0.0185 | 0.0194–0.0194 |
| prone | 11.7814 | 11.2211–11.2211 | 0.0085 | 0.0089–0.0089 |
| strafe | 2.9578 | 2.8178–2.8178 | 0.0340 | 0.0357–0.0357 |
| diagonal | 2.9578 | 2.8178–2.8178 | 0.0340 | 0.0357–0.0357 |
| ADS | 4.2902 | 4.2902–4.2902 | 0.0234 | 0.0234–0.0234 |
| slowADS | 7.4241 | 7.4241–7.4241 | 0.0135 | 0.0135–0.0135 |

Every candidate mode varies by less than 2 ms over 10 m and less than 2 mm stopping distance across these rates. Reversal now brakes through the previous direction instead of erasing velocity immediately. Stance defaults retain prototype heights/eyes: standing **1.82/1.68 m**, crouched **1.12/1.04 m**, prone **0.60/0.43 m**. The existing exponential stance blend and distance-driven footstep/gait system are retained; exact Siege eye heights, transition duration, cadence and sound matching remain unmeasured.

## Firing comparison

Shots during two seconds of held automatic fire, same existing configured weapon rates:

| Weapon / implementation | 30 Hz | 60 Hz | 144 Hz | 240 Hz |
|---|---:|---:|---:|---:|
| R4-C before | 20 | 24 | 27 | 29 |
| R4-C after | 29 | 29 | 29 | 29 |
| SMG-12 before | 30 | 40 | 42 | 40 |
| SMG-12 after | 43 | 43 | 43 | 43 |

The correction verifies configured cadence, not footage-measured gun RPM. Rifle ADS rounds follow the aiming ray with exact zero pitch/yaw recoil. Hip spread recovers with elapsed time; pellets remain distinct. A hard-cover test with a clear eye line but blocked physical barrel causes no target damage. Rendered and logical muzzle positions agree at both lean extremes and neutral.

## Shooter/opponent and terrain checks

Two real Game/World/Lobby/NetworkSession clients connect through the **local development four-letter WebSocket relay**, host at 30 Hz and guest at 240 Hz. Both quick-peek directions expose the same head/eye to shooter and opponent around a pillar; authority-to-remote eye error is **1.384 mm left / 1.636 mm right** in the sampled settled poses. The head hit volume contains the authoritative eye. This is a geometric and replication check, not a human reaction-time or latency claim. Delayed/duplicate lean commands and short pistol trigger edges do not double-toggle or double-fire. The remote client sees all 29 authoritative R4-C rounds.

The visual head hit volume contains the eye in all nine standing/crouched/prone × left/neutral/right combinations. Real movement clears an 8 cm threshold, three 18 cm stairs, a sloped ramp and a 70 cm doorway. A low ceiling permits crouching and refuses standing. A thin solid wall still blocks movement. These fixtures supplement, rather than exhaustively certify, all Oregon terrain.

Live/replay projected weapon points agree within floating-point noise across 18 ADS/lean/shot-age combinations. Repeated reload cancellation, switching and lean/ADS interruption return neutral responsive controls at all four rates. Full-map tests verify legal kit selection, circular reload progress, automatic personal killcam, live teammate spectating and real jammer placement. Two-player round checks verify aftermath movement, the full three-second replay delay, next-round selection and readiness countdown.

## Performance and preservation

Controlled CPU-only walking/leaning/firing simulation on the actual imported map, alternating original/candidate and excluding the first warm-up pass: at 240 Hz, both consume about **53 ms total CPU over two simulated seconds**. At 60 Hz, candidate total is about **27 ms versus 14 ms** because it adds internal substeps. Candidate p95 update cost is approximately **0.2 ms at 240 Hz / 0.3–0.4 ms at 60 Hz** in this fixture. Rendering, bots, GPU performance and end-to-end device FPS are outside this profile. The existing 240 FPS option and GPU launcher are preserved.

Hash comparison covers **31,028 existing files**. No map assets changed or files disappeared. Map/menu/loadout/lobby source hashes are unchanged. The map still has **195 render batches, 481 collision sectors, 41,470 navigation nodes**. Custom destruction regression checks pass unchanged. Only the motion/firing/presentation/replication paths plus physical optic/hand mounting were edited. Existing multiplayer architecture, relay service and selection flows remain in place. Protocol compatibility suffix is `motion-v11`: both players should refresh together after deployment.

## Verification artifacts

| Result file | Passing assertions |
|---|---:|
| Clearance-Firearm-Checks.json | 12 |
| Connected-Motion-Checks.json | 13 |
| full-map.json | 8 |
| kit-network.json | 11 |
| Kit-Regression.json | 158 |
| Map-Motion-Profile.json | 1 |
| Measurements.json | 254 |
| Presentation-Checks.json | 6 |
| round-flow.json | 19 |
| round-network.json | 8 |

TypeScript and production build pass. CLI custom-destruction tests: 7 pass. Four-letter lobby service checks: 113 pass, including 100 ordered messages and 24 parallel rooms. An obsolete v8 fixture initially timed out because it omitted the already-added location-selection stage; the current deployment-v9 fixtures pass. That failure required no production change.

Open `verification/motion-v11/review.html` through the local dev server for the live side-by-side lab: recorded frame, candidate first-person, saved original, and actual opponent head/torso volumes. Controls cover stance, both leans, hip/ADS, optics, walking/stopping, single fire, sustained fire and reload interruption. Other fixtures reproduce the numeric comparisons. JSON results and screenshots sit beside this report. `Comparison.html` is the offline visual/table report.

## Remaining approximations

Exact Siege travel-time calibration, acceleration curves, operator multipliers, eye heights, lean translation/rotation/timing, stance timing, animation grip shape, ADS exit timing, bob/sound cadence and most weapon-specific optic eye relief remain unmeasured. The current 0.48 m lateral lean, 0.20 rad camera roll, response 24, 12-rate stance damping and relative operator factors are prototype/approximate tuning values, explicitly not asserted as exact Siege values. ADS entry classes use published older values; the original animations do not reproduce proprietary rigs or assets. All legal optic pairs are structurally tested, but **only one approximate Reaper/holographic pose has a matched-FOV/aspect footage comparison**. Right lean, crouch/prone and magnified screenshots compare our saved original to candidate; the displayed recorded frame is a reference anchor, not a matched shot for those states. A public production multiplayer smoke test is reported separately after deployment. Further exact matching requires controlled reference capture with known distances and settings for the chosen build.

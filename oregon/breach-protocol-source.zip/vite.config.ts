import {defineConfig} from 'vite';
import {readdirSync,readFileSync,cpSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
// @ts-ignore Node-only service; browser runtime imports no server dependencies.
import {attachLobbyServer} from './tools/lobby-server.mjs';
export default defineConfig(({command,mode})=>{
 const comparison=command==='serve'||mode==='comparison';let output='';
 return {define:{__MAP_COMPARISON__:JSON.stringify(comparison)},publicDir:comparison?'public':false,
 plugins:[{name:'friends-lobbies',configureServer(server){if(server.httpServer)attachLobbyServer(server.httpServer);}},...(comparison?[]:[{name:'rebuilt-map-assets',configResolved(config){output=config.build.outDir;},closeBundle(){
  const copy=(from:string,to:string)=>{mkdirSync(resolve(to,'..'),{recursive:true});cpSync(from,to,{recursive:true});};
  for(const name of readdirSync('public'))if(name!=='assets')copy(resolve('public',name),resolve(output,name));
  for(const name of readdirSync('public/assets'))if(name!=='oregon')copy(resolve('public/assets',name),resolve(output,'assets',name));
  const base='public/assets/oregon/scratch',files=new Set(['manifest.json','palette.json','logical-sources.json','navigation-candidate.json.gz','collision/manifest.json']);
  const manifest=JSON.parse(readFileSync(resolve(base,'manifest.json'),'utf8')),palette=JSON.parse(readFileSync(resolve(base,'palette.json'),'utf8')),collision=JSON.parse(readFileSync(resolve(base,'collision/manifest.json'),'utf8'));
  for(const entry of manifest.entries)files.add(entry.file);
  for(const page of palette.pages){if(!page.startsWith('scratch/'))throw Error('Rebuilt palette references old map');files.add(page.slice(8));}
  for(const sector of collision.sectors){files.add('collision/'+sector.file);files.add('collision/'+sector.metadata);}
  for(const file of files){if(file.includes('..')||file.startsWith('/'))throw Error('Invalid rebuilt asset path');copy(resolve(base,file),resolve(output,'assets/oregon/scratch',file));}
 }}])],server:{watch:{ignored:['**/verification/**','**/dist*/**','**/work/**']}},build:{target:'es2022',rollupOptions:{input:Object.fromEntries(readdirSync('.').filter(p=>p.endsWith('.html')).map(p=>[p.replace('.html',''),resolve(p)]))}}};
});

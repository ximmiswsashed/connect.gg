# Round flow and menu update

- Keep survivor movement for three seconds after final kill; then replay.
- Home: Play, Host Lobby, Join Lobby, Match options; remove operator and loadout preview; clean footer; update Oregon image.
- Every round: side-appropriate operator and kit, confirmation, friendly lineup / concealed enemy operators, three-second countdown after everyone confirms.
- Reticle color picker and opacity, saved locally and applied in replay.
- Compact Escape settings over live gameplay; preserve fullscreen through supported Keyboard Lock API, with browser safety escape intact.
- Verify production classes and rendered UI, then publish to the existing connect.gg sidebar integration.

Preserve the working D3D11 website launcher and 240 FPS cap. User confirmed the launcher runs the website at 240 FPS.

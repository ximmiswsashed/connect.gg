# Breach Protocol interface

The user chose current Siege X on October 21, 2026. This supersedes the older equipment-console sidebar composition. Preserve the all-dark preference, actual game features and existing connect.gg sidebar embed.

## Composition

Use Ubisoft's roadmap New Menu UI image, `Menus-HUB-Main-S2_THUMBNAIL.jpg`, as the composition reference: compact top navigation, red selected-tab underline, actual central operator model, left play/friends controls and a right map panel. Keep the Breach Protocol title. Do not invent a shop, progression rewards or matchmaking service. Operators use official clickable badges and expose legal kits. Selection confirmation remains visible above the roster. Narrow screens stack the two useful control panels; the background preview recedes.

## Palette

- Background `#10151e`, operator stage `#151c29`, navigation `#090d14`.
- Control panels `#141d2b`, equipment panels `#192332`.
- Text `#edf2f7`, secondary text `#c1cad6`, separators `#536071`.
- Selected tab `#f24b45`; filled primary action `#d13a35` with white text; hover `#ba3631`.
- Focus `#b5e5ff`; selected controls `#26384c` and `#78a9db`.
- Attack/defense keep blue/orange role colors. In-game HUD colors remain distinct from menu chrome.

## Type and controls

Self-hosted Barlow for readable controls, Barlow Condensed for navigation, headings and primary actions. Menu body 14–16px, secondary 12–13px, navigation 18–20px, headings 24–56px. Preserve existing in-game HUD size steps. Square tactical navigation and side panels follow the pinned reference. Native selects, checkboxes and sliders remain keyboard-accessible. Theme focus outlines and text selection.

## Motion and performance

Render the central operator only when kit, page or viewport changes. Cache skin materials. Keep persistent result nodes and fixed-capacity tracer/impact pools. Preserve the 240 FPS setting and dynamic resolution. Installation animation is cosmetic; host completion/cancellation owns the actual surface change.

## Verification and provenance

See `SIEGE-X-UPDATE.md` and delivery reports for finite gameplay checks and reference limits. Badge PNGs come from Ubisoft's six operator pages. The central character is the existing game's model. The detector's legacy palette/type advisories are superseded by this deliberate reference-driven redesign. Its accent-border warning does not apply to the square navigation tabs.

# Active work: loading, deployment selection and defuser

The original request is to optimize Breach Protocol loading on the existing connect.gg website. Added while work was active: each attacker chooses Street, Junkyard or Construction Site before operator selection; defenders choose the Oregon bomb site (B, 1F, 2F), using current/relevant Siege references; dropped defuser can be picked up and displays a yellow briefcase instead of a text marker.

## Loading findings and implementation in progress

- Existing website downloads 69,208,537 bytes in 19 map packs before the menu appears. 195 GPU batches and 481 collision sectors are constructed; 41,470 navigation nodes remain after safety validation.
- Preserved baseline sources in project verification/startup-profile/baseline-*.ts. Baseline first run 6031ms (includes public pack transport with local textures); warm baseline 2020ms and 2102ms. First optimized warm setup 2033ms; do not claim a large CPU improvement from that alone.
- Already edited src/map-batches.ts to remove per-vertex TypedArray.slice allocations. src/imported-oregon.ts overlaps visual and collision loading. src/native-map.ts prefetches navigation concurrently, with validation still after collision is ready. tsc passes.
- work/build-fast-asset-packs.py generated transport v2 artifacts in outputs/Breach-Protocol-Loading/website-patch/oregon. All 1,093 underlying assets are byte-identical. JSON metadata compression reduces total payload to 64,527,425 bytes (4,681,112 bytes / 6.76% less). Nine changed data packs plus metadata require about 29.2 MB of new uploads; old packs remain for old clients. New manifest asset-packs-v2-3ee91086fd91.json; metadata packs/map-metadata-0e0067669b8c.json.gz.
- Still implement v2 loader with bounded background prefetch and persistent CacheStorage for content-addressed packs; retain ordinary fetch fallback if storage unavailable. Use a distinct loader + manifest filename, preserving old clients.
- Planned important improvement: initialize main menu and operator/loadout controls while nativeMap loads into an existing World(false). Prevent confirming/deploying/connecting until ready; preserve user input on the ready re-render. Expose window.breach instrumentation only after readiness so old fixtures remain correct. NativeMap accepts optional existing World; initialize plan/spawn metadata synchronously. Do not allow physics or network round start with partial collision. Keep 240 FPS launcher.

## Deployment plan

- Add a location stage to Lobby.selection before operators. Attackers pick independent Member.spawn. Defenders vote for one shared site; deterministic majority, host then stable order for ties. Confirm locations then operators, preserve ready countdown and side swaps every round. Validate choices at host; gate joining/start until map ready.
- NetworkSession resetRemoteRound must use each member's spawn for position AND drone. Active-round onReady must apply selected site and host spawn before game.begin. Include spawn in actor snapshots. Bump lobby protocol compatibility suffix from round-flow-v8 to deployment-v9.
- Existing importedSpawns already name Street (40,29), Junkyard (-44,4), Construction Site (51,-29). Existing site pairs are Laundry/Supply, Kitchen/Dining, Meeting/Kitchen, Kids/Dorms. ImportedBombs holds points in corresponding rooms. Use side-specific location UI before roster.
- Defuser currently picks up with F only during action. Review prep and network pickup, dropped marker and HUD text. Add SVG yellow briefcase, accessible label, retain attacker-only dropped marker rule.

## References read

- Current Ubisoft Oregon page: https://www.ubisoft.com/en-us/game/rainbow-six/siege/game-info/maps/oregon/1000 (March 2026 modernization, blueprint download).
- Ubisoft 2015 launch guide confirms the THREE spawn names; its old Red Stage/Watch Tower bomb site is outdated and MUST NOT be used for current sites.
- Firsthand current in-game screenshots: https://www.r6prep.com/defender/site-setups/oregon (reviewed May 2026, Y11S3): B Laundry Room/Supply Room; 1F Kitchen/Dining Hall; 1F Meeting Hall/Kitchen; 2F Kids' Dorms/Dorms Main Hall.

## Current delivery base

Repo ximmiswsashed/connect.gg, latest merged PR5 commit f9353c10e1d52cff6948530b8372678124814993. Public relay https://mhm.tail8dfc7f.ts.net/breach/health is online. Never relaunch service through a workaround; user manually restarted it. Vite local port5263 is running. CUA publicHostCheck tab6 is live website, startupProfileTab tab11 is benchmark.

Do not spawn agents (not authorized). Use authenticated GitHub connector blobs/tree/commit/PR/merge, attach PR. Package scripts from previous work are work/package-round-flow.py and work/verify-guest-transition-publication.py; adapt to this update rather than overwrite old reports. Source project at C:/Users/cruzi/Documents/Codex/2026-10-02/files-pasted-by-the-user-build/outputs/oregon-tactical.
